# -*- coding: utf-8 -*-
"""Terminist 更新日志工具。

用法（在 Terminist 根目录跑）：
    python tools/changelog.py list            看所有版本存档和日志条目
    python tools/changelog.py show v045       看某个版本的完整需求原文
    python tools/changelog.py add v050 "标题"  往 CHANGELOG.md 头部追加一份骨架
    python tools/changelog.py sync            找出有存档但日志里没有的版本，列出待补
    python tools/changelog.py path           打印 CHANGELOG.md 路径

`add` 只会往 `## vXXX` 之前插入骨架，不会破坏已有内容。
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VERSIONS = ROOT / "versions"
CHANGELOG = ROOT / "CHANGELOG.md"

SKELETON = """## {ver}  （日期待填）— {title}

**为什么**：

**改了什么**：

**验**：

---

"""


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def _metas() -> list[dict]:
    """返回全部版本存档的元信息，按版本号升序。"""
    out: list[dict] = []
    if not VERSIONS.exists():
        return out
    for d in VERSIONS.iterdir():
        if not d.is_dir():
            continue
        meta = d / "meta.json"
        info = {"dir": d.name, "time": "", "status": "", "label": ""}
        if meta.exists():
            try:
                m = json.loads(meta.read_text(encoding="utf-8"))
                info["time"] = str(m.get("time", ""))
                info["status"] = str(m.get("status", ""))
                info["label"] = str(m.get("label", ""))
            except Exception:
                pass
        out.append(info)
    out.sort(key=lambda x: x["dir"])
    return out


def _short_dir(dirname: str) -> str:
    """v045_20261030-110430 -> v045"""
    return dirname.split("_", 1)[0]


def cmd_list() -> int:
    metas = _metas()
    log = _read(CHANGELOG) if CHANGELOG.exists() else ""
    for m in metas:
        ver = _short_dir(m["dir"])
        logged = "有" if re.search(rf"^##\s*{re.escape(ver)}\b", log, re.M) else "—"
        title = re.sub(r"\s+", " ", m["label"]).strip()[:60]
        print(f"{ver}  {m['time']}  [{m['status']}]  日志:{logged}  {title}")
    print(f"\n共 {len(metas)} 个存档")
    return 0


def cmd_show() -> int:
    if len(sys.argv) < 3:
        print("用法: changelog.py show v045")
        return 2
    want = sys.argv[2]
    for m in _metas():
        if _short_dir(m["dir"]) == want:
            print(f"=== {m['dir']} | {m['time']} | {m['status']}")
            print(m["label"])
            return 0
    print(f"没有找到版本 {want}")
    return 1


def cmd_add() -> int:
    if len(sys.argv) < 3:
        print('用法: changelog.py add v050 "标题"')
        return 2
    ver = sys.argv[2]
    title = sys.argv[3] if len(sys.argv) > 3 else "待补"
    if not CHANGELOG.exists():
        _write(CHANGELOG, "# Terminist 更新日志\n\n---\n\n")
    text = _read(CHANGELOG)
    if re.search(rf"^##\s*{re.escape(ver)}\b", text, re.M):
        print(f"{ver} 已经记过了，没动。")
        return 1
    block = SKELETON.format(ver=ver, title=title)
    # 插在第一个 ## 之前，也就是最新版本的位置
    m = re.search(r"^##\s", text, re.M)
    if m:
        text = text[: m.start()] + block + text[m.start() :]
    else:
        text = text.rstrip() + "\n\n" + block
    _write(CHANGELOG, text)
    print(f"已往 CHANGELOG.md 追加 {ver} 骨架，去把「为什么 / 改了什么 / 验」写全。")
    return 0


def cmd_sync() -> int:
    log = _read(CHANGELOG) if CHANGELOG.exists() else ""
    missing = [
        _short_dir(m["dir"])
        for m in _metas()
        if not re.search(rf"^##\s*{re.escape(_short_dir(m['dir']))}\b", log, re.M)
    ]
    if not missing:
        print("所有存档都写过日志了。")
        return 0
    print("这些版本有存档但日志里没有：")
    for v in missing:
        print("  " + v)
    print("\n补骨架: python tools/changelog.py add <版本> \"标题\"")
    return 0


def cmd_path() -> int:
    print(CHANGELOG)
    return 0


COMMANDS = {
    "list": cmd_list,
    "show": cmd_show,
    "add": cmd_add,
    "sync": cmd_sync,
    "path": cmd_path,
}


def main() -> int:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print(__doc__)
        return 2
    return COMMANDS[sys.argv[1]]()


if __name__ == "__main__":
    sys.exit(main())
