"""
root 库：Terminist 的最高权限层。能改受保护的内容（base、lib_b、run.py、lib_a/config.py…）和 B库，
但每一次都走同一套关卡，任何一关不过都不改：

  1. 试验田：要改的内容先完整写进 ~/.terminist/root_trial/<编号>/（正式文件一个字都不动）
  2. 锦衣卫（jinyiwei.py）：独立进程里的 AI，没有任何提示词，只看「文字总结」和「试验田里的真实改动」
     是否一致，回答 是 / 否；同时核查更改者来源（是不是正在运行的 Terminist、是不是 A库 从 root_change 工具发起的）
     和 root 库自己有没有被动过（封印）
  3. 确认弹窗（dialog.py）：独立进程，给用户看文字总结、来源、锦衣卫结论和真实改动，等 3 秒才能点确认；
     弹窗开着时屏幕操作工具一律拒绝，AI 不能自己点
  4. 应用：再核对一次试验田和正式文件都没在中途被换掉，备份原文件到 ~/.terminist/root_backups/<编号>/，再写入
  每次请求都记进 ~/.terminist/root_audit.jsonl。
锦衣卫同时做风控：把每次改动往最坏的企图去想，给风险评级，弹窗里给用户看。

工作流删文件也先过锦衣卫（review_delete，base/guard.py 调）：风险「低」且没碰硬底线就直接删（进回收站），
否则弹窗让用户确认，并附上锦衣卫的原因。

root 库自己（这个文件夹）不归任何人改：受保护（A库、B库 的工具都写不进来）、不进存档 / 回滚 / B库 的临时副本，
锦衣卫每次核对封印，root 文件和封印对不上就一律拒绝。重新封印只能在终端里由人手动运行 python root/seal.py。
"""

import inspect
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from . import common as c

GUARD_TIMEOUT = 300
DIALOG_TIMEOUT = 900


def _python(gui: bool = False) -> str:
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    return str(exe.with_name("pythonw.exe") if gui and exe.with_name("pythonw.exe").is_file() else exe)


def _run(script: str, trial: Path, timeout: int, gui: bool = False, args: tuple = (),
         stdin: str | None = None) -> subprocess.CompletedProcess:
    """独立进程运行 root 里的脚本：-I（不读环境变量、用户包和当前目录），工作目录在试验田，不继承 Terminist 的任何状态。"""
    env = {k: v for k, v in os.environ.items() if k.upper() in ("SYSTEMROOT", "USERPROFILE", "HOMEDRIVE", "HOMEPATH",
                                                                "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "PATH",
                                                                "DEEPSEEK_API_KEY", "COMPUTERNAME", "USERNAME")}
    env["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run([_python(gui), "-I", str(c.ROOT_DIR / script), *args, str(trial)], cwd=str(trial), env=env,
                          input=stdin, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
                          creationflags=0x08000000 if sys.platform == "win32" else 0)


def _origin(agent, entry_file: str) -> dict:
    return {"who": "A库" if getattr(agent, "role", "") in c.ALLOWED_ROLES else str(getattr(agent, "role", "?")),
            "role": getattr(agent, "role", None), "model": getattr(agent, "model", None),
            "pid": os.getpid(), "script": str(Path(sys.argv[0]).resolve()) if sys.argv and sys.argv[0] else "",
            "entry": entry_file}


def work_context(agent) -> dict:
    """给锦衣卫的工作信息（Terminist 自己报的，锦衣卫会当成可能不可信的一方的说法）：
    这一轮的任务、最近的动作、这次会话里 Agent 自己写过 / 建过的文件。"""
    if agent is None:
        return {}
    msgs = getattr(agent, "messages", []) or []
    task = next((m.get("content") for m in reversed(msgs) if m.get("role") == "user"
                 and isinstance(m.get("content"), str) and not str(m.get("content")).startswith("[")), "")
    written = []
    for m in msgs[-300:]:
        for tc in m.get("tool_calls") or []:
            fn = tc.get("function") or {}
            if fn.get("name") in ("write_file", "edit_file", "desktop_write", "desktop_edit", "move_file", "run_command"):
                try:
                    a = json.loads(fn.get("arguments") or "{}", strict=False)
                except ValueError:
                    a = {}
                what = a.get("path") or a.get("dst") or a.get("command") or ""
                written.append(f"{fn['name']} {str(what)[:120]}")
    ws = getattr(agent, "ws", None)
    return {"task": str(task)[:1500], "workspace": str(ws.root) if ws is not None else "（没打开文件夹）",
            "recent_actions": list(getattr(agent, "live_lines", []) or [])[-8:],
            "files_touched_this_session": written[-40:]}


def review_delete(items: list[str], reason: str, context: dict | None = None, role: str = "?") -> dict:
    """工作流要删东西：先让锦衣卫审。返回 {auto, risk, why}；锦衣卫出任何问题都按「要问用户」处理。"""
    caller = inspect.stack()[1].filename
    try:
        entry = Path(caller).resolve().relative_to(c.APP_ROOT).as_posix()
    except ValueError:
        entry = caller
    rid = "del-" + time.strftime("%Y%m%d-%H%M%S") + f"-{time.time_ns() % 100000}"
    trial = c.TRIAL_DIR / rid
    req = {"id": rid, "kind": "delete", "items": [str(i) for i in items], "reason": reason, "context": context or {},
           "origin": {"who": role, "role": role, "model": None, "pid": os.getpid(),
                      "script": str(Path(sys.argv[0]).resolve()) if sys.argv and sys.argv[0] else "", "entry": entry},
           "created": time.strftime("%Y-%m-%d %H:%M:%S")}
    try:
        trial.mkdir(parents=True)
        (trial / "request.json").write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
        out = _run("jinyiwei.py", trial, GUARD_TIMEOUT, args=("--delete",))
        v = json.loads(out.stdout.strip().splitlines()[-1])
    except Exception as e:
        v = {"auto": False, "risk": "未知", "why": f"锦衣卫没给出结论（{type(e).__name__}: {e}），交给你决定"}
    finally:
        shutil.rmtree(trial, ignore_errors=True)
    c.audit({"id": rid, "time": req["created"], "kind": "delete", "items": req["items"][:50], "reason": reason,
             "risk": v.get("risk"), "auto": bool(v.get("auto")), "why": v.get("why", "")[:1000]})
    return {"auto": bool(v.get("auto")), "risk": str(v.get("risk", "未知")), "why": str(v.get("why", ""))}


def _build_trial(rid: str, summary: str, reason: str, changes: list, origin: dict) -> tuple[Path, dict]:
    """把要改的内容写进试验田。edit 依次作用在（试验田里的）最新内容上。"""
    trial = c.TRIAL_DIR / rid
    (trial / "files").mkdir(parents=True)
    ops: dict[str, dict] = {}
    current: dict[str, bytes | None] = {}
    for i, ch in enumerate(changes, 1):
        if not isinstance(ch, dict):
            raise ValueError(f"第 {i} 项改动格式不对")
        if err := c.target_error(ch.get("path", "")):
            raise ValueError(f"第 {i} 项：{err}")
        rel = c.norm_rel(ch["path"])
        action = str(ch.get("action") or "").lower()
        if rel not in current:
            current[rel] = c.read_live(rel)
        if action == "write":
            current[rel] = str(ch.get("content", "")).encode("utf-8")
        elif action == "edit":
            if current[rel] is None:
                raise ValueError(f"第 {i} 项：{rel} 不存在，不能 edit（新建用 write）")
            text = current[rel].decode("utf-8")
            old, new = str(ch.get("old_str", "")), str(ch.get("new_str", ""))
            n = text.count(old) if old else 0
            if n != 1:
                raise ValueError(f"第 {i} 项：old_str 在 {rel} 里出现了 {n} 次（必须正好 1 次）")
            current[rel] = text.replace(old, new, 1).encode("utf-8")
        elif action == "delete":
            if current[rel] is None:
                raise ValueError(f"第 {i} 项：{rel} 本来就不存在")
            current[rel] = None
        else:
            raise ValueError(f"第 {i} 项：action 只能是 write / edit / delete")
    for rel, data in current.items():
        if data is None:
            ops[rel] = {"op": "delete", "path": rel}
        else:
            f = c.trial_file(trial, rel)
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_bytes(data)
            ops[rel] = {"op": "write", "path": rel}
    req = {"id": rid, "summary": summary, "reason": reason, "ops": list(ops.values()), "origin": origin,
           "context": {}, "created": time.strftime("%Y-%m-%d %H:%M:%S")}
    (trial / "request.json").write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
    return trial, req


def request_change(agent, summary: str, changes: list, reason: str = "") -> str:
    """root 改动的唯一入口。返回给 A库 看的结果文字。"""
    caller = inspect.stack()[1].filename
    try:
        entry = Path(caller).resolve().relative_to(c.APP_ROOT).as_posix()
    except ValueError:
        entry = caller
    summary = str(summary or "").strip()
    if not summary:
        return "错误: 必须给出文字总结（summary）：要改哪些文件、改什么、为什么"
    if not changes:
        return "错误: changes 是空的"
    rid = time.strftime("%Y%m%d-%H%M%S") + f"-{os.getpid() % 10000}"
    log = {"id": rid, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "summary": summary, "reason": reason}
    try:
        trial, req = _build_trial(rid, summary, reason, changes, _origin(agent, entry))
        req["context"] = work_context(agent)
        (trial / "request.json").write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
    except (ValueError, UnicodeDecodeError, OSError) as e:
        c.audit({**log, "result": f"试验田没建成：{e}"})
        return f"错误: {e}（什么都没改）"
    log.update(origin=req["origin"], files=[f"{o['op']} {o['path']}" for o in req["ops"]])

    def finish(result: str, keep_trial: bool = False) -> str:
        c.audit({**log, "result": result})
        if not keep_trial:
            shutil.rmtree(trial, ignore_errors=True)
        return result

    # 锦衣卫：独立进程，只看文字总结和真实改动
    agent.emit("info", f"[root] 改动已写进试验田（{len(req['ops'])} 个文件），交给锦衣卫核对…")
    try:
        out = _run("jinyiwei.py", trial, GUARD_TIMEOUT)
        verdict = json.loads(out.stdout.strip().splitlines()[-1])
    except Exception as e:
        return finish(f"没改：锦衣卫没给出结论（{type(e).__name__}: {e}）")
    log["guard"] = verdict
    if not verdict.get("match"):
        return finish(f"没改：锦衣卫判定「否」。{verdict.get('why', '')}".strip())

    # 用户确认：独立弹窗，3 秒后才能点
    rk = verdict.get("risk") or {}
    log["risk"] = rk.get("risk")
    agent.emit("info", f"[root] 锦衣卫：是（文字总结和真实改动一致），风险评级「{rk.get('risk', '?')}」，等你在弹窗里确认…")
    try:
        d = _run("dialog.py", trial, DIALOG_TIMEOUT, gui=True, stdin=json.dumps(verdict, ensure_ascii=False))
        ok = d.returncode == 0
    except subprocess.TimeoutExpired:
        ok = False
    if not ok:
        return finish("没改：用户没有确认（取消、关掉弹窗或超时）")

    # 应用：试验田和正式文件都必须还是锦衣卫看过的样子
    _, hashes = c.real_diff(trial, req)
    if hashes != {k: tuple(v) for k, v in verdict["hashes"].items()}:
        return finish("没改：锦衣卫核对之后，试验田或正式文件又被动过，为安全起见作废")
    backup = c.BACKUP_DIR / rid
    for op in req["ops"]:
        rel, live = op["path"], c.APP_ROOT / op["path"]
        if live.is_file():
            (backup / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(live, backup / rel)
    (backup).mkdir(parents=True, exist_ok=True)
    (backup / "request.json").write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
    done = []
    for op in req["ops"]:
        rel, live = op["path"], c.APP_ROOT / op["path"]
        if op["op"] == "delete":
            live.unlink(missing_ok=True)
        else:
            live.parent.mkdir(parents=True, exist_ok=True)
            tmp = live.with_name(live.name + ".root_tmp")
            shutil.copyfile(c.trial_file(trial, rel), tmp)
            os.replace(tmp, live)
        done.append(f"{'删除' if op['op'] == 'delete' else '写入'} {rel}")
    code = any(o["path"].endswith(".py") for o in req["ops"])
    return finish(f"已改（root，编号 {rid}）：{'；'.join(done)}。原文件备份在 {backup}。"
                  + ("改的是代码，重启 Terminist 后生效。" if code else ""))
