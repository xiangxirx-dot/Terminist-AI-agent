"""
root 改动的确认弹窗：独立进程（tkinter），由 root 库在锦衣卫判「是」之后启动。
给用户看：要改什么（文字总结）、谁要改（来源）、锦衣卫结论、要改的文件、真实改动（这里自己现算）。
「确认修改」要等 3 秒才能点；关掉窗口 = 取消；开着的时候写一个锁文件，Terminist 的屏幕操作工具看到它就拒绝执行，
所以 AI 没法自己去点确认。退出码：0 = 确认，1 = 取消。
"""

import ctypes
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
for _s in (sys.stdout, sys.stderr):                            # pythonw 下没有控制台（是 None）
    if _s is not None:
        _s.reconfigure(encoding="utf-8")
import common as c                                              # noqa: E402

WAIT = 3


def main() -> int:
    import tkinter as tk
    from tkinter import ttk

    trial = Path(sys.argv[1]).resolve()
    req = c.load_request(trial)
    diff, _ = c.real_diff(trial, req)
    ok, origin = c.check_origin(req.get("origin") or {})
    try:                                          # 锦衣卫的结论（含风险评级）由 root 库从标准输入交过来，不经过文件
        verdict = json.loads(sys.stdin.buffer.read().decode("utf-8") or "{}") if sys.stdin is not None else {}   # -I 下按系统编码读会乱码
    except ValueError:
        verdict = {}
    rk = verdict.get("risk") or {}

    result = {"ok": False}
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)        # 高分屏上字不发虚
    except Exception:
        pass
    root = tk.Tk()
    root.title("Terminist root 权限确认")
    root.attributes("-topmost", True)
    k = root.winfo_fpixels("1i") / 96                          # 按屏幕 DPI 放大窗口
    w = min(int(860 * k), root.winfo_screenwidth() - 40)
    h = min(int(720 * k), root.winfo_screenheight() - 80)
    root.geometry(f"{w}x{h}+{(root.winfo_screenwidth() - w) // 2}+{(root.winfo_screenheight() - h) // 3}")
    font = ("Microsoft YaHei UI", 11)
    bold = ("Microsoft YaHei UI", 13, "bold")

    bar = tk.Frame(root)                                          # 按钮先占住底部，内容再多也挤不掉它
    bar.pack(side="bottom", fill="x", padx=16, pady=12)
    tk.Label(root, text="Terminist 要用 root 权限修改受保护的内容", font=bold, fg="#b42318").pack(anchor="w", padx=16, pady=(14, 4))
    tk.Label(root, text=f"来源：{origin}", font=font, fg="#344054" if ok else "#b42318", wraplength=w - 40,
             justify="left").pack(anchor="w", padx=16)
    tk.Label(root, text="锦衣卫：文字总结和试验田里的真实改动一致（是）", font=font, fg="#067647").pack(anchor="w", padx=16, pady=(2, 2))
    level = rk.get("risk", "未评")
    color = {"低": "#067647", "中": "#b54708", "高": "#b42318", "极高": "#7a0d0d"}.get(level, "#b42318")
    risk_box = tk.Frame(root, bg=color)
    risk_box.pack(fill="x", padx=16, pady=(4, 8))
    tk.Label(risk_box, text=f"锦衣卫风险评级：{level}", font=bold, fg="white", bg=color).pack(anchor="w", padx=10, pady=(6, 2))
    lines = [f"往最坏里想：{rk.get('worst_case') or '（没给）'}", f"证据：{rk.get('evidence') or '（没给）'}"]
    if rk.get("advice"):
        lines.append(f"建议：{rk['advice']}")
    tk.Label(risk_box, text="\n".join(lines), font=font, fg="white", bg=color, wraplength=w - 70,
             justify="left").pack(anchor="w", padx=10, pady=(0, 8))

    tk.Label(root, text="要改什么（文字总结）", font=bold).pack(anchor="w", padx=16)
    box = tk.Text(root, height=4, font=font, wrap="word", bg="#fffbeb", relief="flat")
    box.insert("1.0", req["summary"] + (f"\n\n原因：{req['reason']}" if req.get("reason") else ""))
    box.configure(state="disabled")
    box.pack(fill="x", padx=16, pady=(2, 8))

    names = {"write": "写入", "delete": "删除"}
    files = "；".join(f"{names.get(o['op'], o['op'])} {o['path']}" for o in req["ops"])
    tk.Label(root, text=f"文件（{len(req['ops'])} 个）：{files}", font=font, wraplength=w - 40, justify="left").pack(anchor="w", padx=16)

    tk.Label(root, text="真实改动（试验田 vs 正式文件）", font=bold).pack(anchor="w", padx=16, pady=(8, 0))
    frame = tk.Frame(root)
    frame.pack(fill="both", expand=True, padx=16, pady=4)
    view = tk.Text(frame, font=("Consolas", 10), wrap="none", bg="#f8f9fb")
    sy = ttk.Scrollbar(frame, orient="vertical", command=view.yview)
    sx = ttk.Scrollbar(frame, orient="horizontal", command=view.xview)
    view.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
    view.tag_configure("add", foreground="#067647")
    view.tag_configure("del", foreground="#b42318")
    view.tag_configure("head", foreground="#1d4ed8", font=("Consolas", 10, "bold"))
    for line in diff.splitlines():
        tag = ("head" if line.startswith("===") else "add" if line.startswith("+") and not line.startswith("+++")
               else "del" if line.startswith("-") and not line.startswith("---") else "")
        view.insert("end", line + "\n", tag)
    view.configure(state="disabled")
    sy.pack(side="right", fill="y")
    sx.pack(side="bottom", fill="x")
    view.pack(side="left", fill="both", expand=True)


    def done(yes: bool):
        result["ok"] = yes
        root.destroy()

    confirm = tk.Button(bar, text=f"确认修改（{WAIT}）", font=bold, state="disabled", bg="#b42318", fg="white",
                        disabledforeground="#f4c7c3", padx=16, command=lambda: done(True))
    tk.Button(bar, text="取消", font=bold, padx=16, command=lambda: done(False)).pack(side="right")
    confirm.pack(side="right", padx=10)
    if not ok:                                   # 来源核查不过：不给确认（锦衣卫那一关本来就会拦，这里再保险一次）
        confirm.configure(text="来源不对，不能确认")

    def tick(n):
        if not ok:
            return
        if n > 0:
            confirm.configure(text=f"确认修改（{n}）")
            root.after(1000, tick, n - 1)
        else:
            confirm.configure(text="确认修改", state="normal")

    root.protocol("WM_DELETE_WINDOW", lambda: done(False))
    root.bind("<Escape>", lambda e: done(False))
    root.after(0, tick, WAIT)
    root.after(200, lambda: (root.lift(), root.focus_force()))
    root.mainloop()
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    c.HOME.mkdir(parents=True, exist_ok=True)
    c.LOCK_FILE.write_text(str(os.getpid()), encoding="utf-8")   # 弹窗开着：屏幕操作工具一律拒绝
    try:
        code = main()
    except Exception as e:
        sys.stderr.write(f"{type(e).__name__}: {e}\n")
        code = 1
    finally:
        try:
            c.LOCK_FILE.unlink()
        except OSError:
            pass
    sys.exit(code)
