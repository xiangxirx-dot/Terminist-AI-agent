"""
root 库接到 A库 上的工具：root_change。只给主 Agent（A库）；B库、执行成员、前台旁聊都没有这个工具。
这是锦衣卫唯一认可的请求入口（common.ENTRY）。
"""

from . import request_change


def tools(agent) -> dict:
    from lib_a import _fn

    def run(a):
        return request_change(agent, str(a.get("summary") or ""), a.get("changes") or [], str(a.get("reason") or ""))

    return {"root_change": (_fn(
        "root_change",
        "用 root 权限修改 Terminist 里平时改不了的东西：受保护的 base/、lib_b/（B库）、run.py、lib_a/config.py 等，"
        "也能改其他 Terminist 文件。不能改 root/ 自己、versions/、memory/。"
        "流程：先写进试验田 → 锦衣卫（独立的 AI）核对你的文字总结和真实改动是否一致、核查来源 → 弹窗给用户看，等 3 秒确认 → 才真正写入。"
        "summary 必须如实、完整地写清楚改哪些文件、每个文件改什么、为什么——和实际改动对不上锦衣卫会直接拒绝。"
        "普通的界面 / 执行层改动仍然走 request_upgrade 交给 B库；只有 B库 改不了的受保护内容才用这个。",
        {"summary": {"type": "string", "description": "给用户和锦衣卫看的文字总结：逐个文件说清楚改什么、为什么"},
         "reason": {"type": "string", "description": "为什么需要 root 权限（可选）"},
         "changes": {"type": "array", "description": "要做的改动，按顺序执行",
                     "items": {"type": "object", "properties": {
                         "path": {"type": "string", "description": "相对 Terminist 根目录的路径，例如 base/guard.py"},
                         "action": {"type": "string", "enum": ["write", "edit", "delete"],
                                    "description": "write=写整个文件（新建或覆盖）；edit=把唯一出现的 old_str 换成 new_str；delete=删除"},
                         "content": {"type": "string"}, "old_str": {"type": "string"}, "new_str": {"type": "string"}},
                         "required": ["path", "action"]}}},
        ["summary", "changes"]), run)}
