"""
封印 root 库：把 root 文件夹里每个文件的指纹加密存到 ~/.terminist/root_seal.dpapi。
锦衣卫每次核对，root 库的文件和封印对不上就拒绝一切改动。

只能由人在终端里手动运行（python root/seal.py），要亲手输入「封印」两个字；
Terminist 的 run_command 等工具没有交互终端，运行它会被拒绝。你自己改了 root 库之后要重新封印一次。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as c                                              # noqa: E402

if __name__ == "__main__":
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        print("只能在终端里由人手动运行（没有交互终端，拒绝封印）")
        sys.exit(1)
    state = c.check_seal()
    print("当前封印：" + (state or "和 root 库一致"))
    print("root 库文件：")
    for name, h in c.root_fingerprint().items():
        print(f"  {name}  {h[:16]}…")
    if input("确认用现在的 root 库文件重新封印？输入「封印」确认：").strip() != "封印":
        print("已取消")
        sys.exit(1)
    c.write_seal()
    print("已封印：", c.SEAL_FILE)
