"""
root 库的公共部分：锦衣卫（jinyiwei.py）、确认弹窗（dialog.py）、封印（seal.py）和 root 库本身都用它。
只用标准库，不导入 Terminist 的任何代码（lib_a / lib_b / base / surface），这样它们被改坏了也影响不到这里。
"""

import ctypes
import difflib
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent              # root 库自己
APP_ROOT = ROOT_DIR.parent                              # Terminist 文件夹
HOME = Path.home() / ".terminist"
TRIAL_DIR = HOME / "root_trial"                         # 试验田：要改的内容先写在这里
BACKUP_DIR = HOME / "root_backups"                      # 改之前的原文件
AUDIT_FILE = HOME / "root_audit.jsonl"                  # 每次请求的记录
SEAL_FILE = HOME / "root_seal.dpapi"                    # root 库文件指纹（加密），锦衣卫每次核对
LOCK_FILE = HOME / "root_dialog.lock"                   # 确认弹窗开着：屏幕操作工具一律拒绝（AI 不能自己点确认）
KEY_FILE = HOME / "api_key.dpapi"                       # 和 lib_a/config.py 同一个加密 key（这里自己解密，不导入它）
ENTRY = "root/tools.py"                                 # 唯一认可的请求入口（A库 的 root_change 工具）
ALLOWED_ROLES = ("lead", "solo")                        # 只有 A库（组长 / 单模型）能发起；B库、执行成员、前台旁聊都不行
NO_TOUCH = ("root", "versions", "memory", ".git")       # root 也不能改的：root 自己、存档、记忆、git
MAX_DIFF = 120_000                                      # 改动太大，锦衣卫看不完：直接判否，让 A库 拆小


# ---------------- 路径 ----------------
def target_error(rel: str) -> str:
    """rel 能不能当修改目标：返回空字符串表示可以。"""
    rel = str(rel or "").replace("\\", "/").strip().lstrip("/")
    if not rel:
        return "路径是空的"
    p = (APP_ROOT / rel).resolve()
    if p != APP_ROOT and APP_ROOT not in p.parents:
        return f"只能改 Terminist 文件夹里的东西：{rel}"
    rel = p.relative_to(APP_ROOT).as_posix()
    if rel.split("/")[0] in NO_TOUCH:
        return f"root 也不能改 {rel.split('/')[0]}/（root 自己、存档、记忆、git 不归它管）"
    if "__pycache__" in rel.split("/"):
        return "不能改缓存文件"
    return ""


def norm_rel(rel: str) -> str:
    return (APP_ROOT / str(rel).replace("\\", "/").strip().lstrip("/")).resolve().relative_to(APP_ROOT).as_posix()


# ---------------- 哈希 / 读写 ----------------
def sha(data: bytes | None) -> str:
    return "" if data is None else hashlib.sha256(data).hexdigest()


def read_live(rel: str) -> bytes | None:
    p = APP_ROOT / rel
    return p.read_bytes() if p.is_file() else None


def trial_file(trial: Path, rel: str) -> Path:
    return trial / "files" / rel


def read_trial(trial: Path, op: dict) -> bytes | None:
    """试验田里这个文件改完的样子；删除的文件返回 None。"""
    if op["op"] == "delete":
        return None
    return trial_file(trial, op["path"]).read_bytes()


def load_request(trial: Path) -> dict:
    return json.loads((trial / "request.json").read_text(encoding="utf-8"))


# ---------------- 真实改动（锦衣卫和弹窗各自现算，不信任请求方给的任何 diff）----------------
def _text(b: bytes | None) -> list[str]:
    if b is None:
        return []
    return b.decode("utf-8", errors="replace").splitlines(keepends=True)


def real_diff(trial: Path, req: dict) -> tuple[str, dict]:
    """按试验田里的文件和正式文件现算 diff。返回 (diff 文字, {路径: (正式文件哈希, 试验田哈希)})。"""
    parts, hashes = [], {}
    for op in req["ops"]:
        rel = op["path"]
        before = read_live(rel)
        after = read_trial(trial, op)
        hashes[rel] = (sha(before), sha(after))
        if op["op"] == "delete":
            head = f"=== 删除文件 {rel}（原有 {len(_text(before))} 行）==="
        elif before is None:
            head = f"=== 新建文件 {rel}（{len(_text(after))} 行）==="
        else:
            head = f"=== 修改文件 {rel} ==="
        body = "".join(difflib.unified_diff(_text(before), _text(after), f"a/{rel}", f"b/{rel}", n=3))
        if before is not None and after is not None and before == after:
            body = "（内容没有变化）\n"
        parts.append(head + "\n" + body)
    return "\n".join(parts), hashes


# ---------------- DPAPI（和 lib_a/config.py 同样的做法，这里单独一份）----------------
class _Blob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(data: bytes, encrypt: bool, entropy: bytes) -> bytes:
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    src = _Blob(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)), ctypes.POINTER(ctypes.c_char)))
    ent = _Blob(len(entropy), ctypes.cast(ctypes.create_string_buffer(entropy, len(entropy)), ctypes.POINTER(ctypes.c_char)))
    out = _Blob()
    if encrypt:
        ok = crypt32.CryptProtectData(ctypes.byref(src), "Terminist root", ctypes.byref(ent), None, None, 0x1, ctypes.byref(out))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(src), None, ctypes.byref(ent), None, None, 0x1, ctypes.byref(out))
    if not ok:
        raise OSError("DPAPI 失败")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def api_key() -> str:
    env = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if env:
        return env
    if sys.platform != "win32":
        return KEY_FILE.read_text(encoding="utf-8").strip()
    return _dpapi(KEY_FILE.read_bytes(), False, b"Terminist API key").decode("utf-8").strip()


# ---------------- 封印：root 库文件的指纹 ----------------
def root_fingerprint() -> dict[str, str]:
    out = {}
    for f in sorted(ROOT_DIR.rglob("*")):
        if f.is_file() and "__pycache__" not in f.parts:
            out[f.relative_to(ROOT_DIR).as_posix()] = sha(f.read_bytes())
    return out


def write_seal():
    data = json.dumps(root_fingerprint(), sort_keys=True).encode("utf-8")
    HOME.mkdir(parents=True, exist_ok=True)
    SEAL_FILE.write_bytes(_dpapi(data, True, b"Terminist root seal") if sys.platform == "win32" else data)


def check_seal() -> str:
    """root 库文件和封印时一样就返回空字符串，否则返回哪里不对。"""
    try:
        raw = SEAL_FILE.read_bytes()
        sealed = json.loads(_dpapi(raw, False, b"Terminist root seal") if sys.platform == "win32" else raw)
    except FileNotFoundError:
        return "root 库还没有封印（在终端里运行 python root/seal.py）"
    except (OSError, ValueError):
        return "root 库的封印读不出来（被改过或损坏）"
    now = root_fingerprint()
    changed = sorted(k for k in set(sealed) | set(now) if sealed.get(k) != now.get(k))
    return f"root 库在封印之后被改过：{', '.join(changed)}" if changed else ""


# ---------------- 来源核查 ----------------
def process_cmdline(pid: int) -> str:
    """进程的命令行（Windows 用 CIM 查），查不到返回空字符串。"""
    if sys.platform != "win32":
        try:
            return Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ").decode()
        except OSError:
            return ""
    import subprocess
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command",
                              f"(Get-CimInstance Win32_Process -Filter 'ProcessId={int(pid)}').CommandLine"],
                             capture_output=True, text=True, timeout=20, creationflags=0x08000000)
        return out.stdout.strip()
    except Exception:
        return ""


def check_origin(origin: dict, entry: str = ENTRY, roles: tuple | None = ALLOWED_ROLES) -> tuple[bool, str]:
    """看更改者来源：必须是正在运行的 Terminist（run.py），从约定的入口进来；roles 给了就只认这些角色。
    root 改动：入口 root/tools.py，只认 A库；删除审查：入口 base/guard.py，谁删都要审（roles=None）。"""
    problems = []
    pid = int(origin.get("pid") or 0)
    cmd = process_cmdline(pid) if pid else ""
    script = str(origin.get("script") or "").lower().replace("/", "\\")
    via = ""
    if cmd and "run.py" not in cmd.lower() and "spawn_main" in cmd:
        # Terminist 的 Agent 独立进程：命令行是 multiprocessing 的 spawn_main(parent_pid=…)，
        # 它的父进程必须是正在运行的这个 Terminist（run.py）
        import re
        m = re.search(r"parent_pid=(\d+)", cmd)
        parent = process_cmdline(int(m.group(1))) if m else ""
        if "run.py" in parent.lower():
            cmd, via = parent, f"（Agent 独立进程，父进程 {m.group(1)}）"
    if not cmd:
        problems.append(f"发起进程 {pid} 不存在")
    elif "run.py" not in cmd.lower() or script != str(APP_ROOT / "run.py").lower().replace("/", "\\"):
        problems.append(f"发起进程不是这个 Terminist（命令行：{cmd[:120]}，脚本：{origin.get('script')}）")
    pid_desc = f"{pid}{via}"
    if origin.get("entry") != entry:
        problems.append(f"不是从约定入口 {entry} 发起的（入口：{origin.get('entry')}）")
    if roles is not None and origin.get("role") not in roles:
        problems.append(f"发起者不是 A库（角色：{origin.get('role')}）")
    desc = (f"{origin.get('who', '?')}（角色 {origin.get('role')}，模型 {origin.get('model')}），"
            f"进程 {pid_desc}：{cmd[:160] or '查不到'}，入口 {origin.get('entry')}")
    return (not problems), desc + ("" if not problems else "\n问题：" + "；".join(problems))


# ---------------- 风控用的工作信息（锦衣卫自己去看，不只听 Terminist 说）----------------
LOG_FILE = HOME / "logs" / "workflow.log"
DELETE_ENTRY = "base/guard.py"
RISK_LEVELS = ("低", "中", "高", "极高")
MAX_AUTO_ITEMS = 20
_WIDE = ("-r", "-rf", "-fr", "/s", "-recurse", "rmtree", "rmdir", " rd ", "*", "?", "remove-item -r", "del /q")


def log_tail(n: int = 60, chars: int = 8000) -> str:
    """工作流日志最后 n 条（锦衣卫自己读文件）。"""
    try:
        with open(LOG_FILE, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 200_000))
            text = f.read().decode("utf-8", errors="replace")
    except OSError:
        return "（读不到工作流日志）"
    entries, cur = [], ""
    for line in text.splitlines():
        if line.startswith("    "):
            cur += "\n" + line
        else:
            if cur:
                entries.append(cur)
            cur = line
    if cur:
        entries.append(cur)
    out = "\n".join(e[:400] for e in entries[-n:])
    return out[-chars:]


def _redact(text: str) -> str:
    try:
        key = api_key()
    except Exception:
        return text
    return text.replace(key, "sk-…(已隐藏)") if key and key in text else text


def item_facts(item: str) -> dict:
    """要删的东西的真实情况（锦衣卫自己看）：是什么、多大、多旧、在哪、文本文件给一段开头。"""
    import time
    p = Path(item)
    if not p.is_absolute() or not p.exists():
        return {"item": item, "kind": "命令或描述（不是现存的文件路径）"}
    st = p.stat()
    desk = Path.home() / "Desktop"
    where = ("Terminist 自己的文件夹" if p.resolve() == APP_ROOT or APP_ROOT in p.resolve().parents else
             "桌面" if desk in p.resolve().parents else "其他位置")
    facts = {"item": item, "kind": "文件夹" if p.is_dir() else "文件", "where": where,
             "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
             "age_hours": round((time.time() - st.st_mtime) / 3600, 1)}
    if p.is_dir():
        files = [f for f in p.rglob("*") if f.is_file()][:2000]
        facts.update(files=len(files), size=sum(f.stat().st_size for f in files))
    else:
        facts["size"] = st.st_size
        if st.st_size < 2_000_000 and p.suffix.lower() in (".txt", ".md", ".py", ".json", ".csv", ".html", ".js", ".css",
                                                            ".yaml", ".yml", ".toml", ".ini", ".log", ".bat", ".ps1"):
            try:
                facts["preview"] = _redact(p.read_text(encoding="utf-8", errors="replace")[:800])
            except OSError:
                pass
    return facts


def hard_floor(items: list[str], facts: list[dict]) -> list[str]:
    """不管锦衣卫怎么评，碰到这些都必须问用户。"""
    why = []
    if len(items) > MAX_AUTO_ITEMS:
        why.append(f"一次删 {len(items)} 项（超过 {MAX_AUTO_ITEMS} 项）")
    for f in facts:
        if f.get("where") == "Terminist 自己的文件夹":
            why.append(f"要删 Terminist 自己的文件：{f['item']}")
        if f.get("kind") == "文件夹":
            why.append(f"要删整个文件夹：{f['item']}")
    for it in items:
        low = f" {it.lower()} "
        if any(w in low for w in _WIDE) and not Path(it).exists():
            why.append(f"命令带递归 / 通配符：{it[:80]}")
    return why


def audit(entry: dict):
    HOME.mkdir(parents=True, exist_ok=True)
    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
