"""
打包 Terminist：选一个文件夹，生成两个干净的版本（不带任何隐私）
------------------------
  python build.py                          打开打包窗口：选文件夹 → 生成
  python build.py --out <文件夹> [--source] [--exe] [--roles] [--refresh] [--force]
                                           不开窗口直接生成（不写 --source / --exe 就两个都生成）
  python build.py --here [--shortcut] [--desktop]
                                           开发用：在本文件夹里放 runtime/ + Terminist.exe（开始菜单 / 桌面快捷方式指过来）

生成的两个版本：
  Terminist-source/   源码版：只有代码和素材 + requirements.txt + .gitignore + README，可以直接传 GitHub
  Terminist/          可执行版：源码 + 自带的 Python（runtime/）+ Terminist.exe，整个文件夹拷到干净的 Windows 双击就能用
                      --roles / 窗口里勾「带上员工和人设」：再带上员工花名册（含角色训练出来的人设）和头像，不带对话记忆

不带进去的（隐私 / 本机专属）：
  memory/（对话记忆、RAG 库、头像、备份）、versions/（改造存档，里面有你的原话）、terminist_settings.json（窗口布局）、
  __pycache__ / *.pyc（编译缓存里有本机绝对路径）、modules/_unpacked/（运行时解包）、python_path.txt、日志 / 临时文件。
  API key、root 封印、网站密码本来就不在文件夹里（在用户目录，用 Windows 账户加密）。
生成完会把输出整个扫一遍：本机用户目录路径（UTF-8 / UTF-16 都查）、用户名、电脑名、API key 样式的字符串，
有一处命中就算失败并列出来。

为什么只做启动器、不把主程序打成一个 exe：
  modules/ 要能随时丢新的 .tmod 进去，B库 也会改 lib_a / surface 自己 —— 主程序必须保持成散装的 .py 文件；
  Terminist.exe 只做一件事：用 runtime/ 里的 pythonw.exe 在自己所在的文件夹里跑 run.py（没有黑色 cmd 窗口）。
  编译用 Windows 自带的 .NET Framework 编译器（csc.exe），不用装 PyInstaller。

带不走的（换电脑后重新弄一次）：
  - API key 和 root 封印用 Windows 账户加密（DPAPI），别的电脑解不开：到「隐私」重新填 key，终端里 python root/seal.py 重新封印；
  - Ollama（本地小模型：记忆打分、看图）是单独装的程序，没装时这两个功能用不了，别的照常；
  - Whisper 语音模型第一次用语音输入时自动下载。
"""

import ast
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "Terminist.exe"
ICO = ROOT / "icon.ico"
PNG = ROOT / "icon.png"
ICON_SIZES = (16, 24, 32, 48, 64, 128, 256)
RUNTIME = ROOT / "runtime" / "python"              # 自带 Python 的缓存（--here 时就是正式的那份）
RUNTIME_INFO = RUNTIME / "terminist_runtime.json"
SOURCE_NAME, EXE_NAME = "Terminist-source", "Terminist"
SCAN_SKIP = {"versions", "memory", "runtime", ".git", "__pycache__", "root"}   # 扫 import 时跳过（root 单独扫）
EXTRA_DISTS = ("pip",)                            # 代码没 import、但要带上的：pip（以后能往 runtime 里装新库）
STDLIB_SKIP = {"site-packages", "test", "idlelib", "turtledemo", "ensurepip", "__pycache__"}
VC_DLLS = ("msvcp140.dll", "msvcp140_1.dll", "msvcp140_2.dll", "vcruntime140.dll", "vcruntime140_1.dll",
           "concrt140.dll", "vcomp140.dll")       # VC++ 运行库：干净系统可能没有，带一份放在 python.exe 旁边

# 导出时不带的东西
PRIVATE_DIRS = {"memory", "versions", "runtime", "__pycache__", ".git", ".venv", "venv", ".idea", ".vscode",
                ".pytest_cache", ".mypy_cache"}
PRIVATE_SUBDIRS = {"modules/_unpacked"}
PRIVATE_FILES = {"Terminist.exe", "python_path.txt", "terminist_settings.json"}
PRIVATE_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".dpapi", ".flag", ".lnk"}
RUNTIME_SKIP_FILES = {"direct_url.json"}          # pip 记的「从哪装的」：本地装的包会带本机路径
GITIGNORE = """# Terminist：运行时生成 / 本机专属 / 隐私，不进仓库
memory/
versions/
runtime/
__pycache__/
*.pyc
modules/_unpacked/
Terminist.exe
python_path.txt
terminist_settings.json
"""

README = """# Terminist

本地运行的 DeepSeek 智能体，带 pygame 图形界面。

## 从源码运行

```bash
pip install -r requirements.txt
python run.py
```

第一次启动后在顶栏「隐私」里填 DeepSeek API key（用 Windows 账户加密保存在用户目录，不在这个文件夹里）。
要用 root 库的功能，先在终端里运行一次 `python root/seal.py` 封印。

可选：装 [Ollama](https://ollama.com) 并 `ollama pull qwen2.5:3b`（记忆打分）、`ollama pull qwen2.5vl:7b`（看图）。

## 打包

```bash
python build.py
```

选一个文件夹，生成源码版和可执行版（自带 Python，拷到干净的 Windows 双击 `Terminist.exe` 就能用）。

## 模块

`modules/` 里放 `.tmod` 模块包，启动时自动读取。制作教程见 `modules/README.md`。
"""

LAUNCHER_CS = r'''
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("Terminist")]
[assembly: System.Reflection.AssemblyProduct("Terminist")]
[assembly: System.Reflection.AssemblyDescription("Terminist launcher")]

static class Launcher
{
    [STAThread]
    static int Main(string[] args)
    {
        string home = AppDomain.CurrentDomain.BaseDirectory;
        string run = Path.Combine(home, "run.py");
        if (!File.Exists(run))
        {
            MessageBox.Show("找不到 run.py。\n\nTerminist.exe 只是启动器，要和 run.py 放在同一个文件夹里。\n\n当前位置：" + home,
                            "Terminist", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
        string py = FindPython(home);
        if (py == null)
        {
            MessageBox.Show("找不到 Python（pythonw.exe）。\n\n装好 Python 3，或者在 Terminist 文件夹里放一个 python_path.txt，第一行写 pythonw.exe 的完整路径。",
                            "Terminist", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 2;
        }
        string dryRun = null;
        StringBuilder line = new StringBuilder(Quote(run));
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "--launcher-dry-run" && i + 1 < args.Length) { dryRun = args[++i]; continue; }
            line.Append(' ').Append(Quote(args[i]));
        }
        if (dryRun != null)          // 自检用：只把要执行的命令写进文件，不真的启动
        {
            File.WriteAllText(dryRun, py + "\n" + line.ToString() + "\n" + home, Encoding.UTF8);
            return 0;
        }
        ProcessStartInfo psi = new ProcessStartInfo(py, line.ToString());
        psi.UseShellExecute = false;
        psi.CreateNoWindow = true;
        psi.WorkingDirectory = home;
        if (py.StartsWith(Path.Combine(home, "runtime"), StringComparison.OrdinalIgnoreCase))
        {                            // 自带的 Python：只用它自己的库，本机装的 Python 别混进来
            psi.EnvironmentVariables.Remove("PYTHONHOME");
            psi.EnvironmentVariables.Remove("PYTHONPATH");
            psi.EnvironmentVariables["PYTHONNOUSERSITE"] = "1";
        }
        try { Process.Start(psi); }
        catch (Exception e)
        {
            MessageBox.Show("启动失败：" + e.Message + "\n\n" + py, "Terminist", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 3;
        }
        return 0;
    }

    static string FindPython(string home)
    {
        string bundled = Path.Combine(home, @"runtime\python\pythonw.exe");
        if (File.Exists(bundled)) return bundled;
        string env = Environment.GetEnvironmentVariable("TERMINIST_PYTHON");
        if (!string.IsNullOrEmpty(env) && File.Exists(env)) return env;
        string cfg = Path.Combine(home, "python_path.txt");
        if (File.Exists(cfg))
        {
            foreach (string l in File.ReadAllLines(cfg))
            {
                string p = l.Trim().Trim('"');
                if (p.Length > 0) { if (File.Exists(p)) return p; break; }
            }
        }
        string path = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (string name in new string[] { "pythonw.exe", "pyw.exe" })
            foreach (string dir in path.Split(';'))
            {
                if (dir.Trim().Length == 0) continue;
                try
                {
                    string f = Path.Combine(dir.Trim().Trim('"'), name);
                    if (File.Exists(f)) return f;
                }
                catch (ArgumentException) { }
            }
        return null;
    }

    // Windows 命令行参数的标准转义：带空格 / 引号的参数加引号，引号前的反斜杠加倍
    static string Quote(string a)
    {
        if (a.Length > 0 && a.IndexOfAny(new char[] { ' ', '\t', '"' }) < 0) return a;
        StringBuilder sb = new StringBuilder("\"");
        int slashes = 0;
        foreach (char c in a)
        {
            if (c == '\\') { slashes++; continue; }
            if (c == '"') sb.Append('\\', slashes * 2 + 1);
            else sb.Append('\\', slashes);
            slashes = 0;
            sb.Append(c);
        }
        sb.Append('\\', slashes * 2).Append('"');
        return sb.ToString();
    }
}
'''


class BuildError(Exception):
    pass


_log = print                                      # 窗口模式下换成往窗口里写


def log(text: str):
    _log(text)


# ---------------- 自带的 Python（runtime/python）----------------
def _top_imports(path: Path) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except (SyntaxError, ValueError):
        return set()
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            out.add(node.module.split(".")[0])
    return out


def direct_dists() -> list[str]:
    """代码里直接 import 到的第三方库（发行包名）。"""
    from importlib import metadata
    files = [f for f in ROOT.rglob("*.py") if not SCAN_SKIP & set(f.relative_to(ROOT).parts[:-1])]
    files += list((ROOT / "root").rglob("*.py"))
    imports = set().union(*(_top_imports(f) for f in files))
    owners = metadata.packages_distributions()
    picked = set()
    for name in imports:
        cands = sorted(set(owners.get(name, [])))
        if len(cands) > 1:                            # 两个包抢同一个名字（pygame / pygame-ce）：后装的那个才是真在用的
            def installed_at(d):
                try:
                    return Path(metadata.distribution(d)._path).stat().st_mtime
                except Exception:
                    return 0
            cands = [max(cands, key=installed_at)]
        picked.update(cands)
    return sorted(picked - {"pip"})


def needed_dists() -> dict[str, "object"]:
    """直接用到的库 + 顺着依赖展开。返回 {名字: Distribution}。"""
    from importlib import metadata
    from pip._vendor.packaging.requirements import Requirement
    todo = sorted(set(direct_dists()) | set(EXTRA_DISTS))
    found: dict[str, object] = {}
    while todo:
        name = todo.pop()
        key = name.lower().replace("_", "-")
        if key in found:
            continue
        try:
            dist = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            continue
        found[key] = dist
        for r in dist.requires or []:
            req = Requirement(r)
            if req.marker is None or req.marker.evaluate({"extra": ""}):
                todo.append(req.name)
    return found


def _wanted_info(dists) -> dict:
    return {"python": sys.version, "dists": {k: d.version for k, d in sorted(dists.items())}}


def make_runtime(force: bool = False):
    """把这台机器的 Python + 用得到的库拷进 runtime/python。依赖没变就跳过。"""
    dists = needed_dists()
    want = _wanted_info(dists)
    try:
        if not force and json.loads(RUNTIME_INFO.read_text(encoding="utf-8")) == want:
            log(f"自带 Python：没变（{len(dists)} 个库），用现成的")
            return
    except (OSError, ValueError):
        pass
    base = Path(sys.base_prefix)
    site = Path(next(p for p in sys.path if p.endswith("site-packages")))
    tmp = RUNTIME.with_name("python.new")
    shutil.rmtree(tmp, ignore_errors=True)            # 上次装到一半的临时目录（自己生成的东西）
    tmp.mkdir(parents=True)
    log("自带 Python：从本机 Python 拷贝…")
    for f in base.iterdir():                          # python.exe / pythonw.exe / python3*.dll / LICENSE …
        if f.is_file() and f.suffix.lower() in (".exe", ".dll", ".txt"):
            shutil.copy2(f, tmp / f.name)
    for sub in ("DLLs", "tcl"):
        if (base / sub).is_dir():
            shutil.copytree(base / sub, tmp / sub)
    shutil.copytree(base / "Lib", tmp / "Lib", ignore=lambda d, names: [n for n in names if n in STDLIB_SKIP])
    dst_site = tmp / "Lib" / "site-packages"
    dst_site.mkdir(parents=True, exist_ok=True)
    copied = 0
    for dist in dists.values():                       # 只拷每个库自己登记过的文件（RECORD）
        if dist.files is None:
            log(f"  注意：{dist.metadata['Name']} 没有文件清单（RECORD），没拷进去")
        for rel in dist.files or []:
            src = Path(dist.locate_file(rel))
            try:
                inside = src.resolve().relative_to(site.resolve())
            except ValueError:                        # Scripts\ 里的 exe 之类：不在 site-packages 里，不要
                continue
            if "__pycache__" in inside.parts or not src.is_file() or src.name in RUNTIME_SKIP_FILES:
                continue
            out = dst_site / inside
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, out)
            copied += 1
    sys32 = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32"
    for dll in VC_DLLS:
        if not (tmp / dll).exists() and (sys32 / dll).is_file():
            shutil.copy2(sys32 / dll, tmp / dll)
    (tmp / "terminist_runtime.json").write_text(json.dumps(want, ensure_ascii=False, indent=1), encoding="utf-8")
    if RUNTIME.exists():
        old = RUNTIME.with_name("python.old")
        shutil.rmtree(old, ignore_errors=True)
        RUNTIME.rename(old)
        shutil.rmtree(old, ignore_errors=True)        # 旧的那份 runtime（build.py 自己生成的）
    tmp.rename(RUNTIME)
    log(f"自带 Python：{len(dists)} 个库、{copied} 个文件，共 {_size_mb(RUNTIME)} MB")


def check_runtime(app_dir: Path, runtime: Path) -> bool:
    """用自带的 Python、把本机 Python 从 PATH / 用户库里藏起来，试着把主程序的模块都 import 一遍。
    -B：不写 __pycache__（编译缓存里会记下绝对路径，导出的文件夹里不能有）。"""
    env = {k: v for k, v in os.environ.items() if k.upper() not in ("PYTHONPATH", "PYTHONHOME")}
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1", SDL_VIDEODRIVER="dummy",
               PYGAME_HIDE_SUPPORT_PROMPT="1")
    env["PATH"] = os.pathsep.join(p for p in env.get("PATH", "").split(os.pathsep) if "python" not in p.lower())
    code = ("import sys, os; pre = os.path.normcase(os.path.realpath(sys.prefix));"
            "import surface.gui, surface.splash, lib_a, lib_b, base, faster_whisper, playwright.sync_api, yt_dlp, PIL;"
            "bad = [m.__name__ for m in list(sys.modules.values()) if getattr(m, '__file__', None)"
            " and not os.path.normcase(os.path.realpath(m.__file__)).startswith(pre)"
            " and not os.path.normcase(os.path.realpath(m.__file__)).startswith(os.path.normcase(os.getcwd()))];"
            "print('OK', len(sys.modules), 'outside:', bad[:5])")
    r = subprocess.run([str(runtime / "python.exe"), "-B", "-c", code], cwd=app_dir, env=env, capture_output=True,
                       text=True, errors="replace", timeout=300, creationflags=0x08000000)
    tail = (r.stdout + r.stderr).strip().splitlines()
    ok = r.returncode == 0 and bool(tail) and tail[-1].startswith("OK") and tail[-1].endswith("[]")
    log("自检：" + ("通过——不靠本机 Python 也能加载主程序" if ok else "没通过：\n" + "\n".join(tail[-12:])))
    return ok


# ---------------- 图标 / 启动器 ----------------
def find_csc() -> Path | None:
    """Windows 自带的 .NET Framework 4 编译器。"""
    for fw in ("Framework64", "Framework"):
        p = Path(r"C:\Windows\Microsoft.NET") / fw / "v4.0.30319" / "csc.exe"
        if p.is_file():
            return p
    return None


def make_icon():
    """icon.png → icon.ico（多尺寸，每张都直接塞 PNG，Vista 以后都认）。只用 pygame，不需要 PIL。"""
    if ICO.is_file() and ICO.stat().st_mtime >= PNG.stat().st_mtime:
        return
    import io
    os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
    import pygame
    src = pygame.image.load(str(PNG))
    pngs = []
    for n in ICON_SIZES:
        buf = io.BytesIO()
        pygame.image.save(pygame.transform.smoothscale(src, (n, n)), buf, "icon.png")
        pngs.append((n, buf.getvalue()))
    head = struct.pack("<HHH", 0, 1, len(pngs))
    offset = 6 + 16 * len(pngs)
    entries, blobs = b"", b""
    for n, data in pngs:
        entries += struct.pack("<BBBBHHII", n % 256, n % 256, 0, 0, 1, 32, len(data), offset)
        blobs += data
        offset += len(data)
    ICO.write_bytes(head + entries + blobs)
    log(f"图标：{ICO.name}（{len(pngs)} 种尺寸）")


def compile_launcher(dest: Path):
    """编出启动器放到 dest。不带 /debug：exe 里不会留下编译时的路径。"""
    csc = find_csc()
    if csc is None:
        raise BuildError("找不到 .NET Framework 4 的 csc.exe（Windows 自带，一般在 C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319）")
    with tempfile.TemporaryDirectory() as tmp:
        cs = Path(tmp) / "Launcher.cs"
        cs.write_text(LAUNCHER_CS, encoding="utf-8-sig")
        out = Path(tmp) / "Terminist.exe"
        cmd = [str(csc), "/nologo", "/optimize+", "/debug-", "/target:winexe", "/platform:anycpu", "/codepage:65001",
               f"/win32icon:{ICO}", f"/out:{out}", "/r:System.Windows.Forms.dll", str(cs)]
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace", creationflags=0x08000000)
        if r.returncode != 0:
            raise BuildError("启动器编译失败：\n" + (r.stdout + r.stderr).strip())
        try:
            dest.write_bytes(out.read_bytes())
        except PermissionError:
            raise BuildError(f"{dest} 正在被占用（开着的快捷方式属性窗口 / 杀毒扫描？），关掉再打包")
    log(f"启动器：{dest.name}（{dest.stat().st_size // 1024} KB）")


def make_shortcut(lnk: Path, exe: Path):
    """用 WScript.Shell 建 / 改快捷方式，指到启动器。"""
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK);"
          "$s.TargetPath=$env:EXE;$s.Arguments='';$s.WorkingDirectory=$env:HOME_DIR;"
          "$s.IconLocation=$env:EXE+',0';$s.Description='Terminist';$s.Save()")
    env = dict(os.environ, LNK=str(lnk), EXE=str(exe), HOME_DIR=str(exe.parent))
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=env, capture_output=True, text=True,
                       errors="replace", creationflags=0x08000000)
    log(f"快捷方式：{lnk}" + ("" if r.returncode == 0 else f"（失败：{r.stderr.strip()[:200]}）"))


# ---------------- 导出 ----------------
def _size_mb(folder: Path) -> int:
    return sum(f.stat().st_size for f in folder.rglob("*") if f.is_file()) // (1 << 20)


def is_private(rel: Path) -> bool:
    """这个相对路径（相对 Terminist 文件夹）要不要排除。"""
    parts = rel.parts
    if any(p in PRIVATE_DIRS for p in parts[:-1]) or (len(parts) == 1 and parts[0] in PRIVATE_DIRS):
        return True
    posix = rel.as_posix()
    if any(posix == d or posix.startswith(d + "/") for d in PRIVATE_SUBDIRS):
        return True
    if len(parts) == 1 and parts[0] in PRIVATE_FILES:
        return True
    return rel.suffix.lower() in PRIVATE_SUFFIXES


def copy_clean_source(dst: Path) -> int:
    """把代码和素材拷到 dst（排除隐私 / 本机专属的东西），返回拷了几个文件。"""
    n = 0
    for f in sorted(ROOT.rglob("*")):
        rel = f.relative_to(ROOT)
        if not f.is_file() or is_private(rel):
            continue
        out = dst / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, out)
        n += 1
    return n


def write_requirements(dst: Path):
    from importlib import metadata
    lines = []
    for name in direct_dists():
        try:
            lines.append(f"{metadata.distribution(name).metadata['Name']}=={metadata.version(name)}")
        except metadata.PackageNotFoundError:
            continue
    (dst / "requirements.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def export_source(dst: Path):
    log(f"源码版 → {dst}")
    n = copy_clean_source(dst)
    (dst / ".gitignore").write_text(GITIGNORE, encoding="utf-8")
    write_requirements(dst)
    if not (dst / "README.md").exists():
        (dst / "README.md").write_text(README, encoding="utf-8")
    log(f"  {n} 个文件 + requirements.txt / .gitignore / README.md，共 {_size_mb(dst)} MB")


ROLE_FILES = ("staff.json", "avatars", "graph")   # 「带上员工和人设」：花名册 + 头像 + 只装人设训练的 RAG 库，不含对话记忆


def copy_roles(dst: Path):
    """员工花名册和头像拷进可执行版的 memory/：自己 DIY 的角色、训练出来的人设换电脑也带得走。"""
    src = ROOT / "memory"
    for name in ("staff.json", "avatars"):
        f = src / name
        if f.is_dir():
            shutil.copytree(f, dst / "memory" / name)
        elif f.is_file():
            (dst / "memory").mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst / "memory" / name)
    n = len(json.loads((src / "staff.json").read_text(encoding="utf-8"))) if (src / "staff.json").is_file() else 0
    trained = 0
    sys.path.insert(0, str(ROOT))
    from base.graphrag import Graph, shared_path
    try:                                          # 人设训练在共享 RAG 库里：只挑这些钉住的条目，装进一个新的空库
        src_g = Graph(shared_path())
        rows = src_g.q("SELECT text, source FROM passages WHERE pinned=1 AND source LIKE '%人设训练'")
        if rows:
            new_g = Graph(dst / "memory" / "graph" / "shared.sqlite")
            trained = sum(new_g.pin_text(r["text"], r["source"]) for r in rows)
            new_g.db.close()
        src_g.db.close()
    except Exception as e:
        log(f"  注意：人设训练没带上（{type(e).__name__}: {e}）")
    log(f"  员工和人设：花名册（{n} 项）+ 头像 + 人设训练（{trained} 条，进 RAG 库），不含对话记忆")


def export_exe(dst: Path, refresh: bool, roles: bool = False):
    log(f"可执行版 → {dst}")
    n = copy_clean_source(dst)
    log(f"  代码和素材：{n} 个文件")
    if roles:
        copy_roles(dst)
    make_runtime(force=refresh)
    log("  拷贝自带 Python（不带编译缓存）…")
    shutil.copytree(RUNTIME, dst / "runtime" / "python",
                    ignore=lambda d, names: [x for x in names if x == "__pycache__" or x.endswith((".pyc", ".pyo"))])
    compile_launcher(dst / "Terminist.exe")
    if not check_runtime(dst, dst / "runtime" / "python"):
        raise BuildError("可执行版自检没通过（见上面的输出）")
    log(f"  共 {_size_mb(dst)} MB")


# ---------------- 隐私扫描 ----------------
def _needles() -> tuple[list[bytes], list[bytes]]:
    """(哪里都不能出现的, 只在我们自己的文件里查的)。前者：用户目录路径（各种写法、UTF-8 / UTF-16）、API key；
    后者：用户名、电脑名（Python 自带的文件里可能碰巧有同名的贡献者，不查）。"""
    home = str(Path.home())
    forms = {home, home.replace("\\", "/"), home.replace("\\", "\\\\"), home.lower(), home.replace("\\", "/").lower()}
    everywhere = [f.encode(enc) for f in forms for enc in ("utf-8", "utf-16-le")]
    try:
        sys.path.insert(0, str(ROOT))
        from lib_a.config import get_api_key
        key = get_api_key()
        everywhere += [key.encode(), key.encode("utf-16-le")]
    except Exception:
        pass
    ours = []
    for v in (os.environ.get("USERNAME", ""), os.environ.get("COMPUTERNAME", "")):
        if len(v) >= 3:
            ours += [v.encode(), v.encode("utf-16-le")]
    return everywhere, ours


KEY_SHAPE = re.compile(rb"sk-[A-Za-z0-9]{24,}")


def privacy_scan(folder: Path) -> list[str]:
    everywhere, ours = _needles()
    hits = []
    for f in folder.rglob("*"):
        if not f.is_file():
            continue
        try:
            data = f.read_bytes()
        except OSError:
            continue
        rel = f.relative_to(folder).as_posix()
        in_runtime = rel.startswith("runtime/")       # Python 自带的文件：只查路径和 key 本身（别的会误报）
        low = data.lower()
        if any(n.lower() in low for n in everywhere):
            hits.append(f"{rel}：有本机用户目录路径 / API key")
        elif not in_runtime and any(n in data for n in ours):
            hits.append(f"{rel}：有用户名 / 电脑名")
        elif not in_runtime and KEY_SHAPE.search(data):
            hits.append(f"{rel}：有像 API key 的字符串")
    return hits


# ---------------- 一次完整的生成 ----------------
def targets(out: Path, source: bool, exe: bool) -> list[Path]:
    return ([out / SOURCE_NAME] if source else []) + ([out / EXE_NAME] if exe else [])


def check_out_dir(out: Path):
    out = out.resolve()
    if out == ROOT or ROOT in out.parents:
        raise BuildError("输出文件夹不能在 Terminist 文件夹里面（会把自己也拷进去），换一个")


def to_recycle_bin(path: Path):
    """旧的输出挪进回收站（能找回），不直接删。"""
    import ctypes
    from ctypes import wintypes as wt

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wt.HWND), ("wFunc", wt.UINT), ("pFrom", wt.LPCWSTR), ("pTo", wt.LPCWSTR),
                    ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wt.BOOL), ("hNameMappings", ctypes.c_void_p),
                    ("lpszProgressTitle", wt.LPCWSTR)]
    # ALLOWUNDO | NOCONFIRMATION | SILENT | NOERRORUI | WANTNUKEWARNING（太大进不了回收站时先问，不会悄悄永久删）
    op = SHFILEOPSTRUCTW(None, 3, str(path) + "\0", None, 0x0040 | 0x0010 | 0x0004 | 0x0400 | 0x4000, False, None, None)
    if ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) != 0 or path.exists():   # FO_DELETE + ALLOWUNDO
        raise BuildError(f"没法把旧的 {path} 挪进回收站（有文件开着？），关掉再试")


USED_MARKS = ("memory", "versions", "terminist_settings.json")     # 有这些 = 这份已经被拿来用过了


def check_not_used(dst: Path):
    """可执行版跑起来以后，对话记忆 / 存档 / 设置就写在它自己文件夹里：重新生成会把这些一起扔掉，不干。"""
    used = [m for m in USED_MARKS if (dst / m).exists()
            and not (m == "memory" and all(p.name in ROLE_FILES for p in (dst / m).iterdir()))]   # 只有带进去的员工 = 没用过
    if used:
        raise BuildError(f"{dst} 已经被用过（里面有 {'、'.join(used)}：你在那份里的对话记忆 / 设置），"
                         "重新生成会把它们一起扔掉。换一个输出文件夹，或者先把这些挪走")


def build_all(out: Path, source: bool = True, exe: bool = True, refresh: bool = False, roles: bool = False):
    """生成到 out 下（已有的同名输出要先挪走：调用方确认过才调）。成功返回输出的文件夹列表。"""
    t0 = time.time()
    check_out_dir(out)
    for dst in targets(out, source, exe):
        check_not_used(dst)
    out.mkdir(parents=True, exist_ok=True)
    make_icon()
    done = []
    for dst in targets(out, source, exe):
        if dst.exists():
            log(f"旧的 {dst.name} 挪进回收站")
            to_recycle_bin(dst)
        dst.mkdir(parents=True)
        export_source(dst) if dst.name == SOURCE_NAME else export_exe(dst, refresh, roles)
        done.append(dst)
    log("隐私扫描…")
    bad = [f"{d.name}/{h}" for d in done for h in privacy_scan(d)]
    if bad:
        raise BuildError("隐私扫描没通过，这些文件里有本机信息：\n  " + "\n  ".join(bad[:30]))
    log("隐私扫描：通过（没有本机用户目录、用户名、电脑名、API key）")
    log(f"全部完成，用时 {time.time() - t0:.0f} 秒")
    return done


# ---------------- 窗口 ----------------
def run_ui():
    import queue
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    bg, panel, fg, dim, green = "#16181d", "#1f2229", "#e8ecef", "#8b93a1", "#39ff88"
    try:                                              # 先声明认得高 DPI，再建窗口：不然 200% 缩放下字是糊的
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    root.title("Terminist 打包")
    root.configure(bg=bg)
    k = root.winfo_fpixels("1i") / 96                 # 系统缩放倍数：窗口尺寸跟着放大
    w = min(int(760 * k), root.winfo_screenwidth() - 40)
    h = min(int(560 * k), root.winfo_screenheight() - int(90 * k))      # 别被任务栏挡住底部的按钮
    root.geometry(f"{w}x{h}+{(root.winfo_screenwidth() - w) // 2}+{max(0, (root.winfo_screenheight() - h) // 2 - int(30 * k))}")
    root.minsize(int(560 * k), int(440 * k))
    try:
        root.iconbitmap(str(ICO))
    except tk.TclError:
        pass
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=bg, foreground=fg, fieldbackground=panel, font=("Microsoft YaHei UI", 10))
    style.configure("TCheckbutton", background=bg, foreground=fg, indicatorbackground=panel,
                    indicatorforeground=green, indicatormargin=(0, 0, int(8 * k), 0), indicatorsize=int(15 * k))
    style.map("TCheckbutton", background=[("active", bg)], indicatorbackground=[("selected", panel)])
    style.configure("TButton", background=panel, foreground=fg, borderwidth=0, padding=(14, 6))
    style.map("TButton", background=[("active", "#2a2e37"), ("disabled", bg)], foreground=[("disabled", dim)])
    style.configure("Go.TButton", background=green, foreground="#0b0d10", font=("Microsoft YaHei UI", 10, "bold"))
    style.map("Go.TButton", background=[("active", "#7dffb4"), ("disabled", "#2a2e37")])
    style.configure("TEntry", fieldbackground=panel, foreground=fg, insertcolor=fg, borderwidth=0)
    style.configure("green.Horizontal.TProgressbar", background=green, troughcolor=panel, borderwidth=0)

    frm = tk.Frame(root, bg=bg, padx=int(18 * k), pady=int(16 * k))
    frm.pack(fill="both", expand=True)
    wrapped = []                                      # 跟着窗口宽度自动换行的说明文字

    def note(parent, text, **kw):
        lab = tk.Label(parent, text=text, bg=bg, fg=dim, justify="left", anchor="w")
        lab.pack(fill="x", **kw)
        wrapped.append(lab)
        return lab
    frm.bind("<Configure>", lambda e: [w.configure(wraplength=max(100, e.width - int(40 * k))) for w in wrapped])
    tk.Label(frm, text="TERMINIST 打包", bg=bg, fg=green, font=("Microsoft YaHei UI", 16, "bold")).pack(anchor="w")
    note(frm, "选一个文件夹，生成干净的版本：不带对话记忆、改造存档、本机路径、API key。", pady=(2, 12))

    row = tk.Frame(frm, bg=bg)
    row.pack(fill="x")
    tk.Label(row, text="输出到", bg=bg, fg=fg).pack(side="left")
    out_var = tk.StringVar(value=str(Path.home() / "Desktop" / "Terminist-build"))
    ttk.Entry(row, textvariable=out_var).pack(side="left", fill="x", expand=True, padx=8, ipady=4)

    def pick():
        d = filedialog.askdirectory(title="选输出文件夹", initialdir=str(Path(out_var.get()).parent))
        if d:
            out_var.set(str(Path(d)))
    ttk.Button(row, text="选择…", command=pick).pack(side="left")

    src_var, exe_var, ref_var = tk.BooleanVar(value=True), tk.BooleanVar(value=True), tk.BooleanVar(value=False)
    role_var = tk.BooleanVar(value=True)
    opts = tk.Frame(frm, bg=bg)
    opts.pack(fill="x", pady=(int(12 * k), int(6 * k)))
    for var, title, desc in (
            (src_var, f"源码版　{SOURCE_NAME}/", "只有代码和素材，带 requirements.txt / .gitignore / README，可以直接传 GitHub"),
            (exe_var, f"可执行版　{EXE_NAME}/", "自带 Python（约 500 MB），整个文件夹拷到干净的 Windows，双击 Terminist.exe 就能用"),
            (role_var, "可执行版带上员工和人设", "花名册、头像、角色训练出来的人设（只带这些 RAG 条目）一起带走，不含对话记忆；"
                                           "这是你自己的东西，这份就别公开分享了。源码版永远不带"),
            (ref_var, "重新拷贝自带 Python", "升级过 Python 或第三方库之后勾上；平常不用")):
        ttk.Checkbutton(opts, variable=var, text=title).pack(anchor="w", pady=(int(4 * k), 0))
        note(opts, desc, padx=(int(26 * k), 0))

    bar = ttk.Progressbar(frm, mode="determinate", value=0, style="green.Horizontal.TProgressbar")
    bar.pack(fill="x", pady=(10, 8))
    btns = tk.Frame(frm, bg=bg)                       # 按钮先占住底部，日志框再填剩下的空间
    btns.pack(side="bottom", fill="x", pady=(int(10 * k), 0))
    box = tk.Text(frm, bg=panel, fg=fg, insertbackground=fg, relief="flat", font=("Consolas", 10), wrap="word",
                  padx=10, pady=8, height=8, state="disabled")
    box.pack(fill="both", expand=True)
    box.tag_configure("bad", foreground="#ff6b6b")
    box.tag_configure("good", foreground=green)

    open_btn = ttk.Button(btns, text="打开输出文件夹", state="disabled",
                          command=lambda: os.startfile(out_var.get()))
    open_btn.pack(side="right")
    go = ttk.Button(btns, text="开始生成", style="Go.TButton")
    go.pack(side="right", padx=8)

    q: "queue.Queue" = queue.Queue()

    def write(text, tag=None):
        box.configure(state="normal")
        box.insert("end", text + "\n", tag)
        box.see("end")
        box.configure(state="disabled")

    def pump():
        try:
            while True:
                kind, text = q.get_nowait()
                if kind == "log":
                    write(text)
                else:
                    bar.stop()
                    bar.configure(mode="determinate", value=100 if kind == "ok" else 0)
                    go.configure(state="normal")
                    write(text, "good" if kind == "ok" else "bad")
                    if kind == "ok":
                        open_btn.configure(state="normal")
        except queue.Empty:
            pass
        root.after(80, pump)

    def start():
        global _log
        out = Path(out_var.get().strip().strip('"'))
        if not out_var.get().strip():
            messagebox.showwarning("Terminist 打包", "先选一个输出文件夹")
            return
        if not (src_var.get() or exe_var.get()):
            messagebox.showwarning("Terminist 打包", "源码版、可执行版至少勾一个")
            return
        try:
            check_out_dir(out)
        except BuildError as e:
            messagebox.showerror("Terminist 打包", str(e))
            return
        old = [d for d in targets(out, src_var.get(), exe_var.get()) if d.exists()]
        if old and not messagebox.askyesno("Terminist 打包", "这些已经存在：\n\n" + "\n".join(str(d) for d in old)
                                            + "\n\n挪进回收站，重新生成？"):
            return
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.configure(state="disabled")
        go.configure(state="disabled")
        open_btn.configure(state="disabled")
        bar.configure(mode="indeterminate")
        bar.start(12)
        _log = lambda t: q.put(("log", t))

        def work():
            try:
                done = build_all(out, src_var.get(), exe_var.get(), ref_var.get(), role_var.get())
                q.put(("ok", "好了：\n" + "\n".join(f"  {d}" for d in done)))
            except BuildError as e:
                q.put(("fail", "失败：" + str(e)))
            except Exception as e:
                import traceback
                q.put(("fail", f"出错：{type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}"))
        threading.Thread(target=work, daemon=True).start()

    go.configure(command=start)
    pump()
    root.mainloop()


def main():
    if sys.platform != "win32":
        sys.exit("打包只做 Windows 版；其他系统直接 python run.py")
    args = sys.argv[1:]
    try:
        if "--here" in args:                          # 开发用：就地放 runtime/ + Terminist.exe
            make_icon()
            make_runtime(force="--refresh" in args)
            compile_launcher(EXE)
            if not check_runtime(ROOT, RUNTIME):
                sys.exit(1)
            if "--shortcut" in args:
                make_shortcut(Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Terminist.lnk", EXE)
            if "--desktop" in args:
                make_shortcut(Path.home() / "Desktop" / "Terminist.lnk", EXE)
            return
        if "--out" in args:
            i = args.index("--out")
            if i + 1 >= len(args):
                sys.exit("--out 后面要跟文件夹")
            out = Path(args[i + 1])
            src, exe = "--source" in args, "--exe" in args
            if not (src or exe):
                src = exe = True
            old = [d for d in targets(out, src, exe) if d.exists()]
            if old and "--force" not in args:
                sys.exit("已经存在：" + ", ".join(map(str, old)) + "（加 --force 把旧的挪进回收站再生成）")
            build_all(out, src, exe, "--refresh" in args, "--roles" in args)
            return
    except BuildError as e:
        sys.exit("失败：" + str(e))
    run_ui()


if __name__ == "__main__":
    main()
