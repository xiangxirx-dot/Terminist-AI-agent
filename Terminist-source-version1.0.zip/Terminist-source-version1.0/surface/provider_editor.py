"""
AI 接口编辑器：新建 / 修改一个 OpenAI 兼容的 AI 接口（名字、地址、API key、主模型、快模型）。

单独一个小窗口进程（tkinter：输入法、粘贴都现成），顶栏「隐私」里点「＋ 添加接口」或某个接口的「编辑」时起它：
  python -m surface.provider_editor <接口 id>     改已有的
  python -m surface.provider_editor --new         新建（先选预设）
key 直接用 Windows 账户加密存盘（lib_a/config.py），不经过 Agent；输入框只显示圆点。
最后一行往标准输出打一行纯 ASCII 的 JSON：{"saved": id, "restart": 在用的接口地址 / 模型变了, "key_changed": ...}
/ {"deleted": id} / {}（取消），主界面读到就刷新列表，必要时重启或换上新 key。
"""

import json
import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from lib_a import config as cfg                 # noqa: E402


def run(pid: str | None):
    import tkinter as tk
    from tkinter import messagebox, ttk
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    is_new = not pid
    data = cfg.load_providers()
    if not is_new and pid not in data["providers"]:
        print(json.dumps({"error": f"没有这个接口：{pid}"}))
        return
    info = {} if is_new else dict(data["providers"][pid])
    active = (not is_new) and pid == data["active"]
    has_key = (not is_new) and cfg.key_source(pid) != "none"
    result = {}

    bg, panel, fg, dim, green, red = "#16181d", "#1f2229", "#e8ecef", "#8b93a1", "#39ff88", "#ff6b6b"
    root = tk.Tk()
    root.title("添加 AI 接口" if is_new else f"编辑 AI 接口：{info.get('name') or pid}")
    root.configure(bg=bg)
    k = root.winfo_fpixels("1i") / 96
    w = min(int(600 * k), root.winfo_screenwidth() - 40)
    h = min(int(640 * k), root.winfo_screenheight() - int(90 * k))
    root.geometry(f"{w}x{h}+{(root.winfo_screenwidth() - w) // 2}+{max(0, (root.winfo_screenheight() - h) // 2 - int(30 * k))}")
    root.minsize(int(460 * k), int(520 * k))
    try:
        root.iconbitmap(str(ROOT / "icon.ico"))
    except tk.TclError:
        pass
    root.attributes("-topmost", True)
    root.after(400, lambda: root.attributes("-topmost", False))
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=bg, foreground=fg, fieldbackground=panel, font=("Microsoft YaHei UI", 10))
    style.configure("TButton", background=panel, foreground=fg, borderwidth=0, padding=(14, 6))
    style.map("TButton", background=[("active", "#2a2e37"), ("disabled", bg)], foreground=[("disabled", dim)])
    style.configure("Go.TButton", background=green, foreground="#0b0d10", font=("Microsoft YaHei UI", 10, "bold"))
    style.map("Go.TButton", background=[("active", "#7dffb4")])
    style.configure("Del.TButton", background=panel, foreground=red)
    style.map("Del.TButton", background=[("active", "#3a2228")])
    style.configure("TEntry", fieldbackground=panel, foreground=fg, insertcolor=fg, borderwidth=0)
    style.configure("TCombobox", fieldbackground=panel, foreground=fg, background=panel, arrowcolor=fg)
    style.map("TCombobox", fieldbackground=[("readonly", panel)], foreground=[("readonly", fg)])
    root.option_add("*TCombobox*Listbox.background", panel)
    root.option_add("*TCombobox*Listbox.foreground", fg)

    frm = tk.Frame(root, bg=bg, padx=int(18 * k), pady=int(16 * k))
    frm.pack(fill="both", expand=True)

    def label(text, note=None):
        tk.Label(frm, text=text, bg=bg, fg=dim).pack(anchor="w", pady=(int(12 * k), int(3 * k)))
        if note:
            tk.Label(frm, text=note, bg=bg, fg=dim, justify="left", anchor="w",
                     wraplength=w - int(60 * k)).pack(anchor="w", pady=(0, int(3 * k)))

    name_var = tk.StringVar(value=str(info.get("name") or ""))
    url_var = tk.StringVar(value=str(info.get("base_url") or ""))
    key_var = tk.StringVar()
    main_var = tk.StringVar(value=str(info.get("main") or ""))
    fast_var = tk.StringVar(value=str(info.get("fast") or ""))
    preset_var = tk.StringVar()

    if is_new:                                         # 新建：先选预设，地址自动填好
        label("选一家（地址会自动填好；不在列表里的选「自定义」）")
        names = [p["name"] for p in cfg.PRESETS.values()]
        box = ttk.Combobox(frm, textvariable=preset_var, values=names, state="readonly")
        box.pack(fill="x", ipady=int(3 * k))

        def on_preset(*_):
            key = next((kk for kk, p in cfg.PRESETS.items() if p["name"] == preset_var.get()), "custom")
            p = cfg.PRESETS[key]
            name_var.set(p["name"] if key != "custom" else "")
            url_var.set(p.get("base_url", ""))
            main_var.set(p.get("main", ""))
            fast_var.set(p.get("fast", ""))
        box.bind("<<ComboboxSelected>>", on_preset)

    label("名字（列表里显示的）")
    ttk.Entry(frm, textvariable=name_var).pack(fill="x", ipady=int(4 * k))
    label("接口地址（OpenAI 兼容，一般以 /v1 结尾）")
    ttk.Entry(frm, textvariable=url_var).pack(fill="x", ipady=int(4 * k))
    cur = ""
    if has_key:
        try:
            cur = cfg.mask_key(cfg.get_api_key(pid))
        except NotImplementedError:
            cur = ""
    label("API key", f"留空 = 不改（现在：{cur}）" if cur else "只存在这台电脑上，用 Windows 账户加密，Agent 读不到")
    key_entry = ttk.Entry(frm, textvariable=key_var, show="•")
    key_entry.pack(fill="x", ipady=int(4 * k))

    label("主模型（想方案、写代码）/ 快模型（前台闲聊、助手、记忆整理；不填就用主模型）",
          "点「拉取模型列表」从这个接口查有哪些模型，再从下拉里选；也可以直接打名字。")
    mrow = tk.Frame(frm, bg=bg)
    mrow.pack(fill="x")
    main_box = ttk.Combobox(mrow, textvariable=main_var)
    main_box.pack(side="left", fill="x", expand=True, ipady=int(3 * k))
    fast_box = ttk.Combobox(mrow, textvariable=fast_var)
    fast_box.pack(side="left", fill="x", expand=True, ipady=int(3 * k), padx=(int(8 * k), 0))

    status = tk.Label(frm, text="", bg=bg, fg=dim, justify="left", anchor="w", wraplength=w - int(60 * k))
    tools = tk.Frame(frm, bg=bg)
    tools.pack(fill="x", pady=(int(10 * k), 0))
    status.pack(fill="x", pady=(int(8 * k), 0))

    def the_key() -> str:
        typed = key_var.get().strip()
        if typed:
            return typed
        if has_key:
            try:
                return cfg.get_api_key(pid)
            except NotImplementedError:
                return ""
        return ""

    def say(text, color=dim):
        root.after(0, lambda: status.configure(text=text, fg=color))

    def fetch_models():
        url, key = url_var.get().strip(), the_key()
        if not url or not key:
            say("先填接口地址和 key", red)
            return
        say("正在拉取模型列表…")

        def work():
            try:
                import openai
                ids = sorted(m.id for m in openai.OpenAI(api_key=key, base_url=url, timeout=20, max_retries=0).models.list())
            except Exception as e:
                say(f"拉不到模型列表（{type(e).__name__}）：检查地址和 key；也可以直接把模型名打进去", red)
                return

            def done():
                main_box.configure(values=ids)
                fast_box.configure(values=ids)
                status.configure(text=f"拉到 {len(ids)} 个模型，从下拉里选", fg=green)
            root.after(0, done)
        threading.Thread(target=work, daemon=True).start()

    def test():
        url, key = url_var.get().strip(), the_key()
        if not url or not key:
            say("先填接口地址和 key", red)
            return
        say("正在试连接…")

        def work():
            from surface import check_api_key
            ok, msg = check_api_key(key, url, name_var.get().strip() or "这个接口")
            say("能连上，key 有效" if ok else msg, green if ok else red)
        threading.Thread(target=work, daemon=True).start()

    ttk.Button(tools, text="拉取模型列表", command=fetch_models).pack(side="left")
    ttk.Button(tools, text="测试连接", command=test).pack(side="left", padx=(int(8 * k), 0))

    btns = tk.Frame(frm, bg=bg)
    btns.pack(side="bottom", fill="x", pady=(int(14 * k), 0))

    def save():
        name, url = name_var.get().strip(), url_var.get().strip().rstrip("/")
        if not url.startswith(("http://", "https://")):
            messagebox.showwarning("保存", "接口地址要以 http:// 或 https:// 开头", parent=root)
            return
        if not name:
            messagebox.showwarning("保存", "起个名字吧", parent=root)
            return
        new_id = pid or cfg.new_provider_id(next((kk for kk, p in cfg.PRESETS.items()
                                                  if p["name"] == preset_var.get()), "custom"))
        old = cfg.provider(new_id) if not is_new else {}
        cfg.upsert_provider(new_id, name, url, main_var.get(), fast_var.get())
        typed = key_var.get().strip()
        if typed:
            cfg.set_api_key(typed, new_id)
        changed = any(str(old.get(f) or "").strip().rstrip("/") != str(v).strip().rstrip("/")
                      for f, v in (("base_url", url), ("main", main_var.get()), ("fast", fast_var.get())))
        result.update(saved=new_id, new=is_new, restart=bool(active and changed), key_changed=bool(typed))
        root.destroy()

    def delete():
        if not messagebox.askyesno("删除接口", f"删掉「{name_var.get() or pid}」和它保存的 key？", parent=root):
            return
        why = cfg.remove_provider(pid)
        if why:
            messagebox.showwarning("删除接口", why, parent=root)
            return
        result.update(deleted=pid)
        root.destroy()

    ttk.Button(btns, text="保存", style="Go.TButton", command=save).pack(side="right")
    ttk.Button(btns, text="取消", command=root.destroy).pack(side="right", padx=int(8 * k))
    if not is_new and pid != cfg.DEFAULT_PROVIDER and not active:
        ttk.Button(btns, text="删除这个接口", style="Del.TButton", command=delete).pack(side="left")
    elif active:
        tk.Label(btns, text="正在用：改地址 / 模型会重启 Terminist", bg=bg, fg=dim).pack(side="left")

    root.bind("<Escape>", lambda e: root.destroy())
    root.mainloop()
    print(json.dumps(result))                          # 纯 ASCII：无窗口进程的输出编码是系统 GBK，主界面按 UTF-8 读也不会乱


if __name__ == "__main__":
    args = sys.argv[1:]
    run(None if not args or args[0] == "--new" else args[0])
