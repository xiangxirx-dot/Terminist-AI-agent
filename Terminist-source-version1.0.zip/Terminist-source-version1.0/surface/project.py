"""
投影壳
------
屏幕上的用户看到的是一个常驻的「投影壳」窗口（无边框、置顶）：壳只负责显示画面，
真正的窗口（真窗口）在屏幕外运行，把每一帧写成 BMP 放进帧交换目录，壳按 mtime
发现新帧就重新 load + blit + flip。用户点壳 = 壳窗口被激活，壳收到的键鼠事件编码
成 JSON 行 append 到事件队列，真窗口 poll 后 pygame.event.post 注入自己的队列，
所以真窗口本身从来不抢焦点。

任何一步失败都静默跳过：投影不能影响主流程。不弹控制台，不阻塞主循环。
只依赖 pygame / os / subprocess / sys / time / json / pathlib，不 import surface.gui。
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

SHELL_ENV = "TERMINIST_SHELL_ENV"            # 新进程读它：自己该往哪个帧目录写
PROJ_DIR = Path.home() / ".terminist" / "proj"
FRAME_DIR = PROJ_DIR / "frames"              # 帧交换目录：真窗口写 <pid>.bmp，壳读完改名 <pid>.done
EV_DIR = PROJ_DIR / "ev"                     # 事件队列：壳 append <pid>.jsonl
FLAG = PROJ_DIR / "shell.flag"               # {"pid": 壳的 pid, "rect": [...], "frames": ..., "ev": ...}
TARGET = PROJ_DIR / "target.pid"             # 真窗口启动时写自己的 pid（一行数字）
KILL = PROJ_DIR / "shell.kill"               # 存在就让壳退出并删掉自己
# 帧走共享内存（不写文件、不编码）：真窗口把像素（BGRA）写进命名共享内存 Terminist_proj_<pid>，壳直接读。
# 以前每帧存一张 11MB 的 BMP（55ms/帧）再从磁盘读，主循环被拖到 8fps；共享内存写 ~10ms、读 + 贴 ~5ms。
# 头部 32 字节：seq(u64) w(u32) h(u32)；seq 最后写，壳看到 seq 变了才读，读到的一定是完整的一帧。
try:                                         # 壳代码的版本：壳跨重启一直活着，代码改了要换一个新壳，不然新功能永远用不上
    import hashlib as _hashlib
    SHELL_VERSION = _hashlib.sha1(Path(__file__).read_bytes()).hexdigest()[:12]
except OSError:
    SHELL_VERSION = ""
SHM_PREFIX = "Terminist_proj_"
SHM_HEADER = 32
SHM_CAP = SHM_HEADER + 3840 * 2400 * 4      # 最大支持 3840x2400 的窗口；更大就不送（壳 8 秒没画面会自己退，真窗口回屏幕）
FAILED = PROJ_DIR / "shell.failed"           # 壳显示不出画面时写这个再自己退出：真窗口看到就回屏幕上
SHOW_TIMEOUT = 8.0                           # 这么多秒一帧都没显示成功 → 判失败（别挂着一块黑窗口盖住屏幕）
LOG_DIR = Path.home() / ".terminist" / "logs"
MAX_EVENT_BYTES = 256 * 1024                 # 事件文件上限：超了直接清空，别涨成天文数字
SCAN_HZ = 60                                 # 壳扫帧 / 收事件的节奏（30 时每次输入到上屏多等一帧）

# textinput / textediting：输入法（拼写中的文字、确定上屏的文字）。壳拿着焦点，输入法的事件只有壳收得到，必须转过去
EVENT_TYPES = ("mousemotion", "mousedown", "mouseup", "mousewheel", "keydown", "keyup", "textinput", "textediting")


# ---------------- 尺寸 → 纯函数 ----------------

def shell_size_for(size, desk):
    """把想要的尺寸夹进桌面范围，返回 (w, h)；desk 非法时原样返回；size 非法返回 None。"""
    try:
        if not isinstance(size, (list, tuple)) or len(size) != 2:
            return None
        w, h = int(size[0]), int(size[1])
        if w <= 0 or h <= 0:
            return None
        if isinstance(desk, (list, tuple)) and len(desk) == 2:
            dw, dh = int(desk[0]), int(desk[1])
            if dw > 0 and dh > 0:
                w = min(w, dw)
                h = min(h, dh)
        return w, h
    except (TypeError, ValueError):
        return None


def shell_rect_for(pos, size, desk):
    """把位置和尺寸夹到桌面内，返回 (x, y, w, h)；参数非法返回 None。"""
    got = shell_size_for(size, desk)
    if got is None:
        return None
    try:
        if not isinstance(pos, (list, tuple)) or len(pos) != 2:
            return None
        x, y = int(pos[0]), int(pos[1])
    except (TypeError, ValueError):
        return None
    w, h = got
    if isinstance(desk, (list, tuple)) and len(desk) == 2:
        try:
            dw, dh = int(desk[0]), int(desk[1])
        except (TypeError, ValueError):
            dw, dh = 0, 0
        if dw > 0 and dh > 0:
            x = max(0, min(x, dw - w))
            y = max(0, min(y, dh - h))
    return x, y, w, h


def proj_rect(pos, size, desk):
    """旧名字，等价于 shell_rect_for（外部还在用）。"""
    return shell_rect_for(pos, size, desk)


# ---------------- 帧交换目录 ----------------

def frame_dir() -> Path:
    """帧交换目录 ~/.terminist/proj/frames/，建不出来也不报错。"""
    try:
        FRAME_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return FRAME_DIR


def frame_path(pid) -> Path:
    """真窗口这一帧写到哪：<pid>.bmp。"""
    return frame_dir() / f"{int(pid)}.bmp"


def write_frame(pid, data):
    """真窗口写帧：先落 <pid>.tmp 再 os.replace 成 <pid>.bmp（原子），顺手清掉更老的帧。"""
    try:
        pid = int(pid)
        if pid <= 0:
            return None
        d = frame_dir()
        tmp = d / f"{pid}.tmp"
        tmp.write_bytes(data)
        out = d / f"{pid}.bmp"
        os.replace(tmp, out)
        _prune_frames(out)
        return out
    except Exception:
        return None


def _prune_frames(keep):
    """只删比 keep 更老的帧，绝不删 keep 自己（壳手上永远有一张能读的）。"""
    try:
        keep_m = keep.stat().st_mtime_ns
        files = [f for f in FRAME_DIR.iterdir() if f.is_file()]
    except OSError:
        return
    for f in files:
        try:
            if f == keep or f.stat().st_mtime_ns >= keep_m:
                continue
            f.unlink()
        except OSError:
            pass


# ---------------- 事件通道：JSON 行 ----------------

def ev_path(pid) -> Path:
    """这个真窗口的事件队列文件：<pid>.jsonl。"""
    return EV_DIR / f"{int(pid)}.jsonl"


def encode_event(ev) -> str:
    """pygame 事件字典 → 一行 JSON；不认识的事件返回空串。"""
    if not isinstance(ev, dict):
        return ""
    kind = ev.get("type")
    if kind not in EVENT_TYPES:
        return ""
    out = {"type": kind}
    if kind == "mousemotion":
        out["x"] = _int(ev.get("x"))
        out["y"] = _int(ev.get("y"))
    elif kind in ("mousedown", "mouseup"):
        out["x"] = _int(ev.get("x"))
        out["y"] = _int(ev.get("y"))
        out["button"] = _int(ev.get("button"))
        out["mod"] = _int(ev.get("mod"))
    elif kind == "mousewheel":
        out["x"] = _int(ev.get("x"))
        out["y"] = _int(ev.get("y"))
        out["mod"] = _int(ev.get("mod"))
    elif kind == "textinput":
        out["text"] = str(ev.get("text") or "")[:256]
    elif kind == "textediting":
        out["text"] = str(ev.get("text") or "")[:256]
        out["start"] = _int(ev.get("start"))
        out["length"] = _int(ev.get("length"))
    else:                                       # keydown / keyup
        out["key"] = str(ev.get("key") or "")[:32]
        out["mod"] = _int(ev.get("mod"))
    try:
        return json.dumps(out, ensure_ascii=False)
    except (TypeError, ValueError):
        return ""


def decode_events(text) -> list:
    """事件队列文本 → 事件字典列表；坏行直接跳过。"""
    out = []
    if not text:
        return out
    for line in str(text).splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if isinstance(ev, dict) and ev.get("type") in EVENT_TYPES:
            out.append(ev)
    return out


def drain_events(pid) -> list:
    """真窗口 poll：读到文本后把文件清空（容忍并发 / 异常）。"""
    try:
        p = ev_path(pid)
        text = p.read_text(encoding="utf-8", errors="ignore")
    except (OSError, TypeError, ValueError):
        return []
    if not text:
        return []
    try:
        with open(p, "w", encoding="utf-8"):
            pass                                 # 清空：壳之后 append 的还是新内容
    except OSError:
        pass
    return decode_events(text)


def _append_event(pid, line):
    """壳 side：把一行事件 append 到 <pid>.jsonl，超过上限就先清空。"""
    if not line:
        return
    try:
        pid = int(pid)
        if pid <= 0:
            return
        EV_DIR.mkdir(parents=True, exist_ok=True)
        p = ev_path(pid)
        try:
            if p.stat().st_size > MAX_EVENT_BYTES:
                with open(p, "w", encoding="utf-8"):
                    pass
        except OSError:
            pass
        with open(p, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except (OSError, TypeError, ValueError):
        pass


def _int(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


# ---------------- Win32：置顶 / 跳任务栏（pygame-ce 拿不到这些标志，只能自己调 API） ----------------

def get_hwnd():
    """从 pygame 拿壳窗口的 HWND；没有 display 或失败返回 None。"""
    try:
        import pygame
        info = pygame.display.get_wm_info()
        h = info.get("window") if isinstance(info, dict) else None
        return int(h) if h else None
    except Exception:
        return None


def make_topmost(hwnd) -> bool:
    """把窗口钉在最上层（HWND_TOPMOST = -1）；非 win32 / 拿不到 hwnd 返回 False。"""
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        import ctypes
        swp = 0x0002 | 0x0001 | 0x0010         # SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE
        ok = ctypes.windll.user32.SetWindowPos(int(hwnd), -1, 0, 0, 0, 0, swp)
        return bool(ok)
    except Exception:
        return False


def hide_from_taskbar(hwnd) -> bool:
    """加 WS_EX_TOOLWINDOW、去掉 WS_EX_APPWINDOW：壳不出现在任务栏。"""
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        import ctypes
        u = ctypes.windll.user32
        gwl_exstyle = -20
        ws_ex_toolwindow, ws_ex_appwindow = 0x00000080, 0x00040000
        if hasattr(u, "GetWindowLongPtrW"):             # 64 位
            get, put = u.GetWindowLongPtrW, u.SetWindowLongPtrW
        else:                                           # 32 位回退
            get, put = u.GetWindowLongW, u.SetWindowLongW
        style = get(int(hwnd), gwl_exstyle)
        style = (style | ws_ex_toolwindow) & ~ws_ex_appwindow
        put(int(hwnd), gwl_exstyle, style)
        return True
    except Exception:
        return False


def _flag_hwnd() -> int:
    """从 shell.flag 读壳的 HWND；读不到返回 0。"""
    try:
        data = json.loads(FLAG.read_text(encoding="utf-8"))
        return _int(data.get("hwnd") or 0)
    except (OSError, ValueError, TypeError, AttributeError):
        return 0


def ensure_topmost() -> bool:
    """壳还活着就把它重新钉到最上层（hwnd 从 shell.flag 读）。"""
    if not shell_alive():
        return False
    return make_topmost(_flag_hwnd())


def _patch_flag_hwnd(hwnd):
    """只改 shell.flag 里的 hwnd 字段，其它字段原样保留。"""
    try:
        data = json.loads(FLAG.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    data["hwnd"] = _int(hwnd)
    try:
        PROJ_DIR.mkdir(parents=True, exist_ok=True)
        FLAG.write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


# ---------------- 进程：起壳 / 查活 / 杀壳 ----------------

def _pythonw() -> str:
    """子进程用 pythonw.exe（不需要控制台窗口）。"""
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    if sys.platform == "win32" and exe.name.lower() == "python.exe" and w.is_file():
        return str(w)
    return str(exe)


def _alive(pid) -> bool:
    """pid 还活着吗：Windows 用 ctypes OpenProcess，其他平台 os.kill(pid, 0)。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if sys.platform == "win32":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)        # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            try:
                code = ctypes.c_ulong(0)
                if not k.GetExitCodeProcess(h, ctypes.byref(code)):
                    return False
                return code.value == 259                 # STILL_ACTIVE
            finally:
                k.CloseHandle(h)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _write_flag(pid, rect, hwnd=0):
    """原子写 shell.flag（先写临时文件再改名）：另一个进程读的时候不会读到半截、写成缺字段的样子。"""
    try:
        PROJ_DIR.mkdir(parents=True, exist_ok=True)
        tmp = FLAG.with_name(f"shell.flag.{os.getpid()}.tmp")
        tmp.write_text(json.dumps({"pid": int(pid), "rect": [int(v) for v in rect], "hwnd": _int(hwnd),
                                   "frames": str(FRAME_DIR), "ev": str(EV_DIR), "ver": SHELL_VERSION}),
                       encoding="utf-8")
        os.replace(tmp, FLAG)
    except (OSError, TypeError, ValueError):
        pass


def _flag_version() -> str:
    try:
        return str(json.loads(FLAG.read_text(encoding="utf-8")).get("ver") or "")
    except (OSError, ValueError, TypeError, AttributeError):
        return ""


def _flag_pid() -> int:
    try:
        data = json.loads(FLAG.read_text(encoding="utf-8"))
        return int(data.get("pid") or 0)
    except (OSError, ValueError, TypeError, AttributeError):
        return 0


def shell_alive() -> bool:
    """投影壳还活着吗。"""
    pid = _flag_pid()
    return bool(pid) and _alive(pid)


def kill_shell() -> bool:
    """让壳自己退：写 shell.kill，壳看到就删掉它并退出；同时清掉 shell.flag。"""
    try:
        PROJ_DIR.mkdir(parents=True, exist_ok=True)
        KILL.write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass
    try:
        FLAG.unlink()
    except OSError:
        pass
    return True


def write_target(pid):
    """真窗口启动时把自己 pid 写进 target.pid（壳照这个决定事件写哪个文件）。"""
    try:
        PROJ_DIR.mkdir(parents=True, exist_ok=True)
        TARGET.write_text(str(int(pid)), encoding="utf-8")
        return True
    except (OSError, TypeError, ValueError):
        return False


def spawn_shell(rect):
    """起一个独立进程的投影壳，返回壳 pid；已经有活着的壳就直接返回它；失败 None。"""
    try:
        r = [int(v) for v in rect]
    except (TypeError, ValueError):
        return None
    if len(r) != 4 or r[2] <= 0 or r[3] <= 0:
        return None
    old = _flag_pid()
    if old and _alive(old):
        if _flag_version() == SHELL_VERSION:
            ensure_topmost()                    # 复用旧壳：顺手把它重新钉到最上层
            return old
        kill_shell()                            # 旧壳跑的是旧代码：换一个（只在代码改过之后的第一次重启发生）
        for _ in range(30):
            if not _alive(old):
                break
            time.sleep(0.1)
        if not _alive(old):
            try:
                KILL.unlink()                   # 旧壳没来得及删的 kill 文件：别让新壳一出生就看到它退掉
            except OSError:
                pass
    frame_dir()
    try:
        EV_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    root = str(Path(__file__).resolve().parent.parent)
    code = ("import sys; sys.path.insert(0, %r); from surface.project import shell_main; "
            "shell_main(%r)" % (root, r))
    kw = dict(cwd=root, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
              stderr=subprocess.DEVNULL, close_fds=True)
    try:
        if sys.platform == "win32":
            detached, group, breakaway = 0x00000008, 0x00000200, 0x01000000
            try:
                proc = subprocess.Popen([_pythonw(), "-c", code],
                                        creationflags=detached | group | breakaway, **kw)
            except OSError:                             # 不让跳出 Job 时退而求其次
                proc = subprocess.Popen([_pythonw(), "-c", code],
                                        creationflags=detached | group, **kw)
        else:
            proc = subprocess.Popen([_pythonw(), "-c", code], start_new_session=True, **kw)
    except Exception:
        return None
    _write_flag(proc.pid, r)
    return proc.pid


# ---------------- 壳本体 ----------------

def _read_target(prev) -> int:
    """读 target.pid；读不到就沿用上一次的 pid。"""
    try:
        text = TARGET.read_text(encoding="utf-8", errors="ignore").strip()
        pid = int(text.split()[0])
        return pid if pid > 0 else prev
    except (OSError, ValueError, IndexError):
        return prev


def _latest_frame(pid):
    """当前该显示哪张 .bmp：优先 target 的 <pid>.bmp，否则目录里 mtime 最新的。"""
    try:
        if pid:
            p = frame_path(pid)
            if p.is_file():
                return p
        best, best_m = None, -1
        for f in FRAME_DIR.glob("*.bmp"):
            try:
                m = f.stat().st_mtime_ns
            except OSError:
                continue
            if m > best_m:
                best, best_m = f, m
        return best
    except OSError:
        return None


class FrameWriter:
    """真窗口这边：把 pygame Surface 写进自己的共享内存。"""

    def __init__(self, pid):
        import mmap
        self.mm = mmap.mmap(-1, SHM_CAP, tagname=f"{SHM_PREFIX}{int(pid)}")
        self.seq = 0

    def write(self, surface) -> bool:
        import pygame
        w, h = surface.get_size()
        if SHM_HEADER + w * h * 4 > SHM_CAP:
            return False
        self.mm[SHM_HEADER:SHM_HEADER + w * h * 4] = pygame.image.tobytes(surface, "BGRA")
        self.seq += 1
        self.mm[8:16] = w.to_bytes(4, "little") + h.to_bytes(4, "little")
        self.mm[0:8] = self.seq.to_bytes(8, "little")          # 最后写 seq：壳看到它变了，像素已经写完
        return True

    def set_ime_rect(self, rect):
        """告诉壳输入法光标在哪（真窗口坐标），壳把候选框摆过去。"""
        try:
            x, y, w, h = (int(v) for v in rect)
            self.mm[16:32] = b"".join(v.to_bytes(4, "little", signed=True) for v in (x, y, w, h))
        except Exception:
            pass

    def close(self):
        try:
            self.mm.close()
        except Exception:
            pass


class FrameReader:
    """壳这边：读某个真窗口的共享内存。真窗口退出后壳手里的映射还在，最后一帧照样能显示（重启空档靠它）。"""

    def __init__(self, pid):
        import mmap
        self.pid = int(pid)
        self.mm = mmap.mmap(-1, SHM_CAP, tagname=f"{SHM_PREFIX}{self.pid}")
        self.seq = 0

    def poll(self):
        """有新的一帧就返回 pygame Surface，没有返回 None。"""
        import pygame
        seq = int.from_bytes(self.mm[0:8], "little")
        if not seq or seq == self.seq:
            return None
        w = int.from_bytes(self.mm[8:12], "little")
        h = int.from_bytes(self.mm[12:16], "little")
        if w <= 0 or h <= 0 or SHM_HEADER + w * h * 4 > SHM_CAP:
            return None
        img = pygame.image.frombuffer(self.mm[SHM_HEADER:SHM_HEADER + w * h * 4], (w, h), "BGRA")
        self.seq = seq
        return img

    def ime_rect(self):
        """真窗口的输入法光标矩形；还没设过返回 None。"""
        x, y, w, h = (int.from_bytes(self.mm[i:i + 4], "little", signed=True) for i in range(16, 32, 4))
        return (x, y, w, h) if w > 0 and h > 0 else None

    def close(self):
        try:
            self.mm.close()
        except Exception:
            pass


def shell_failed() -> bool:
    try:
        return FAILED.exists()
    except OSError:
        return False


def _pump_frame(screen, pid, last_path, last_mtime):
    """扫一次帧：路径或 mtime 变了就重新 load + blit + flip，读完把文件改名 .done。"""
    p = _latest_frame(pid)
    if p is None:
        return last_path, last_mtime
    try:
        mtime = p.stat().st_mtime_ns
    except OSError:
        return last_path, last_mtime
    if str(p) == str(last_path) and mtime == last_mtime:
        return last_path, last_mtime
    try:
        import pygame
        img = pygame.image.load(str(p))
        if img.get_size() != screen.get_size():
            img = pygame.transform.smoothscale(img, screen.get_size())
        screen.blit(img, (0, 0))
        pygame.display.flip()
    except Exception:
        return last_path, last_mtime                   # 读不动就跳过这一帧，别把别的帧删了
    try:
        p.replace(p.with_name(f"{p.stem}.done"))
    except OSError:
        pass
    return str(p), mtime


def _event_dict(e, k=(1.0, 1.0)):
    """pygame 事件 → encode_event 吃的字典；不要的事件返回 None。k：壳坐标 → 真窗口坐标的缩放。"""
    try:
        import pygame
        t = e.type
        pos = lambda: (round(e.pos[0] * k[0]), round(e.pos[1] * k[1]))
        if t == pygame.TEXTINPUT:
            return {"type": "textinput", "text": e.text}
        if t == pygame.TEXTEDITING:
            return {"type": "textediting", "text": e.text, "start": getattr(e, "start", 0),
                    "length": getattr(e, "length", 0)}
        if t == pygame.MOUSEMOTION:
            x, y = pos()
            return {"type": "mousemotion", "x": x, "y": y}
        if t == pygame.MOUSEBUTTONDOWN:
            x, y = pos()
            return {"type": "mousedown", "x": x, "y": y, "button": getattr(e, "button", 0)}
        if t == pygame.MOUSEBUTTONUP:
            x, y = pos()
            return {"type": "mouseup", "x": x, "y": y, "button": getattr(e, "button", 0)}
        if t == pygame.MOUSEWHEEL:
            return {"type": "mousewheel", "x": getattr(e, "x", 0), "y": getattr(e, "y", 0)}
        if t == pygame.KEYDOWN:
            return {"type": "keydown", "key": pygame.key.name(getattr(e, "key", 0)),
                    "mod": getattr(e, "mod", 0)}
        if t == pygame.KEYUP:
            return {"type": "keyup", "key": pygame.key.name(getattr(e, "key", 0)),
                    "mod": getattr(e, "mod", 0)}
    except Exception:
        return None
    return None


def shell_main(rect):
    """壳进程本体：无边框 / 置顶 / 不上任务栏，可点击激活（这样才能打字），
    按 30fps 扫帧与事件，收到 QUIT 忽略，只有 shell.kill 文件能让它退。"""
    import pygame
    try:
        x, y, w, h = (int(v) for v in rect)
    except (TypeError, ValueError):
        return
    if w <= 0 or h <= 0:
        return
    try:
        os.environ["SDL_VIDEO_WINDOW_POS"] = f"{x},{y}"     # set_mode 之前设：窗口一出生就在原位
        # 和主窗口一样：DPI 感知（坐标对得上）、显示输入法候选框、长拼写完整收到。壳拿着焦点，输入法是壳的
        os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")
        os.environ.setdefault("SDL_IME_SHOW_UI", "1")
        os.environ.setdefault("SDL_IME_SUPPORT_EXTENDED_TEXT", "1")
        pygame.display.init()
        flags = pygame.NOFRAME
        screen = pygame.display.set_mode((w, h), flags)
        setter = getattr(pygame.display, "set_window_position", None)
        if setter is not None:
            try:
                setter((x, y))
            except Exception:
                pass
    except Exception:
        try:
            pygame.quit()
        except Exception:
            pass
        return

    hwnd = get_hwnd()                           # pygame-ce 不支持置顶/跳任务栏标志，用 Win32 补
    hide_from_taskbar(hwnd)
    make_topmost(hwnd)
    _write_flag(os.getpid(), [x, y, w, h], hwnd)     # 壳自己写完整的 flag（pid / 位置 / hwnd），原子写
    try:
        pygame.key.start_text_input()           # 输入法要靠它：打开后才有拼写 / 上屏事件
    except Exception:
        pass
    frame_size = (w, h)                         # 真窗口的画面尺寸（鼠标坐标按它换算）
    ime_at = None

    clock = pygame.time.Clock()
    attach = 0                                  # 事件写给哪个真窗口
    shown_path, shown_mtime = None, None
    try:
        FAILED.unlink()                         # 新的壳：清掉上一个壳留下的失败标记
    except OSError:
        pass
    shown_at = time.time()                      # 最近一次成功显示画面的时间（看门狗用）
    reader = None                               # 当前真窗口的共享内存
    screen.fill((32, 32, 36))                   # 第一帧来之前先不是纯黑
    pygame.display.flip()
    scan_at = 0.0
    top_at = 0.0
    frame_dir()
    while True:
        now = time.time()
        if hwnd and now - top_at >= 2.0:        # 每 2 秒重钉一次，防止被别的程序抢到上面
            top_at = now
            make_topmost(hwnd)
        try:
            if KILL.exists():
                try:
                    KILL.unlink()
                except OSError:
                    pass
                break
        except OSError:
            pass
        if now - scan_at >= 1.0 / SCAN_HZ:
            scan_at = now
            attach = _read_target(attach)
            shown = False
            try:
                if attach and (reader is None or reader.pid != attach):
                    reader = FrameReader(attach)    # 换了真窗口（重启）：换一块共享内存；旧画面先留在屏幕上
                img = reader.poll() if reader is not None else None
                if img is not None:
                    frame_size = img.get_size()
                    if img.get_size() != screen.get_size():
                        img = pygame.transform.scale(img, screen.get_size())
                    screen.blit(img, (0, 0))
                    pygame.display.flip()
                    shown = True
            except Exception:
                pass
            try:                                # 输入法候选框跟着真窗口的光标走
                r = reader.ime_rect() if reader is not None else None
                if r and r != ime_at:
                    ime_at = r
                    sx, sy = screen.get_width() / frame_size[0], screen.get_height() / frame_size[1]
                    pygame.key.set_text_input_rect(pygame.Rect(round(r[0] * sx), round(r[1] * sy),
                                                               max(1, round(r[2] * sx)), max(1, round(r[3] * sy))))
            except Exception:
                pass
            if shown or not attach or not _alive(attach):
                shown_at = now                  # 显示成功了，或者现在本来就没有真窗口在送帧（重启空档）
            elif now - shown_at > SHOW_TIMEOUT:
                try:                            # 真窗口活着、却一帧都显示不出来：报失败、自己退，让真窗口回屏幕上
                    FAILED.write_text(f"{time.strftime('%H:%M:%S')} 壳 {SHOW_TIMEOUT:.0f} 秒没显示出画面", encoding="utf-8")
                except OSError:
                    pass
                break
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                continue                        # 关不掉：只有 shell.kill 能退
            d = _event_dict(e, (frame_size[0] / screen.get_width(), frame_size[1] / screen.get_height()))
            if d and attach:
                _append_event(attach, encode_event(d))
        clock.tick(SCAN_HZ)

    try:
        pygame.quit()
    except Exception:
        pass


# ---------------- 旧窗口重启失败日志 ----------------

def log_restart_fail(text: str, log_path: str = "", show_box: bool = False) -> Path | None:
    """旧窗口已经关掉时重启失败：写进 ~/.terminist/logs（聊天区已经没了）。
    show_box=True 时再弹一个原生小提示框（不弹控制台）。返回日志文件或 None。"""
    out = None
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        out = LOG_DIR / f"restart_fail_{time.strftime('%Y%m%d-%H%M%S')}.log"
        out.write_text(str(text) + (f"\n\n日志：{log_path}" if log_path else ""), encoding="utf-8")
    except OSError:
        out = None
    if show_box and sys.platform == "win32":
        try:
            import tkinter
            from tkinter import messagebox
            root = tkinter.Tk()
            root.withdraw()
            messagebox.showwarning("Terminist", str(text)[:800])
            root.destroy()
        except Exception:
            pass
    return out
