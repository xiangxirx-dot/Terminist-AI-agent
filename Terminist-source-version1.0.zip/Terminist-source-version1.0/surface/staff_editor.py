"""
员工设定编辑器：新建前台角色，或者改已有员工的简单设定（显示名 / 职责 / 人设 / 头像）。

单独一个小窗口进程（tkinter：中文输入法、长文本编辑都现成），主界面点员工卡上的「编辑」或员工栏的「＋ 新角色」时起它：
  python -m surface.staff_editor <员工内部名>     改已有的
  python -m surface.staff_editor --new             新建一个前台
保存时直接写花名册（memory/staff.json）和头像（memory/avatars/<内部名>.png），
最后一行往标准输出打一行 JSON：{"saved": 内部名, "label": 显示名, "new": 是否新建} / {"deleted": 内部名} / {}（取消），
主界面读到就刷新头像、正在上岗的立刻换上新人设。
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from lib_a import staff as st                     # noqa: E402

AVATAR_PX = 256                                   # 存盘的头像边长
FONT_FILES = (r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simhei.ttf")


def square(img, size: int):
    """居中裁成正方形再缩放。"""
    from PIL import ImageOps
    img = ImageOps.exif_transpose(img).convert("RGBA")
    side = min(img.size)
    left, top = (img.width - side) // 2, (img.height - side) // 2
    return img.crop((left, top, left + side, top + side)).resize((size, size), 1)   # 1 = LANCZOS


def circle(img):
    from PIL import Image, ImageDraw
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).ellipse((0, 0, img.width - 1, img.height - 1), fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


def default_avatar(key: str, label: str, size: int):
    """没传图片时的默认头像：按员工固定的底色 + 显示名第一个字（和主界面画的一样）。"""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((0, 0, size - 1, size - 1), fill=st.avatar_color(key) + (255,))
    font = None
    for f in FONT_FILES:
        try:
            font = ImageFont.truetype(f, int(size * 0.48))
            break
        except OSError:
            continue
    ch = st.avatar_initial(key, label)
    font = font or ImageFont.load_default()
    box = d.textbbox((0, 0), ch, font=font)
    d.text(((size - (box[2] - box[0])) / 2 - box[0], (size - (box[3] - box[1])) / 2 - box[1]), ch,
           fill=(255, 255, 255, 255), font=font)
    return img


def run(name: str | None):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from PIL import Image, ImageTk
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    is_new = not name
    key = st.new_staff_id() if is_new else st.canon(name)
    roster = st.load_staff()
    info = {} if is_new else dict(roster.get(key) or {})
    if not is_new and not info:
        print(json.dumps({"error": f"没有这个员工：{key}"}))
        return
    role = str(info.get("role") or "front")
    result = {}

    bg, panel, fg, dim, green, red = "#16181d", "#1f2229", "#e8ecef", "#8b93a1", "#39ff88", "#ff6b6b"
    root = tk.Tk()
    root.title("新建前台角色" if is_new else f"编辑员工：{info.get('label') or key}")
    root.configure(bg=bg)
    k = root.winfo_fpixels("1i") / 96
    w = min(int(640 * k), root.winfo_screenwidth() - 40)
    h = min(int(700 * k), root.winfo_screenheight() - int(90 * k))
    root.geometry(f"{w}x{h}+{(root.winfo_screenwidth() - w) // 2}+{max(0, (root.winfo_screenheight() - h) // 2 - int(30 * k))}")
    root.minsize(int(480 * k), int(520 * k))
    try:
        root.iconbitmap(str(ROOT / "icon.ico"))
    except tk.TclError:
        pass
    root.attributes("-topmost", True)                 # 主界面是全屏 / 置顶的：编辑窗别被压在下面
    root.after(400, lambda: root.attributes("-topmost", False))
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=bg, foreground=fg, fieldbackground=panel, font=("Microsoft YaHei UI", 10))
    style.configure("TButton", background=panel, foreground=fg, borderwidth=0, padding=(14, 6))
    style.map("TButton", background=[("active", "#2a2e37")])
    style.configure("Go.TButton", background=green, foreground="#0b0d10", font=("Microsoft YaHei UI", 10, "bold"))
    style.map("Go.TButton", background=[("active", "#7dffb4")])
    style.configure("Del.TButton", background=panel, foreground=red)
    style.map("Del.TButton", background=[("active", "#3a2228")])
    style.configure("TEntry", fieldbackground=panel, foreground=fg, insertcolor=fg, borderwidth=0)

    frm = tk.Frame(root, bg=bg, padx=int(18 * k), pady=int(16 * k))
    frm.pack(fill="both", expand=True)

    # ---- 头像 ----
    state = {"picked": None, "reset": False}          # picked：新选的图（PIL）；reset：恢复默认头像
    top = tk.Frame(frm, bg=bg)
    top.pack(fill="x")
    pv = int(96 * k)
    face = tk.Label(top, bg=bg)
    face.pack(side="left")
    side = tk.Frame(top, bg=bg)
    side.pack(side="left", fill="x", expand=True, padx=(int(16 * k), 0))
    tk.Label(side, text="头像", bg=bg, fg=dim).pack(anchor="w")
    av_btns = tk.Frame(side, bg=bg)
    av_btns.pack(anchor="w", pady=(int(4 * k), 0))
    av_note = tk.Label(side, text="", bg=bg, fg=dim, justify="left", anchor="w")
    av_note.pack(anchor="w", pady=(int(6 * k), 0))

    label_var = tk.StringVar(value=str(info.get("label") or ""))

    def current_face():
        if state["picked"] is not None:
            return circle(square(state["picked"], pv)), "新选的图片（保存后生效）"
        if not state["reset"] and not is_new:
            p = st.avatar_path(key)
            if p:
                try:
                    return circle(square(Image.open(p), pv)), "当前头像"
                except OSError:
                    pass
        return default_avatar(key, label_var.get(), pv), "默认头像：显示名第一个字（可以换成图片）"

    def refresh_face(*_):
        img, note = current_face()
        face.image = ImageTk.PhotoImage(img)           # 留着引用，不然被回收就不显示了
        face.configure(image=face.image)
        av_note.configure(text=note)

    def pick_image():
        p = filedialog.askopenfilename(parent=root, title="选一张头像图片",
                                       filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("所有文件", "*.*")])
        if not p:
            return
        try:
            img = Image.open(p)
            img.load()
        except Exception as e:
            messagebox.showerror("头像", f"这张图读不出来：{e}", parent=root)
            return
        state["picked"], state["reset"] = img, False
        refresh_face()

    def reset_image():
        state["picked"], state["reset"] = None, True
        refresh_face()

    ttk.Button(av_btns, text="选图片…", command=pick_image).pack(side="left")
    ttk.Button(av_btns, text="用默认头像", command=reset_image).pack(side="left", padx=(int(8 * k), 0))

    # ---- 显示名 / 职责 / 人设 ----
    def field(title, var=None, note=None):
        tk.Label(frm, text=title, bg=bg, fg=dim).pack(anchor="w", pady=(int(14 * k), int(3 * k)))
        if note:
            tk.Label(frm, text=note, bg=bg, fg=dim, justify="left", anchor="w",
                     wraplength=w - int(60 * k)).pack(anchor="w", pady=(0, int(3 * k)))
        if var is not None:
            e = ttk.Entry(frm, textvariable=var)
            e.pack(fill="x", ipady=int(4 * k))
            return e

    name_entry = field("显示名（聊天里、员工栏里显示的名字）", label_var)
    label_var.trace_add("write", lambda *_: refresh_face() if state["picked"] is None else None)
    duty_var = tk.StringVar(value=str(info.get("duty") or ""))
    field("职责（一句话，员工卡上显示）", duty_var)
    field("人设（发给模型的设定：身份、性格、说话方式）",
          note=None if role == "front" else "这是工作组的岗位，不是前台：它的人设会影响它怎么干活，改之前想清楚。")
    box = tk.Frame(frm, bg=panel)
    box.pack(fill="both", expand=True)
    text = tk.Text(box, bg=panel, fg=fg, insertbackground=fg, relief="flat", wrap="word", undo=True,
                   font=("Microsoft YaHei UI", 10), padx=int(10 * k), pady=int(8 * k), height=10)
    sb = ttk.Scrollbar(box, command=text.yview)
    text.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    text.pack(side="left", fill="both", expand=True)
    text.insert("1.0", str(info.get("persona") or "") if not is_new else
                st.PERSONA_TEMPLATE.format(label="新角色"))

    # ---- 按钮 ----
    btns = tk.Frame(frm, bg=bg)
    btns.pack(fill="x", pady=(int(14 * k), 0))

    def save():
        label = label_var.get().strip()
        persona = text.get("1.0", "end").strip()
        if not label:
            messagebox.showwarning("保存", "显示名不能空着", parent=root)
            name_entry.focus_set()
            return
        if role == "front" and not persona:
            messagebox.showwarning("保存", "前台的人设不能空着（它就靠这个说话）", parent=root)
            return
        if is_new and "「新角色」" in persona:
            persona = persona.replace("「新角色」", f"「{label}」")
        avatar = None                                  # None = 头像不动
        if state["picked"] is not None:
            st.AVATAR_DIR.mkdir(parents=True, exist_ok=True)
            fname = f"{key}.png"
            square(state["picked"], AVATAR_PX).save(st.AVATAR_DIR / fname)
            avatar = fname
        elif state["reset"]:
            avatar = ""
        st.update_staff(key, label=label, duty=duty_var.get().strip(), persona=persona, avatar=avatar)
        result.update(saved=key, label=label, new=is_new)
        root.destroy()

    def delete():
        if not messagebox.askyesno("删除角色", f"删掉「{label_var.get() or key}」？\n（头像图片留在 memory/avatars 里）",
                                   parent=root):
            return
        why = st.remove_staff(key)
        if why:
            messagebox.showwarning("删除角色", why, parent=root)
            return
        result.update(deleted=key)
        root.destroy()

    ttk.Button(btns, text="保存", style="Go.TButton", command=save).pack(side="right")
    ttk.Button(btns, text="取消", command=root.destroy).pack(side="right", padx=int(8 * k))
    if not is_new and key not in st.BUILTIN:
        ttk.Button(btns, text="删除这个角色", style="Del.TButton", command=delete).pack(side="left")
    elif key in st.BUILTIN:
        tk.Label(btns, text="内置员工：能改设定，不能删", bg=bg, fg=dim).pack(side="left")

    root.bind("<Escape>", lambda e: root.destroy())
    refresh_face()
    name_entry.focus_set()
    root.mainloop()
    print(json.dumps(result))                     # 纯 ASCII：无窗口进程的输出编码是系统 GBK，主界面按 UTF-8 读也不会乱


if __name__ == "__main__":
    args = sys.argv[1:]
    run(None if not args or args[0] == "--new" else args[0])
