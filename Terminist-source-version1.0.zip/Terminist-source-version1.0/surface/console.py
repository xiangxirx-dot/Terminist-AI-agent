"""
Surface（渲染层）- 命令行界面。
用法:  python run.py --cli <要编辑的文件夹>
       python run.py --cli ./myproj --ask      (写文件/执行命令前逐次确认；默认不问)
"""

import argparse
import io
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")   # 别让 pygame 的欢迎语混进命令行输出
try:
    import pygame                      # 命令行界面的独立小屏幕要用；没装就静默跳过
except ImportError:
    pygame = None

import lib_a
import lib_b
import base
from base.config import WEB_VIEWPORT
from surface import (help_text, restart_tool_schema, rollback_to, run_self_test, request_self_test,
                     self_test_flag_path,
                     MEMORY_ROOT_ENV, desktop_folder, open_folder_result, open_folder_schema,
                     api_key_text, check_api_key, save_api_key)
from lib_a.staff import (front_persona, load_staff, active_persona, active_staff,
                         add_staff, set_active, set_staff_persona, canon)
from lib_a import (LEAD_MODEL, TEAM_MODE, WORKER_MODEL, Agent, Workspace, fmt_tokens)
from lib_a import web_guard


class ConsoleEmitter:
    """把 A库 的事件打印到终端。

    事件类型: reasoning / assistant (流式片段), tool, result, info, error, done
      member      本次请求使用的模型（工作组模式下是组长）
      worker      执行成员的事件 (JSON: w 编号, kind 事件类型, text 内容)；kind 另有 start / end
      memory      记忆压缩等提示
      b_*         B库（改造层）的事件：b_stage 阶段、b_tool / b_result / b_assistant 等同上
    以下事件给 GUI 用，终端忽略:
      context     当前上下文大小 (JSON: tokens, limit)
      model_info  服务端实际返回的模型名
      tool_args   工具参数的流式片段 (JSON: i, name, delta, new)
      tool_call   开始执行工具 (JSON: name, args)
    """
    KINDS = {"reasoning", "assistant", "tool", "result", "info", "error", "done", "member", "escalate", "memory"}

    def __init__(self):
        self.last = None
        self.member = None
        self.answer = ""                 # 一轮的结论文字（重启后自检用它判断有没有失败项）
        self.restart_version = ""        # B库 交工了需要重启的改动时，记下改造前的存档名

    def __call__(self, kind: str, text: str):
        if kind.startswith("b_"):
            return self.b_event(kind[2:], text)
        if kind == "worker":
            return self.worker_event(json.loads(text))
        if kind == "penalty":
            s = json.loads(text)
            print(f"\033[31m  [奖惩] 累计扣分 A库 {s['A']}，B库 {s['B']}；"
                  f"奖励 A库 {s.get('RA', 0)}，B库 {s.get('R', 0)}\033[0m")
            return
        if kind == "image":                  # 终端里放不了图，给出图片位置
            ev = json.loads(text)
            print(f"\033[36m  [图] {ev.get('title', '')} → {ev.get('path', '')}\033[0m")
            return
        if kind == "front_report":           # B库 实在改不好：前台用自己的口吻来告诉你
            ev = json.loads(text)
            print(f"\n\033[1;34mTerminist\033[0m\033[90m·{ev.get('who', '前台')}\033[0m {ev.get('text', '')}")
            self.last = None
            return
        if kind not in self.KINDS or (kind == "member" and text == self.member):
            return
        if self.last in ("assistant", "reasoning") and kind not in (self.last,):
            print()
        if kind == "reasoning":
            print(f"\033[90m{text}\033[0m", end="", flush=True)
        elif kind == "assistant":
            self.answer += text
            if self.last != "assistant":
                print(f"\n\033[1;34mTerminist\033[0m\033[90m·{self.member}\033[0m ", end="")
            print(text, end="", flush=True)
        elif kind == "tool":
            print(f"\033[35m  ⚙ {text}\033[0m")
        elif kind == "result":
            print(f"\033[90m    → {text.splitlines()[0][:100] if text else ''}\033[0m")
        elif kind == "member":
            self.member = text
        elif kind == "memory":
            print(f"\033[36m  [记忆] {text}\033[0m")
        elif kind in ("info", "error"):
            print(f"\033[{'31' if kind == 'error' else '33'}m{text}\033[0m")
        self.last = None if kind == "done" else kind

    def b_event(self, kind: str, text: str):
        """B库（改造层）的事件，缩进显示。"""
        if self.last in ("assistant", "reasoning", "b_assistant") and kind != "assistant":
            print()
        if kind == "stage":
            print(f"\033[32m  [B库] {text}\033[0m")
        elif kind == "assistant":
            if self.last != "b_assistant":
                print("\033[32m  [B库说明]\033[0m ", end="")
            print(text, end="", flush=True)
            self.last = "b_assistant"
            return
        elif kind == "tool":
            print(f"\033[35m    [B] ⚙ {text}\033[0m")
        elif kind == "result":
            print(f"\033[90m      → {text.splitlines()[0][:100] if text else ''}\033[0m")
        elif kind == "delivered":
            ev = json.loads(text)
            if ev.get("restart"):
                self.restart_version = ev.get("version", "")
                print("\033[33m  [B库] 改动涉及核心代码，本轮结束后自动重启\033[0m")
        self.last = "b_" + kind

    def worker_event(self, ev: dict):
        """执行成员的事件：多个成员并行，只打印关键步骤，前面带编号。"""
        w, kind, text = ev["w"], ev["kind"], ev["text"]
        if self.last in ("assistant", "reasoning", "b_assistant"):
            print()
        if kind == "start":
            info = json.loads(text)
            print(f"\033[33m  [#{w} {info['model']}] 开始：{info['title']}（负责 {', '.join(info['files']) or '只读'}）\033[0m")
        elif kind == "tool":
            print(f"\033[35m    [#{w}] ⚙ {text[:120]}\033[0m")
        elif kind == "end":
            res = json.loads(text)
            print(f"\033[33m  [#{w}] {'完成' if res.get('ok') else '失败'}："
                  f"{res.get('report', '').strip().splitlines()[0][:120] if res.get('report') else ''}\033[0m")
        else:
            return
        self.last = "worker"


SETTINGS_FILE = lib_a.APP_ROOT / "terminist_settings.json"     # 和图形界面共用

_busy = False       # A库 正在干活（跑干活轮前置 True、结束置 False）：命令行顺序执行，据此判断输入该不该另走闲聊

_screen_ready = False       # 命令行界面的独立小屏幕已经开好（display 窗口只开一个）
_screen_starting = False    # 正在建窗口：防止连着几次网页操作各起一个线程
_watching = False           # base.web 是否已经包过一层（只包一次）


def _gui_running() -> bool:
    """是不是图形界面（surface.gui）正在跑：那种情况下小屏幕窗口由 gui 自己开，这里一律不插手。"""
    return "surface.gui" in sys.modules


def _screen_auto_on() -> bool:
    """设置里的 screen_window：图形界面里能选开/关，off / noauto 就不自动开。"""
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        val = str(data.get("screen_window") or "").strip().lower()
    except (OSError, ValueError):
        return True
    return val not in ("off", "noauto", "0", "false")


_align_want = False         # 网页刚操作过：等绘制线程自己把窗口尺寸对回网页尺寸


def _web_window_size():
    """小屏幕的目标尺寸：跟网页内容尺寸对齐，按桌面大小整体缩小到放得下。"""
    vw, vh = WEB_VIEWPORT
    try:
        from base import web as _w
        s = getattr(_w, "page_size", None)
        if callable(s):
            vw, vh = s()
    except Exception:
        vw, vh = WEB_VIEWPORT
    try:
        vw, vh = int(vw), int(vh)
        if vw <= 0 or vh <= 0:
            raise ValueError
    except Exception:
        vw, vh = WEB_VIEWPORT
    desk_w, desk_h = 1920, 1080
    try:
        for size in pygame.display.get_desktop_sizes():
            desk_w, desk_h = int(size[0]), int(size[1])
    except Exception:
        pass
    k = min(1.0, desk_h * 0.92 / float(vh), desk_w * 0.90 / float(vw))
    return (max(160, int(round(vw * k))), max(120, int(round(vh * k))))


def _topmost() -> None:
    """小屏幕置顶：pygame-ce 没这个开关，Windows 上借用 Win32。"""
    try:
        if sys.platform == "win32":
            import ctypes
            hwnd = int(pygame.display.get_wm_info().get("window") or 0)
            ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0,
                                              0x0001 | 0x0002 | 0x0040)
    except Exception:
        pass


def _align_to_web() -> None:
    """网页换页后把窗口调成网页尺寸（比例偏差 ≤2% 就不动，用户自己拖的大小不会被抢回去）。"""
    try:
        surf = pygame.display.get_surface()
        if surf is None:
            return
        w, h = surf.get_size()
        tw, th = _web_window_size()
        if abs(w - tw) <= max(2, tw * 0.02) and abs(h - th) <= max(2, th * 0.02):
            return
        pygame.display.set_mode((tw, th), pygame.RESIZABLE | pygame.NOFRAME)
        _topmost()
    except Exception:
        pass


def _screen_loop(font) -> None:
    """小屏幕的绘制 + 事件循环：认拖动缩放，截图按视口比例铺满整块画面。"""
    global _align_want
    while True:
        try:
            for e in pygame.event.get():
                if e.type in (pygame.QUIT, pygame.WINDOWCLOSE):
                    return
                if e.type in (pygame.WINDOWSIZECHANGED, pygame.WINDOWRESIZED, pygame.VIDEORESIZE):
                    nw = int(getattr(e, "w", 0) or 0)      # 用户拖多大就多大，保持无边框可缩放
                    nh = int(getattr(e, "h", 0) or 0)
                    if nw >= 160 and nh >= 120:
                        pygame.display.set_mode((nw, nh), pygame.RESIZABLE | pygame.NOFRAME)
            if _align_want:                            # 网页操作过：对齐一次网页尺寸
                _align_want = False
                _align_to_web()
            surf = pygame.display.get_surface()
            if surf is None:
                pygame.time.wait(500)
                continue
            surf.fill((30, 30, 34))
            drawn = False
            try:
                data = base.web.screenshot(False)
            except Exception:
                data = b""
            if data:
                try:
                    img = pygame.image.load(io.BytesIO(data))
                    area = surf.get_rect()
                    sw, sh = img.get_size()
                    k = max(area.w / float(sw), area.h / float(sh))
                    img = pygame.transform.smoothscale(
                        img, (max(1, int(sw * k)), max(1, int(sh * k))))
                    surf.set_clip(area)
                    surf.blit(img, (0, 0))         # 左上对齐铺满，比例已对齐所以既不变形也不留白
                    surf.set_clip(None)
                    drawn = True
                except Exception:
                    try:
                        surf.set_clip(None)
                    except Exception:
                        pass
            if not drawn and font is not None:
                try:
                    surf.blit(font.render("小屏幕：等待网页", True, (200, 200, 200)), (12, 12))
                except Exception:
                    pass
            pygame.display.flip()
            pygame.time.wait(500)              # 每秒两帧就够，别把 CPU 占满
        except Exception:
            return


def open_screen_window() -> None:
    """命令行界面也开始独立小屏幕：不填文件夹（只聊天）时照样能开。

    必须跑在后台线程里（pygame 事件循环会一直占着）；没装 pygame、建窗口失败、
    或者设置里关了都静默跳过，命令行不能崩。
    """
    global _screen_ready, _screen_starting
    if pygame is None or _screen_starting or _screen_ready or not _screen_auto_on() or _gui_running():
        return
    _screen_starting = True
    try:
        try:
            pygame.init()
        except Exception:
            pass
        w, h = _web_window_size()          # 窗口尺寸跟网页内容尺寸对齐
        try:                                # 无边框 + 可缩放
            pygame.display.set_mode((w, h), pygame.RESIZABLE | pygame.NOFRAME)
        except Exception:
            return
        try:
            pygame.display.set_caption("小屏幕 · Terminist")
        except Exception:
            pass
        _topmost()
        _screen_ready = True
        font = None
        try:
            pygame.font.init()
            font = pygame.font.SysFont(None, 20)
        except Exception:
            font = None
        _screen_loop(font)
    except Exception:
        pass
    finally:
        _screen_ready = False
        _screen_starting = False


def _web_seen() -> None:
    """每次网页操作后调一次：确保小屏幕已经开在后台线程里（去重靠 _screen_ready）。

    网页操作跑在 A库 的线程里，不能直接碰 pygame，所以只置个标志，
    让绘制线程下一轮自己调一次 _align_to_web()。
    """
    global _align_want
    if _gui_running():
        return
    if _screen_ready or _screen_starting:
        _align_want = True
        return
    threading.Thread(target=open_screen_window, daemon=True).start()


def _watch_web() -> None:
    """把 base.web 的六个网页函数各包一层：一上网就在后台开独立小屏幕（只包一次）。"""
    global _watching
    if _gui_running():            # 图形界面自己开独立小屏幕窗口，这里绝不包 base.web，否则会抢窗口
        return
    if _watching or pygame is None:
        return
    _watching = True
    for name in ("open_url", "search", "click", "type_into", "scroll", "back"):
        func = getattr(base.web, name, None)
        if not callable(func):
            continue

        def _wrapped(*a, _f=func, **k):
            _web_seen()
            return _f(*a, **k)

        setattr(base.web, name, _wrapped)


def _front_desk_saved() -> bool:
    try:
        return bool(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")).get("front_desk"))
    except (OSError, ValueError):
        return False


def _save_front_desk(on: bool):
    """记住前台在不在岗（重启后保持），不动设置里的其他项。"""
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data["front_desk"] = on
    try:
        SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def _selftest_bad(text: str) -> str:
    """从自检结论里挑出失败项（"0 项失败 / 没有失败" 之类不算），返回摘要，全通过就返回空串。"""
    bad = []
    for ln in (text or "").splitlines():
        ln = ln.strip()
        if not ln or not any(w in ln for w in ("失败", "未通过", "不通过")):
            continue
        if re.search(r"(0|零|无|没有|全部?\s*通过)\s*(项|个|处)?\s*(失败|未通过|不通过)", ln):
            continue
        bad.append(ln)
    return "\n".join(bad[:3])


def main():
    global _busy
    ap = argparse.ArgumentParser(description="Terminist - 本地 Code Agent（命令行）")
    ap.add_argument("--cli", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("folder", nargs="?", default=None, help="要让 agent 操作的文件夹；不给就只聊天")
    ap.add_argument("--ask", action="store_true", help="写文件/执行命令前逐次确认（默认不问）")
    ap.add_argument("--model", default=TEAM_MODE,
                    help=f"模型名；默认 {TEAM_MODE} = 工作组模式（{LEAD_MODEL} 拆任务查工，{WORKER_MODEL} 并行执行）")
    args = ap.parse_args()

    root = Path(args.folder) if args.folder else None
    if root is not None and not root.is_dir():
        sys.exit(f"文件夹不存在: {root}")
    if os.name == "nt":
        os.system("")  # 让 Windows 终端支持 ANSI 颜色

    emitter = ConsoleEmitter()
    ws = Workspace(root, auto_yes=not args.ask) if root else None       # 没给文件夹：只聊天
    agent = Agent(ws, emit=emitter, model=args.model)
    lib_b.attach(agent)
    web_guard.install()                  # 网页操作超时自动截图：先包好 base.web，再 attach 注册工具
    _watch_web()                         # 命令行也一样：一上网就在后台开独立小屏幕（要赶在 attach 之前）
    base.attach(agent)                   # 桌面文件 + 屏幕操作；删除确认用 base.guard 的终端版
    web_guard.describe_tools(agent)       # 让模型知道网页超时会自动带截图
    if _front_desk_saved():              # 上次前台在岗（和图形界面共用设置文件）：接着上岗
        agent.set_persona(front_persona())
    want_restart = []                    # Agent 调了 restart_terminist：这一轮说完就重启

    def restart_tool(args):
        """和图形界面一样支持 selfcheck：不填只重启；true/yes 重启后跑默认自检；一段文字 = 重启后重点验证这个。"""
        raw = str((args or {}).get("selfcheck") or "").strip()
        if raw:
            instruction = "" if raw.lower() in ("true", "1", "yes", "on", "selftest") else raw
            msg = request_self_test(True, instruction)
            if "失败" in msg:
                return f"没有重启：自检标记没写上（{msg}），这一轮不触发重启，别跟用户说已经重启。"
        want_restart.append(True)
        return ("好了，这一轮说完就重启" + ("，重启完会自动跑自检" if raw else "") +
                "（记忆和设置都保留）。用一句话告诉用户马上重启即可。")
    agent.custom_tools["restart_terminist"] = (restart_tool_schema(), restart_tool)

    def open_folder_tool(a):
        """AI 自己打开桌面上的文件夹（桌面外的一律拒绝），并在终端里告知。"""
        try:
            path, created = desktop_folder(a.get("path", ""), bool(a.get("create")))
        except (ValueError, OSError) as e:
            return f"错误: {e}"
        if agent.ws is not None and agent.ws.root == path:
            return f"{path} 已经是当前工作区了，不用再打开"
        ws = Workspace(path, auto_yes=not args.ask)
        ws.protected = [lib_a.APP_ROOT]                # Terminist 自己的代码仍然只能走 B库
        agent.switch_workspace(ws)
        verb = "新建并打开了" if created else "打开了"
        print(f"\033[36m[AI 自己{verb}文件夹] {path}（只能是桌面里的文件夹；删除仍要你确认）\033[0m")
        return open_folder_result(path, created)
    agent.custom_tools["open_folder"] = (open_folder_schema(), open_folder_tool)
    if MEMORY_ROOT_ENV in os.environ:          # 重启前 AI 自己换过文件夹：接着读原来那份对话记忆
        mr = os.environ.pop(MEMORY_ROOT_ENV)
        agent._memory_root = Path(mr) if mr else None
    turns = agent.load_memory()

    try:                                 # 重启后自检：跑一遍本地工具，验证改造没弄坏东西（过程只写工作流日志，不刷屏）
        cmd = run_self_test("restart")
        if cmd:
            lib_b.worklog.write("Terminist", "info", f"重启后自检：请求已排上（标记 {self_test_flag_path()}）")
            emitter.answer = ""
            agent.chat(cmd)
            bad = _selftest_bad(emitter.answer)
            if bad:                      # 只有出现失败项才在终端里点一句
                lib_b.worklog.write("Terminist", "info", f"重启后自检：失败 {bad}")
                print(f"\033[31m重启后自检有失败项：{bad}\033[0m")
            else:
                lib_b.worklog.write("Terminist", "info", "重启后自检：全部通过")
    except Exception as e:
        print(f"\033[31m自检出错: {type(e).__name__}: {e}\033[0m")

    def restart(version: str = ""):
        """重启命令行版（新进程接着用这个终端，记忆和设置都保留）。"""
        import run
        agent.save_memory()
        if hasattr(agent, "_memory_root"):        # AI 换过文件夹：新进程读同一份记忆
            os.environ[MEMORY_ROOT_ENV] = str(agent._memory_root or "")
        print("\033[33m重启中…\033[0m\n")
        argv = ["--cli"] + ([str(agent.ws.root)] if agent.ws else []) + \
               (["--after-upgrade", version] if version else []) + \
               (["--ask"] if args.ask else []) + (["--model", args.model] if args.model != TEAM_MODE else [])
        notice = f"已重启到新版本（改造前的存档：{version}）" if version else "已重启"
        sys.exit(run.launch(argv, notice=notice, wait=True))

    def mode_text():
        return f"工作组（{LEAD_MODEL} 指挥 + {WORKER_MODEL} 执行）" if agent.mode == TEAM_MODE else agent.mode

    chat_agent = []                       # 第二个常驻闲聊 Agent（第一次用到时创建，memory_key="chat" 单独存一份记忆）

    def chat_turn(text: str):
        """以 # 开头的输入：另起一个常驻闲聊 Agent 跑一轮，不打断干活那一轮（和图形界面里忙时插话等价）。"""
        global _busy
        if not text:
            print("（闲聊）在 # 后面说点什么")
            return
        if not chat_agent:
            a = Agent(ws, emit=emitter, model=WORKER_MODEL, persist=True, memory_key="chat")
            a.set_persona(active_persona())
            a.load_memory()                     # 先读上次的闲聊（没读过的记忆不会被存盘盖掉）
            chat_agent.append(a)
        was_busy, _busy = _busy, False      # 闲聊不算干活轮
        print("\033[36m（闲聊）\033[0m" + ("（干活那轮继续，不打断）" if was_busy else ""))
        try:
            chat_agent[0].chat(text)
        except KeyboardInterrupt:
            print("\n[闲聊已中断]")
        except Exception as e:
            print(f"\n\033[31m闲聊出错: {type(e).__name__}: {e}\033[0m")
        finally:
            _busy = was_busy

    print(f"Terminist  |  模式: {mode_text()}  |  工作区: {agent.ws.root if agent.ws else '无（只聊天）'}")
    if os.environ.get("TERMINIST_NOTICE"):
        print(f"\033[32m{os.environ.pop('TERMINIST_NOTICE')}\033[0m")
    if turns:
        print(f"\033[36m已恢复记忆：{turns} 轮对话，上下文约 {fmt_tokens(agent.context_tokens())} tokens"
              f"（/clear 清空）\033[0m")
    print(f"输入需求开始；以 # 开头 = 闲聊（另起一个常驻闲聊 Agent，不占干活那一轮）；/model 查看或切换模型（/model {TEAM_MODE} = 工作组），/versions 版本，/rollback [版本] 回滚改造，/penalty 扣分，/clear 清空对话和记忆，/restart 重启，/selftest 重启后自检，/help 帮助，/exit 退出\n")
    while True:
        try:
            q = input("\033[1;32m你> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q:
            continue
        if q in ("/exit", "/quit"):
            break
        if q.startswith("#"):             # 以 # 开头：走第二个常驻闲聊 Agent（_busy 时就是干活中插话，不打断那一轮）
            chat_turn(q[1:].strip())
            continue
        if q == "/clear":
            agent.clear_memory()
            print("已清空对话和记忆")
            continue
        if q in ("/restart", "/重启"):
            restart()
        if q == "/apikey" or q.startswith("/apikey "):
            import getpass
            print("当前 key：" + api_key_text())
            key = getpass.getpass("粘贴新的 DeepSeek API key（输入不显示，直接回车取消）：").strip()
            if not key:
                continue
            ok, msg = check_api_key(key)
            if ok is False:
                print(msg + "，没有保存")
                continue
            save_api_key(agent, key)
            print(("新 key 能用，" if ok else msg + "，") + "已保存：" + api_key_text())
            continue
        if q == "/selftest" or q.startswith("/selftest "):
            arg = q[len("/selftest"):].strip()
            print(request_self_test(arg != "cancel"))
            continue
        if q == "/staff" or q.startswith("/staff "):
            arg = q[len("/staff"):].strip()
            if arg == "on":
                agent.set_persona(front_persona())
                _save_front_desk(True)
                print("前台肥鱼已上岗（deepseek-flash，不思考，接到就回）")
            elif arg == "off":
                agent.set_persona("")
                _save_front_desk(False)
                print("前台已下班，恢复默认语气")
            elif arg.startswith("use "):
                name = canon(arg[4:].strip())    # 旧名兼容：front_desk→fish、scaramouche→cat
                if not name or name.startswith("_") or name not in load_staff():
                    print(f"没有这个员工：{name}。用 /staff 看花名册。")
                else:
                    set_active(name)
                    agent.set_persona(active_persona())
                    summary = getattr(agent, "handover_memory", None)
                    if summary and summary():
                        print("已交接：上一个前台的对话压成了摘要，新前台接着往下聊")
                    print(f"已切换到 {load_staff().get(name, {}).get('label', name)} 上岗，正在重启…")
                    restart()                    # 切换和保存都完成了：直接重启让新语气生效
            else:
                staff = load_staff()
                names = [n for n in staff if not str(n).startswith("_") and isinstance(staff[n], dict)]
                print(f"员工列表（{len(names)} 个，当前上岗：{active_staff()}）：")
                for name in names:
                    s = staff[name]
                    print(f"  {s.get('label', name)}（{name}）：{s.get('duty', '')}")
                print("命令：/staff on 开前台，/staff off 关前台，/staff use <名字> 换上岗，/staff list 看列表")
            continue
        if q in ("/help", "/帮助"):
            print(help_text())
            continue
        if q == "/rollback" or q.startswith("/rollback "):
            arg = q[len("/rollback"):].strip()
            if arg:
                ok, msg = rollback_to(arg)
                print(msg)
                if ok:
                    print("重启 Terminist 后完全生效。")
            else:
                print(lib_b.versions_command("/rollback"))
            continue
        if q in ("/versions", "/penalty", "/penalty reset"):
            print(lib_b.versions_command(q))
            continue
        if q.startswith("/model"):
            name = q[len("/model"):].strip()
            if name:
                agent.set_model(name)
                print(f"已切换到 {mode_text()}")
            else:
                print(f"当前: {mode_text()}\n可用: {TEAM_MODE}, {', '.join(agent.list_models())}")
            continue
        _busy = True
        try:
            agent.chat(q)
        except KeyboardInterrupt:
            print("\n[已中断]")
        except Exception as e:
            print(f"\n\033[31m出错: {type(e).__name__}: {e}\033[0m")
        finally:
            _busy = False
        if emitter.restart_version:       # B库 改了核心代码：自动重启到新版本
            restart(emitter.restart_version)
        if want_restart:                  # 用户让 Agent 重启
            restart()


if __name__ == "__main__":
    main()
