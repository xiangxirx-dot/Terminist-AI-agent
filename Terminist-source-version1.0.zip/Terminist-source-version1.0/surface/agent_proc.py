"""
Agent 独立进程：界面进程只管画和收输入，A库（连同 B库、base 工具、旁聊）在另一个进程里跑。

为什么：两边在同一个进程里时共用 Python 的 GIL，Agent 一忙（流式接收、解析 JSON、估 token、写日志），
界面线程就抢不到 CPU，画面掉帧。分开以后界面进程只做界面的事。

结构：
  界面进程  AgentProxy   —— 和 Agent 长得一样（gui.py 用到的那些成员），调用转成消息发给 Agent 进程
  Agent 进程 host_main   —— 真正的 Agent；要用界面的地方（确认弹窗、删除弹窗、要账号密码、set_ui / 重启 /
                           打开文件夹这几个界面工具、小屏幕窗口）都反过来发消息请界面做
  两边用一条 multiprocessing.Pipe，消息：
    ("event", kind, payload)        Agent 进程 → 界面：Agent 的事件（和以前 emit 的一样）
    ("state", {...})                Agent 进程 → 界面：暂停 / 停止 / 工作流现场，每 0.2 秒有变化才推（界面画的时候不用等）
    ("call", id, 方法, args, kwargs) 任一边请对方做事；("reply", id, ok, 结果) 回复
界面进程退出 → 管道断开 → Agent 进程存好记忆自己退；Agent 进程崩了 → 界面提示并在下次用到时重开一个。

这个模块顶层只用标准库：Agent 进程不导入 pygame / 界面代码。
"""

import itertools
import os
import sys
import threading
import time
import traceback
from pathlib import Path

CALL_TIMEOUT = 15.0            # 界面等 Agent 进程的普通调用最多等多久（聊天这种长调用不限时）


# ============================================================
# 两边共用：一条管道上的请求 / 回复 / 推送
# ============================================================
class Link:
    def __init__(self, conn, handler, on_message=None, on_close=None):
        self.conn = conn
        self.handler = handler          # handler(方法名, args, kwargs) -> 结果（对方发来的 call）
        self.on_message = on_message    # 其他消息（event / state）
        self.on_close = on_close
        self.lock = threading.Lock()
        self.ids = itertools.count(1)
        self.pending: dict[int, list] = {}
        self.closed = False
        threading.Thread(target=self._reader, daemon=True, name="agent-link").start()

    def send(self, msg) -> bool:
        if self.closed:
            return False
        try:
            with self.lock:
                self.conn.send(msg)
            return True
        except (OSError, EOFError, ValueError, BrokenPipeError):
            self._close()
            return False

    def call(self, method, *args, timeout=CALL_TIMEOUT, default=None, **kwargs):
        """请对方做事并等结果。对方报错就抛 RuntimeError；超时 / 管道断了返回 default。"""
        cid = next(self.ids)
        slot = [threading.Event(), None, None]
        self.pending[cid] = slot
        if not self.send(("call", cid, method, args, kwargs)):
            self.pending.pop(cid, None)
            return default
        if not slot[0].wait(timeout):
            self.pending.pop(cid, None)
            return default
        ok, value = slot[1], slot[2]
        if ok is None:                   # 管道断了
            return default
        if not ok:
            raise RuntimeError(value)
        return value

    def _serve(self, cid, method, args, kwargs):
        try:
            value, ok = self.handler(method, args, kwargs), True
        except Exception as e:
            value, ok = f"{type(e).__name__}: {e}", False
        self.send(("reply", cid, ok, value))

    def _reader(self):
        while True:
            try:
                msg = self.conn.recv()
            except (OSError, EOFError, ValueError):
                break
            try:
                kind = msg[0]
                if kind == "call":
                    _, cid, method, args, kwargs = msg
                    threading.Thread(target=self._serve, args=(cid, method, args, kwargs), daemon=True).start()
                elif kind == "reply":
                    _, cid, ok, value = msg
                    slot = self.pending.pop(cid, None)
                    if slot:
                        slot[1], slot[2] = ok, value
                        slot[0].set()
                elif self.on_message:
                    self.on_message(msg)
            except Exception:
                pass
        self._close()

    def _close(self):
        if self.closed:
            return
        self.closed = True
        for slot in list(self.pending.values()):
            slot[1] = None
            slot[0].set()
        self.pending.clear()
        if self.on_close:
            try:
                self.on_close()
            except Exception:
                pass


# ============================================================
# Agent 进程
# ============================================================
def _make_owner(link):
    """小屏幕扩展（screen_actions / screen_window_tool）要找的「界面对象」：只露出它们用的几个成员，全都转给界面。"""
    class Owner:
        def take_screen_actions(self, *a, **k):
            return link.call("owner_call", "take_screen_actions", a, k, timeout=None)

        def set_screen_result(self, *a, **k):
            return link.call("owner_call", "set_screen_result", a, k)

        def open_screen_window(self, *a, **k):
            return link.call("owner_call", "open_screen_window", a, k)

        def close_screen_window(self, *a, **k):
            return link.call("owner_call", "close_screen_window", a, k)

        @property
        def screen_win_open(self):
            return bool(link.call("owner_get", "screen_win_open", default=False))
    return Owner()


def host_main(conn, init: dict):
    """Agent 进程入口（multiprocessing 起的）。"""
    sys.path.insert(0, init["app_root"])
    os.chdir(init["app_root"])
    for k, v in (init.get("env") or {}).items():
        os.environ[k] = v
    import lib_a as da
    from lib_a import web_guard
    import lib_b
    import base
    from base import guard
    from lib_a.sidechat import SideChat
    from lib_a.staff import active_staff, load_staff
    if init.get("memory_dir"):                      # 测试用：记忆放到别处，不碰真的
        da.core.MEMORY_DIR = da.MEMORY_DIR = Path(init["memory_dir"])

    box = {}
    ready = threading.Event()                       # Agent 装好之前进来的调用先等着（装 B库 / base 工具要几秒）

    def handle(method, args, kwargs):
        if not ready.wait(120):
            raise RuntimeError("Agent 进程还没准备好")
        return getattr(box["host"], "rpc_" + method)(*args, **kwargs)

    def on_close():                                 # 界面进程没了：存好记忆就走
        try:
            box["agent"].stop_all()
            box["agent"].save_memory()
        except Exception:
            pass
        os._exit(0)

    link = Link(conn, handle, on_close=on_close)
    owner = _make_owner(link)

    class RemoteWorkspace(da.Workspace):
        """工作区在 Agent 进程里；要问用户的事（确认、账号密码）请界面弹窗。"""

        def __init__(self, root, auto_yes=True):
            super().__init__(Path(root), auto_yes)
            self.screen_owner = owner
            self.agent = None

        def confirm(self, msg: str, detail: str = "", items: list | None = None):
            """请界面弹确认框；items 非空时原样回传勾选结果（不能 bool() 包，会丢勾选内容）。"""
            if self.auto_yes:
                return True
            res = link.call("confirm", msg, detail, items, timeout=None, default=False)
            return res

        def ask_credentials(self, site: str, note: str = "") -> dict:
            return link.call("credentials", site, note, timeout=None, default={"ok": False}) or {"ok": False}

    def make_ws(root):
        if not root:
            return None
        ws = RemoteWorkspace(root)
        ws.protected = [da.APP_ROOT] if Path(root).resolve() != Path(da.APP_ROOT).resolve() else []
        return ws

    def emit(kind, text):
        link.send(("event", kind, text))

    ws = make_ws(init.get("ws_root"))
    agent = da.Agent(ws, emit=emit, model=init["model"])
    box["agent"] = agent
    if ws is not None:
        ws.agent = agent
    if init.get("memory_root") is not None:
        agent._memory_root = Path(init["memory_root"]) if init["memory_root"] else None
    lib_b.attach(agent)
    web_guard.install()
    base.attach(agent)
    web_guard.describe_tools(agent)
    guard.set_handler(lambda items, reason, wait: bool(link.call("delete", items, reason, wait,
                                                                 timeout=None, default=False)))
    for name, schema in (init.get("gui_tools") or {}).items():       # set_ui / 重启 / 打开文件夹：界面的工具
        if schema is None:                                            # 每次请求现生成的（set_ui 的选项跟着设置变）
            schema = (lambda n=name: link.call("gui_schema", n))
        agent.custom_tools[name] = (schema, lambda a, n=name: link.call("gui_tool", n, a, timeout=None,
                                                                        default="错误: 界面没有响应"))

    class ModuleTools:
        """外接模块声明给 Agent 的工具：模块在界面进程里，定义和调用都走管道；定义缓存 2 秒（每次请求都要列一遍）。"""

        def __init__(self):
            self.cache, self.at = [], 0.0

        def schemas(self):
            now = time.monotonic()
            if now - self.at > 2:
                got = link.call("module_tools", timeout=10, default=None)
                if isinstance(got, list):
                    self.cache = got
                self.at = now
            return self.cache

        def names(self):
            return {t["function"]["name"] for t in self.schemas()}

        def call(self, name, args):
            return link.call("module_tool_call", name, args, timeout=None, default="错误: 界面没有响应")

    agent.tool_providers.append(ModuleTools())

    def staff_name():
        try:
            info = load_staff().get(active_staff())
            return str(info.get("label") or active_staff()) if isinstance(info, dict) else str(active_staff())
        except Exception:
            return "前台"

    side = SideChat(agent, emit=lambda k, t: emit("chat_" + k, t),
                    on_stop=lambda: link.call("stop_workflow", timeout=5), label=staff_name)

    class Host:
        # ---- 界面调过来的 ----
        def rpc_chat(self, text):
            agent.chat(text)

        def rpc_side_ask(self, text):
            side.ask(text)

        def rpc_side_merge(self):
            return side.merge_into_main()

        def rpc_side_clear(self):
            side.session.clear()

        def rpc_get(self, name):
            return getattr(agent, name)

        def rpc_messages(self):
            return list(agent.messages)

        def rpc_switch_workspace(self, root):
            new = make_ws(root)
            if new is not None:
                new.agent = agent
            agent.switch_workspace(new)

        def rpc_request_economy(self):
            """界面定时拉经济栏：在 Agent 进程里重算并下发 context（空闲不烧 token 也走这条）。"""
            agent._emit_context()
            return True

        def rpc_memory_root(self):
            """(有没有设过, 值)：Agent 上 _memory_root 只有 AI 换过文件夹才有，界面靠 hasattr 判断。"""
            if not hasattr(agent, "_memory_root"):
                return False, ""
            return True, str(agent._memory_root or "")

        # 内置浏览器在 Agent 进程里（A库 上网用的就是它）：小屏幕的截图 / 手动点击都得在这边做，
        # 界面进程自己调 base.web 会另起一个空白的 Edge
        def rpc_web_screenshot(self, full=False):
            from base import web
            return web.screenshot(bool(full))

        def rpc_web_mouse(self, kind, x, y, amount=0, right=False):
            from base import web
            b = web.browser()
            if kind == "click":
                b.call(lambda bb: bb.page.mouse.click(x, y, button="right" if right else "left"), timeout=20)
            else:
                def roll(bb):
                    bb.page.mouse.move(x, y)
                    bb.page.mouse.wheel(0, amount * 100)
                b.call(roll, timeout=20)
            return True

        def rpc_web_frame(self, quality=72):
            from base import web
            return web.frame(int(quality))

        def rpc_web_ui(self, op, args=None):
            from base import web
            return web.ui(str(op), **(args or {}))

        def rpc_takeover(self, on, paused=False):
            """接管模式开 / 关 / 暂停：眼睛（截图 + 本地识别）在这边跑，Agent 每做一件事带上前 5 秒的眼睛日志。"""
            from base import eye
            agent.takeover = bool(on)
            eye.set_takeover(bool(on), bool(paused))
            return eye.status()

        def rpc_set_memory_root(self, root):
            agent._memory_root = Path(root) if root else None

        def __getattr__(self, name):                 # 其余都是直接调 Agent 的方法：rpc_pause → agent.pause()
            if name.startswith("rpc_"):
                fn = getattr(agent, name[4:])
                return lambda *a, **k: fn(*a, **k)
            raise AttributeError(name)

    box["host"] = Host()
    ready.set()

    def push_state():                               # 界面每帧要读的状态：变了就推，界面不用等
        last = None
        while not link.closed:
            try:
                st = {"paused": agent.paused, "stop_requested": agent.stop_requested,
                      "live": agent.live_report(), "busy": agent.live_busy,
                      "ws": str(agent.ws.root) if agent.ws is not None else None}
                if st != last:
                    link.send(("state", st))
                    last = st
            except Exception:
                pass
            time.sleep(0.2)

    threading.Thread(target=push_state, daemon=True).start()        # 第一份状态推过去，界面就知道 Agent 进程起来了
    while not link.closed:
        time.sleep(0.5)


# ============================================================
# 界面进程：和 Agent 长得一样的代理
# ============================================================
class _Session:
    def __init__(self, link):
        self.link = link

    def clear(self):
        self.link.call("side_clear", default=None)


class SideProxy:
    """界面这边的旁聊：真正的旁聊 Agent 在 Agent 进程里（它要读干活 Agent 的记忆和现场）。"""

    def __init__(self, link):
        self.link = link
        self.session = _Session(link)

    def ask(self, text):
        self.link.call("side_ask", text, timeout=None)

    def merge_into_main(self):
        return self.link.call("side_merge", default=False)


class AgentProxy:
    """界面进程里代替 Agent 的对象。gui.py 用到的成员都在这里，调用转给 Agent 进程。"""

    def __init__(self, app, ws, model: str, gui_tools: dict, events, extra_init: dict | None = None):
        import multiprocessing as mp
        self.app, self._ws, self.events = app, ws, events
        self.state = {"paused": False, "stop_requested": False, "live": "", "busy": False,
                      "ws": str(ws.root) if ws is not None else None}
        self.gui_tools = gui_tools                   # 名字 -> (定义 或 None=每次现生成, 函数)
        app_root = str(Path(__file__).resolve().parent.parent)
        init = {"app_root": app_root, "model": model, "ws_root": str(ws.root) if ws is not None else None,
                "gui_tools": {n: (None if callable(s) else s) for n, (s, _) in gui_tools.items()},
                "env": {k: v for k, v in os.environ.items() if k.startswith(("TERMINIST_", "DEEPSEEK_"))}}
        init.update(extra_init or {})
        ctx = mp.get_context("spawn")
        here, there = ctx.Pipe(duplex=True)
        self.proc = ctx.Process(target=host_main, args=(there, init), daemon=True, name="terminist-agent")
        self.proc.start()
        there.close()
        self.alive = True
        self.ready = threading.Event()               # Agent 进程推来第一份状态 = 装好了
        self.link = Link(here, self._handle, on_message=self._on_message, on_close=self._on_close)
        self.side = SideProxy(self.link)

    # ---------------- Agent 进程发过来的 ----------------
    def _on_message(self, msg):
        if msg[0] == "event":
            self.events.put((msg[1], msg[2]))
        elif msg[0] == "state":
            self.state = msg[1]
            self.ready.set()
            if self.state.get("ws") and (self._ws is None or str(self._ws.root) != self.state["ws"]):
                self._ws = self.app.gui_workspace(self.state["ws"])     # Agent 自己换了文件夹：界面这边也换一个

    def _on_close(self):
        self.ready.set()                             # 别让等着的调用一直等
        if self.alive:
            self.alive = False
            self.events.put(("error", "Agent 进程退出了（下次发消息会自动重开一个，记忆在每轮结束时已经存好）"))
            self.events.put(("done", ""))

    def _handle(self, method, args, kwargs):
        app = self.app
        if method == "confirm":
            return app.remote_confirm(*args)
        if method == "credentials":
            return app.remote_credentials(*args)
        if method == "delete":
            return app._delete_handler(*args)
        if method == "gui_tool":
            name, a = args
            return self.gui_tools[name][1](a)
        if method == "gui_schema":
            s = self.gui_tools[args[0]][0]
            return s() if callable(s) else s
        if method == "owner_call":
            name, a, k = args
            return getattr(app, name)(*a, **k)
        if method == "owner_get":
            return getattr(app, args[0], None)
        if method == "stop_workflow":
            app.on_stop()
            return True
        if method == "module_tools":                 # 外接模块声明给 Agent 的工具（模块在界面进程里）
            from surface import modules_api
            return modules_api.agent_tool_schemas()
        if method == "module_tool_call":
            from surface import modules_api
            return modules_api.call_agent_tool(*args)
        raise AttributeError(method)

    # ---------------- gui.py 用到的 Agent 成员 ----------------
    def _call(self, method, *args, default=None, timeout=CALL_TIMEOUT, **kwargs):
        if not self.alive or not self.ready.wait(90):   # 刚起的 Agent 进程要几秒装好：先等它
            return default
        try:
            return self.link.call(method, *args, timeout=timeout, default=default, **kwargs)
        except RuntimeError as e:                      # Agent 进程那边出错：报出来，绝不让它把界面弄崩
            self.events.put(("error", f"[Agent 进程] {method} 出错：{e}"))
            return default

    @property
    def paused(self):
        return bool(self.state.get("paused"))

    @property
    def stop_requested(self):
        return bool(self.state.get("stop_requested"))

    @property
    def live_busy(self):
        return bool(self.state.get("busy"))

    def live_report(self):
        return self.state.get("live") or ""

    @property
    def ws(self):
        return self._ws

    @property
    def messages(self):
        return self._call("messages", default=[{"role": "system", "content": ""}], timeout=60)

    @property
    def _memory_root(self):
        """和真 Agent 一样：没设过就是没有这个属性（hasattr 为 False），不能抛别的异常——
        以前这里把对面的 AttributeError 变成 RuntimeError，hasattr 接不住，重启时整个窗口崩掉。"""
        got = self._call("memory_root", default=(False, ""))
        if not got or not got[0]:
            raise AttributeError("_memory_root")
        return Path(got[1]) if got[1] else None

    @_memory_root.setter
    def _memory_root(self, root):
        self._call("set_memory_root", str(root) if root else "")

    @staticmethod
    def is_internal(m):
        from lib_a import Agent
        return Agent.is_internal(m)

    def chat(self, text):
        if not self.alive or not self.ready.wait(90):
            raise RuntimeError("Agent 进程不在了")
        self.link.call("chat", text, timeout=None)

    def switch_workspace(self, ws):
        self._ws = ws
        self._call("switch_workspace", str(ws.root) if ws is not None else None)

    def stop_all(self):
        self.state["stop_requested"] = True          # 界面马上当成在停（真正的停在 Agent 进程里）
        return bool(self._call("stop_all", default=False, timeout=5))

    def stop(self):
        self.state["stop_requested"] = True
        return self._call("stop", timeout=5)

    def web_screenshot(self, full=False) -> bytes:
        return self._call("web_screenshot", full, default=b"", timeout=60) or b""

    def web_mouse(self, kind, x, y, amount=0, right=False):
        """出错时抛 RuntimeError（小屏幕要把失败原因显示出来）。"""
        if not self.alive or not self.ready.wait(90):
            raise RuntimeError("Agent 进程不在了")
        return self.link.call("web_mouse", kind, x, y, amount, right, timeout=40, default=None)

    def set_takeover(self, on, paused=False):
        """接管模式开关：转给 Agent 进程（眼睛在那边跑）。"""
        return self._call("takeover", bool(on), bool(paused), default=None, timeout=20)

    def web_frame(self, quality=72) -> dict:
        """小屏幕的一帧：{"jpeg", "url", "title", "loading"}；拿不到返回空 dict。"""
        return self._call("web_frame", quality, default={}, timeout=20) or {}

    def web_ui(self, op, args=None):
        """小屏幕上的手动操作（出错时抛 RuntimeError，小屏幕要把原因显示出来）。"""
        if not self.alive or not self.ready.wait(90):
            raise RuntimeError("Agent 进程不在了")
        return self.link.call("web_ui", op, dict(args or {}), timeout=45, default=None)

    def load_memory(self):
        return self._call("load_memory", default=None, timeout=60)     # None = 没读成（进程还没起来 / 超时），界面会重试

    def context_tokens(self):
        return self._call("context_tokens", default=0, timeout=30)

    def request_economy(self):
        """让 Agent 进程立刻重算并下发一次经济栏（context 事件），空闲时也能用。"""
        return self._call("request_economy", default=None, timeout=10)

    def list_models(self):
        return self._call("list_models", default=[], timeout=60)

    def __getattr__(self, name):
        """其余方法（pause / resume / add_instruction / take_steer / set_model / set_persona / save_memory /
        clear_memory …）原样转过去。"""
        if name.startswith("_"):
            raise AttributeError(name)
        return lambda *a, **k: self._call(name, *a, **k)

    def close(self):
        """界面正常退出：请 Agent 进程存好记忆，再结束它。"""
        if self.alive:
            try:
                self._call("save_memory", timeout=10)
            except Exception:
                pass
        self.alive = False
        try:
            self.proc.terminate()
        except Exception:
            pass
