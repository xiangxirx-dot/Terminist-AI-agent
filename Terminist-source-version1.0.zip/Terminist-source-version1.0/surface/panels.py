# -*- coding: utf-8 -*-
"""停靠面板系统：7 个模块的统一注册表 + 槽位状态模型 + 设置持久化。
阶段一只建数据层，不改界面渲染。"""
import copy

PANEL_KEYS = ("staff", "screen", "economy", "task_queue", "flow", "write", "board", "tree", "takeover")

# 每个面板：key、默认停靠边（"left"/"right"）、默认是否隐藏、中文标题
PANELS = {
    "staff":   {"side": "left",  "hidden": False, "title": "员工栏"},
    "screen":  {"side": "left",  "hidden": False, "title": "小屏幕"},
    "economy": {"side": "left",  "hidden": False, "title": "经济栏"},
    "task_queue": {"side": "right", "hidden": False, "title": "任务队列"},
    "flow":    {"side": "right", "hidden": False, "title": "工作流"},
    "write":   {"side": "right", "hidden": True,  "title": "写入预览"},
    "board":   {"side": "right", "hidden": True,  "title": "小画板"},
    "tree":    {"side": "right", "hidden": True,  "title": "文件树视图"},
    "takeover": {"side": "right", "hidden": True, "title": "接管"},
}

LEFT_MAX = 3   # 左栏最多 3 个槽

# 默认槽位状态 = 现在的布局：左栏 3 槽、右栏工作流，tree 隐藏
DEFAULT_DOCK = {
    "left": ["staff", "screen", "economy"],
    "right": ["task_queue", "flow"],
    "hidden": ["tree", "board", "write", "takeover"],
}


def default_dock() -> dict:
    """默认槽位状态（深拷贝，随便改不会污染 DEFAULT_DOCK）。"""
    return copy.deepcopy(DEFAULT_DOCK)


def load_dock(settings: dict) -> dict:
    """从设置文件读 dock 状态；键名 "panel_dock"。读不到/坏了就用默认。
    每个面板都保证在某一列里：哪一栏都不在的（后来新加的、旧存档里没有的）放进 hidden，模块管理里才找得到。"""
    raw = settings.get("panel_dock") if isinstance(settings, dict) else None
    d = default_dock()
    if isinstance(raw, dict):
        left = raw.get("left")
        right = raw.get("right")
        hidden = raw.get("hidden")
        if isinstance(left, list):
            d["left"] = [k for k in left if k in PANELS][:LEFT_MAX]
        if isinstance(right, list):
            d["right"] = [k for k in right if k in PANELS and k not in d["left"]]
        if isinstance(hidden, list):
            d["hidden"] = [k for k in hidden if k in PANELS and k not in d["left"] and k not in d["right"]]
    placed = set(d["left"]) | set(d["right"]) | set(d["hidden"])
    d["hidden"] += [k for k in PANELS if k not in placed]
    return d


def save_dock(settings: dict, dock: dict) -> None:
    """把 dock 写回 settings（调用方负责 _save_setting 落盘）。"""
    if not isinstance(settings, dict) or not isinstance(dock, dict):
        return
    settings["panel_dock"] = {
        "left": list(dock.get("left", [])),
        "right": list(dock.get("right", [])),
        "hidden": list(dock.get("hidden", [])),
    }


if __name__ == "__main__":
    print(default_dock())
    print(load_dock({}))
    print(load_dock({"panel_dock": {"left": ["staff", "bogus"], "right": ["write"], "hidden": []}}))
