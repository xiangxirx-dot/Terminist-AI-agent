param(
    [Parameter(Mandatory=$true)][string]$AppRoot,
    [Parameter(Mandatory=$true)][string]$B64,
    [string]$Icon = ""
)
$ErrorActionPreference = "Stop"

$appId = "Terminist"
if ([string]::IsNullOrEmpty($Icon)) { $Icon = Join-Path $AppRoot "icon.png" }

# 确保 AUMID 已注册（未注册时 Show 会静默丢弃通知）
$reg = "HKCU:\Software\Classes\AppUserModelID\$appId"
if (!(Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
New-ItemProperty -Path $reg -Name DisplayName -Value "Terminist" -Force | Out-Null
if (Test-Path $Icon) { New-ItemProperty -Path $reg -Name IconUri -Value $Icon -Force | Out-Null }

$Text = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($B64))
$Text = $Text -replace "\r", " " -replace "\n", " "

# 图标转成 file:// 绝对路径（用 Uri 转义，空格变 %20）
$iconUrl = ([System.Uri]$Icon).AbsoluteUri

# XML 转义
$safe = $Text -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' -replace '"','&quot;' -replace "'",'&apos;'

# 带图标、foreground 激活的 toast
$xml = "<toast activationType=`"foreground`" launch=`"Terminist`"><visual><binding template=`"ToastGeneric`"><text>Terminist</text><text>$safe</text><image placement=`"appLogoOverride`" src=`"$iconUrl`" /></binding></visual></toast>"

[void][Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]
[void][Windows.Data.Xml.Dom.XmlDocument,Windows.Data.Xml.Dom.XmlDocument,ContentType=WindowsRuntime]
[void][Windows.UI.Notifications.ToastNotification,Windows.UI.Notifications,ContentType=WindowsRuntime]

$doc = New-Object Windows.Data.Xml.Dom.XmlDocument
$doc.LoadXml($xml)
$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId)
$toast = New-Object Windows.UI.Notifications.ToastNotification $doc
$notifier.Show($toast)
"ok"
