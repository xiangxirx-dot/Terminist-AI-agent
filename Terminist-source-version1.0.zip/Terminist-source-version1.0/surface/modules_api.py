"""
外接模块：Terminist 根目录下的 modules/ 文件夹放模块包，启动时自动解包、读进来，和内置模块（员工栏、工作流、经济栏……）
一样能放进左栏 / 右栏、拖成独立小窗口、在「模块管理」里放回。运行中加了 / 换了模块包：顶栏「模块」→「刷新模块」
（或者输入 /modules reload），不用重启。

modules/ 里认三种东西：
- 模块包 xxx.tmod（或 .zip）：一个压缩包，里面有 module.json（名字、标题、入口……）、入口代码（默认 main.py）、
  assets/ 里的贴图和音效。解到 modules/_unpacked/xxx/ 再读；包没变不重复解，换了新包重新解。
- 模块文件夹 xxx/：和包里一样的结构，没打包（做模块时边改边试用这个）。
- 单个 xxx.py：最简单的模块，没有素材。
制作教程见 modules/README.md；打包：python -m surface.modules_api pack <模块文件夹>。

模块代码里写一个 MODULE 字典（module.json 里写的元信息优先）：
    MODULE = {"key": "clock", "title": "时钟", "side": "right", "sub": "…", "refresh": 1.0,
              "draw": draw, "on_click": on_click}
ctx 是给模块用的小接口（不把整个界面对象交出去，模块写错了也不会把界面弄坏）：
    ctx.screen / ctx.rect          要画的 Surface / 内容区
    ctx.font / ctx.small           大 / 小号字体             ctx.text(str, color=None, small=False) -> Surface
    ctx.color(name)                主题颜色                  ctx.s(px)  按界面缩放换算像素
    ctx.mouse / ctx.now            鼠标位置 / 当前时间        ctx.state  模块自己的 dict（跨帧保留）
    ctx.asset(name) -> Path        模块素材的路径（assets/ 下找，找不到再在模块根目录找）
    ctx.image(name, size=None)     贴图 -> Surface（读一次就缓存）
    ctx.sound(name, volume=1.0)    播音效（没有声卡 / 读不了就静默跳过）
    画图形：ctx.box(px, py, w, h, color, width=0, radius=0) / ctx.circle(cx, cy, r, color, width=0)
            ctx.line([(x, y), …], color, width=1) / ctx.polygon([(x, y), …], color, width=0)
            width=0 填充、>0 只描边；color 可以是主题色名字、RGB 元组或 pygame.Color
    ctx.text_size(str, small=False) -> (w, h)   量文字宽高（不落笔）
    ctx.clip((x, y, w, h))                      可 with 的裁剪区：with ctx.clip(box): 画的东西只在这个范围里可见
    输入框：ctx.input(name, (x, y, w, h), placeholder="", password=False, max_len=0, small=False,
                      on_submit=fn(ctx, text), on_change=fn(ctx, text)) -> 当前文字
            只给位置就行：画框、点击拿焦点、光标闪烁、打字、输入法预览、退格 / Delete / ←→ / Home / End、
            Shift / 拖拽 / 双击选择、Ctrl+A/C/X/V、文字太长横向滚动，全由框架处理；文字存在 ctx.state[name]。
            Enter 调 on_submit（没给就交给 on_key）；Tab、↑↓ 等别的键照常进 on_key；Esc / 点框外放掉焦点。
            ctx.input_focused(name=None) / ctx.focus_input(name) / ctx.set_input(name, text)
    全局变量（所有模块共用、存盘）：MODULE["globals"] = {"city": "北京", "volume": {"default": 5, "min": 0, "max": 10,
            "title": "音量", "desc": "…"}, "unit": {"options": ["C", "F"]}}（module.json 里也能写 globals）；
            type 可写 str/int/float/bool/choice，不写按默认值推断。读写：ctx.get_global(name, default=None) /
            ctx.set_global(name, value)（按类型转换，转不了抛 ValueError）/ ctx.reset_global(name) / ctx.globals；
            谁改了，所有模块重画并收到 on_global(ctx, name, value)。主人在「模块管理」→「全局模块设置」面板里直接改。
    ctx.title / ctx.side / ctx.refresh          模块标题 / 停在哪一栏 / 自动重画间隔
    ctx.redraw()                                让模块马上一帧重画（不等 refresh）
    ctx.save(data=None) -> bool / ctx.load() -> dict   把状态存成文件 / 读回来（data 省略就存 ctx.state）
    鼠标事件：MODULE 里可选写 on_click（按下）/ on_up / on_wheel / on_motion / on_enter / on_leave，
             统一由 event(kind, …) 入口分发（kind: down/up/wheel/motion/enter/leave，不认识的返回 False）。
    数据读入：ctx.read_file(name) / ctx.write_file(name, text) / ctx.http_get(url) / ctx.tool(name, **kwargs)
             （写文件不许跑出模块目录；http_get 读一次缓存 60 秒）
    数据读入（只读契约）：ctx.tool(name, **kwargs) 只读白名单制，白名单 = now / file_stats / find_files / grep_files /
              read_lines / web_history / web_last / bg_list / bg_output / credentials_list / credentials_get /
              graph_query / recall / web_search / web_open，每次现场取最新值、不缓存，白名单外的名字（含写类工具）
              一律返回空串；ctx.import_lib(name) 只 import 任意 lib_a 模块（只读、不执行、不缓存，越界返回 None）；
              ctx.notify(text) 弹一条界面通知。
    控件（只给位置）：ctx.button / ctx.checkbox / ctx.slider / ctx.select / with ctx.scroll(...) as top；
             文字排版 ctx.wrap / ctx.ellipsize / ctx.text_box。
    给 Agent 的工具：MODULE["tools"] = {名字: {"desc", "params", "required", "fn": fn(ctx, args)}}，
             Agent 看到的名字是 <key>__<名字>，在界面主线程里跑；ctx.ask_agent(text) 请 Agent 做事（忙就排队）。
    后台：ctx.fetch(url, on_done=None, method=, json_body=, cache=) 不卡界面；ctx.run_bg(fn, on_done)。
    事件：on_load / on_unload / on_resize(w, h) / on_message(event, data, sender)（ctx.emit 发）/
             on_agent(kind, text) / on_drop(path) / on_theme，全在 HOOKS 里。
    系统：ctx.clipboard_get / clipboard_set / toast / open_url / browse / colors / dark。
    开发：modules/ 里文件改了 1.5 秒内自动重读；完整报错写进 modules/.logs/<key>.log；
             python -m surface.modules_api test <模块> 不开界面自测；停用记在 modules/.disabled.json。
    完整说明见 modules/README.md。
"""

import hashlib
import importlib.util
import json
import queue
import shutil
import sys
import threading
import time
import traceback
import zipfile
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
MODULES_DIR = APP_ROOT / "modules"
UNPACK_DIR_NAME = "_unpacked"
PACK_SUFFIXES = (".tmod", ".zip")
MAX_UNPACKED = 200 * 1024 * 1024      # 一个模块包解开最多 200MB（防止压缩炸弹）
BUILTIN = {"staff", "screen", "economy", "flow", "write", "board", "tree"}
GLOBALS_KEY = "module_globals"        # 内置的「全局模块设置」面板（用外接模块同一套机制画）
GLOBAL_TYPES = ("str", "int", "float", "bool", "choice")

_plugins: dict[str, dict] = {}        # key -> {key, title, side, sub, refresh, draw, on_click, path, dir, mtime, state}
_errors: dict[str, str] = {}          # 文件名 -> 加载出错的原因
_images: dict[tuple, object] = {}     # (模块目录, 文件名, 尺寸) -> Surface
_sounds: dict[str, object] = {}
_dirty: set[str] = set()              # 模块调了 ctx.redraw()，下一帧就要重画的 key
_focus_key: str | None = None         # 当前拿到键盘焦点的模块 key（None 表示没有）
_focus_field: str | None = None       # 焦点在这个模块的哪个输入框（ctx.input 的 name；None = 模块自己处理键盘）
_fields: dict[tuple[str, str], dict] = {}   # (模块 key, 输入框 name) -> 光标 / 选择 / 滚动 / 本帧位置
_blink_phase = None                   # 输入框光标闪烁相位：变了就重画一帧
_widgets: dict[tuple[str, str], dict] = {}  # (模块 key, 控件 name) -> 按钮 / 勾选 / 滑块 / 下拉 / 滚动区的本帧位置和状态
_overlays: list = []                  # 本帧要最后画的东西（下拉展开的列表），(模块 key, fn)
_last_frame_t = None                  # 上一帧时刻（给 on_frame 用，算帧间隔）
_http_cache: dict[str, tuple[float, dict]] = {}   # url -> (取的时间, 结果)，60 秒内不重复取
MODULE_COMMANDS: dict[str, tuple[str, object]] = {}   # 命令前缀（小写、无斜杠）-> (插件 key, fn(ctx, arg_str))
_host: dict = {"app": None, "colors": None, "scale": None, "text": None}   # 界面：模块回调要的 ctx 从这里拼
_main_jobs: "queue.Queue" = queue.Queue()   # 后台线程做完的事：(模块 key, fn(ctx, *args), args, 等待的 Event 或 None)
_main_thread = threading.main_thread()
_inflight: dict = {}                  # 正在后台取的网址 -> [(模块 key, on_done)]
_asks: list = []                      # 模块请 Agent 做的事，Agent 空了按顺序提交：(模块 key, 文字)
_watch = {"at": 0.0, "sig": None}     # 自动刷新：modules/ 里的文件签名
_theme = {"sig": None}
HOOKS = ("on_click", "on_up", "on_wheel", "on_motion", "on_enter", "on_leave", "on_tick", "on_frame", "on_key",
         "on_global", "on_load", "on_unload", "on_resize", "on_message", "on_agent", "on_drop", "on_theme")
DISABLED_FILE = ".disabled.json"      # modules/ 下：停用的模块（文件名列表），停用的不读


# ---------------- 找模块 / 解包 ----------------
def disabled() -> set[str]:
    """停用的模块（modules/ 里的文件名 / 文件夹名，和「模块管理」里显示的一样）。"""
    try:
        data = json.loads((MODULES_DIR / DISABLED_FILE).read_text(encoding="utf-8"))
        return {str(x) for x in data} if isinstance(data, list) else set()
    except Exception:
        return set()


def set_enabled(label: str, on: bool) -> bool:
    """启用 / 停用一个模块（按 modules/ 里的名字，文件夹带 /）。下次刷新生效。"""
    off = disabled()
    (off.discard if on else off.add)(str(label))
    try:
        MODULES_DIR.mkdir(exist_ok=True)
        (MODULES_DIR / DISABLED_FILE).write_text(json.dumps(sorted(off), ensure_ascii=False), encoding="utf-8")
        return True
    except OSError:
        return False


def _sources(include_disabled: bool = False) -> list[tuple[str, Path]]:
    """modules/ 里的模块：[(名字, 路径)]。包（.tmod/.zip）、文件夹（module.json 或 main.py 或 __init__.py）、单个 .py。"""
    if not MODULES_DIR.is_dir():
        return []
    off = set() if include_disabled else disabled()
    out = []
    for p in sorted(MODULES_DIR.iterdir()):
        if (p.name + "/" if p.is_dir() else p.name) in off:
            continue
        if p.name.startswith(("_", ".")):
            continue
        if p.is_file() and p.suffix.lower() in PACK_SUFFIXES:
            out.append((p.name, p))
        elif p.is_file() and p.suffix == ".py":
            out.append((p.name, p))
        elif p.is_dir() and any((p / n).is_file() for n in ("module.json", "main.py", "__init__.py")):
            out.append((p.name + "/", p))
    return out


def _unpack(pack: Path) -> Path:
    """把模块包解到 modules/_unpacked/<包名>/：包没变（大小 + 修改时间一样）就不重复解。防路径穿越、防压缩炸弹。"""
    dest = MODULES_DIR / UNPACK_DIR_NAME / pack.stem
    stamp = f"{pack.stat().st_size}:{pack.stat().st_mtime_ns}"
    marker = dest / ".unpacked_from"
    try:
        if marker.read_text(encoding="utf-8") == stamp:
            return dest
    except OSError:
        pass
    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(pack) as z:
        names = [i for i in z.infolist() if not i.is_dir()]
        if sum(i.file_size for i in names) > MAX_UNPACKED:
            raise ValueError(f"解开太大了（超过 {MAX_UNPACKED // 1024 // 1024}MB）")
        prefix = _common_root(names)
        root = dest.resolve()
        for i in names:
            rel = i.filename[len(prefix):] if prefix else i.filename
            if not rel:
                continue
            target = (dest / rel).resolve()
            if root not in target.parents:
                raise ValueError(f"包里有越界的路径：{i.filename}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(i) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)
    marker.write_text(stamp, encoding="utf-8")
    return dest


def _common_root(infos) -> str:
    """打包时连外层文件夹一起压进去了（clock/main.py …）：解包时去掉这一层。"""
    tops = {i.filename.replace("\\", "/").split("/", 1)[0] for i in infos}
    if len(tops) == 1 and all("/" in i.filename.replace("\\", "/") for i in infos):
        return tops.pop() + "/"
    return ""


def _load(src: Path) -> dict:
    """读一个模块（包 / 文件夹 / 单个 .py），返回规范化好的描述；出错抛异常（调用方记下原因）。"""
    if src.is_file() and src.suffix.lower() in PACK_SUFFIXES:
        folder = _unpack(src)
    elif src.is_dir():
        folder = src
    else:
        folder = None
    meta = {}
    if folder is not None:
        mj = folder / "module.json"
        if mj.is_file():
            meta = json.loads(mj.read_text(encoding="utf-8"))
            if not isinstance(meta, dict):
                raise ValueError("module.json 要是一个 {…} 对象")
        entry = folder / str(meta.get("entry") or ("__init__.py" if (folder / "__init__.py").is_file() else "main.py"))
        if not entry.is_file():
            raise ValueError(f"找不到入口代码 {entry.name}（module.json 里的 entry，默认 main.py）")
    else:
        entry, folder = src, src.parent
    name = f"terminist_module_{src.stem}"
    spec = importlib.util.spec_from_file_location(name, entry)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    added = str(folder) not in sys.path and folder != MODULES_DIR
    if added:
        sys.path.insert(0, str(folder))           # 入口代码里可以 import 同一个包里的别的 .py
    try:
        spec.loader.exec_module(mod)
    finally:
        if added:
            try:
                sys.path.remove(str(folder))
            except ValueError:
                pass
    m = dict(getattr(mod, "MODULE", None) or {})
    if not m and not meta:
        raise ValueError("代码里没有 MODULE 字典，也没有 module.json")
    for k in ("key", "title", "side", "sub", "refresh"):    # module.json 写的元信息优先
        if meta.get(k) not in (None, ""):
            m[k] = meta[k]
    key = str(m.get("key") or "").strip()
    if not key or not key.replace("_", "").isalnum():
        raise ValueError("key 要写一个英文名（字母、数字、下划线）")
    if key in BUILTIN or key == GLOBALS_KEY:
        raise ValueError(f"key「{key}」和内置模块重名了")
    gdecl = _parse_globals({**(m.get("globals") or {}), **(meta.get("globals") or {})}
                           if isinstance(m.get("globals") or {}, dict) and isinstance(meta.get("globals") or {}, dict)
                           else None)
    if not callable(m.get("draw")):
        raise ValueError("MODULE['draw'] 要是一个函数 draw(ctx)")
    side = str(m.get("side") or "right")
    cmds = m.get("commands") or {}
    if not isinstance(cmds, dict):
        raise ValueError("MODULE['commands'] 要是一个 {前缀: 函数} 字典")
    commands = {}
    for prefix, fn in cmds.items():
        pfx = str(prefix).strip().lower()
        if not pfx or not pfx[0].isalpha() or not pfx.replace("_", "").isalnum() or not pfx.isascii():
            raise ValueError(f"命令前缀「{prefix}」要写纯英文（字母开头的字母、数字、下划线）")
        if not callable(fn):
            raise ValueError(f"MODULE['commands']['{pfx}'] 要是一个函数 fn(ctx, arg_str)")
        commands[pfx] = fn
    tools = _parse_tools(key, {**(m.get("tools") or {})})
    out = {"key": key, "title": str(m.get("title") or key), "side": side if side in ("left", "right") else "right",
           "sub": str(m.get("sub") or ""), "refresh": float(m.get("refresh") or 0),
           "version": str(meta.get("version") or m.get("version") or ""),
           "author": str(meta.get("author") or m.get("author") or ""),
           "description": str(meta.get("description") or m.get("description") or ""),
           "draw": m["draw"], "globals": gdecl, "tools": tools, "commands": commands,
           "path": str(src), "dir": str(folder), "mtime": _mtime(src), "state": {}, "_need_load": True}
    # 事件函数都是可选的（HOOKS 里每个名字的参数见文件开头的说明 / modules/README.md）
    for h in HOOKS:
        out[h] = m.get(h) if callable(m.get(h)) else None
    return out


def _mtime(src: Path) -> float:
    """模块变没变：包看包本身；文件夹看里面最新改过的文件（边改边刷新也认得出）。"""
    if src.is_dir():
        return max((p.stat().st_mtime for p in src.rglob("*") if p.is_file()), default=src.stat().st_mtime)
    return src.stat().st_mtime


def load_all() -> tuple[list[str], list[str], dict[str, str]]:
    """扫一遍 modules/：新的读进来，改过的重新读（包会重新解），删掉的去掉。返回 (新加的 key, 去掉的 key, 出错 {名字: 原因})。"""
    MODULES_DIR.mkdir(exist_ok=True)
    seen, added = set(), []
    _errors.clear()
    by_path = {p["path"]: k for k, p in _plugins.items()}
    for label, src in _sources():
        old_key = by_path.get(str(src))
        try:
            if old_key and _plugins[old_key]["mtime"] == _mtime(src):
                seen.add(old_key)                      # 没改过：不重读
                continue
            p = _load(src)
        except Exception as e:
            _errors[label] = f"{type(e).__name__}: {e}"
            if old_key:
                seen.add(old_key)                      # 改坏了：先留着旧的那份
            continue
        if p["key"] in _plugins and _plugins[p["key"]]["path"] != p["path"]:
            _errors[label] = f"key「{p['key']}」和 {Path(_plugins[p['key']]['path']).name} 重名了"
            continue
        if old_key:
            _call_hook(_plugins[old_key], "on_unload")   # 旧的那份先收拾（线程、文件）再换
        if old_key and old_key != p["key"]:
            _plugins.pop(old_key, None)
        if old_key:
            p["state"] = _plugins.get(p["key"], {}).get("state", {})   # 重新读：保留它自己的状态
        else:
            added.append(p["key"])
        _clear_assets(p["dir"])                         # 换了包：贴图 / 音效重新读
        _plugins[p["key"]] = p
        seen.add(p["key"])
    if GLOBALS_KEY not in _plugins:                    # 内置的全局设置面板：跟外接模块一样放进「模块管理」
        _plugins[GLOBALS_KEY] = _globals_plugin()
        added.append(GLOBALS_KEY)
    seen.add(GLOBALS_KEY)
    removed = [k for k in list(_plugins) if k not in seen]
    for k in removed:
        _call_hook(_plugins[k], "on_unload")
        _plugins.pop(k, None)
        for fk in [fk for fk in _fields if fk[0] == k]:
            _fields.pop(fk, None)
        for wk in [wk for wk in _widgets if wk[0] == k]:
            _widgets.pop(wk, None)
    if _focus_key is not None and _focus_key not in _plugins:
        set_focus(None)
    _rebuild_globals()
    try:
        rebuild_commands()
    except ValueError as e:                            # 两个模块抢同一个命令前缀：记下来，别让刷新整个失败
        _errors["命令冲突"] = str(e)
    _note_installs()
    _watch["sig"] = _source_sig()                      # 刚读完：自动刷新从这一刻的样子开始比
    return added, removed, dict(_errors)


_new_installs: list = []


def _note_installs():
    """第一次见到的模块记下来，界面提醒一次：模块的代码以 Terminist 的权限运行，只装信得过的。"""
    path = MODULES_DIR / ".state" / "_known.json"
    try:
        known = set(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        known = None                                    # 第一次用这个功能：现有的都当见过，不吓人
    now = {k for k in _plugins if k != GLOBALS_KEY}
    if known is not None:
        _new_installs.extend(sorted(now - known))
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(sorted(now | (known or set())), ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def take_new_installs() -> list[str]:
    """新装的模块标题（取一次就清空）。"""
    out = [_plugins[k]["title"] for k in _new_installs if k in _plugins]
    _new_installs.clear()
    return out


def catalog() -> list[dict]:
    """「模块管理」用：modules/ 里所有模块（含停用的、读不了的）：名字、key、标题、版本、作者、是否启用、出错原因。"""
    off = disabled()
    by_path = {p["path"]: p for p in _plugins.values()}
    out = []
    for label, src in _sources(include_disabled=True):
        p = by_path.get(str(src))
        row = {"label": label, "enabled": label not in off, "key": p["key"] if p else "",
               "title": p["title"] if p else "", "version": p.get("version", "") if p else "",
               "author": p.get("author", "") if p else "", "error": _errors.get(label, ""),
               "last_error": (p or {}).get("last_error", ""), "tools": len((p or {}).get("tools") or {})}
        if not p:                                        # 没读进来（停用 / 出错）：只看 module.json，不跑代码
            mj = (src / "module.json") if src.is_dir() else None
            try:
                meta = json.loads(mj.read_text(encoding="utf-8")) if mj and mj.is_file() else {}
                row.update(title=str(meta.get("title") or ""), version=str(meta.get("version") or ""),
                           author=str(meta.get("author") or ""))
            except Exception:
                pass
        row["title"] = row["title"] or label.rstrip("/").rsplit(".", 1)[0]
        out.append(row)
    return out


def rebuild_commands() -> None:
    """按当前 _plugins 重建命令注册表；同一个前缀被两个插件占了就抛异常（说清是哪两个）。"""
    MODULE_COMMANDS.clear()
    for key, p in _plugins.items():
        for prefix, fn in (p.get("commands") or {}).items():
            if prefix in MODULE_COMMANDS:
                other = MODULE_COMMANDS[prefix][0]
                raise ValueError(f"命令前缀「{prefix}」和模块 {other}、{key} 冲突了")
            MODULE_COMMANDS[prefix] = (key, fn)


def get_module_command(prefix: str):
    """按前缀取 (插件 key, 函数 fn(ctx, arg_str))；没有返回 None。"""
    return MODULE_COMMANDS.get(str(prefix or "").strip().lower())


def list_module_commands() -> list[str]:
    """所有模块命令前缀（排好序，给 /help 用）。"""
    return sorted(MODULE_COMMANDS)


def get(key: str) -> dict | None:
    return _plugins.get(key)


def keys() -> list[str]:
    return list(_plugins)


def errors() -> dict[str, str]:
    return dict(_errors)


# ---------------- 运行时：界面接进来、出错记录、事件函数、每帧泵 ----------------
def set_host(app, colors, scale, text_fn):
    """界面把自己交进来（启动 / 刷新模块时）：后台回调、Agent 工具、定时器要的 ctx 都从这里拼。"""
    _host.update(app=app, colors=colors, scale=scale, text=text_fn)


def _plain_text(font, s, color):
    return font.render(str(s), True, color)


def _ctx_for(p: dict, rect=None) -> "Ctx":
    import pygame
    app = _host["app"]
    return Ctx(app, p, getattr(app, "screen", None), rect or pygame.Rect(0, 0, 0, 0), _host["colors"] or {},
               _host["scale"] or (lambda v: int(v)), _host["text"] or _plain_text)


def _log_dir() -> Path:
    return MODULES_DIR / ".logs"


def _record_error(p: dict) -> str:
    """模块代码出错：面板上显示最后一行，完整的出错位置追加到 modules/.logs/<key>.log。返回最后一行。"""
    trace = traceback.format_exc().strip()
    last = trace.splitlines()[-1] if trace else "未知错误"
    p["last_error"], p["last_trace"] = last, trace
    try:
        d = _log_dir()
        d.mkdir(parents=True, exist_ok=True)
        f = d / f"{p['key']}.log"
        if f.exists() and f.stat().st_size > 256 * 1024:          # 太大就从头记
            f.unlink()
        with open(f, "a", encoding="utf-8") as out:
            out.write(f"===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n{trace}\n\n")
    except OSError:
        pass
    return last


def log_path(key: str) -> Path:
    """模块的完整报错日志在哪。"""
    return _log_dir() / f"{key}.log"


def _call_hook(p: dict, name: str, *args, rect=None):
    """调模块的一个可选事件函数；出错记下来，不往外抛。返回函数的返回值（没有这个函数返回 None）。"""
    fn = p.get(name) if p else None
    if not callable(fn):
        return None
    try:
        return fn(_ctx_for(p, rect), *args)
    except Exception:
        _record_error(p)
        _dirty.add(p["key"])
        return None


call_hook = _call_hook                 # 界面用：on_tick / on_frame 这类定时调用


def _run_on_main(key: str, fn, *args, wait: float = 0):
    """放到主线程（界面每帧的 pump）里跑 fn(ctx, *args)。wait>0：等它跑完并返回结果（超时抛 TimeoutError）。"""
    if threading.current_thread() is _main_thread:
        p = _plugins.get(key)
        return fn(_ctx_for(p), *args) if p else None
    done = threading.Event() if wait else None
    box = {}
    _main_jobs.put((key, fn, args, done, box))
    if not wait:
        return None
    if not done.wait(wait):
        raise TimeoutError("界面没空处理（主线程忙）")
    if "error" in box:
        raise box["error"]
    return box.get("result")


def _source_sig():
    """modules/ 里模块文件的签名（名字 + 修改时间）：变了就该刷新。"""
    try:
        return tuple((label, _mtime(src)) for label, src in _sources()) + (tuple(sorted(disabled())),)
    except OSError:
        return None


def pump(app) -> bool:
    """界面主循环每帧调一次。跑后台做完的回调、on_load、Agent 空了就交模块的请求、主题变了发 on_theme；
    返回 True 表示 modules/ 里的文件变了，界面该刷新模块（边改边看效果）。"""
    _host["app"] = app
    for _ in range(50):                                   # 一帧最多处理 50 个，别卡住画面
        try:
            key, fn, args, done, box = _main_jobs.get_nowait()
        except queue.Empty:
            break
        p = _plugins.get(key)
        try:
            box["result"] = fn(_ctx_for(p), *args) if p else None
        except Exception as e:
            box["error"] = e
            if p:
                _record_error(p)
        _dirty.add(key)
        if done is not None:
            done.set()
    for p in list(_plugins.values()):
        if p.pop("_need_load", False):
            _call_hook(p, "on_load")
    if _asks and not getattr(app, "busy", True) and getattr(app, "agent", None) is not None \
            and hasattr(app, "_submit_turn"):
        key, text = _asks.pop(0)
        title = _plugins[key]["title"] if key in _plugins else key
        try:
            app._submit_turn(f"（外接模块「{title}」请你做）{text}")
        except Exception:
            pass
    colors = _host.get("colors") or {}
    sig = hashlib.md5(repr(sorted(colors.items())).encode()).hexdigest() if colors else None
    if sig != _theme["sig"]:
        first = _theme["sig"] is None
        _theme["sig"] = sig
        if not first:
            for p in list(_plugins.values()):
                _call_hook(p, "on_theme")
                _dirty.add(p["key"])
    now = time.monotonic()
    if now - _watch["at"] >= 1.5:                         # 边改边看：每 1.5 秒看一眼 modules/ 变没变
        _watch["at"] = now
        sig = _source_sig()
        if sig is not None and _watch["sig"] is not None and sig != _watch["sig"]:
            _watch["sig"] = sig
            return True
    return False


# ---- Agent 工具：模块在 MODULE["tools"] 里声明，Agent 直接调 ----
def _parse_tools(key: str, raw: dict) -> dict:
    """{"add": {"desc": "…", "params": {"text": "提醒内容", "minutes": {"type": "integer", "description": "…"}},
    "required": ["text"], "fn": fn(ctx, args) -> str}}；params 里只写一句话 = 字符串参数。"""
    out = {}
    for name, spec in (raw or {}).items():
        name = str(name).strip()
        if not name or not name.replace("_", "").isalnum() or not name.isascii():
            raise ValueError(f"工具名「{name}」要写英文（字母、数字、下划线）")
        if callable(spec):
            spec = {"fn": spec}
        if not isinstance(spec, dict) or not callable(spec.get("fn")):
            raise ValueError(f"MODULE['tools']['{name}'] 要写成 {{'desc': ..., 'params': ..., 'fn': fn(ctx, args)}}")
        props = {}
        for pn, ps in (spec.get("params") or {}).items():
            props[str(pn)] = {"type": "string", "description": ps} if isinstance(ps, str) else dict(ps)
        req = [str(r) for r in (spec.get("required") or []) if str(r) in props]
        full = f"{key}__{name}"
        if len(full) > 64:
            raise ValueError(f"工具名太长：{full}")
        out[name] = {"name": full, "desc": str(spec.get("desc") or spec.get("description") or name),
                     "props": props, "required": req, "fn": spec["fn"]}
    return out


def agent_tool_schemas() -> list[dict]:
    """所有模块声明给 Agent 的工具定义（名字是 <模块key>__<工具名>）。"""
    out = []
    for key, p in _plugins.items():
        for t in (p.get("tools") or {}).values():
            out.append({"type": "function", "function": {
                "name": t["name"], "description": f"[外接模块「{p['title']}」] {t['desc']}",
                "parameters": {"type": "object", "properties": t["props"], "required": t["required"]}}})
    return out


def call_agent_tool(name: str, args: dict) -> str:
    """Agent 调模块工具：在界面主线程里跑（模块的状态都在那边），最多等 60 秒。"""
    key, _, tname = str(name).partition("__")
    p = _plugins.get(key)
    t = (p or {}).get("tools", {}).get(tname)
    if t is None:
        return f"错误: 没有这个模块工具 {name}（模块可能被刷新 / 停用了）"
    try:
        res = _run_on_main(key, lambda ctx, a: t["fn"](ctx, a), dict(args or {}), wait=60)
    except Exception as e:
        return f"错误: 模块「{p['title']}」的工具出错：{type(e).__name__}: {e}"
    if isinstance(res, (dict, list)):
        return json.dumps(res, ensure_ascii=False)
    return "完成" if res is None else str(res)


class LocalTools:
    """Agent 和界面在同一个进程时的工具提供方（core.Agent.tool_providers 用）。"""

    def schemas(self):
        return agent_tool_schemas()

    def names(self):
        return {t["function"]["name"] for t in agent_tool_schemas()}

    def call(self, name, args):
        return call_agent_tool(name, args)


# ---- 界面转进来的事：Agent 的动态、拖进来的文件 ----
AGENT_EVENTS = ("tool", "result", "done", "error", "info")


def agent_event(kind: str, text) -> None:
    """Agent 的动态（调了什么工具、结果、这一轮做完、出错）转给带 on_agent(ctx, kind, text) 的模块。"""
    if kind not in AGENT_EVENTS:
        return
    text = str(text or "")[:2000]
    for p in list(_plugins.values()):
        if p.get("on_agent"):
            _call_hook(p, "on_agent", kind, text)


def drop(key: str, path: str, rect=None) -> bool:
    """文件拖到模块上：交给它的 on_drop(ctx, path)；没有 on_drop 返回 False（界面按原来的方式处理）。"""
    p = _plugins.get(key)
    if not p or not p.get("on_drop"):
        return False
    _call_hook(p, "on_drop", str(path), rect=rect)
    _dirty.add(key)
    return True


# ---------------- 素材 ----------------
def _clear_assets(folder: str):
    for k in [k for k in _images if k[0] == folder]:
        _images.pop(k, None)
    for k in [k for k in _sounds if k.startswith(folder)]:
        _sounds.pop(k, None)


def asset_path(folder: str, name: str) -> Path:
    """模块素材：先在 assets/ 下找，再在模块根目录找；不许用 .. 跑出模块目录。"""
    base = Path(folder).resolve()
    for p in (base / "assets" / name, base / name):
        p = p.resolve()
        if (p == base or base in p.parents) and p.is_file():
            return p
    raise FileNotFoundError(f"模块里没有素材 {name}")


def image(folder: str, name: str, size=None):
    import pygame
    key = (folder, name, tuple(size) if size else None)
    if key not in _images:
        img = pygame.image.load(str(asset_path(folder, name)))
        try:
            img = img.convert_alpha()
        except pygame.error:
            pass
        if size:
            img = pygame.transform.smoothscale(img, (int(size[0]), int(size[1])))
        _images[key] = img
    return _images[key]


def sound(folder: str, name: str, volume: float = 1.0) -> bool:
    try:
        import pygame
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        path = str(asset_path(folder, name))
        snd = _sounds.get(path)
        if snd is None:
            snd = _sounds[path] = pygame.mixer.Sound(path)
        snd.set_volume(max(0.0, min(1.0, float(volume))))
        snd.play()
        return True
    except Exception:
        return False                                    # 没声卡 / 读不了：静默跳过，不影响模块


def _state_path(key: str) -> Path:
    """模块状态文件：modules/.state/<key>.json。"""
    return MODULES_DIR / ".state" / f"{key}.json"


def _auto_load(key: str) -> dict:
    """读模块状态文件返回 dict；没有文件 / 读坏了 / 不是 dict 都返回 {}。"""
    try:
        data = json.loads(_state_path(key).read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


# ---------------- 全局变量（所有外接模块共用）----------------
_global_decls: dict[str, dict] = {}   # 名字 -> {type, default, title, desc, options, min, max, owners}
_global_cache: dict = {"path": None, "values": {}}   # 全局变量当前值（只存改过的；没改过用声明里的默认值）


def _infer_type(v) -> str:
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, int):
        return "int"
    if isinstance(v, float):
        return "float"
    return "str"


def _coerce(decl: dict, v):
    """把值转成声明的类型；转不了抛 ValueError。"""
    t = decl["type"]
    if t == "bool":
        if isinstance(v, str):
            s = v.strip().lower()
            if s in ("1", "true", "yes", "on", "是", "开"):
                return True
            if s in ("0", "false", "no", "off", "否", "关", ""):
                return False
            raise ValueError(f"「{v}」不是开 / 关")
        return bool(v)
    if t in ("int", "float"):
        if t == "int":
            if isinstance(v, float) and v != int(v):
                raise ValueError("要写整数")
            n = int(v) if isinstance(v, (int, float)) else int(str(v).strip())
        else:
            n = float(str(v).strip()) if isinstance(v, str) else float(v)
        if decl.get("min") is not None and n < decl["min"]:
            raise ValueError(f"不能小于 {decl['min']}")
        if decl.get("max") is not None and n > decl["max"]:
            raise ValueError(f"不能大于 {decl['max']}")
        return n
    if t == "choice":
        if v not in decl["options"]:
            raise ValueError(f"只能是 {decl['options']} 里的一个")
        return v
    return "" if v is None else str(v)


def _parse_globals(raw) -> dict:
    """MODULE['globals'] / module.json 里的 globals：{名字: 默认值} 或 {名字: {default, type, title, desc, options, min, max}}。"""
    if raw is None:
        raise ValueError("globals 要是一个 {名字: 默认值或说明} 字典")
    out = {}
    for name, spec in raw.items():
        name = str(name).strip()
        if not name or any(c.isspace() for c in name) or "." in name:
            raise ValueError(f"全局变量名「{name}」不能为空、不能有空格和点")
        spec = dict(spec) if isinstance(spec, dict) else {"default": spec}
        t = str(spec.get("type") or ("choice" if spec.get("options") else _infer_type(spec.get("default", ""))))
        if t not in GLOBAL_TYPES:
            raise ValueError(f"全局变量「{name}」的 type 只能是 {'/'.join(GLOBAL_TYPES)}")
        opts = list(spec.get("options") or [])
        if t == "choice" and not opts:
            raise ValueError(f"全局变量「{name}」是 choice，要给 options 列表")
        decl = {"type": t, "title": str(spec.get("title") or name), "desc": str(spec.get("desc") or ""),
                "options": opts, "min": spec.get("min"), "max": spec.get("max")}
        default = spec.get("default", opts[0] if t == "choice" else {"bool": False, "int": 0, "float": 0.0}.get(t, ""))
        try:
            decl["default"] = _coerce(decl, default)
        except (TypeError, ValueError) as e:
            raise ValueError(f"全局变量「{name}」的默认值不对：{e}")
        out[name] = decl
    return out


def _globals_path() -> Path:
    return MODULES_DIR / ".state" / "_globals.json"


def _global_values() -> dict:
    """全局变量当前值（懒加载，MODULES_DIR 变了就重读）。"""
    p = _globals_path()
    if _global_cache["path"] != p:
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        _global_cache.update(path=p, values=data if isinstance(data, dict) else {})
    return _global_cache["values"]


def _save_globals() -> bool:
    try:
        p = _globals_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(_global_values(), ensure_ascii=False, indent=1), encoding="utf-8")
        return True
    except Exception:
        return False


def _rebuild_globals():
    """按当前所有模块的声明重建全局变量表。两个模块声明同名变量：类型一样就共用（第一个的说明为准），不一样记错。"""
    _global_decls.clear()
    for key, p in _plugins.items():
        for name, d in (p.get("globals") or {}).items():
            have = _global_decls.get(name)
            if have is None:
                _global_decls[name] = {**d, "owners": [key]}
            elif have["type"] != d["type"]:
                _errors[f"全局变量 {name}"] = (f"{'、'.join(have['owners'])} 声明成 {have['type']}，"
                                              f"{key} 又声明成 {d['type']}；以先读到的为准")
            else:
                have["owners"].append(key)
    vals = _global_values()                          # 存盘的值和现在的声明对不上（类型改了）：丢掉，用默认值
    for name in [n for n in vals if n in _global_decls]:
        try:
            vals[name] = _coerce(_global_decls[name], vals[name])
        except (TypeError, ValueError):
            vals.pop(name, None)


def get_global(name: str, default=None):
    name = str(name)
    vals = _global_values()
    if name in vals:
        return vals[name]
    if name in _global_decls:
        return _global_decls[name]["default"]
    return default


def all_globals() -> dict:
    """所有全局变量的当前值（声明过的 + 运行时设过的）。"""
    out = {n: d["default"] for n, d in _global_decls.items()}
    out.update(_global_values())
    return out


def _put_global(name: str, value, reset: bool = False):
    """写一个全局变量（按声明转类型，转不了抛 ValueError）。返回 (改了没有, 新值)。"""
    name = str(name)
    decl = _global_decls.get(name)
    vals = _global_values()
    old = get_global(name)
    if reset:
        vals.pop(name, None)
        new = get_global(name)
    else:
        if decl is not None:
            new = _coerce(decl, value)
        elif isinstance(value, str) and name in vals and not isinstance(old, str) \
                and _infer_type(old) in ("int", "float", "bool"):
            new = _coerce({"type": _infer_type(old)}, value)   # 没声明、但已经是数字 / 开关：面板里打的字按原类型转
        else:
            json.dumps(value)                        # 没声明的：只要能存成 json 就行
            new = value
        vals[name] = new
    if new == old and type(new) is type(old):
        return False, new
    _save_globals()
    return True, new


def _broadcast_global(src_ctx, name: str, value):
    """全局变量变了：所有模块重画，带 on_global 的挨个通知（一个出错不影响别的）。"""
    for k, p in list(_plugins.items()):
        _dirty.add(k)
        fn = p.get("on_global")
        if fn is None:
            continue
        try:
            import pygame
            fn(Ctx(src_ctx._app, p, src_ctx.screen, pygame.Rect(0, 0, 0, 0), src_ctx._colors, src_ctx.s,
                   src_ctx._text), name, value)
        except Exception:
            _record_error(p)


class _Clip:
    """with ctx.clip((x, y, w, h)) 用：进来收窄绘制区，出去（异常也）还原。"""

    def __init__(self, screen, box):
        self.screen = screen
        self.box = box
        self.old = None

    def __enter__(self):
        self.old = self.screen.get_clip()
        self.screen.set_clip(self.box)
        return self

    def __exit__(self, exc_type, exc, tb):
        self.screen.set_clip(self.old)
        return False


class Ctx:
    """给模块画图用的小接口。"""

    # 外接模块只能调这些「只读」工具（写类一律拒绝），见 tool()
    _READONLY_TOOLS = {"now", "file_stats", "find_files", "grep_files", "read_lines", "web_history",
                       "web_last", "bg_list", "bg_output", "credentials_list", "credentials_get",
                       "graph_query", "recall", "web_search", "web_open"}

    def __init__(self, app, plugin: dict, surface, rect, colors: dict, scale, text_fn):
        self.screen = surface
        self.rect = rect
        self.font = app.font
        self.small = app.small
        self.mouse = __import__("pygame").mouse.get_pos()
        self.now = time.time()
        self.state = plugin["state"]
        self._dir = plugin["dir"]
        self._colors = colors
        self.s = scale
        self._text = text_fn
        self._meta = plugin
        self._key = plugin["key"]
        self._app = app
        self._ws = getattr(app, "ws", None)
        if not self.state:
            # load_all 热刷新会把 state 清空：状态文件里还有就自动接回来
            old = _auto_load(self._key)
            if old:
                self.state.update(old)

    # ---- 内部：颜色统一成一个 pygame 认的 ----
    def _resolve_color(self, c):
        """颜色：主题色名字走 self.color(name)，否则原样交给 pygame（RGB 元组 / pygame.Color）。"""
        if isinstance(c, str):
            return self.color(c)
        return c

    @property
    def title(self):
        return self._meta.get("title", self._key)

    @property
    def side(self):
        return self._meta.get("side", "right")

    @property
    def refresh(self):
        return self._meta.get("refresh", 0)

    def color(self, name: str):
        return self._colors.get(name) or self._colors.get("text") or (0, 0, 0)

    def text(self, s, color=None, small: bool = False):
        return self._text(self.small if small else self.font, str(s),   # 颜色也认主题色名字，和 ctx.box 一样
                          self._resolve_color(color) if color is not None else self.color("text"))

    def asset(self, name: str) -> Path:
        return asset_path(self._dir, name)

    def image(self, name: str, size=None):
        return image(self._dir, name, size)

    def sound(self, name: str, volume: float = 1.0) -> bool:
        return sound(self._dir, name, volume)

    # ---- 画图形（坐标就是模块自己量的像素，直接落在 ctx.screen 上）----
    def box(self, px, py, w, h, color, *, width=0, radius=0):
        """矩形：width=0 填充、>0 只描边；radius>0 圆角。"""
        import pygame
        r = pygame.Rect(int(px), int(py), int(w), int(h))
        if radius > 0:
            pygame.draw.rect(self.screen, self._resolve_color(color), r, width=width, border_radius=int(radius))
        else:
            pygame.draw.rect(self.screen, self._resolve_color(color), r, width=width)

    def circle(self, cx, cy, r, color, *, width=0):
        """圆：width=0 填充、>0 只描边。"""
        import pygame
        pygame.draw.circle(self.screen, self._resolve_color(color), (int(cx), int(cy)), int(r), width=width)

    def line(self, points, color, *, width=1):
        """折线：points 是 [(x, y), …]。"""
        import pygame
        pygame.draw.lines(self.screen, self._resolve_color(color), False, list(points), width=width)

    def polygon(self, points, color, *, width=0):
        """多边形：width=0 填充、>0 只描边。"""
        import pygame
        pygame.draw.polygon(self.screen, self._resolve_color(color), list(points), width=width)

    def text_size(self, s, small: bool = False):
        """量一段文字渲染后的 (宽, 高)，不落笔。"""
        surf = self.text(s, small=small)
        return (surf.get_width(), surf.get_height())

    def clip(self, box):
        """可 with 的裁剪区：with ctx.clip((x, y, w, h)): 画的东西只在这块可见，退出后恢复整块画布。"""
        return _Clip(self.screen, box)

    # ---- 输入框（框架全包：焦点、光标、选择、输入法、复制粘贴、滚动）----
    def input(self, name, box, *, placeholder="", password=False, max_len=0, small=False,
              on_submit=None, on_change=None) -> str:
        """在 box=(x, y, w, h) 画一个单行输入框，返回当前文字。文字就存在 ctx.state[name]（ctx.save() 一起落盘）。
        点它拿焦点；打字 / 输入法 / 退格 / Delete / ←→ / Home / End / Shift 选择 / Ctrl+A/C/X/V 都由框架处理；
        Enter 调 on_submit(ctx, text)（没给就交给模块的 on_key）；文字变了调 on_change(ctx, text)；
        Tab / ↑↓ 等别的键照常交给模块的 on_key。Esc 或点框外面放掉焦点。"""
        return _draw_field(self, str(name), box, placeholder=str(placeholder), password=bool(password),
                           max_len=int(max_len or 0), small=bool(small),
                           on_submit=on_submit if callable(on_submit) else None,
                           on_change=on_change if callable(on_change) else None)

    # ---- 全局变量（所有模块共用，存盘，改了所有模块都收到 on_global）----
    def get_global(self, name, default=None):
        """读一个全局变量：改过的值 > 声明里的默认值 > default。"""
        return get_global(name, default)

    def set_global(self, name, value) -> bool:
        """改一个全局变量（按声明的类型转换，转不了 / 超出 min、max 抛 ValueError）。改了返回 True，没变返回 False。
        没声明过的名字也能设（值要能存成 json），但最好在 MODULE['globals'] 里声明，全局设置面板才有标题和说明。"""
        changed, new = _put_global(name, value)
        if changed:
            _broadcast_global(self, str(name), new)
        return changed

    def reset_global(self, name) -> bool:
        """全局变量恢复成声明里的默认值。"""
        changed, new = _put_global(name, None, reset=True)
        if changed:
            _broadcast_global(self, str(name), new)
        return changed

    @property
    def globals(self) -> dict:
        """所有全局变量当前值的一份拷贝（改它不会生效，要改用 set_global）。"""
        return all_globals()

    def input_focused(self, name=None) -> bool:
        """这个模块的输入框（name 省略 = 任意一个）现在有没有键盘焦点。"""
        return _focus_key == self._key and _focus_field is not None and (name is None or _focus_field == str(name))

    def focus_input(self, name=None):
        """让输入框 name 拿到键盘焦点（光标放到末尾）；name=None 放掉焦点。"""
        if name is None:
            set_focus(None)
        else:
            set_focus(self._key, str(name))
            f = _field(self._key, str(name))
            f["cursor"] = f["anchor"] = len(str(self.state.get(str(name), "")))
        self.redraw()

    def set_input(self, name, text):
        """改输入框 name 的文字（光标移到末尾）。"""
        self.state[str(name)] = str(text)
        f = _field(self._key, str(name))
        f["cursor"] = f["anchor"] = len(str(text))
        self.redraw()

    # ---- 控件（和输入框一样：只给位置，点击 / 拖动 / 滚轮框架全包）----
    def button(self, name, box, label="", *, on_click=None, style="normal", enabled=True, small=False,
               color=None) -> bool:
        """按钮。style：normal / primary（主色）/ danger（红）/ ghost（只有描边）/ flat（平时只有字，悬停才有底色，
        适合 ✕ 这种小图标按钮）。color：文字颜色（可选）。
        按下再在按钮上松开算一次点击：调 on_click(ctx)，并且这次 draw 里 ctx.button 返回 True（只返回一次）。"""
        w = _widget(self, name, "button", box, label=str(label), on_click=on_click if callable(on_click) else None,
                    style=str(style), enabled=bool(enabled), small=bool(small),
                    color=self._resolve_color(color) if color is not None else None)
        _draw_button(self, w)
        return bool(w.pop("clicked", False))

    def checkbox(self, name, box, label="", *, on_change=None, switch=False, small=False) -> bool:
        """勾选框（switch=True 画成开关）。值存在 ctx.state[name]（True / False），变了调 on_change(ctx, value)。"""
        self.state.setdefault(str(name), False)
        w = _widget(self, name, "check", box, label=str(label), on_change=on_change if callable(on_change) else None,
                    switch=bool(switch), small=bool(small), enabled=True)
        _draw_check(self, w)
        return bool(self.state[str(name)])

    def slider(self, name, box, lo=0, hi=100, step=1, *, on_change=None, show_value=True, fmt=None,
               enabled=True):
        """滑块：拖、点、滚轮都能改。值存在 ctx.state[name]（lo 和 step 是整数就存整数）。fmt(value) -> 显示的文字。"""
        w = _widget(self, name, "slider", box, lo=lo, hi=hi, step=step,
                    on_change=on_change if callable(on_change) else None, show_value=bool(show_value),
                    fmt=fmt if callable(fmt) else None, enabled=bool(enabled))
        self.state.setdefault(str(name), _slider_clamp(w, lo))
        _draw_slider(self, w)
        return self.state[str(name)]

    def select(self, name, box, options, *, on_change=None, placeholder="请选择", small=False):
        """下拉选择。options：["a", "b"] 或 [(值, "显示的字"), …]。值存在 ctx.state[name]，选了调 on_change(ctx, value)。
        展开的列表画在模块最上层，列表里能滚轮。"""
        w = _widget(self, name, "select", box, options=list(options or []),
                    on_change=on_change if callable(on_change) else None, placeholder=str(placeholder),
                    small=bool(small), enabled=True)
        _draw_select(self, w)
        return self.state.get(str(name))

    def scroll(self, name, box, content_h):
        """能滚动的区域：with ctx.scroll("list", (x, y, w, h), content_h=总高度) as top:
        里面按 y = top + 第几行 * 行高 画；超出范围的看不见也点不到。滚轮、拖右边的滚动条都由框架处理。"""
        w = _widget(self, name, "scroll", box, content_h=max(0, int(content_h)))
        return _Scroll(self, w)

    def scroll_to(self, name, offset):
        """把滚动区 name 滚到 offset 像素（0 = 顶部）。"""
        self.state.setdefault("_scroll", {})[str(name)] = max(0, int(offset))
        self.redraw()

    # ---- 自我管理 ----
    def redraw(self):
        """让这个模块下一帧马上重画（不等 refresh）。"""
        _dirty.add(self._key)

    # ---- 持久化 ----
    def save(self, data=None) -> bool:
        """把 data（省略则 ctx.state）存成 json；成功 True，失败 False（不抛异常）。"""
        path = MODULES_DIR / ".state" / f"{self._key}.json"
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(self.state if data is None else data, ensure_ascii=False), encoding="utf-8")
            return True
        except Exception:
            return False

    def load(self) -> dict:
        """读回存过的状态：没有文件 / 读坏了都返回 {}。"""
        return _auto_load(self._key)

    # ---- 数据读入 ----
    def read_file(self, name) -> str:
        """读模块目录里的文本文件（名字不许跑出模块目录，跑出去抛异常）。"""
        return asset_path(self._dir, name).read_text(encoding="utf-8")

    def write_file(self, name, text) -> bool:
        """把 text 写进模块目录里的文件；成功 True，失败 / 路径跑出模块目录返回 False（不抛异常）。"""
        base = Path(self._dir).resolve()
        try:
            p = (base / str(name)).resolve()
        except Exception:
            return False
        if not (base == p or base in p.parents):
            return False
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(str(text), encoding="utf-8")
            return True
        except Exception:
            return False

    def http_get(self, url, timeout=10) -> dict:
        """GET 一个网址，返回 {"status", "text", "json", "error"}；同一个 url 60 秒内用缓存（不抛异常）。"""
        import urllib.request
        now = time.time()
        c = _http_cache.get(url)
        if c and now - c[0] < 60:
            return c[1]
        out = {"status": 0, "text": "", "json": None, "error": ""}
        try:
            req = urllib.request.Request(str(url), headers={"User-Agent": "TerministModule/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                out["status"] = int(getattr(resp, "status", 0) or 0)
                out["text"] = resp.read().decode("utf-8", "replace")
            try:
                out["json"] = json.loads(out["text"])
            except Exception:
                out["json"] = None
        except Exception as e:
            out["error"] = str(e)
        _http_cache[url] = (now, out)
        return out

    def tool(self, name, **kwargs) -> str:
        """只读调用 A库工具（白名单制）：每次现场取最新值，不缓存；写类工具一律返回空串。

        白名单 = Ctx._READONLY_TOOLS。命中后优先 EXT_TOOLS[name]["run"](self._ws, **kwargs) 现场取；
        graph_query / recall / now 这三个若没注册进 EXT_TOOLS，回落 lib_a 顶层真函数。其它名字返回空串。
        """
        if not isinstance(name, str) or name not in self._READONLY_TOOLS:
            return ""
        try:
            from lib_a.core import EXT_TOOLS
        except Exception:
            EXT_TOOLS = {}
        if name in EXT_TOOLS:
            try:
                return str(EXT_TOOLS[name]["run"](self._ws, **kwargs))
            except Exception:
                return ""
        # 三个库内只读函数（可能不在 EXT_TOOLS）：回落用真函数实时取
        if name == "graph_query":
            try:
                fn = _first_call(["lib_b.graph_store", "lib_b.graph", "lib_a.graph"], ["query", "query_graph"])
                if fn:
                    return str(fn(question=kwargs.get("question", ""), mode=kwargs.get("mode", "local")))
                from lib_a.graph import graph_query
                return str(graph_query(kwargs.get("question", ""), kwargs.get("mode", "local")))
            except Exception:
                return ""
        if name == "recall":
            try:
                fn = _first_call(["lib_b.memory", "lib_a.memory"], ["recall"])
                if fn:
                    try:
                        return str(fn(kwargs.get("query", ""), kwargs.get("k", 5)))
                    except TypeError:
                        return str(fn(kwargs.get("query", "")))
                from lib_a import recall
                return str(recall(kwargs.get("query", ""), kwargs.get("k", 5)))
            except Exception:
                return ""
        if name == "now":
            try:
                return time.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                return ""
        return ""

    def import_lib(self, name: str):
        """动态 import lib_a 下的模块，返回模块对象；越界 / 失败返回 None。"""
        if not isinstance(name, str) or "/" in name or "\\" in name or ".." in name:
            return None
        try:
            return importlib.import_module("lib_a." + name)
        except Exception:
            return None

    def notify(self, text: str):
        """在界面左下角弹一条通知（复用 show_toast）。"""
        fn = getattr(self._app, "show_toast", None)
        if fn:
            try:
                fn(str(text))
            except Exception:
                pass

    # ---- 和 Agent / 别的模块打交道 ----
    def ask_agent(self, text: str) -> None:
        """请 Agent 做一件事（像主人在对话框里说了一句，前面注明是哪个模块请的）。Agent 正忙就排着，空了马上交。"""
        if str(text or "").strip():
            _asks.append((self._key, str(text).strip()))

    def emit(self, event: str, data=None, to: str | None = None) -> int:
        """给别的模块发消息：它们的 on_message(ctx, event, data, sender) 会收到。to=模块 key 时只发给它。
        返回收到的模块数。自己不收自己发的（除非 to 写自己）。"""
        n = 0
        for k, p in list(_plugins.items()):
            if (to is not None and k != to) or (to is None and k == self._key) or not p.get("on_message"):
                continue
            _call_hook(p, "on_message", str(event), data, self._key)
            _dirty.add(k)
            n += 1
        return n

    # ---- 后台做事：不卡界面 ----
    def fetch(self, url, on_done=None, *, method="GET", data=None, json_body=None, headers=None, cache=60,
              timeout=15):
        """后台请求一个网址，不卡界面。返回缓存里的结果（{"status","text","json","error"}），没有就返回 None；
        取回来以后模块自动重画，给了 on_done 就在主线程调 on_done(ctx, result)。
        在 draw 里直接写 r = ctx.fetch(url) 就行：第一次是 None（显示加载中），回来了下一帧就有。
        method / data（str 或 bytes）/ json_body（会转成 JSON）/ headers 可选；cache 秒内同一个请求不重复发（0 = 每次都发）。"""
        body = json.dumps(json_body, ensure_ascii=False).encode("utf-8") if json_body is not None else \
            (data.encode("utf-8") if isinstance(data, str) else data)
        ck = f"{method.upper()} {url} {hashlib.md5(body or b'').hexdigest() if body else ''}"
        hit = _http_cache.get(ck)
        fresh = hit is not None and cache and time.time() - hit[0] < cache
        if fresh:
            if on_done:                                     # 回调统一放到下一帧在主线程调
                _main_jobs.put((self._key, on_done, (hit[1],), None, {}))
            return hit[1]
        waiters = _inflight.get(ck)
        if waiters is not None:                             # 已经在取了：排上队，一起回来
            waiters.append((self._key, on_done))
            return hit[1] if hit else None
        _inflight[ck] = [(self._key, on_done)]
        hdrs = {"User-Agent": "TerministModule/1.0", **(headers or {})}
        if json_body is not None:
            hdrs.setdefault("Content-Type", "application/json")

        def work():
            import urllib.request
            out = {"status": 0, "text": "", "json": None, "error": ""}
            try:
                req = urllib.request.Request(str(url), data=body, headers=hdrs, method=method.upper())
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    out["status"] = int(getattr(resp, "status", 0) or 0)
                    out["text"] = resp.read().decode("utf-8", "replace")
            except Exception as e:
                code = getattr(e, "code", None)
                if code:
                    out["status"] = int(code)
                    try:
                        out["text"] = e.read().decode("utf-8", "replace")
                    except Exception:
                        pass
                out["error"] = str(e)
            try:
                out["json"] = json.loads(out["text"]) if out["text"] else None
            except Exception:
                out["json"] = None
            _http_cache[ck] = (time.time(), out)
            for key, cb in _inflight.pop(ck, []):
                _dirty.add(key)
                if cb:
                    _main_jobs.put((key, cb, (out,), None, {}))
        threading.Thread(target=work, daemon=True, name=f"module-fetch-{self._key}").start()
        return hit[1] if hit else None

    def run_bg(self, fn, on_done=None) -> None:
        """后台跑一个耗时的函数 fn()（读大文件、算东西），不卡界面。跑完在主线程调 on_done(ctx, result, error)
        （error 是异常或 None）。fn 里别直接画东西，也别碰 ctx.screen。"""
        key = self._key

        def work():
            res, err = None, None
            try:
                res = fn()
            except Exception as e:
                err = e
                p = _plugins.get(key)
                if p:
                    _record_error(p)
            _dirty.add(key)
            if on_done:
                _main_jobs.put((key, on_done, (res, err), None, {}))
        threading.Thread(target=work, daemon=True, name=f"module-bg-{key}").start()

    # ---- 系统能力 ----
    def clipboard_get(self) -> str:
        """读系统剪贴板里的文字。"""
        return _clip_board_get()

    def clipboard_set(self, text) -> None:
        """把文字放进系统剪贴板。"""
        _clip_board_put(str(text))

    def toast(self, text: str) -> bool:
        """弹一条 Windows 系统通知（右下角，Terminist 最小化了也看得到）；弹不了就退回界面里的通知。"""
        fn = getattr(self._app, "_windows_toast", None)
        try:
            if callable(fn) and fn(str(text)):
                return True
        except Exception:
            pass
        self.notify(text)
        return False

    def open_url(self, url: str) -> bool:
        """用系统浏览器打开网址（只认 http / https）。"""
        url = str(url or "")
        if not url.startswith(("http://", "https://")):
            return False
        import webbrowser
        return bool(webbrowser.open(url))

    def browse(self, url: str) -> bool:
        """在 Terminist 的小屏幕（内置小浏览器）里打开网址或搜索词；小屏幕在「模块」里放出来就能看到、能点。"""
        fn = getattr(self._app, "_web_send", None)
        if not callable(fn) or not str(url or "").strip():
            return False
        fn("goto", text=str(url).strip())
        return True

    @property
    def colors(self) -> dict:
        """当前主题所有颜色 {名字: (r, g, b)} 的拷贝。常用：bg panel text dim border btn btn_on on_text
        input_bg input_border input_focus hdr warn add del。"""
        return dict(self._colors)

    @property
    def dark(self) -> bool:
        """现在是不是深色主题（按背景色亮度判断）。"""
        bg = self._colors.get("bg") or self._colors.get("panel") or (255, 255, 255)
        return (bg[0] * 299 + bg[1] * 587 + bg[2] * 114) / 1000 < 128

    # ---- 文字排版 ----
    def wrap(self, text, width, small: bool = False) -> list[str]:
        """按宽度把文字折成几行（中英文都行，保留原来的换行），返回行列表。"""
        font = self.small if small else self.font
        lines = []
        for para in str(text).split("\n"):
            cur = ""
            for ch in para:
                if font.size(cur + ch)[0] <= width or not cur:
                    cur += ch
                    continue
                cut = cur.rfind(" ")                         # 英文尽量在空格处断
                if 0 < cut and ch != " " and cur[-1] != " " and cur[:cut].isascii():
                    lines.append(cur[:cut])
                    cur = cur[cut + 1:] + ch
                else:
                    lines.append(cur)
                    cur = ch.lstrip() if ch == " " else ch
            lines.append(cur)
        return lines

    def ellipsize(self, text, width, small: bool = False) -> str:
        """太长就截断加「…」，保证不超过 width 像素。"""
        font = self.small if small else self.font
        s = str(text)
        if font.size(s)[0] <= width:
            return s
        while s and font.size(s + "…")[0] > width:
            s = s[:-1]
        return s + "…"

    def text_box(self, text, box, color=None, small: bool = False, align: str = "left", max_lines: int = 0) -> int:
        """在 box=(x, y, w, h) 里画一段自动换行的文字（超出高度的行不画，最后一行加「…」）。返回实际用掉的高度。"""
        x, y, w, h = (int(v) for v in box)
        font = self.small if small else self.font
        lh = font.get_linesize()
        lines = self.wrap(text, w, small)
        room = max(1, h // lh) if h > 0 else len(lines)
        if max_lines:
            room = min(room, max_lines)
        if len(lines) > room:
            lines = lines[:room]
            lines[-1] = self.ellipsize(lines[-1] + "…", w, small)
        for i, line in enumerate(lines):
            surf = self.text(line, color, small)
            dx = {"center": (w - surf.get_width()) // 2, "right": w - surf.get_width()}.get(align, 0)
            self.screen.blit(surf, (x + dx, y + i * lh))
        return len(lines) * lh


# ---------------- 通用控件：按钮 / 勾选 / 滑块 / 下拉 / 滚动区（只给位置，点击拖动滚轮框架全包）----------------
_clip_stack: list = []                # 滚动区嵌套时的可见范围：控件只有露出来的部分能点
_seq = [0]                            # 控件登记顺序：后画的在上面，先接点击


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _visible(box):
    """控件的可点范围 = 控件本身 ∩ 当前滚动区（没露出来就是 None）。"""
    import pygame
    r = pygame.Rect(*(int(v) for v in box))
    for c in _clip_stack:
        r = r.clip(c)
    return tuple(r) if r.w > 0 and r.h > 0 else None


def _widget(ctx, name, kind, box, **opts) -> dict:
    w = _widgets.setdefault((ctx._key, str(name)), {"kind": kind})
    _seq[0] += 1
    w.update(kind=kind, name=str(name), box=tuple(int(v) for v in box), hit=_visible(box), seen=True,
             order=_seq[0], opts=opts)
    return w


def _in(box, pos) -> bool:
    return bool(box) and box[0] <= pos[0] < box[0] + box[2] and box[1] <= pos[1] < box[1] + box[3]


def _btn_colors(ctx, style, hover, pressed, enabled):
    base = {"primary": "btn_on", "danger": "del", "ghost": None, "flat": None}.get(style, "btn")
    fg = ctx.color("on_text") if style in ("primary", "danger") else ctx.color("text")
    if base is None:
        bg = _mix(ctx.color("panel"), ctx.color("text"), 0.10) if hover else None
    else:
        bg = ctx.color(base)
        if pressed:
            bg = _mix(bg, (0, 0, 0), 0.18)
        elif hover:
            bg = _mix(bg, (255, 255, 255), 0.12)
    if not enabled:
        fg = ctx.color("dim")
        bg = _mix(bg, ctx.color("panel"), 0.5) if bg else None
    return bg, fg


def _draw_button(ctx, w):
    o = w["opts"]
    x, y, bw, bh = w["box"]
    hover = o["enabled"] and _in(w.get("hit"), ctx.mouse)
    bg, fg = _btn_colors(ctx, o["style"], hover, w.get("pressed") and hover, o["enabled"])
    if bg:
        ctx.box(x, y, bw, bh, bg, radius=ctx.s(6))
    if o["style"] == "ghost" and not bg:
        ctx.box(x, y, bw, bh, "border", width=1, radius=ctx.s(6))
    label = ctx.ellipsize(o["label"], max(1, bw - ctx.s(6)), o["small"])
    t = ctx.text(label, o.get("color") or fg, o["small"])
    ctx.screen.blit(t, (x + (bw - t.get_width()) // 2, y + (bh - t.get_height()) // 2))


def _draw_check(ctx, w):
    o = w["opts"]
    x, y, bw, bh = w["box"]
    on = bool(ctx.state.get(w["name"]))
    s = ctx.s
    if o["switch"]:
        sw, sh = s(34), s(18)
        sy = y + (bh - sh) // 2
        ctx.box(x, sy, sw, sh, "btn_on" if on else _mix(ctx.color("btn"), ctx.color("text"), 0.15), radius=sh // 2)
        ctx.circle(x + (sw - sh // 2 if on else sh // 2), sy + sh // 2, sh // 2 - s(3), "on_text")
        tx = x + sw + s(8)
    else:
        cs = s(16)
        cy = y + (bh - cs) // 2
        if on:
            ctx.box(x, cy, cs, cs, "btn_on", radius=s(4))
            ctx.line([(x + s(4), cy + s(8)), (x + s(7), cy + s(11)), (x + s(12), cy + s(5))], "on_text", width=s(2))
        else:
            ctx.box(x, cy, cs, cs, "input_bg", radius=s(4))
            ctx.box(x, cy, cs, cs, "input_border", width=1, radius=s(4))
        tx = x + cs + s(8)
    if o["label"]:
        t = ctx.text(ctx.ellipsize(o["label"], max(1, x + bw - tx), o["small"]), None, o["small"])
        ctx.screen.blit(t, (tx, y + (bh - t.get_height()) // 2))


def _slider_clamp(w, v):
    """对齐到 step、夹进 [lo, hi]；lo 和 step 都是整数时结果是整数。"""
    o = w["opts"]
    if o["step"]:
        v = o["lo"] + round((v - o["lo"]) / o["step"]) * o["step"]
    v = max(min(o["lo"], o["hi"]), min(max(o["lo"], o["hi"]), v))
    return int(round(v)) if isinstance(o["step"], int) and isinstance(o["lo"], int) else round(v, 6)


def _slider_value_at(w, px):
    o = w["opts"]
    x, _, bw, _ = w["track"]
    k = max(0.0, min(1.0, (px - x) / max(1, bw)))
    return _slider_clamp(w, o["lo"] + k * (o["hi"] - o["lo"]))


def _set_widget_value(ctx, w, v):
    old = ctx.state.get(w["name"])
    ctx.state[w["name"]] = v
    cb = w["opts"].get("on_change")
    if v != old and cb:
        cb(ctx, v)
    ctx.redraw()


def _draw_slider(ctx, w):
    o = w["opts"]
    x, y, bw, bh = w["box"]
    s = ctx.s
    v = ctx.state.get(w["name"], o["lo"])
    vt = ctx.text(o["fmt"](v) if o["fmt"] else (f"{v:g}" if isinstance(v, float) else str(v)), "dim", True) \
        if o["show_value"] else None
    tw = (vt.get_width() + s(8)) if vt else 0
    track = (x + s(8), y, max(s(10), bw - s(16) - tw), bh)
    w["track"] = track
    cy = y + bh // 2
    span = (o["hi"] - o["lo"]) or 1
    k = max(0.0, min(1.0, (v - o["lo"]) / span))
    kx = track[0] + int(track[2] * k)
    ctx.box(track[0], cy - s(2), track[2], s(4), _mix(ctx.color("btn"), ctx.color("text"), 0.15), radius=s(2))
    ctx.box(track[0], cy - s(2), kx - track[0], s(4), "btn_on", radius=s(2))
    hot = w.get("drag") or _in(w.get("hit"), ctx.mouse)
    ctx.circle(kx, cy, s(8) if hot else s(7), "btn_on")
    ctx.circle(kx, cy, s(3), "on_text")
    if vt:
        ctx.screen.blit(vt, (x + bw - vt.get_width(), cy - vt.get_height() // 2))


def _opt_list(options):
    return [(o[0], str(o[1])) if isinstance(o, (tuple, list)) and len(o) == 2 else (o, str(o)) for o in options]


def _draw_select(ctx, w):
    o = w["opts"]
    x, y, bw, bh = w["box"]
    s = ctx.s
    opts = _opt_list(o["options"])
    v = ctx.state.get(w["name"])
    label = next((lab for val, lab in opts if val == v), o["placeholder"] if v is None else str(v))
    hover = _in(w.get("hit"), ctx.mouse)
    ctx.box(x, y, bw, bh, "input_bg", radius=s(6))
    ctx.box(x, y, bw, bh, "input_focus" if w.get("open") or hover else "input_border", width=1, radius=s(6))
    t = ctx.text(ctx.ellipsize(label, bw - s(30), o["small"]), "text" if v is not None else "dim", o["small"])
    ctx.screen.blit(t, (x + s(8), y + (bh - t.get_height()) // 2))
    ax, ay = x + bw - s(14), y + bh // 2
    ctx.polygon([(ax - s(4), ay - s(2)), (ax + s(4), ay - s(2)), (ax, ay + s(3))], "dim")
    if w.get("open"):
        def overlay(c=ctx, ww=w, items=opts):
            rh = bh
            top = y + bh + s(2)
            room = max(1, (c.rect.bottom - top) // rh) if c.rect.h else len(items)
            if room < len(items) and y - c.rect.y > c.rect.bottom - top:      # 下面放不下、上面空：往上展开
                room = max(1, (y - s(2) - c.rect.y) // rh)
                top = y - s(2) - min(room, len(items)) * rh
            shown = items[ww.get("first", 0):ww.get("first", 0) + room]
            c.box(x, top, bw, rh * len(shown), "input_bg", radius=s(6))
            c.box(x, top, bw, rh * len(shown), "input_focus", width=1, radius=s(6))
            ww["rows"] = []
            for i, (val, lab) in enumerate(shown):
                ry = top + i * rh
                if _in((x, ry, bw, rh), c.mouse) or val == c.state.get(ww["name"]):
                    c.box(x + s(2), ry + s(1), bw - s(4), rh - s(2), _mix(c.color("input_bg"), c.color("input_focus"),
                                                                          0.25 if val != c.state.get(ww["name"]) else 0.4),
                          radius=s(4))
                tt = c.text(c.ellipsize(lab, bw - s(16), o["small"]), None, o["small"])
                c.screen.blit(tt, (x + s(8), ry + (rh - tt.get_height()) // 2))
                ww["rows"].append(((x, ry, bw, rh), val))
            ww["list"] = (x, top, bw, rh * len(shown))
        _overlays.append((ctx._key, overlay))


class _Scroll:
    """with ctx.scroll(name, box, content_h) as top: 里面按 y = top + … 画内容；滚轮 / 拖滚动条框架处理。"""

    def __init__(self, ctx, w):
        self.ctx, self.w = ctx, w

    def __enter__(self):
        w = self.w
        x, y, bw, bh = w["box"]
        maxoff = max(0, w["opts"]["content_h"] - bh)
        st = self.ctx.state.setdefault("_scroll", {})
        off = max(0, min(maxoff, int(st.get(w["name"], 0))))
        st[w["name"]] = off
        w["max"], w["off"] = maxoff, off
        self.clip = self.ctx.clip(w["hit"] or (x, y, 0, 0))
        self.clip.__enter__()
        import pygame
        _clip_stack.append(pygame.Rect(*(w["hit"] or (x, y, 0, 0))))
        return y - off

    def __exit__(self, *exc):
        _clip_stack.pop()
        self.clip.__exit__(*exc)
        w, c = self.w, self.ctx
        x, y, bw, bh = w["box"]
        if w["max"] > 0:                                    # 内容比框高：右边画一条滚动条
            s = c.s
            ch = w["opts"]["content_h"]
            th = max(s(24), int(bh * bh / ch))
            ty = y + int((bh - th) * w["off"] / w["max"])
            w["bar"] = (x + bw - s(6), y, s(6), bh)
            w["thumb"] = (x + bw - s(6), ty, s(6), th)
            hot = w.get("drag") or _in(w.get("bar"), c.mouse)
            c.box(x + bw - s(5), ty, s(4), th, _mix(c.color("panel"), c.color("text"), 0.45 if hot else 0.25),
                  radius=s(2))
        else:
            w["bar"] = w["thumb"] = None
        return False


def _scroll_by(ctx, w, dy):
    st = ctx.state.setdefault("_scroll", {})
    st[w["name"]] = max(0, min(w.get("max", 0), int(st.get(w["name"], 0)) + int(dy)))
    ctx.redraw()


def _hit_widget(key, pos, kinds=None):
    """pos 落在哪个控件上（后画的优先）。下拉展开的列表最先。"""
    best = None
    for (k, _n), w in _widgets.items():
        if k != key:
            continue
        if kinds and w["kind"] not in kinds:
            continue
        if w["kind"] == "select" and w.get("open") and _in(w.get("list"), pos):
            return w
        if w["kind"] == "scroll":
            continue                                       # 滚动区本身只管滚轮和滚动条，见下面
        if _in(w.get("hit"), pos) and (best is None or w["order"] > best["order"]):
            best = w
    return best


def _widget_down(ctx, pos) -> bool:
    key = ctx._key
    for (k, _n), w in _widgets.items():                   # 先收起别的展开的下拉（点在列表里的除外）
        if k == key and w["kind"] == "select" and w.get("open") and not _in(w.get("list"), pos) \
                and not _in(w.get("hit"), pos):
            w["open"] = False
            ctx.redraw()
    w = _hit_widget(key, pos)
    if w is None:                                          # 滚动条
        for (k, _n), sw in _widgets.items():
            if k == key and sw["kind"] == "scroll" and _in(sw.get("bar"), pos):
                t = sw.get("thumb") or (0, 0, 0, 0)
                if not _in(t, pos):                        # 点在空槽上：直接跳过去
                    bh = sw["box"][3]
                    _scroll_by(ctx, sw, (pos[1] - (t[1] + t[3] // 2)) * max(1, sw["max"]) / max(1, bh - t[3]))
                sw["drag"] = (pos[1], ctx.state.get("_scroll", {}).get(sw["name"], 0))
                return True
        return False
    kind = w["kind"]
    if kind == "select" and w.get("open") and _in(w.get("list"), pos):
        for box, val in w.get("rows") or []:
            if _in(box, pos):
                _set_widget_value(ctx, w, val)
        w["open"] = False
        return True
    if not w["opts"].get("enabled", True):
        return True
    if kind == "select":
        w["open"] = not w.get("open")
        opts = _opt_list(w["opts"]["options"])
        cur = next((i for i, (val, _l) in enumerate(opts) if val == ctx.state.get(w["name"])), 0)
        w["first"] = max(0, cur - 3)
    elif kind == "slider":
        w["drag"] = True
        _set_widget_value(ctx, w, _slider_value_at(w, pos[0]))
    else:
        w["pressed"] = True
    ctx.redraw()
    return True


def _widget_up(ctx, pos) -> bool:
    hit = False
    for (k, _n), w in list(_widgets.items()):
        if k != ctx._key:
            continue
        if w.get("drag"):
            w["drag"] = None
            hit = True
        if w.get("pressed"):
            w["pressed"] = False
            hit = True
            if _in(w.get("hit"), pos):
                if w["kind"] == "button":
                    w["clicked"] = True
                    cb = w["opts"].get("on_click")
                    if cb:
                        cb(ctx)
                elif w["kind"] == "check":
                    _set_widget_value(ctx, w, not bool(ctx.state.get(w["name"])))
    if hit:
        ctx.redraw()
    return hit


def _widget_motion(ctx, pos) -> bool:
    for (k, _n), w in _widgets.items():
        if k != ctx._key or not w.get("drag"):
            continue
        if w["kind"] == "slider":
            _set_widget_value(ctx, w, _slider_value_at(w, pos[0]))
            return True
        if w["kind"] == "scroll":
            y0, off0 = w["drag"]
            t = w.get("thumb") or (0, 0, 0, 1)
            bh = w["box"][3]
            ctx.state.setdefault("_scroll", {})[w["name"]] = off0
            _scroll_by(ctx, w, (pos[1] - y0) * max(1, w["max"]) / max(1, bh - t[3]))
            return True
    return False


def _widget_wheel(ctx, pos, dy) -> bool:
    """滚轮：下拉列表 > 滑块 > 最里层的滚动区。"""
    for (k, _n), w in _widgets.items():
        if k == ctx._key and w["kind"] == "select" and w.get("open") and _in(w.get("list"), pos):
            n = len(_opt_list(w["opts"]["options"]))
            w["first"] = max(0, min(max(0, n - 1), w.get("first", 0) - int(dy)))
            ctx.redraw()
            return True
    w = _hit_widget(ctx._key, pos, kinds=("slider",))
    if w is not None and w["opts"].get("enabled", True):
        step = w["opts"]["step"] or (w["opts"]["hi"] - w["opts"]["lo"]) / 20
        v = ctx.state.get(w["name"], w["opts"]["lo"]) + step * (1 if dy > 0 else -1)
        _set_widget_value(ctx, w, _slider_clamp(w, v))
        return True
    best = None
    for (k, _n), w in _widgets.items():
        if k == ctx._key and w["kind"] == "scroll" and _in(w.get("hit"), pos) and w.get("max", 0) > 0 \
                and (best is None or w["order"] > best["order"]):
            best = w
    if best is not None:
        _scroll_by(ctx, best, -int(dy) * ctx.s(48))
        return True
    return False


# ---------------- 通用输入框（ctx.input）----------------
def _field(key: str, name: str) -> dict:
    """输入框的编辑状态（光标 / 选择起点 / 横向滚动 / 本帧位置）：不进 ctx.state，不落盘。"""
    return _fields.setdefault((key, name), {"cursor": 0, "anchor": 0, "scroll": 0, "box": None,
                                            "drag": False, "opts": {}})


def _clip_board_get() -> str:
    try:
        import pygame
        s = pygame.scrap.get_text()
        if s:
            return s
    except Exception:
        pass
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        s = r.clipboard_get()
        r.destroy()
        return s
    except Exception:
        return ""


def _clip_board_put(text: str):
    try:
        import pygame
        pygame.scrap.put_text(text)
        return
    except Exception:
        pass
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
    except Exception:
        pass


def _shown(text: str, password: bool) -> str:
    return "•" * len(text) if password else text


def _text_w(ctx, font, s: str) -> int:
    return ctx._text(font, s, (0, 0, 0)).get_width() if s else 0


def _index_at(ctx, f: dict, x: int) -> int:
    """横坐标 x 落在第几个字前面（取最近的字缝）。"""
    o = f["opts"]
    text = _shown(str(ctx.state.get(f["name"], "")), o.get("password"))
    font = ctx.small if o.get("small") else ctx.font
    rel = x - f["text_x"] + f["scroll"]
    best, best_d = 0, abs(rel)
    for i in range(1, len(text) + 1):
        d = abs(_text_w(ctx, font, text[:i]) - rel)
        if d < best_d:
            best, best_d = i, d
    return best


def _draw_field(ctx, name, box, *, placeholder, password, max_len, small, on_submit, on_change) -> str:
    import pygame
    x, y, w, h = (int(v) for v in box)
    f = _field(ctx._key, name)
    f.update(name=name, box=(x, y, w, h), hit=_visible((x, y, w, h)), seen=True,
             opts={"password": password, "max_len": max_len, "small": small,
                   "on_submit": on_submit, "on_change": on_change})
    text = str(ctx.state.get(name, "") or "")
    ctx.state[name] = text
    f["cursor"] = max(0, min(len(text), f["cursor"]))
    f["anchor"] = max(0, min(len(text), f["anchor"]))
    focused = _focus_key == ctx._key and _focus_field == name
    font = ctx.small if small else ctx.font
    s = ctx.s
    radius = s(6)
    ctx.box(x, y, w, h, "input_bg", radius=radius)
    ctx.box(x, y, w, h, "input_focus" if focused else "input_border", width=1, radius=radius)
    pad = s(8)
    inner = pygame.Rect(x + pad, y + 1, max(1, w - pad * 2), max(1, h - 2))
    f["text_x"] = inner.x

    comp = str(getattr(ctx._app, "composing", "") or "") if focused else ""
    shown = _shown(text, password)
    cur = f["cursor"]
    line_h = font.get_linesize()
    ty = y + (h - line_h) // 2
    cur_px = _text_w(ctx, font, shown[:cur] + comp)
    # 横向滚动：光标始终在可见范围里
    if cur_px - f["scroll"] > inner.w - s(2):
        f["scroll"] = cur_px - inner.w + s(2)
    elif cur_px - f["scroll"] < 0:
        f["scroll"] = cur_px
    full_w = _text_w(ctx, font, shown[:cur] + comp + shown[cur:])
    f["scroll"] = max(0, min(f["scroll"], max(0, full_w - inner.w + s(2))))
    ox = inner.x - f["scroll"]

    with ctx.clip(inner.clip(ctx.screen.get_clip() or inner)):
        if not text and not comp:
            if placeholder:
                ctx.screen.blit(ctx.text(placeholder, ctx.color("dim"), small=small), (inner.x, ty))
        else:
            a, b = sorted((f["anchor"], cur))
            if focused and a != b and not comp:                    # 选中的文字画底色
                x1, x2 = _text_w(ctx, font, shown[:a]), _text_w(ctx, font, shown[:b])
                fc, bc = ctx.color("input_focus"), ctx.color("input_bg")
                shade = tuple(int(p * 0.35 + q * 0.65) for p, q in zip(fc[:3], bc[:3]))
                ctx.box(ox + x1, ty, max(s(2), x2 - x1), line_h, shade)
            ctx.screen.blit(ctx.text(shown[:cur] + comp + shown[cur:], small=small), (ox, ty))
        cx = ox + cur_px
        if comp:                                                    # 输入法正在拼的字：下划线
            cw = _text_w(ctx, font, comp)
            ctx.line([(cx - cw, ty + line_h - s(2)), (cx, ty + line_h - s(2))], "input_focus", width=s(2))
        if focused and pygame.time.get_ticks() // 530 % 2 == 0:
            ctx.line([(cx, ty + s(2)), (cx, ty + line_h - s(2))], "text", width=s(2))
    if focused:                                                     # 输入法候选框跟着光标
        ime = (cx - (_text_w(ctx, font, comp) if comp else 0), ty, s(10), line_h)
        if ime != f.get("ime"):
            f["ime"] = ime
            try:
                pygame.key.set_text_input_rect(pygame.Rect(*ime))
            except Exception:
                pass
    return text


def _field_at(key: str, pos):
    x, y = int(pos[0]), int(pos[1])
    for (k, name), f in _fields.items():
        b = f.get("hit") if f.get("box") else None          # 滚动区里的输入框：只有露出来的部分能点
        if k == key and b and b[0] <= x < b[0] + b[2] and b[1] <= y < b[1] + b[3]:
            return name, f
    return None, None


def _field_down(ctx, pos) -> bool:
    """模块里按下鼠标：点在输入框上就拿焦点、放光标（Shift 扩选）；点在框外放掉输入框焦点。返回是否吃掉。"""
    import pygame
    name, f = _field_at(ctx._key, pos)
    if f is None:
        if _focus_key == ctx._key and _focus_field is not None:
            set_focus(None)
            ctx.redraw()
        return False
    set_focus(ctx._key, name)
    f.pop("ime", None)
    idx = _index_at(ctx, f, int(pos[0]))
    if not (pygame.key.get_mods() & pygame.KMOD_SHIFT):
        f["anchor"] = idx
    f["cursor"] = idx
    now = time.time()
    if now - f.get("down_at", 0) < 0.35:                    # 双击：全选
        f["anchor"], f["cursor"] = 0, len(str(ctx.state.get(name, "")))
    f["down_at"] = now
    f["drag"] = True
    ctx.redraw()
    return True


def _set_text(ctx, f: dict, text: str, cursor: int):
    name, o = f["name"], f["opts"]
    if o.get("max_len") and len(text) > o["max_len"]:
        return
    old = str(ctx.state.get(name, ""))
    ctx.state[name] = text
    f["cursor"] = f["anchor"] = max(0, min(len(text), cursor))
    if text != old and o.get("on_change"):
        o["on_change"](ctx, text)


def _field_key(ctx, ekey, etext) -> bool | None:
    """有焦点的输入框处理按键。True = 吃掉了；None = 交给模块自己的 on_key。"""
    import pygame
    f = _fields.get((ctx._key, _focus_field))
    if f is None or f.get("box") is None:
        return None
    name = f["name"]
    text = str(ctx.state.get(name, "") or "")
    cur = max(0, min(len(text), f["cursor"]))
    a, b = sorted((max(0, min(len(text), f["anchor"])), cur))
    ctx.redraw()
    if etext:
        etext = str(etext).replace("\r", "").replace("\n", " ")
        _set_text(ctx, f, text[:a] + etext + text[b:], a + len(etext))
        return True
    if ekey is None:
        return True
    mods = pygame.key.get_mods()
    ctrl, shift = bool(mods & pygame.KMOD_CTRL), bool(mods & pygame.KMOD_SHIFT)
    if ekey in (pygame.K_RETURN, pygame.K_KP_ENTER):
        cb = f["opts"].get("on_submit")
        if cb:
            cb(ctx, text)
            return True
        return None
    if ctrl and ekey == pygame.K_a:
        f["anchor"], f["cursor"] = 0, len(text)
        return True
    if ctrl and ekey in (pygame.K_c, pygame.K_x):
        if a != b and not f["opts"].get("password"):
            _clip_board_put(text[a:b])
            if ekey == pygame.K_x:
                _set_text(ctx, f, text[:a] + text[b:], a)
        return True
    if ctrl and ekey == pygame.K_v:
        paste = _clip_board_get().replace("\r", "").replace("\n", " ")
        if paste:
            _set_text(ctx, f, text[:a] + paste + text[b:], a + len(paste))
        return True
    if ekey == pygame.K_BACKSPACE:
        if a != b:
            _set_text(ctx, f, text[:a] + text[b:], a)
        elif cur > 0:
            _set_text(ctx, f, text[:cur - 1] + text[cur:], cur - 1)
        return True
    if ekey == pygame.K_DELETE:
        if a != b:
            _set_text(ctx, f, text[:a] + text[b:], a)
        elif cur < len(text):
            _set_text(ctx, f, text[:cur] + text[cur + 1:], cur)
        return True
    move = {pygame.K_LEFT: cur - 1, pygame.K_RIGHT: cur + 1, pygame.K_HOME: 0, pygame.K_END: len(text)}
    if ekey in move:
        if not shift and a != b and ekey in (pygame.K_LEFT, pygame.K_RIGHT):
            to = a if ekey == pygame.K_LEFT else b              # 有选择时 ←/→ 先收到选择两端
        else:
            to = max(0, min(len(text), move[ekey]))
        f["cursor"] = to
        if not shift:
            f["anchor"] = to
        return True
    return None


def draw(app, key: str, surface, rect, colors: dict, scale, text_fn) -> str:
    """画一个外接模块的内容区；出错就在那块写出错原因（不往外抛）。返回出错信息（没错返回空串）。"""
    p = _plugins.get(key)
    if p is None:
        return "模块不在了"
    for (k, _n), f in _fields.items():
        if k == key:
            f["seen"] = False
    for (k, _n), w in _widgets.items():
        if k == key:
            w["seen"] = False
    _host.update(app=app, colors=colors, scale=scale, text=text_fn)
    _clip_stack.clear()
    _overlays.clear()
    ctx = Ctx(app, p, surface, rect, colors, scale, text_fn)
    size = (int(rect.w), int(rect.h))
    try:
        if p.get("_size") != size:                         # 面板尺寸变了（包括第一次画）：先告诉模块
            p["_size"] = size
            if p.get("on_resize"):
                p["on_resize"](ctx, *size)
        p["draw"](ctx)
        for k, fn in list(_overlays):                      # 下拉展开的列表：画在模块最上层
            if k == key:
                fn()
        p.pop("last_error", None)
        return ""
    except Exception:
        err = _record_error(p)
        return err
    finally:
        _clip_stack.clear()
        _overlays.clear()
        for (k, n), f in _fields.items():                 # 这一帧没画出来的输入框：不再接点击
            if k == key and not f.get("seen"):
                f["box"] = None
                if _focus_key == key and _focus_field == n:
                    set_focus(None)
        for (k, n), w in _widgets.items():                # 没画出来的控件同样不接点击
            if k == key and not w.get("seen"):
                w["hit"], w["open"] = None, False


def click(app, key: str, surface, rect, colors: dict, scale, text_fn, pos) -> bool:
    p = _plugins.get(key)
    if p is None:
        return False
    try:
        ctx = Ctx(app, p, surface, rect, colors, scale, text_fn)
        if _widget_down(ctx, pos):                         # 控件（按钮、下拉、滑块、滚动条）先接
            if _focus_key == key and _focus_field is not None:
                set_focus(None)
            return True
        if _field_down(ctx, pos):
            return True
    except Exception:
        _record_error(p)
        return True
    if p["on_click"] is None:
        return False
    try:
        p["on_click"](Ctx(app, p, surface, rect, colors, scale, text_fn), pos)
        return True
    except Exception:
        _record_error(p)
        return True


def _first_call(mod_names, attr_names):
    """按候选模块 / 函数名挨个试 import，找到第一个能用的就返回（找不到 / 出错返回 None）。"""
    for mod_name, fn_name in zip(mod_names, attr_names):
        try:
            mod = importlib.import_module(mod_name)
            fn = getattr(mod, fn_name, None)
            if callable(fn):
                return fn
        except Exception:
            continue
    return None


_EVENT_CBS = {"down": "on_click", "up": "on_up", "wheel": "on_wheel",
              "motion": "on_motion", "enter": "on_enter", "leave": "on_leave",
              "key": "on_key"}


def set_focus(key=None, field=None):
    """设置拿到键盘焦点的模块 key（None 表示谁都没有）；field 是这个模块里拿焦点的输入框 name。"""
    global _focus_key, _focus_field
    _focus_key = key
    _focus_field = field if key is not None else None
    for f in _fields.values():
        f["drag"] = False
        f.pop("ime", None)


def focused_field():
    """当前拿到键盘焦点的输入框 (模块 key, name)；没有返回 None。"""
    return (_focus_key, _focus_field) if _focus_key is not None and _focus_field is not None else None


def focused():
    """返回当前拿到键盘焦点的模块 key（没有就是 None）。"""
    return _focus_key


def event(kind: str, app, key: str, body, colors, scale, text_fn, *args) -> bool:
    """外接模块的鼠标事件统一入口：kind 是 down/up/wheel/motion/enter/leave，分发给 MODULE 里对应的回调；没这个回调返回 False。"""
    p = _plugins.get(key)
    if p is None:
        return False
    cb_name = _EVENT_CBS.get(kind)
    if not cb_name:
        return False
    if kind in ("motion", "up", "wheel", "down") and args:   # 控件：松手算点击、拖滑块 / 滚动条、滚轮
        try:
            wctx = Ctx(app, p, app.screen, body, colors, scale, text_fn)
            if kind == "up" and _widget_up(wctx, args[0]):
                return True
            if kind == "motion" and _widget_motion(wctx, args[0]):
                return True
            if kind == "wheel":
                pos, dy = args[0] if len(args) == 1 and isinstance(args[0], tuple) else (args[0], args[1])
                if _widget_wheel(wctx, pos, dy):
                    return True
        except Exception:
            _record_error(p)
            return True
    if kind in ("motion", "up") and args:                 # 输入框里按住拖：选文字
        f = _fields.get((key, _focus_field)) if _focus_key == key else None
        if f is not None and f.get("drag") and f.get("box"):
            try:
                ctx = Ctx(app, p, app.screen, body, colors, scale, text_fn)
                f["cursor"] = _index_at(ctx, f, int(args[0][0]))
                if kind == "up":
                    f["drag"] = False
                ctx.redraw()
            except Exception:
                _record_error(p)
            return True
    fn = p.get(cb_name)
    if fn is None:
        return False
    if kind == "wheel" and len(args) == 1 and isinstance(args[0], tuple) and len(args[0]) == 2 \
            and _positional_count(fn) != 2:
        args = args[0]                      # 界面传 ((x, y), dy)：拆成 on_wheel(ctx, pos, dy)；只收一个参数的老写法照旧
    try:
        fn(Ctx(app, p, app.screen, body, colors, scale, text_fn), *args)
        return True
    except Exception:
        _record_error(p)
        return True


def _positional_count(fn) -> int:
    """回调能收几个位置参数（有 *args 算很多）；看不出来返回 -1。"""
    import inspect
    try:
        ps = inspect.signature(fn).parameters.values()
    except (TypeError, ValueError):
        return -1
    if any(q.kind == q.VAR_POSITIONAL for q in ps):
        return 99
    return sum(q.kind in (q.POSITIONAL_ONLY, q.POSITIONAL_OR_KEYWORD) for q in ps)


def key_event(app, key: str, body, colors, scale, text_fn, ekey, etext) -> bool:
    """外接模块的键盘事件入口：把 ekey / etext 交给 MODULE 的 on_key 回调；没这个回调返回 False。"""
    p = _plugins.get(key)
    if p is None:
        return False
    cb = p.get("on_key")
    has_field = _focus_key == key and _focus_field is not None
    if not callable(cb) and not has_field:
        return False
    try:
        ctx = Ctx(app, p, app.screen, body, colors, scale, text_fn)
        if has_field and _field_key(ctx, ekey, etext):
            return True                                   # 输入框自己处理掉了
        if callable(cb) and not (has_field and etext):    # 文字已经进了输入框，不再重复给 on_key
            cb(ctx, ekey, etext)
        return True                                       # 输入框有焦点：按键不漏给主输入框
    except Exception:
        _record_error(p)
        return True


def needs_redraw(visible: list[str]) -> bool:
    """看得见的外接模块里，有到点要重画的（refresh 秒一次），或者刚调过 ctx.redraw()。"""
    global _blink_phase
    if _focus_key in visible and _focus_field is not None:        # 输入框光标闪烁
        phase = int(time.time() * 1000) // 530 % 2
        if phase != _blink_phase:
            _blink_phase = phase
            return True
    for k in visible:
        if k in _dirty:
            _dirty.discard(k)
            return True
    now = time.time()
    for k in visible:
        p = _plugins.get(k)
        if p and p["refresh"] > 0 and now - p.get("drawn_at", 0) >= p["refresh"]:
            return True
    return False


def mark_drawn(key: str):
    p = _plugins.get(key)
    if p:
        p["drawn_at"] = time.time()


# ---------------- 内置面板：全局模块设置 ----------------
def _fmt_global(v) -> str:
    if isinstance(v, float):
        return f"{v:g}"
    return "" if v is None else str(v)


def _gp_draw(ctx):
    """全局模块设置：每个全局变量一行（标题 / 来自哪些模块 / 编辑器 / 恢复默认），模块间共用、改了马上生效。"""
    st = ctx.state
    r = ctx.rect
    s = ctx.s
    pad = s(10)
    hits = []
    st["_hits"] = hits
    names = sorted(_global_decls, key=lambda n: (_global_decls[n]["owners"][0], n))
    names += sorted(n for n in _global_values() if n not in _global_decls)        # 没声明、运行时设的
    if not names:
        y = r.y + pad
        for line in ("还没有模块声明全局变量。",
                     "在模块的 MODULE 里写 \"globals\": {名字: 默认值}，",
                     "所有模块就能用 ctx.get_global / ctx.set_global 共用。"):
            ctx.screen.blit(ctx.text(line, ctx.color("dim"), small=True), (r.x + pad, y))
            y += ctx.small.get_linesize() + s(2)
        return
    lh, slh = ctx.font.get_linesize(), ctx.small.get_linesize()
    ed_h = s(28)
    row_h = lh + slh + ed_h + s(16)
    total = row_h * len(names)
    st["scroll"] = max(0, min(int(st.get("scroll", 0)), max(0, total - r.h + pad)))
    y = r.y + pad - st["scroll"]
    w = r.w - pad * 2
    vals = all_globals()
    for name in names:
        if y + row_h < r.y or y > r.bottom:
            y += row_h
            continue
        d = _global_decls.get(name) or {"type": _infer_type(vals.get(name)), "title": name, "desc": "",
                                        "options": [], "owners": [], "default": None}
        v = vals.get(name)
        x = r.x + pad
        ctx.screen.blit(ctx.text(d["title"]), (x, y))
        src = (f"{name} · " + ("来自 " + "、".join(d["owners"]) if d["owners"] else "运行时设的，没有模块声明")
               + (f" · {d['desc']}" if d["desc"] else ""))
        with ctx.clip((x, y + lh, w, slh)):
            ctx.screen.blit(ctx.text(src, ctx.color("dim"), small=True), (x, y + lh))
        ey = y + lh + slh + s(4)
        is_default = name not in _global_values()
        rw = 0 if is_default or not d["owners"] else ctx.text_size("默认", small=True)[0] + s(12)
        ew = w - rw - (s(6) if rw else 0)
        t = d["type"]
        if t == "bool":
            on = bool(v)
            tw, th = s(40), s(22)
            ty = ey + (ed_h - th) // 2
            ctx.box(x, ty, tw, th, "btn_on" if on else "btn", radius=th // 2)
            ctx.circle(x + (tw - th // 2 if on else th // 2), ty + th // 2, th // 2 - s(3), "on_text")
            lab = ctx.text("开" if on else "关", ctx.color("text"), small=True)
            ctx.screen.blit(lab, (x + tw + s(8), ey + (ed_h - lab.get_height()) // 2))
            hits.append(((x, ey, tw + s(8) + lab.get_width(), ed_h), "toggle", name))
        elif t == "choice":
            ctx.box(x, ey, ew, ed_h, "input_bg", radius=s(6))
            ctx.box(x, ey, ew, ed_h, "input_border", width=1, radius=s(6))
            lab = ctx.text(f"{_fmt_global(v)}   ▾（点一下换下一个）", small=False)
            with ctx.clip((x, ey, ew, ed_h)):
                ctx.screen.blit(lab, (x + s(8), ey + (ed_h - lab.get_height()) // 2))
            hits.append(((x, ey, ew, ed_h), "cycle", name))
        else:
            fname = "v:" + name
            if not ctx.input_focused(fname):
                st[fname] = _fmt_global(v)            # 没在编辑：跟着当前值（别的模块改了也能看到）
            ctx.input(fname, (x, ey, ew, ed_h), placeholder=f"（{t}）",
                      on_change=lambda c, text, n=name: _gp_try_set(c, n, text, quiet=True),
                      on_submit=lambda c, text, n=name: (_gp_try_set(c, n, text), c.focus_input(None)))
            if st.get("err:" + name):
                et = ctx.text(st["err:" + name], ctx.color("warn"), small=True)
                ctx.screen.blit(et, (x + ew - et.get_width() - s(6), ey - slh))
        if rw:
            rt = ctx.text("默认", ctx.color("hdr"), small=True)
            rx = x + w - rw
            ctx.screen.blit(rt, (rx + (rw - rt.get_width()) // 2, ey + (ed_h - rt.get_height()) // 2))
            hits.append(((rx, ey, rw, ed_h), "reset", name))
        y += row_h
        ctx.line([(r.x + pad, y - s(6)), (r.right - pad, y - s(6))], "border")


def _gp_try_set(ctx, name, text, quiet=False):
    """面板里改了文字：转得了就写进全局变量；转不了在输入框上方提示（打字途中的半截数字不提示）。"""
    try:
        ctx.set_global(name, text)
        ctx.state.pop("err:" + name, None)
    except (TypeError, ValueError) as e:
        if not quiet or str(text).strip() not in ("", "-", ".", "-."):
            ctx.state["err:" + name] = str(e) if "不能" in str(e) or "只能" in str(e) else "格式不对"
    ctx.redraw()


def _gp_click(ctx, pos):
    x, y = int(pos[0]), int(pos[1])
    for (hx, hy, hw, hh), act, name in ctx.state.get("_hits") or []:
        if hx <= x < hx + hw and hy <= y < hy + hh:
            if act == "toggle":
                ctx.set_global(name, not bool(get_global(name)))
            elif act == "cycle":
                opts = (_global_decls.get(name) or {}).get("options") or []
                if opts:
                    cur = get_global(name)
                    ctx.set_global(name, opts[(opts.index(cur) + 1) % len(opts)] if cur in opts else opts[0])
            elif act == "reset":
                ctx.reset_global(name)
                ctx.state.pop("err:" + name, None)
            ctx.redraw()
            return


def _gp_wheel(ctx, *args):
    dy = args[0][1] if len(args) == 1 and isinstance(args[0], tuple) else (args[-1] if args else 0)
    ctx.state["scroll"] = max(0, int(ctx.state.get("scroll", 0)) - int(dy) * ctx.s(40))
    ctx.redraw()


def _globals_plugin() -> dict:
    p = {"key": GLOBALS_KEY, "title": "全局模块设置", "side": "right", "sub": "外接模块共用的变量，改了所有模块马上生效",
         "refresh": 0.0, "version": "", "author": "Terminist", "description": "",
         "draw": _gp_draw, "globals": {}, "tools": {}, "commands": {},
         "path": "<builtin:module_globals>", "dir": str(MODULES_DIR), "mtime": 0, "state": {}}
    for h in HOOKS:
        p[h] = None
    p["on_click"], p["on_wheel"] = _gp_click, _gp_wheel
    return p


# ---------------- 打包（给做模块的人用） ----------------
def pack(folder, out=None) -> Path:
    """把模块文件夹打成模块包 <文件夹名>.tmod（放在文件夹旁边）。打之前先按 Terminist 读模块的方式试读一遍，读不了就不打。"""
    folder = Path(folder).resolve()
    if not folder.is_dir():
        raise ValueError(f"{folder} 不是文件夹")
    _load(folder)                                     # 先试读：key / 入口 / draw 有问题当场报出来
    out = Path(out) if out else folder.with_suffix(".tmod")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and not p.name.startswith("."):
                z.write(p, p.relative_to(folder).as_posix())
    return out


# ---------------- 自测（给做模块的人用）：不开界面，把模块里里外外点一遍 ----------------
def selftest(target) -> int:
    """在一份临时拷贝上（不碰真的状态）读模块、在两种尺寸下画、点每个控件、往每个输入框打字、滚轮、按键、
    跑 on_tick / on_frame、检查给 Agent 的工具定义、最后 on_unload。打印每一步，返回出错的步数。"""
    import os
    import tempfile
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    import pygame
    global MODULES_DIR
    src = Path(target).resolve()
    if not src.exists():
        print(f"找不到 {src}")
        return 1
    pygame.init()
    pygame.display.set_mode((800, 800))
    tmp = Path(tempfile.mkdtemp(prefix="tmod_test_"))
    real_dir = MODULES_DIR
    MODULES_DIR = tmp
    fails = []
    notes = []

    def step(name, fn):
        try:
            out = fn()
            print(f"  [通过] {name}" + (f"：{out}" if out else ""))
        except Exception:
            fails.append(name)
            print(f"  [出错] {name}\n" + "\n".join("        " + ln for ln in traceback.format_exc().strip().splitlines()))
    try:
        (shutil.copytree if src.is_dir() else shutil.copy2)(src, tmp / src.name)
        print(f"自测 {src.name}（临时目录 {tmp}）")

        class App:
            busy, agent, composing = False, None, ""
            font = pygame.font.Font(None, 22)
            small = pygame.font.Font(None, 17)
            screen = pygame.display.get_surface()

            def show_toast(self, text):
                notes.append(str(text))
        app = App()
        colors = {"bg": (30, 30, 30), "panel": (36, 36, 36), "text": (230, 230, 230), "dim": (150, 150, 150),
                  "border": (70, 70, 70), "btn": (60, 60, 60), "btn_on": (40, 120, 75), "on_text": (255, 255, 255),
                  "input_bg": (42, 42, 42), "input_border": (80, 80, 80), "input_focus": (76, 139, 255),
                  "hdr": (76, 139, 255), "warn": (220, 150, 40), "add": (60, 170, 90), "del": (200, 70, 70)}

        def text_fn(font, s, color):
            return font.render(str(s), True, color)
        set_host(app, colors, lambda v: int(v), text_fn)
        added, _removed, errs = load_all()
        keys = [k for k in added if k != GLOBALS_KEY]
        if errs or not keys:
            print(f"  [出错] 读模块：{errs or '没读到模块（检查 key / draw）'}")
            return 1
        key = keys[0]
        p = _plugins[key]
        print(f"  [通过] 读模块：key={key}，标题「{p['title']}」，事件函数 "
              f"{', '.join(h for h in HOOKS if p.get(h)) or '无'}")
        step("on_load", lambda: pump(app) and None)
        screen = app.screen
        rects = [pygame.Rect(0, 0, 360, 480), pygame.Rect(0, 0, 640, 720)]

        def draw_at(r):
            err = draw(app, key, screen, r, colors, lambda v: int(v), text_fn)
            if err:
                raise RuntimeError(p.get("last_trace") or err)
            return f"{r.w}x{r.h}"
        for r in rects:
            step(f"画（{r.w}x{r.h}）", lambda r=r: draw_at(r))
        body = rects[1]
        ws = [w for (k, _n), w in _widgets.items() if k == key and w.get("hit") and w["kind"] != "scroll"]
        for w in ws:
            def poke(w=w):
                c = (w["hit"][0] + w["hit"][2] // 2, w["hit"][1] + w["hit"][3] // 2)
                click(app, key, screen, body, colors, lambda v: int(v), text_fn, c)
                event("up", app, key, body, colors, lambda v: int(v), text_fn, c)
                draw_at(body)
                if w["kind"] == "select" and w.get("rows"):            # 下拉：点开以后选最后一项
                    b = w["rows"][-1][0]
                    click(app, key, screen, body, colors, lambda v: int(v), text_fn, (b[0] + 4, b[1] + 4))
                    draw_at(body)
                return f"值 = {p['state'].get(w['name'])!r}" if w["kind"] != "button" else ""
            step(f"点 {w['kind']}「{w['name']}」", poke)
        for (k, n), f in list(_fields.items()):
            if k != key or not f.get("hit"):
                continue

            def typing(f=f, n=n):
                b = f["hit"]
                click(app, key, screen, body, colors, lambda v: int(v), text_fn, (b[0] + 4, b[1] + b[3] // 2))
                for ch in "测试abc":
                    key_event(app, key, body, colors, lambda v: int(v), text_fn, None, ch)
                key_event(app, key, body, colors, lambda v: int(v), text_fn, pygame.K_BACKSPACE, "")
                draw_at(body)
                key_event(app, key, body, colors, lambda v: int(v), text_fn, pygame.K_RETURN, "")
                draw_at(body)
                set_focus(None)
                return f"打完是 {p['state'].get(n)!r}"
            step(f"输入框「{n}」打字 + 回车", typing)
        def wheel():
            for d in (1, -3):
                event("wheel", app, key, body, colors, lambda v: int(v), text_fn, (body.center, d))
            draw_at(body)

        def middle():
            click(app, key, screen, body, colors, lambda v: int(v), text_fn, body.center)
            event("up", app, key, body, colors, lambda v: int(v), text_fn, body.center)
            draw_at(body)

        def keys_():
            for kk in (pygame.K_TAB, pygame.K_DOWN, pygame.K_UP):
                key_event(app, key, body, colors, lambda v: int(v), text_fn, kk, "")

        def strict(hook, *args):
            def run():
                p.pop("last_error", None)
                _call_hook(p, hook, *args)
                if p.get("last_error"):
                    raise RuntimeError(p.get("last_trace"))
            return run
        step("滚轮（上、下）", wheel)
        if p.get("on_click"):
            step("点内容区中间", middle)
        if p.get("on_key"):
            step("按键（Tab / ↓ / ↑）", keys_)
        if p.get("on_tick"):
            step("on_tick", strict("on_tick"))
        if p.get("on_frame"):
            step("on_frame（10 帧）", lambda: [strict("on_frame", 0.016)() for _ in range(10)] and None)
        tools = agent_tool_schemas()
        if tools:
            step(f"给 Agent 的工具（{len(tools)} 个）", lambda: json.dumps(tools, ensure_ascii=False) and
                 "、".join(t["function"]["name"] for t in tools))
        if p.get("commands"):
            print(f"  [信息] 斜杠命令：{', '.join('/' + c for c in p['commands'])}")
        step("pump（后台回调）", lambda: [pump(app) for _ in range(3)] and None)
        step("on_unload", lambda: _call_hook(p, "on_unload") and None)
        if p.get("last_error"):
            fails.append("运行中出错")
            print(f"  [出错] 运行中记下的错误：\n{p.get('last_trace')}")
        if notes:
            print(f"  [信息] 模块弹的通知：{notes[:5]}")
        print(f"结果：{'全部通过' if not fails else f'{len(fails)} 步出错：' + '、'.join(fails)}")
        return len(fails)
    finally:
        MODULES_DIR = real_dir
        for k in list(_plugins):
            _plugins.pop(k, None)
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "pack":
        print(f"打好了：{pack(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)}")
    elif len(sys.argv) >= 3 and sys.argv[1] == "test":
        sys.exit(1 if selftest(sys.argv[2]) else 0)
    else:
        print("用法：python -m surface.modules_api pack <模块文件夹> [输出文件.tmod]\n"
              "      python -m surface.modules_api test <模块文件夹或 .tmod>   （不开界面把模块点一遍）")
