"""Surface（渲染层）：gui.py 图形界面，console.py 命令行。"""

import json
import time
from pathlib import Path

SELF_TEST_FLAG = ".terminist/selftest_pending.json"


def help_text() -> str:
    """斜杠命令清单，GUI 和 CLI 的 /help 共用。"""
    return ("可用命令：\n"
            "  /help            显示本帮助\n"
            "  /clear           清空对话和记忆\n"
            "  /versions        查看版本存档\n"
            "  /rollback [版本] 回滚到最近一次/指定版本的改造（需重启生效）\n"
            "  /penalty         查看扣分；/penalty reset 清零\n"
            "  /theme [名字]    切换主题 light/dark/green/sepia\n"
            "  /set [键] [值]   查看/修改设置\n"
            "  /model [名字]    查看/切换模型（team = 工作组）\n"
            "  /selftest        重启后自动跑一遍本地工具自检（/selftest cancel 取消）\n"
            "  /restart         重启 Terminist（对话记忆和设置都保留）\n"
            "  /apikey          换 DeepSeek API key（命令行；图形界面在设置里换；加密保存）\n"
            "干活时（图形界面）：直接说话 = 边干边聊（问进度、暂停、继续、提新要求都行）；\n"
            "  /pause /resume   暂停 / 继续工作流；/plan 内容  把新要求直接交给干活的 Agent")


def restart_tool_schema() -> dict:
    """给 A库 的 restart_terminist 工具：用户要重启时调用，这一轮说完就重启。"""
    from lib_a import _fn
    return _fn("restart_terminist",
               "重启 Terminist（例如用户让你重启、或者改了设置 / 代码要重启生效）。"
               "不会丢东西：新窗口先起来，旧窗口再关，对话记忆和设置都保留；这一轮回复说完才会重启。"
               "重启由界面另起一个新进程完成，你可以放心调用。",
               {"selfcheck": {"type": "string", "description": (
                   "可选。不填=只重启不自检；填 \"true\"/\"yes\"=重启后按默认自检项验证；"
                   "填一段自定义文本（例如「试一下 now() 能不能用」）=重启后按这段内容验证，"
                   "由你用本地工具实际执行并逐项报告。")}})


def choose_schema() -> dict:
    """给 A库 的 choose 工具：让主人在几条里勾选（走界面弹窗，不依赖打开文件夹）。"""
    from lib_a import _fn
    return _fn("choose",
               "在聊天里插一张选择卡片，等主人选完再返回。默认多选：每条前面一个勾选框（默认都不勾），"
               "主人勾好点「确定」，或者点「都不要」。single=true 时是单选：主人点一条就直接提交。"
               "卡片最后还有一行「自己写一个」：主人可以不用你给的选项，自己打字回答（会标明是主人自己写的）。"
               "返回主人选中的条目；一个都没选就照「都不要」处理。之后只做选中的，没选的不做。"
               "问题里别写「点允许」之类的操作说明，卡片自己有按钮。",
               {"msg": {"type": "string", "description": "要问主人的问题，例如「要做下面哪几件」"},
                "items": {"type": "array", "items": {"type": "string"}, "description": "选项列表，每条一个字符串"},
                "single": {"type": "boolean", "description": "true = 只能选一个（点一下就提交）；默认 false 多选"},
                "detail": {"type": "string", "description": "可选，补充说明（显示在问题下面）"}},
               ["msg", "items"])


def request_takeover_schema() -> dict:
    """给 A库 的 request_takeover 工具：申请进入接管模式（弹确认框，主人点「确定」才进）。"""
    from lib_a import _fn
    return _fn("request_takeover",
               "申请进入接管模式：界面弹出确认框，写明你的理由，主人点「确定」才进入（点「取消」或 5 分钟没理就不进）。"
               "进入后眼睛开始本地截图识别，你每做一步都会带上前 5 秒的眼睛日志，还能用 skip(毫秒) 等待；"
               "接下来用 screen_* 工具自己动鼠标键盘干。只在确实要连续操作电脑界面时申请；主人拒绝了就别反复申请。",
               {"reason": {"type": "string",
                           "description": "为什么要接管、打算做什么（一两句大白话，会原样显示给主人看）"}},
               ["reason"])


def end_takeover_schema() -> dict:
    """给 A库 的 end_takeover 工具：自己退出接管模式（不用主人确认，界面会弹窗告诉主人已退出）。"""
    from lib_a import _fn
    return _fn("end_takeover",
               "退出接管模式：接管下的活干完了（或者干不下去了）就调它，眼睛停止截图，鼠标键盘交还给主人，"
               "界面会弹窗告诉主人「已退出接管」。不用主人确认。summary 写一句干了什么 / 为什么退出，会显示在弹窗里。",
               {"summary": {"type": "string", "description": "一句大白话：这次接管干了什么、结果怎样（或者为什么提前退出）"}},
               ["summary"])


def notify_schema() -> dict:
    """给 A库 的 notify 工具：在界面左下角弹一条测试通知。"""
    from lib_a import _fn
    return _fn("notify",
               "在 Terminist 界面左下角弹一条通知（复用已有的 toast），4 秒后自动消失。用于验证通知功能。",
               {"text": {"type": "string", "description": "要显示的通知文字"}},
               ["text"])


def rollback_to(name: str):
    """回滚到指定已交工的版本存档，返回 (是否成功, 信息)。"""
    import lib_b.versions as vv
    vs = {n: m for n, m in vv.list_versions()}
    if name not in vs:
        return False, f"没有这个版本：{name}，用 /versions 查看可用版本"
    if vs[name].get("status") != "已交工":
        return False, f"{name} 不是已交工的版本，不能回滚（只有交工过的改造才能回滚）"
    backup = vv.snapshot(f"回滚 {name} 之前的样子")
    vv.mark(backup, "回滚前备份")
    vv.restore(name)
    vv.mark(name, "已回滚")
    return True, f"已回滚到 {name}，回滚前的样子备份为 {backup}。重启 Terminist 后完全生效。"


def self_test_flag_path() -> Path:
    """自检标记文件路径：APP_ROOT/memory/selftest_pending.json。
    放在 memory/ 里：不进版本存档、不被回滚和 B库 的临时副本删掉（以前放 .terminist/，回滚时会被当成多余文件删掉）。"""
    import lib_a as da
    return Path(da.MEMORY_DIR) / "selftest_pending.json"


def _legacy_flag_path() -> Path:
    import lib_a as da
    return Path(da.APP_ROOT) / ".terminist" / "selftest_pending.json"


def self_test_prompt(custom: str = "") -> str:
    """重启后自检要发给 A库 的那段指令文本。custom 非空时追加这条重点验证项。"""
    text = ("这是一次重启后的自检，不是主人的新需求。请用本地工具真跑一遍，不要只说不做：\n"
            "1) 用 find_files 找 *.py，确认能找到文件；\n"
            "2) 挑其中一个文件，用 read_lines 读它前 5 行；\n"
            "3) 用 run_bg 跑 python -c \"print('selftest ok')\"，再用 bg_output 读出结果；\n"
            "4) 用 wait 等 1 秒；\n"
            "5) 故意用 read_lines 读一个工作区外的路径（比如 C:/Windows/win.ini 或 ../ 之类的越界路径），"
            "确认被工具拒绝；\n"
            "没打开文件夹时就用沙箱目录做上面这些，不用报错。\n"
            "最后用简洁的中文汇总：哪几项通过、哪几项失败；失败就直说，别掩饰。")
    custom = (custom or "").strip()
    if custom and custom != "restart selftest":
        text += (f"\n另外，主人这次要求重点验证：{custom}。"
                 "这一项请务必用本地工具真的执行并验证，把每一步的真实结果（成功/失败/输出摘要）逐条报出来，不要只说不做。")
    return text


def run_self_test(config: str = "") -> str | None:
    """读自检标记：不存在 / 内容坏掉 / 超过 10 分钟都当没有；拿到就立刻删掉，同一份最多跑一次。"""
    try:
        p = self_test_flag_path()
        if not p.exists() and _legacy_flag_path().exists():     # 旧位置留下的标记也认
            p = _legacy_flag_path()
        if not p.exists():
            return None
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            data = None
        created = data.get("created") if isinstance(data, dict) else None
        if not isinstance(created, (int, float)):
            created = None
        req = data.get("request") if isinstance(data, dict) else None
        if not isinstance(req, str) or not req.strip():
            req = data.get("requested") if isinstance(data, dict) else None
        custom = req.strip() if isinstance(req, str) and req.strip() else ""
        # 先读内容、再删文件：标记到此为止，绝不无限重启循环
        try:
            p.unlink(missing_ok=True)
        except Exception:
            pass
        if created is None or time.time() - created > 600:
            return None
        return self_test_prompt(custom)
    except Exception:
        return None


def request_self_test(on: bool = True, instruction: str = "") -> str:
    """写/删自检标记文件，返回给主人看的提示文字。instruction 非空时写进去当这次要重点验证的内容。"""
    try:
        p = self_test_flag_path()
        if not on:
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass
            return "已取消重启自检"
        p.parent.mkdir(parents=True, exist_ok=True)
        req = (instruction or "restart selftest").strip() or "restart selftest"
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"request": req, "requested": req, "created": time.time()}, f, ensure_ascii=False)
        return "自检已排上，重启 Terminist 后会自动跑一遍本地工具验证"
    except Exception as e:
        return f"自检标记写入失败：{e}"


# ---------------- API key（界面里换新的）----------------
def check_api_key(key: str, url: str = "", name: str = "") -> tuple[bool | None, str]:
    """试一下 key（不传地址就是当前在用的接口）：(True, "") 能用；(False, 原因) 被拒绝，不要保存；(None, 原因) 连不上，没法确认。"""
    key = (key or "").strip()
    if not key or any(ch.isspace() for ch in key):
        return False, "key 不能为空，也不能有空格"
    import openai
    from lib_a import config
    url = url or config.base_url() or config.BASE_URL
    name = name or config.provider().get("name") or "接口"
    try:
        openai.OpenAI(api_key=key, base_url=url, timeout=15, max_retries=0).models.list()
        return True, ""
    except (openai.AuthenticationError, openai.PermissionDeniedError):
        return False, f"{name} 拒绝了这个 key（无效或没有权限）"
    except Exception as e:
        return None, f"连不上 {name}（{type(e).__name__}），没法确认 key 能不能用"


def save_api_key(agent, key: str):
    """加密保存新 key，正在用的 Agent 立刻换上。"""
    from lib_a.config import set_api_key
    set_api_key(key)
    if agent is not None:
        agent.reset_client()


def clear_api_key(agent) -> str:
    """清空保存的 key（删掉加密文件），正在用的 Agent 也立刻停用旧 key。返回给人看的结果。"""
    from lib_a.config import ENV_KEY, key_source, set_api_key
    had = key_source()
    set_api_key("")
    if agent is not None:
        try:
            agent.reset_client()
        except Exception:
            pass
    if had == "env":
        return f"保存的 key 已清空；但环境变量 {ENV_KEY} 里还有一个，正在用的是它（要在系统环境变量里删）"
    return "已清空保存的 key：这台电脑上不再有 Terminist 的 key，要用时重新填一个"


def api_key_text() -> str:
    """给人看的当前 key：前 3 位…后 4 位 + 来源。"""
    from lib_a.config import get_api_key, key_source, mask_key
    src = key_source()
    if src == "none":
        return "未填写"
    return f"{mask_key(get_api_key())}（{'环境变量 DEEPSEEK_API_KEY' if src == 'env' else '已加密保存'}）"


def provider_rows() -> list[dict]:
    """「隐私」里的接口列表：每个接口一行（名字、地址、模型、key 打码），在用的排最前。"""
    from lib_a import config
    data = config.load_providers()
    out = []
    for pid, p in data["providers"].items():
        src = config.key_source(pid)
        try:
            key = config.mask_key(config.get_api_key(pid)) if src != "none" else "未填 key"
        except NotImplementedError:
            key = "未填 key"
        if src == "env":
            key += "（环境变量）"
        out.append({"id": pid, "name": p.get("name") or pid, "url": p.get("base_url") or "",
                    "main": p.get("main") or "", "fast": p.get("fast") or "", "key": key,
                    "has_key": src != "none", "active": pid == data["active"]})
    out.sort(key=lambda r: (not r["active"], r["id"] != config.DEFAULT_PROVIDER))
    return out


# ---------------- AI 自己打开文件夹（只限桌面）----------------
MEMORY_ROOT_ENV = "TERMINIST_MEMORY_ROOT"    # 重启时带上：AI 换过文件夹，新窗口仍然读原来那份对话记忆


_BAD_NAME = set('<>:"|?*')


def desktop_folder(path: str, create: bool = False) -> tuple[Path, bool]:
    """把 AI 给的路径解析成桌面里的一个文件夹，返回 (文件夹, 是不是刚新建的)。
    不在桌面里抛 ValueError；不存在时 create=True 就新建，否则也抛 ValueError。
    先 resolve 再判断，所以 ..、快捷方式 / 链接指到桌面外面的都会被拒绝；Terminist 自己的文件夹里不能新建。"""
    import lib_a as da
    from base.tools import desktop_dir
    desk = desktop_dir()
    raw = str(path or "").strip().strip('"')
    p = Path(raw)
    if not p.is_absolute():
        p = desk / p
    p = p.resolve()
    if p != desk and desk not in p.parents:
        raise ValueError(f"只能打开桌面（{desk}）里的文件夹，{p} 不在桌面里")
    if p.is_dir():
        return p, False
    if p.exists():
        raise ValueError(f"{p} 是文件，不是文件夹")
    if not create:
        raise ValueError(f"桌面上没有这个文件夹：{p}（要新建的话调用时带上 create=true）")
    app_root = Path(da.APP_ROOT).resolve()
    if p == app_root or app_root in p.parents:
        raise ValueError("不能在 Terminist 自己的文件夹里新建工作区")
    if any(ch in _BAD_NAME for part in p.relative_to(desk).parts for ch in part):
        raise ValueError(f"文件夹名里不能有这些字符：{' '.join(sorted(_BAD_NAME))}")
    p.mkdir(parents=True)
    return p, True


def open_folder_schema() -> dict:
    from lib_a import _fn
    return _fn("open_folder",
               "自己打开桌面上的一个文件夹当工作区，之后就能用文件工具读写里面的东西（删除文件仍然要用户弹窗确认）。"
               "只能是桌面里的文件夹；文件夹还不存在时带上 create=true 就会新建再打开。"
               "打开 / 新建后界面会通知用户；你也要在回复里用一句话告诉用户是哪个文件夹、要拿它做什么。",
               {"path": {"type": "string", "description": "相对桌面的路径（例如 aim、projects/demo），或桌面里的绝对路径"},
                "create": {"type": "boolean", "description": "文件夹不存在时新建它（默认不新建）"}},
               ["path"])


def open_folder_result(path: Path, created: bool = False) -> str:
    return (f"已{'新建并' if created else ''}打开文件夹 {path}。从下一步起你的工具里就有 write_file、edit_file、"
            f"list_dir、read_file、run_command、delete_file 等文件工具了，直接用相对这个文件夹的路径读写（删除仍要用户确认）。"
            f"界面上已经通知了用户；回复里用一句话告诉用户你{'新建了' if created else '打开了'}这个文件夹、要用它做什么。")
