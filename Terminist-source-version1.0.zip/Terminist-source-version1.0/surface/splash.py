"""
开机特效：透明底的启动画面——屏幕中央是 Terminist 图标（呼吸光晕 + 两圈反向旋转的刻度环），
四周一圈追光点阵 + 两条斜椭圆轨道上绕着图标转的彗星（前半圈压在图标上，有立体感），底下是一节一节的科技感加载条（亮着的段发光、正在加载的段闪烁、有一道扫光）。

单独一个小进程（只用 pygame 画图 + Windows 分层窗口贴屏，不等主程序那一大堆代码加载）：
- run.py 冷启动时起它（重启不起：重启本来就是无缝的），把进度文件路径和父进程 pid 传进来；
- 主程序启动到哪一步就往进度文件里写「进度|在干什么」（run.splash()），这边每帧读一次，进度条平滑追上去；
- 读到 1（主界面第一帧画出来、Agent 进程也起来了）就粒子炸开、整体淡出、退出；父进程没了 / 超时也退出。
只在 Windows 上显示（透明窗口用的是 UpdateLayeredWindow）；别的系统直接退出，不影响启动。

单独看效果：python -m surface.splash --demo
"""

import math
import os
import random
import sys
import time
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
GREEN = (57, 255, 136)
GREEN_DIM = (20, 90, 52)
SEGMENTS = 30
MIN_SHOW = 1.6            # 最少显示这么久（秒），太快一闪而过看不到特效
TIMEOUT = 90              # 主程序一直没说好：最多显示这么久


def _alive(pid: int) -> bool:
    if pid <= 0:
        return True
    import ctypes
    h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
    if not h:
        return False
    code = ctypes.c_ulong()
    ok = ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
    ctypes.windll.kernel32.CloseHandle(h)
    return bool(ok) and code.value == 259


class LayeredWindow:
    """一个没边框、不抢焦点、置顶、不进任务栏的分层窗口：每帧把带 alpha 的画面整张贴上去（真透明）。"""

    def __init__(self, w, h):
        import ctypes
        import ctypes.wintypes as wt
        self.ct, self.wt = ctypes, wt
        # 自己的 DLL 实例 + 写全参数类型：64 位下句柄可能超过 32 位，不写 argtypes 会偶发溢出 / 截断
        u, g, k = ctypes.WinDLL("user32"), ctypes.WinDLL("gdi32"), ctypes.WinDLL("kernel32")
        self.u, self.g = u, g
        P, H = ctypes.c_void_p, wt.HANDLE
        for fn, res, args in (
                (k.GetModuleHandleW, H, [wt.LPCWSTR]),
                (u.GetDC, H, [wt.HWND]),
                (u.ReleaseDC, ctypes.c_int, [wt.HWND, H]),
                (u.ShowWindow, wt.BOOL, [wt.HWND, ctypes.c_int]),
                (u.DestroyWindow, wt.BOOL, [wt.HWND]),
                (u.GetSystemMetrics, ctypes.c_int, [ctypes.c_int]),
                (u.CreateWindowExW, wt.HWND, [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int, ctypes.c_int,
                                              ctypes.c_int, ctypes.c_int, wt.HWND, H, H, P]),
                (u.UpdateLayeredWindow, wt.BOOL, [wt.HWND, H, P, P, H, P, wt.DWORD, P, wt.DWORD]),
                (u.PeekMessageW, wt.BOOL, [P, wt.HWND, wt.UINT, wt.UINT, wt.UINT]),
                (u.TranslateMessage, wt.BOOL, [P]),
                (u.DispatchMessageW, ctypes.c_ssize_t, [P]),
                (g.CreateCompatibleDC, H, [H]),
                (g.CreateDIBSection, H, [H, P, wt.UINT, P, H, wt.DWORD]),
                (g.SelectObject, H, [H, H]),
                (g.DeleteObject, wt.BOOL, [H]),
                (g.DeleteDC, wt.BOOL, [H])):
            fn.restype, fn.argtypes = res, args
        try:
            u.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))     # 按真实像素画，不被系统放大糊掉
        except Exception:
            u.SetProcessDPIAware()
        WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
        u.DefWindowProcW.restype = ctypes.c_ssize_t
        u.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
        self._proc = WNDPROC(lambda h, m, wp, lp: u.DefWindowProcW(h, m, wp, lp))

        class WNDCLASS(ctypes.Structure):
            _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", wt.HINSTANCE), ("hIcon", wt.HICON),
                        ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH), ("lpszMenuName", wt.LPCWSTR),
                        ("lpszClassName", wt.LPCWSTR)]
        inst = k.GetModuleHandleW(None)
        wc = WNDCLASS(0, self._proc, 0, 0, inst, None, None, None, None, "TerministSplash")
        u.RegisterClassW(ctypes.byref(wc))
        sw, sh = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
        self.w, self.h = w, h
        self.x, self.y = (sw - w) // 2, (sh - h) // 2
        ex = 0x00080000 | 0x00000008 | 0x00000080 | 0x08000000   # LAYERED | TOPMOST | TOOLWINDOW | NOACTIVATE
        self.hwnd = u.CreateWindowExW(ex, "TerministSplash", "Terminist", 0x80000000,   # WS_POPUP
                                      self.x, self.y, w, h, None, None, inst, None)
        # 一张 32 位自上而下的 DIB：每帧把画面字节拷进去，再整张贴到窗口
        self.screen_dc = u.GetDC(None)
        self.mem_dc = g.CreateCompatibleDC(self.screen_dc)
        bmi = (ctypes.c_byte * 44)()
        ctypes.memmove(bmi, (ctypes.c_int * 3)(40, w, -h), 12)
        ctypes.memmove(ctypes.byref(bmi, 12), (ctypes.c_short * 2)(1, 32), 4)
        self.bits = ctypes.c_void_p()
        self.bmp = g.CreateDIBSection(self.mem_dc, bmi, 0, ctypes.byref(self.bits), None, 0)
        g.SelectObject(self.mem_dc, self.bmp)
        u.ShowWindow(self.hwnd, 4)                    # SW_SHOWNOACTIVATE

    def show(self, surf, alpha=255):
        """surf：带 alpha 的 pygame Surface（大小和窗口一样）。alpha：整体透明度（淡入淡出）。"""
        ct, wt = self.ct, self.wt
        data = __import__("pygame").image.tobytes(surf.premul_alpha(), "BGRA")
        ct.memmove(self.bits, data, len(data))

        class BLEND(ct.Structure):
            _fields_ = [("op", ct.c_ubyte), ("flags", ct.c_ubyte), ("alpha", ct.c_ubyte), ("fmt", ct.c_ubyte)]
        pos, size, src = wt.POINT(self.x, self.y), wt.SIZE(self.w, self.h), wt.POINT(0, 0)
        self.u.UpdateLayeredWindow(self.hwnd, self.screen_dc, ct.byref(pos), ct.byref(size), self.mem_dc,
                                   ct.byref(src), 0, ct.byref(BLEND(0, 0, max(0, min(255, int(alpha))), 1)), 2)
        msg = wt.MSG()
        while self.u.PeekMessageW(ct.byref(msg), None, 0, 0, 1):     # 别让系统觉得窗口「没响应」
            self.u.TranslateMessage(ct.byref(msg))
            self.u.DispatchMessageW(ct.byref(msg))

    def close(self):
        try:
            self.u.DestroyWindow(self.hwnd)
            self.g.DeleteObject(self.bmp)
            self.g.DeleteDC(self.mem_dc)
            self.u.ReleaseDC(None, self.screen_dc)
        except Exception:
            pass


class Splash:
    """只管画（不碰窗口）：给一个时间和进度，画一帧带 alpha 的画面。"""

    def __init__(self, scale: float = 1.0):
        import pygame
        self.pg = pygame
        s = self.s = lambda v: max(1, int(round(v * scale)))
        self.W, self.H = s(760), s(520)
        self.surf = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        self.cx, self.cy = self.W // 2, s(200)
        icon = pygame.image.load(str(APP_ROOT / "icon.png"))
        self.icon = pygame.transform.smoothscale(icon, (s(150), s(150)))
        self.glow = self._glow_sprite(s(24))
        self.big_glow = self._glow_sprite(s(160), strength=0.55)
        pygame.font.init()
        self.mono = pygame.font.SysFont("consolas,cascadiamono,couriernew", s(15))
        self.title = pygame.font.SysFont("consolas,cascadiamono,couriernew", s(30), bold=True)
        self.cjk = pygame.font.SysFont("microsoftyahei,simhei,msgothic", s(15))
        self.parts = []
        self.ring_r = s(118)
        self.burst = None
        self.burst_t = None

    def _glow_sprite(self, r, strength=1.0):
        """径向渐变的绿色光点（叠加混合用：粒子、图标光晕都靠它发光）。"""
        pg = self.pg
        sp = pg.Surface((r * 2, r * 2), pg.SRCALPHA)
        for i in range(r, 0, -1):
            k = 1 - i / r
            a = int(255 * strength * (k ** 2.2))
            pg.draw.circle(sp, (*GREEN, a), (r, r), i)
        return sp

    HALO_DOTS = 60                 # 点阵光环的点数
    ORBITS = ((-0.33, 0.55), (0.33, -0.42))     # 两条椭圆轨道：(倾斜角, 角速度)
    COMETS = 3                     # 每条轨道上均匀分布几颗彗星
    TAIL = 22                      # 彗尾取样点数（连续的一条，不碎）

    def _orbit_pos(self, tilt, th, grow=1.0):
        """椭圆轨道上 th 处的位置 + 远近（-1 后 ~ 1 前）。椭圆压扁再倾斜，看起来像斜着看的一圈轨道。"""
        rx, ry = self.s(255) * grow, self.s(62) * grow
        lx, ly = math.cos(th) * rx, math.sin(th) * ry
        c, si = math.cos(tilt), math.sin(tilt)
        return self.cx + lx * c - ly * si, self.cy + lx * si + ly * c, math.sin(th)

    def _draw_orbits(self, t, front: bool, burst: float):
        """front=False 画轨道后半圈（在图标后面），True 画前半圈（压在图标上）：有立体的绕行感。"""
        pg, s, surf = self.pg, self.s, self.surf
        grow, fade = 1 + burst * 2.2, max(0.0, 1 - burst * 1.8)
        if fade <= 0:
            return
        for tilt, speed in self.ORBITS:
            if not front:                                 # 轨道本身：一条很淡的线
                pts = [self._orbit_pos(tilt, i / 90 * math.tau, grow)[:2] for i in range(91)]
                pg.draw.aalines(surf, (*GREEN_DIM, int(150 * fade)), False, pts)
            for k in range(self.COMETS):
                head = t * speed * 2 + k * math.tau / self.COMETS
                hx, hy, depth = self._orbit_pos(tilt, head, grow)
                if (depth > 0) != front:
                    continue
                near = 0.6 + 0.4 * (depth + 1) / 2            # 近的大一点亮一点
                step = 0.03 * (1 if speed > 0 else -1)
                prev = self._orbit_pos(tilt, head - step * self.TAIL, grow)[:2]
                for i in range(self.TAIL - 1, -1, -1):        # 从尾巴往头连成一条渐粗渐亮的线，头最后画在最上面
                    cur = self._orbit_pos(tilt, head - step * i, grow)[:2]
                    k2 = 1 - i / self.TAIL
                    pg.draw.line(surf, (*GREEN, int(220 * k2 ** 1.5 * near * fade)), prev, cur,
                                 max(1, int(s(4) * k2 * near)))
                    prev = cur
                g = pg.transform.smoothscale(self.glow, (int(s(26) * near), int(s(26) * near)))
                g.set_alpha(int(230 * near * fade))
                surf.blit(g, g.get_rect(center=(hx, hy)))
                pg.draw.circle(surf, (170, 255, 200, int(255 * fade)), (int(hx), int(hy)), max(1, int(s(2.6) * near)))

    def _draw_halo(self, t, burst: float):
        """均匀的一圈点阵：三道亮光沿着它追着转；收尾时整圈整齐地往外扩散。"""
        pg, s, surf = self.pg, self.s, self.surf
        r = self.ring_r + s(44) + burst * burst * s(420)
        fade = max(0.0, 1 - burst * 1.6)
        if fade <= 0:
            return
        n = self.HALO_DOTS
        for i in range(n):
            a = i / n * math.tau - t * 0.25
            wave = max(0.0, math.cos((i / n * 3 - t * 0.9) * math.tau)) ** 6     # 三道追光
            x, y = self.cx + math.cos(a) * r, self.cy + math.sin(a) * r
            pg.draw.circle(surf, (*GREEN, int((70 + 185 * wave) * fade)), (int(x), int(y)),
                           max(1, int(s(1.4) + s(1.6) * wave)))
            if wave > 0.45:
                g = pg.transform.smoothscale(self.glow, (s(16), s(16)))
                g.set_alpha(int(170 * wave * fade))
                surf.blit(g, g.get_rect(center=(x, y)))

    def _shadow_text(self, font, text, color, center=None, topleft=None):
        """带深色描边的字：桌面是亮色也看得清（透明底，没有背景板）。"""
        pg, surf = self.pg, self.surf
        fg = font.render(text, True, color)
        sh = font.render(text, True, (0, 0, 0))
        sh.set_alpha(170)
        r = fg.get_rect(center=center) if center else fg.get_rect(topleft=topleft)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1)):
            surf.blit(sh, r.move(dx * self.s(1), dy * self.s(1)))
        surf.blit(fg, r)
        return r

    def frame(self, t: float, dt: float, prog: float, label: str, fade: float = 1.0):
        pg, s, surf = self.pg, self.s, self.surf
        surf.fill((0, 0, 0, 0))
        cx, cy = self.cx, self.cy
        if self.burst and self.burst_t is None:
            self.burst_t = t
        burst = 0.0 if self.burst_t is None else min(1.0, (t - self.burst_t) / 0.6)
        # 图标后面的呼吸光晕（淡）
        breathe = 0.85 + 0.15 * math.sin(t * 2.4)
        bg = pg.transform.smoothscale(self.big_glow, (int(s(260) * breathe), int(s(260) * breathe)))
        bg.set_alpha(120)
        surf.blit(bg, bg.get_rect(center=(cx, cy)))
        # 两圈刻度环：一正一反地转
        for rr, speed, ticks, width, col in ((self.ring_r, 0.6, 72, 2, GREEN), (self.ring_r + s(14), -0.35, 24, 3, GREEN_DIM)):
            base = t * speed
            for i in range(ticks):
                a = base + i / ticks * math.tau
                long = i % 6 == 0
                r1 = rr - (s(9) if long else s(4))
                c = col if (i % 3) or long else GREEN_DIM
                pg.draw.line(surf, (*c, 230 if long else 150),
                             (cx + math.cos(a) * r1, cy + math.sin(a) * r1),
                             (cx + math.cos(a) * rr, cy + math.sin(a) * rr), width if long else 1)
        for k in range(3):                          # 三段转动的弧（扫描感）
            a0 = -t * 1.3 + k * math.tau / 3
            rect = pg.Rect(0, 0, (self.ring_r + s(26)) * 2, (self.ring_r + s(26)) * 2)
            rect.center = (cx, cy)
            pg.draw.arc(surf, (*GREEN, 220), rect, a0, a0 + 0.7, s(3))
        self._draw_halo(t, burst)
        self._draw_orbits(t, False, burst)
        # 图标
        sz = int(self.icon.get_width() * (0.97 + 0.03 * math.sin(t * 2.4)))
        ic = pg.transform.smoothscale(self.icon, (sz, sz))
        surf.blit(ic, ic.get_rect(center=(cx, cy)))
        self._draw_orbits(t, True, burst)
        # 标题
        self._shadow_text(self.title, "  ".join("TERMINIST"), (225, 255, 238), center=(cx, s(352)))
        # 一节一节的加载条
        n = SEGMENTS
        seg_w, gap, seg_h = s(16), s(5), s(12)
        total_w = n * seg_w + (n - 1) * gap
        x0, y0 = cx - total_w // 2, s(392)
        lit = prog * n
        sweep = (t * 1.4) % 1.6 - 0.3                 # 扫光走到哪儿（0~1 是在条上）
        for i in range(n):
            x = x0 + i * (seg_w + gap)
            poly = [(x + s(4), y0), (x + seg_w + s(4), y0), (x + seg_w, y0 + seg_h), (x, y0 + seg_h)]   # 平行四边形
            if i < int(lit):
                shine = max(0.0, 1 - abs(i / n - sweep) * 8)
                col = tuple(min(255, int(c + (255 - c) * shine * 0.75)) for c in GREEN)
                pg.draw.polygon(surf, (0, 0, 0, 120), [(px + s(1), py + s(1)) for px, py in poly])   # 一点投影：亮色桌面上也立得住
                pg.draw.polygon(surf, (*col, 255), poly)
                pg.draw.line(surf, (235, 255, 242, 255), poly[0], poly[1], 1)       # 顶边高光
            elif i == int(lit):                          # 正在加载的那一段：闪
                a = int(110 + 130 * (0.5 + 0.5 * math.sin(t * 12)))
                pg.draw.polygon(surf, (*GREEN, a), poly)
            else:
                pg.draw.polygon(surf, (10, 40, 24, 120), poly)
                pg.draw.polygon(surf, (*GREEN_DIM, 220), poly, 1)
        # 角括号
        L = s(10)
        for (bx, by, dx, dy) in ((x0 - s(14), y0 - s(8), 1, 1), (x0 + total_w + s(14), y0 - s(8), -1, 1),
                                 (x0 - s(14), y0 + seg_h + s(8), 1, -1), (x0 + total_w + s(14), y0 + seg_h + s(8), -1, -1)):
            pg.draw.line(surf, (*GREEN, 230), (bx, by), (bx + L * dx, by), s(2))
            pg.draw.line(surf, (*GREEN, 230), (bx, by), (bx, by + L * dy), s(2))
        # 百分比 + 在干什么
        pr = self.mono.render(f"{int(prog * 100):3d}%", True, GREEN)
        self._shadow_text(self.mono, f"{int(prog * 100):3d}%", GREEN,
                          topleft=(x0 + total_w - pr.get_width(), y0 + seg_h + s(16)))
        dots = "." * (int(t * 3) % 4)
        self._shadow_text(self.cjk, f"> {label}{dots}", (190, 245, 210), topleft=(x0, y0 + seg_h + s(14)))
        # 一闪一闪的十六进制「数据流」小字
        rnd = random.Random(int(t * 8))
        hexline = " ".join(f"{rnd.randrange(16 ** 4):04X}" for _ in range(8))
        self._shadow_text(self.mono, hexline, (60, 170, 110), center=(cx, y0 + seg_h + s(52)))
        return surf

    def explode(self):
        """加载完：光环整圈往外扩散、轨道撑大淡出（在 frame 里按时间算）。"""
        self.burst = True


def read_progress(path: Path) -> tuple[float, str]:
    try:
        v, _, label = path.read_text(encoding="utf-8").partition("|")
        return float(v), label.strip()
    except (OSError, ValueError):
        return 0.0, ""


def run(progress_file: str, parent: int, demo: bool = False):
    if sys.platform != "win32":
        return
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")   # 不要 SDL 自己的窗口：画面贴到分层窗口上
    import ctypes
    import pygame
    pygame.init()
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    try:
        dpi = ctypes.windll.user32.GetDpiForSystem() / 96
    except Exception:
        dpi = 1.0
    sp = Splash(scale=max(1.0, dpi))
    win = LayeredWindow(sp.W, sp.H)
    path = Path(progress_file) if progress_file else None
    t0 = last = time.time()
    shown, done_at, label = 0.0, None, "正在启动"
    clock = pygame.time.Clock()
    try:
        while True:
            now = time.time()
            t, dt = now - t0, min(0.05, now - last)
            last = now
            if demo:
                target = min(1.0, t / 5.0)
                label = ("正在加载界面", "正在建窗口", "正在启动 Agent 进程", "正在读记忆", "就绪")[min(4, int(target * 5))]
            else:
                target, lab = read_progress(path) if path else (0.0, "")
                label = lab or label
            if not demo and (not _alive(parent) or t > TIMEOUT):
                target = 1.0
            shown += (target - shown) * min(1.0, dt * 6)            # 平滑追上真实进度
            if target >= 1.0 and shown > 0.985 and t >= MIN_SHOW and done_at is None:
                shown, done_at = 1.0, now
                sp.explode()
            fade_in = min(1.0, t / 0.35)
            fade_out = 1.0 if done_at is None else max(0.0, 1 - (now - done_at) / 0.55)
            if done_at is not None and fade_out <= 0:
                break
            win.show(sp.frame(t, dt, min(1.0, shown), label), 255 * fade_in * fade_out)
            clock.tick(60)
    finally:
        win.close()
        if path:
            try:
                path.unlink()
            except OSError:
                pass


if __name__ == "__main__":
    if "--demo" in sys.argv:
        run("", 0, demo=True)
    elif len(sys.argv) >= 3:
        run(sys.argv[1], int(sys.argv[2]))
