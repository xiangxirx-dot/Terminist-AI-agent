"""
Surface（渲染层）- pygame 图形界面
------------------------------------
负责显示，并把用户的指令交给 A库；B库 改造 Terminist 的过程也显示在右栏工作流里。
用法:  python run.py [要编辑的文件夹]    (不传则启动后点 "打开文件夹" 选择)
命令:  /clear 清空聊天栏显示（/clear memory 才清记忆）   /versions 查看版本存档   /rollback 回滚最近一次改造
       /stop 立刻停掉正在跑的工作流（也可以点顶栏「停止」或输入框右边的按钮）
       /set 查看界面设置   /set 名字 值 改界面设置（设置都登记在 UI_SETTINGS 注册表里）
       /penalty 查看扣分   /resetpenalty 扣分和奖励分清零（别名 /重置奖惩、/penaltyreset）
热刷新: B库 每做完一个改了界面的子任务，这个文件会被重新加载，正在运行的窗口直接换成新代码（状态保留）。
        新增的界面状态写在 App.hot_state() 里。

布局:
  左栏  文件夹结构，高亮 Agent 当前正在看/改的位置（R=读过 M=改过 +=新建）
  中间  对话（只显示你的需求和 Terminist 的结论）
  右栏  上：工作流，实时显示思考、工具调用和工作组交接；点中间某一轮的对话可查看那一轮
        下：写入面板，Agent 写文件时实时显示内容；点左栏文件可预览

操作:
  Enter 发送 / Shift+Enter 换行 / Ctrl+V 粘贴 / 滚轮滚动（按鼠标所在区域）
  点击右栏里的 "工具结果" / "思考过程" 卡片可展开、折叠
  确认弹窗: Y 允许 / N 拒绝 / A 全部允许
  F11 切换全屏；顶栏 "设置" 里可选显示模式和界面缩放（保存在 terminist_settings.json）
"""

import functools
import json
import io
import math
import os
import queue
import re
import sys
import threading
import time
from pathlib import Path

if sys.platform == "win32":
    # 声明 DPI 感知，否则 Windows 缩放（如 200%）时会把窗口按位图拉伸，全屏分辨率也会被算错
    os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")
# SDL 默认把系统输入法的候选字窗口藏起来（只给程序发拼写中的文字），中文输入法就看不到候选字了；打开它
os.environ.setdefault("SDL_IME_SHOW_UI", "1")
os.environ.setdefault("SDL_IME_SUPPORT_EXTENDED_TEXT", "1")      # 拼写内容超过 32 个字也能完整收到

import pygame

import lib_a as da
import lib_b
from lib_a.sidechat import SideChat
from surface.agent_proc import AgentProxy
from lib_a import web_guard
from surface import (help_text, restart_tool_schema, choose_schema, notify_schema, rollback_to,
                     request_takeover_schema, end_takeover_schema,
                     run_self_test, request_self_test, self_test_flag_path,
                     MEMORY_ROOT_ENV, desktop_folder, open_folder_result, open_folder_schema,
                     api_key_text, check_api_key, save_api_key, clear_api_key)
from surface import project      # 投影主窗口：屏幕上的常驻投影壳（真窗口在屏幕外送帧/收转发输入）
from surface import panels        # 面板数据模型（停靠编排状态，阶段二拖拽嵌入用）
from surface import modules_api   # 外接模块：modules/ 文件夹里的模块启动时自动读进来
from lib_a.staff import (front_persona, load_staff, active_persona, active_staff,
                         add_staff, set_active, set_staff_persona, canon, avatar_path,
                         avatar_color, avatar_initial, STAFF_FILE, BUILTIN as STAFF_BUILTIN)
import base
from base import web as webpage
from lib_a import voice_input

# 以下尺寸是 100% 缩放下的数值，启动时按界面缩放比例换算（见 apply_scale）
BASE_SIZES = {"WIN_W": 1440, "WIN_H": 860, "TOP_H": 48, "INPUT_H": 120, "LEFT_W": 270,
              "RIGHT_W": 430, "PAD": 12, "FONT_SIZE": 17, "CODE_SIZE": 15}
WIN_W = WIN_H = TOP_H = INPUT_H = LEFT_W = RIGHT_W = PAD = FONT_SIZE = CODE_SIZE = 0
SCALE = 1.0
COLLAPSED_LINES = 4
SCREEN_QMAX = 20            # 小屏幕上标点/滚动攒着的待办最多这么多条
SCREEN_MARK_R = 9           # 小屏幕标点红圈的半径（100% 缩放像素，画圈和判定误触共用这一个值）
SCREEN_HIT_SLOP = 4         # 判红圈时额外放宽的像素，手抖几个像素不至于白点
SCREEN_WIN_SIZE = (480, 560)     # 独立小屏幕窗口的初始大小（100% 缩放像素）
SCREEN_ESC_GAP = 600             # 关独立小屏幕要连按两次 Esc，两次间隔不超过这么多毫秒
SCREEN_HOT_STRIP = 30            # 旧版顶部拖动条高度（保留常量兼容，命中判定已改用标题条 SCREEN_TITLE_H）
SCREEN_RESIZE = 24               # 右下角缩放手柄的边长（逻辑像素）
SCREEN_MIN_W = 320               # 独立窗口最小宽度
SCREEN_MIN_H = 240               # 独立窗口最小高度
SCREEN_FRAME = 6                 # 独立窗口最外圈自绘边框的留白（逻辑像素，圆角面板画在这圈里面）
SCREEN_TITLE_H = 30              # 自绘标题条高度（逻辑像素，写标题 + 置顶/关闭两颗自绘按钮）
SCREEN_RADIUS = 12               # 自绘圆角面板的圆角半径（逻辑像素）
SCREEN_ONLINE = {"open_url", "search", "click", "type_into", "scroll", "back"}   # base.web 里会让页面变化的函数名
STAFF_WIN_SIZE = (300, 520)      # 独立员工栏窗口的初始大小（100% 缩放像素）
STAFF_WIN_MIN_W = 220            # 独立员工栏窗口最小宽度
STAFF_WIN_TITLE_H = 28           # 独立员工栏窗口自绘标题条高度（标题 + 收起按钮）
STAFF_WIN_RADIUS = 10            # 独立员工栏窗口自绘圆角面板的圆角半径
STAFF_DRAG_SLOP = 8              # 拖出员工栏的判定距离（小于这个算点击、不算拖）
SCALE_OPTIONS = [1.0, 1.25, 1.5, 1.75, 2.0, 2.5]
SETTINGS_FILE = da.APP_ROOT / "terminist_settings.json"
DEFAULT_SETTINGS = {"fullscreen": False, "scale": "auto", "window_size": None,
                    "agent_process": True,  # Agent 在独立进程里跑（界面不和它抢 GIL，不掉帧）；关掉退回同一个进程
                    "window_pos": None,     # 上次窗口位置 [x, y]（非全屏时记，启动时恢复）
                    "b_assistants": 2,      # B库 改造时带几个助手（1~5）
                    "auto_restart": True,   # B库 交工后自动重启到新版本
                    "perf_mode": "normal",    # 性能模式：save 省token / normal 正常 / balanced 高均衡 / ultra Ultra*
                    "theme": "light",       # 会话主题：light/dark/green/sepia
                    "language": "zh",       # 界面语言：zh / en（只影响显示文字）
                    "front_desk": False,   # 前台肥鱼在不在岗（重启后保持上次的状态）
    "top_hidden": [],       # 顶栏里被隐藏的按钮（内部名，见 TOP_BUTTONS）
    "hud": True,            # 闲聊时也在输入框上方显示干活那一轮的工作流现场
    "screen_window": "on",  # 小屏幕：on 自动开独立窗口 / off 不独立 / noauto 只显示不自动开
    "anim": True,           # 界面动画（关了就和改造之前一样，不加位移不淡化）
    "anim_speed": 1.0,      # 动画速度倍数（0.25~4，越大越快）
    "candy_btn": True,      # 右下角的糖果按钮（关了就不画也不响应点击）
    "projection_shell": True}   # 投影主窗口：屏幕上是投影壳，真窗口在屏幕外（见 surface/project.py）

# 已经不用的旧设置键：读设置时清掉（员工栏 / 画板 / 两侧栏显隐现在都归模块管理）
STALE_SETTINGS = ("staff_panel", "board", "auto_hide_panels", "anim_frames", "flow_expanded",
                  "screen_window", "b_assistants")


def apply_scale(s: float):
    global SCALE
    SCALE = s
    for k, v in BASE_SIZES.items():
        globals()[k] = round(v * s)


def S(x: float) -> int:
    """把 100% 缩放下的像素值换算成当前缩放。"""
    return max(1, round(x * SCALE))


apply_scale(1.0)


class PanelWindow:
    """区块投影窗口：独立窗口只做渲染投影，滚动 / 点击仍转回主窗口那一套状态。

    注意：pygame 的 Window.get_surface() 是 SDL 窗口表面，blit 完必须调 flip()
    （内部是 SDL_UpdateWindowSurface）才会真的上屏；主循环里的 pygame.display.flip()
    只刷主窗口，刷不到这个窗口——不调 flip() 窗口里就是一片空白。
    """

    def __init__(self, title: str, size, pos=None, topmost=True):
        self.win = pygame.Window(title, (max(1, int(size[0])), max(1, int(size[1]))))
        self.dead = False
        for act in (lambda: setattr(self.win, "resizable", True),
                    lambda: setattr(self.win, "borderless", True)):
            try:
                act()
            except Exception:
                pass
        if pos is not None:
            self.set_position(pos)
        if topmost:
            try:
                self.win.always_on_top = True
            except Exception:
                pass

    def size(self):
        """窗口现在的宽高。"""
        try:
            w, h = self.win.size
            return (int(w), int(h))
        except Exception:
            return (0, 0)

    def position(self):
        """窗口在桌面上的位置。"""
        try:
            x, y = self.win.position
            return (int(x), int(y))
        except Exception:
            return (0, 0)

    def set_position(self, pos) -> bool:
        try:
            self.win.position = (int(pos[0]), int(pos[1]))
            return True
        except Exception:
            return False

    def id(self):
        """窗口 id（认事件用）。"""
        try:
            return self.win.id
        except Exception:
            return None

    def hwnd(self) -> int:
        """win32 句柄（拿不到返回 0）。"""
        try:
            return int(getattr(self.win, "handle", 0) or 0)
        except Exception:
            return 0

    def surface(self):
        """SDL 窗口表面（blit 完要调 flip()）。"""
        try:
            return self.win.get_surface()
        except Exception:
            return None

    def blit(self, img, pos=(0, 0)) -> bool:
        """往窗口表面上贴一张图（还没上屏，要再 flip）。"""
        surf = self.surface()
        if surf is None:
            return False
        surf.blit(img, pos)
        return True

    def flip(self) -> bool:
        """把窗口表面推上屏：不调这个窗口里永远是空白。"""
        try:
            self.win.flip()
            return True
        except Exception:
            return False

    def destroy(self):
        if self.dead:
            return
        self.dead = True
        try:
            self.win.destroy()
        except Exception:
            pass


def _ease_out(t: float) -> float:
    """缓出曲线（1-(1-t)^3）：开头快、结尾慢，用来让动画看起来不硬。"""
    t = 0.0 if t < 0 else (1.0 if t > 1 else t)
    return 1.0 - (1.0 - t) ** 3


class _Tween:
    """帧驱动的缓动值：每帧 tick() 推进一步，走完自动停在 target。不做按时间算的动画。"""

    def __init__(self, value: float = 0.0, frames: int = 20):
        self.at = value; self.value = value; self.start = value; self.target = value
        self.frames = max(1, int(frames)); self.last = -1

    def to(self, target: float, frames: int | None = None) -> "_Tween":
        if frames:
            self.frames = max(1, int(frames))
        self.start = self.value; self.target = float(target); self.last = -1
        return self

    def tick(self) -> float:
        """推进一帧；返回推进后的值。已经到目标就原地不动。"""
        if self.last < 0:
            self.last = self.value
        if self.value == self.target:
            self._done(); return self.value
        step = (self.target - self.start) / self.frames
        v = self.value + step
        if (step > 0 and v >= self.target) or (step < 0 and v <= self.target) or abs(v - self.target) < 1e-4:
            v = self.target
        self.last = self.value; self.value = v
        if v == self.target:
            self._done()
        return self.value

    def smoothed(self) -> float:
        """按 start->target 的进度缓动取值，不推进状态（查表式动画每帧直接调用，没副作用）。"""
        span = self.target - self.start
        if not span:
            return self.target
        return self.start + span * _ease_out((self.value - self.start) / span)

    def busy(self) -> bool:
        """还在走（没到目标值）就返回 True。"""
        return self.value != self.target

    @property

    def a_differs(self) -> bool:
        """这一帧的值和上一帧不一样（用来判断要不要重绘）。"""
        return abs(self.value - self.last) > 1e-4

    def _done(self):
        self.last = self.value

C = {
    "bg": (255, 255, 255),          # 会话主区域纯白
    "panel": (250, 250, 250),       # 侧栏浅灰
    "panel_hdr": (244, 244, 244),
    "border": (229, 229, 229),      # 分割线/边框浅灰 #E5E5E5
    "top": (247, 247, 247),
    "input_bg": (255, 255, 255),
    "input_border": (204, 204, 204),
    "input_focus": (30, 100, 220),
    "text": (31, 31, 31),           # 正文深色 #1F1F1F
    "dim": (153, 153, 153),         # 次要文字/占位符中灰 #999999
    "btn": (235, 235, 235),
    "btn_on": (46, 125, 80),
    "btn_danger": (200, 70, 70),
    "scroll": (180, 180, 180),
    "overlay": (0, 0, 0, 120),
    "modal": (255, 255, 255),
    "add": (40, 150, 80),
    "del": (205, 70, 70),
    "hdr": (30, 100, 220),
    "dir": (30, 90, 180),
    "warn": (200, 130, 20),
    "lineno": (150, 150, 150),
    "on_text": (255, 255, 255),     # 彩色按钮/选中项上的白字
}

# 每种消息的样式: (标签, 标签颜色, 卡片背景, 文字颜色, 是否可折叠)
STYLE = {
    "user":      ("你",        (40, 150, 80), (247, 247, 247), (31, 31, 31), False),
    "assistant": ("肥鱼", (30, 100, 220), (255, 255, 255), (31, 31, 31), False),
    "workflow":  ("工作流",     (120, 80, 180), (250, 250, 252), (70, 60, 90), True),
    "reasoning": ("思考过程",   (130, 130, 135), (245, 245, 245), (90, 90, 95), True),
    "tool":      ("工具调用",   (140, 70, 200), (250, 245, 255), (120, 70, 160), False),
    "result":    ("工具结果",   (130, 130, 135), (245, 245, 245), (90, 90, 95), True),
    "info":      ("提示",      (190, 135, 20), (255, 250, 235), (140, 100, 20), False),
    "escalate":  ("工作组交接", (215, 120, 30), (255, 244, 230), (150, 80, 20), False),
    "memory":    ("记忆",       (20, 140, 150), (240, 250, 250), (20, 110, 120), False),
    "b_stage":     ("B库",          (30, 140, 90), (240, 250, 245), (30, 110, 80), False),
    "b_reasoning": ("B库 · 思考",   (60, 130, 90), (243, 248, 244), (75, 100, 80), True),
    "b_assistant": ("B库 · 说明",   (30, 140, 90), (245, 250, 247), (31, 31, 31), True),
    "b_tool":      ("B库 · 工具调用", (30, 140, 90), (243, 248, 244), (30, 100, 70), False),
    "b_result":    ("B库 · 工具结果", (60, 130, 90), (240, 245, 241), (75, 100, 80), True),
    "worker":    ("执行成员",   (180, 110, 20), (255, 249, 238), (110, 80, 30), False),
    "error":     ("错误",      (205, 70, 70), (255, 240, 240), (180, 60, 60), False),
    "choice":    ("选一个", (30, 100, 220), (240, 245, 255), (31, 31, 31), False),
}
_BASE_STYLE = dict(STYLE)          # 默认配色：主题里缺的消息类型从这里补

# Agent 动作 -> (显示名, 文件树高亮颜色)
ACTIONS = {
    "list_dir":    ("浏览", (230, 238, 250)),
    "read_file":   ("读取", (230, 238, 250)),
    "file_stats":  ("查看信息", (230, 238, 250)),
    "search":      ("搜索", (230, 238, 250)),
    "write_file":  ("写入", (255, 242, 220)),
    "edit_file":   ("修改", (255, 242, 220)),
    "delete_file": ("删除", (255, 235, 235)),
    "move_file":   ("移动", (255, 242, 220)),
    "run_command": ("执行命令", (240, 235, 250)),
    "escalate":    ("上交", (255, 242, 220)),
    "request_upgrade": ("改造自身", (235, 248, 240)),
    "dispatch":    ("派工", (255, 242, 220)),
}
WRITE_TOOLS = ("write_file", "edit_file")
MARKS = {"read": ("R", C["hdr"]), "modified": ("M", C["warn"]), "new": ("+", C["add"])}

# 4 套完整配色主题，每套自包含 C / STYLE / ACTIONS / DIFF 四块。
# STYLE 值：(标签, 标签色, 卡片底色, 正文字色, 是否可折叠)；各主题折叠行为一致。
THEMES = {
    "light": {
        "C": {
            "bg": (255, 255, 255), "panel": (250, 250, 250), "panel_hdr": (244, 244, 244),
            "border": (229, 229, 229), "top": (247, 247, 247), "input_bg": (255, 255, 255),
            "input_border": (204, 204, 204), "input_focus": (30, 100, 220), "text": (31, 31, 31),
            "dim": (153, 153, 153), "btn": (235, 235, 235), "btn_on": (46, 125, 80),
            "btn_danger": (200, 70, 70), "scroll": (180, 180, 180), "overlay": (0, 0, 0, 120),
            "modal": (255, 255, 255), "add": (40, 150, 80), "del": (205, 70, 70),
            "hdr": (30, 100, 220), "dir": (30, 90, 180), "warn": (200, 130, 20),
            "lineno": (150, 150, 150), "on_text": (255, 255, 255),
        },
        "STYLE": {
            "user":      ("你",        (40, 150, 80), (247, 247, 247), (31, 31, 31), False),
            "assistant": ("肥鱼", (30, 100, 220), (255, 255, 255), (31, 31, 31), False),
            "workflow":  ("工作流",     (120, 80, 180), (250, 250, 252), (70, 60, 90), True),
            "reasoning": ("思考过程",   (130, 130, 135), (245, 245, 245), (90, 90, 95), True),
            "tool":      ("工具调用",   (140, 70, 200), (250, 245, 255), (120, 70, 160), False),
            "result":    ("工具结果",   (130, 130, 135), (245, 245, 245), (90, 90, 95), True),
            "info":      ("提示",      (190, 135, 20), (255, 250, 235), (140, 100, 20), False),
            "escalate":  ("工作组交接", (215, 120, 30), (255, 244, 230), (150, 80, 20), False),
            "memory":    ("记忆",       (20, 140, 150), (240, 250, 250), (20, 110, 120), False),
            "b_stage":     ("B库",          (30, 140, 90), (240, 250, 245), (30, 110, 80), False),
            "b_reasoning": ("B库 · 思考",   (60, 130, 90), (243, 248, 244), (75, 100, 80), True),
            "b_assistant": ("B库 · 说明",   (30, 140, 90), (245, 250, 247), (31, 31, 31), True),
            "b_tool":      ("B库 · 工具调用", (30, 140, 90), (243, 248, 244), (30, 100, 70), False),
            "b_result":    ("B库 · 工具结果", (60, 130, 90), (240, 245, 241), (75, 100, 80), True),
            "worker":    ("执行成员",   (180, 110, 20), (255, 249, 238), (110, 80, 30), False),
            "error":     ("错误",      (205, 70, 70), (255, 240, 240), (180, 60, 60), False),
        },
        "ACTIONS": {
            "list_dir":    ("浏览", (230, 238, 250)),
            "read_file":   ("读取", (230, 238, 250)),
            "file_stats":  ("查看信息", (230, 238, 250)),
            "search":      ("搜索", (230, 238, 250)),
            "write_file":  ("写入", (255, 242, 220)),
            "edit_file":   ("修改", (255, 242, 220)),
            "delete_file": ("删除", (255, 235, 235)),
            "move_file":   ("移动", (255, 242, 220)),
            "run_command": ("执行命令", (240, 235, 250)),
            "escalate":    ("上交", (255, 242, 220)),
            "request_upgrade": ("改造自身", (235, 248, 240)),
            "dispatch":    ("派工", (255, 242, 220)),
        },
        "DIFF": {"old_bg": (255, 235, 235), "old_fg": (180, 60, 60),
                 "new_bg": (235, 250, 235), "new_fg": (30, 130, 70)},
    },
    "dark": {
        "C": {
            "bg": (30, 30, 30), "panel": (37, 37, 38), "panel_hdr": (40, 40, 40),
            "border": (60, 60, 60), "top": (45, 45, 48), "input_bg": (42, 42, 42),
            "input_border": (70, 70, 70), "input_focus": (76, 139, 255), "text": (230, 230, 230),
            "dim": (154, 154, 154), "btn": (58, 58, 60), "btn_on": (40, 120, 75),
            "btn_danger": (185, 65, 65), "scroll": (90, 90, 90), "overlay": (0, 0, 0, 160),
            "modal": (42, 42, 44), "add": (80, 180, 110), "del": (235, 95, 95),
            "hdr": (100, 160, 255), "dir": (110, 150, 220), "warn": (230, 160, 60),
            "lineno": (110, 110, 110), "on_text": (255, 255, 255),
        },
        "STYLE": {
            "user":      ("你",        (100, 210, 140), (45, 45, 47), (230, 230, 230), False),
            "assistant": ("肥鱼", (100, 160, 255), (37, 37, 39), (230, 230, 230), False),
            "workflow":  ("工作流",     (175, 135, 235), (45, 42, 55), (210, 195, 235), True),
            "reasoning": ("思考过程",   (175, 175, 180), (50, 50, 52), (205, 205, 210), True),
            "tool":      ("工具调用",   (185, 135, 235), (52, 44, 60), (222, 185, 242), False),
            "result":    ("工具结果",   (175, 175, 180), (50, 50, 52), (205, 205, 210), True),
            "info":      ("提示",      (238, 185, 85), (55, 48, 35), (232, 202, 150), False),
            "escalate":  ("工作组交接", (242, 165, 85), (58, 45, 32), (236, 195, 145), False),
            "memory":    ("记忆",       (95, 205, 215), (38, 52, 54), (185, 228, 232), False),
            "b_stage":     ("B库",          (105, 215, 145), (40, 48, 42), (205, 238, 215), False),
            "b_reasoning": ("B库 · 思考",   (125, 205, 155), (40, 48, 42), (190, 220, 196), True),
            "b_assistant": ("B库 · 说明",   (105, 215, 145), (40, 48, 42), (230, 230, 230), True),
            "b_tool":      ("B库 · 工具调用", (105, 215, 145), (40, 48, 42), (190, 220, 196), False),
            "b_result":    ("B库 · 工具结果", (125, 205, 155), (40, 48, 42), (190, 220, 196), True),
            "worker":    ("执行成员",   (232, 175, 85), (55, 47, 36), (232, 208, 165), False),
            "error":     ("错误",      (242, 115, 115), (58, 38, 38), (242, 185, 185), False),
        },
        "ACTIONS": {
            "list_dir":    ("浏览", (52, 58, 78)),
            "read_file":   ("读取", (52, 58, 78)),
            "file_stats":  ("查看信息", (52, 58, 78)),
            "search":      ("搜索", (52, 58, 78)),
            "write_file":  ("写入", (72, 62, 42)),
            "edit_file":   ("修改", (72, 62, 42)),
            "delete_file": ("删除", (72, 42, 42)),
            "move_file":   ("移动", (72, 62, 42)),
            "run_command": ("执行命令", (62, 54, 74)),
            "escalate":    ("上交", (72, 62, 42)),
            "request_upgrade": ("改造自身", (46, 66, 52)),
            "dispatch":    ("派工", (72, 62, 42)),
        },
        "DIFF": {"old_bg": (62, 32, 32), "old_fg": (255, 120, 120),
                 "new_bg": (32, 52, 34), "new_fg": (120, 220, 150)},
    },
    "green": {
        "C": {
            "bg": (234, 243, 236), "panel": (224, 234, 224), "panel_hdr": (218, 228, 218),
            "border": (205, 218, 208), "top": (227, 237, 227), "input_bg": (245, 250, 246),
            "input_border": (200, 212, 203), "input_focus": (40, 130, 80), "text": (31, 42, 31),
            "dim": (125, 140, 128), "btn": (214, 226, 216), "btn_on": (60, 140, 90),
            "btn_danger": (190, 80, 70), "scroll": (170, 185, 173), "overlay": (0, 0, 0, 120),
            "modal": (248, 251, 248), "add": (50, 150, 90), "del": (200, 80, 70),
            "hdr": (40, 120, 80), "dir": (40, 110, 75), "warn": (190, 130, 40),
            "lineno": (150, 160, 152), "on_text": (255, 255, 255),
        },
        "STYLE": {
            "user":      ("你",        (40, 140, 85), (225, 237, 227), (31, 42, 31), False),
            "assistant": ("肥鱼", (30, 100, 70), (245, 249, 245), (31, 42, 31), False),
            "workflow":  ("工作流",     (110, 80, 165), (238, 235, 248), (70, 55, 95), True),
            "reasoning": ("思考过程",   (110, 120, 115), (232, 240, 233), (70, 80, 72), True),
            "tool":      ("工具调用",   (130, 70, 180), (238, 233, 245), (110, 65, 150), False),
            "result":    ("工具结果",   (110, 120, 115), (232, 240, 233), (70, 80, 72), True),
            "info":      ("提示",      (180, 120, 20), (250, 244, 228), (130, 90, 20), False),
            "escalate":  ("工作组交接", (200, 110, 30), (250, 240, 226), (140, 75, 20), False),
            "memory":    ("记忆",       (20, 130, 140), (232, 245, 245), (20, 105, 115), False),
            "b_stage":     ("B库",          (30, 130, 85), (234, 245, 237), (30, 105, 75), False),
            "b_reasoning": ("B库 · 思考",   (55, 120, 85), (234, 245, 237), (65, 95, 75), True),
            "b_assistant": ("B库 · 说明",   (30, 130, 85), (234, 245, 237), (31, 42, 31), True),
            "b_tool":      ("B库 · 工具调用", (30, 130, 85), (234, 245, 237), (30, 95, 65), False),
            "b_result":    ("B库 · 工具结果", (55, 120, 85), (234, 245, 237), (65, 95, 75), True),
            "worker":    ("执行成员",   (170, 105, 20), (250, 243, 230), (105, 75, 28), False),
            "error":     ("错误",      (195, 65, 60), (250, 232, 232), (170, 55, 55), False),
        },
        "ACTIONS": {
            "list_dir":    ("浏览", (222, 235, 225)),
            "read_file":   ("读取", (222, 235, 225)),
            "file_stats":  ("查看信息", (222, 235, 225)),
            "search":      ("搜索", (222, 235, 225)),
            "write_file":  ("写入", (244, 238, 214)),
            "edit_file":   ("修改", (244, 238, 214)),
            "delete_file": ("删除", (245, 222, 222)),
            "move_file":   ("移动", (244, 238, 214)),
            "run_command": ("执行命令", (236, 234, 244)),
            "escalate":    ("上交", (244, 238, 214)),
            "request_upgrade": ("改造自身", (224, 240, 226)),
            "dispatch":    ("派工", (244, 238, 214)),
        },
        "DIFF": {"old_bg": (248, 225, 225), "old_fg": (170, 60, 60),
                 "new_bg": (225, 246, 228), "new_fg": (30, 130, 70)},
    },
    "sepia": {
        "C": {
            "bg": (245, 239, 224), "panel": (239, 230, 212), "panel_hdr": (233, 224, 205),
            "border": (218, 206, 185), "top": (240, 232, 214), "input_bg": (250, 246, 236),
            "input_border": (210, 198, 178), "input_focus": (150, 100, 40), "text": (58, 48, 37),
            "dim": (140, 128, 110), "btn": (230, 220, 200), "btn_on": (140, 100, 50),
            "btn_danger": (185, 75, 60), "scroll": (190, 178, 158), "overlay": (0, 0, 0, 120),
            "modal": (250, 246, 236), "add": (130, 110, 60), "del": (190, 80, 65),
            "hdr": (150, 100, 40), "dir": (140, 95, 45), "warn": (190, 130, 30),
            "lineno": (160, 148, 128), "on_text": (255, 255, 255),
        },
        "STYLE": {
            "user":      ("你",        (130, 110, 60), (236, 226, 208), (58, 48, 37), False),
            "assistant": ("肥鱼", (150, 100, 40), (250, 245, 234), (58, 48, 37), False),
            "workflow":  ("工作流",     (130, 95, 70), (238, 232, 222), (95, 70, 55), True),
            "reasoning": ("思考过程",   (135, 120, 100), (240, 231, 215), (95, 82, 68), True),
            "tool":      ("工具调用",   (140, 100, 60), (240, 232, 220), (120, 85, 55), False),
            "result":    ("工具结果",   (135, 120, 100), (240, 231, 215), (95, 82, 68), True),
            "info":      ("提示",      (175, 115, 25), (248, 238, 214), (130, 85, 25), False),
            "escalate":  ("工作组交接", (185, 105, 30), (248, 232, 210), (140, 78, 25), False),
            "memory":    ("记忆",       (90, 125, 110), (234, 240, 232), (55, 100, 85), False),
            "b_stage":     ("B库",          (120, 110, 60), (236, 243, 230), (80, 100, 55), False),
            "b_reasoning": ("B库 · 思考",   (115, 115, 70), (236, 243, 230), (80, 90, 60), True),
            "b_assistant": ("B库 · 说明",   (120, 110, 60), (236, 243, 230), (58, 48, 37), True),
            "b_tool":      ("B库 · 工具调用", (120, 110, 60), (236, 243, 230), (70, 95, 55), False),
            "b_result":    ("B库 · 工具结果", (115, 115, 70), (236, 243, 230), (80, 90, 60), True),
            "worker":    ("执行成员",   (170, 110, 30), (248, 236, 210), (105, 72, 30), False),
            "error":     ("错误",      (180, 70, 55), (248, 226, 222), (160, 55, 50), False),
        },
        "ACTIONS": {
            "list_dir":    ("浏览", (236, 226, 208)),
            "read_file":   ("读取", (236, 226, 208)),
            "file_stats":  ("查看信息", (236, 226, 208)),
            "search":      ("搜索", (236, 226, 208)),
            "write_file":  ("写入", (244, 232, 200)),
            "edit_file":   ("修改", (244, 232, 200)),
            "delete_file": ("删除", (244, 218, 212)),
            "move_file":   ("移动", (244, 232, 200)),
            "run_command": ("执行命令", (238, 232, 220)),
            "escalate":    ("上交", (244, 232, 200)),
            "request_upgrade": ("改造自身", (230, 238, 222)),
            "dispatch":    ("派工", (244, 232, 200)),
        },
        "DIFF": {"old_bg": (246, 222, 214), "old_fg": (170, 60, 50),
                 "new_bg": (224, 240, 220), "new_fg": (40, 120, 70)},
    },
}

# 模块级 DIFF，初始即 light；apply_theme 会随主题整体替换
DIFF = dict(THEMES["light"]["DIFF"])

THEME_LABELS = {"light": "白色", "dark": "深色", "green": "护眼绿", "sepia": "暖色"}
THEME_ALIASES = {"light": "light", "白色": "light", "浅色": "light",
                 "dark": "dark", "深色": "dark", "暗色": "dark",
                 "green": "green", "护眼绿": "green", "绿色": "green",
                 "sepia": "sepia", "暖色": "sepia", "羊皮纸": "sepia"}


# ============================================================
# 界面语言：语言只影响显示文字，不动任何设置的值和功能。
# 词表键用小写下划线英文；lang() 取当前语言的文字，缺词回落 default 或 key。
# ============================================================
LANG_ZH = {
    # 顶栏
    "settings": "设置", "fullscreen": "全屏", "clear_chat": "清空对话", "clear_view": "清屏",
    "cleared_view": "聊天栏已清空，记忆和上下文都还在",
    "auto_on": "自动确认: 开", "auto_off": "自动确认: 关", "stop": "停止", "restart": "重启生效",
    "stop_workflow": "停止工作流",
    "send": "发送", "chat": "对话",
    "team_running": "工作组: {n} 个 {m} 执行中  ▼", "team_lead": "工作组: {m} 指挥  ▼",
    "model_line": "模型: {m}  ▼", "no_folder": "未打开文件夹",
    "server_model": "服务端返回模型: {m}", "memory_usage": "记忆 {used} / {limit}",
    "running": "运行中…", "ready": "就绪",
    "score_line": "扣分 A{a} · B{b}  奖励 A+{ra} · B+{r}",
    # 设置弹窗与选项
    "api_key": "API key", "change": "更换", "clear_key": "清空", "clear_key_confirm": "确认清空", "reset_builtin": "恢复内置", "save": "保存",
    "cancel": "取消", "try_saving": "试一下…", "done": "完成",
    "settings_hint1": "F11 可随时切换全屏。",
    "settings_hint2": "缩放会同时调整字体和布局；设置会自动保存。",
    "window": "窗口", "auto_scale": "自动 ({p}%)", "auto_restart_on": "自动重启",
    "auto_restart_off": "手动重启", "on_duty": "在岗", "off_duty": "下班",
    "show": "显示", "hide": "隐藏", "px": "像素", "assistants_n": "{n} 个",
    "theme_light": "白色", "theme_dark": "深色", "theme_green": "护眼绿", "theme_sepia": "暖色",
    "label_fullscreen": "显示模式", "label_scale": "界面缩放", "label_theme": "会话主题",
    "label_auto_restart": "改造后", "label_front_desk": "前台肥鱼",
    "label_projection_shell": "投影主窗口",
    "label_b_assistants": "B库 助手", "label_hud": "工作流现场", "label_staff_panel": "员工栏",
    "label_auto_hide_panels": "按需显示两侧栏",
    "label_anim": "界面动画", "label_anim_speed": "动画速度",
    "label_panel_left_w": "左栏宽度", "label_panel_right_w": "右栏宽度",
    "label_input_height": "输入框高度", "label_language": "界面语言",
    "zh": "中文", "en": "English",
    # 设置面板：分组、滑杆、数值输入、顶栏开关、实时拖动布局
    # 网页要账号密码时的弹窗
    "cred_title": "网页需要账号密码", "cred_user": "账号", "cred_pass": "密码",
    "cred_remember": "记住密码", "cred_give": "提供", "cred_deny": "拒绝",
    "cred_saved": "已保存到本地密钥库",
    "group_look": "外观", "group_layout": "布局", "group_staff": "成员", "group_work": "干活",
    "group_topbar": "顶栏", "group_api": "接口", "group_other": "其他",
    "settings_edit_hint": "直接输入数值后回车", "settings_edit_err": "这个值不行",
    "layout_live": "实时拖动布局",
    "layout_live_hint": "实时调节：拖左栏 / 右栏 / 输入框的分隔线，Esc 或右键结束",
    "topbar_hint": "点按钮显示 / 隐藏顶栏那一项（停止按钮始终保留）",
    "topbar_empty": "顶栏已精简：没有常驻按钮。「清空聊天栏」用 /clear（只清显示），真清记忆用 /clear memory，会先弹确认",
    "nav_model": "模型", "nav_clear": "清空对话", "nav_clearview": "清屏", "nav_auto": "自动确认",
    "nav_settings": "设置", "nav_stop": "停止",
    # 每个 UI 区块自己的设置面板（藏在右栏里，不再是居中弹窗）
    "settings_icon": "设置", "settings_panel": "设置", "back": "‹ 返回",
    "panel_note": "这里的设置都立刻生效、自动保存", "no_settings_here": "这个区块暂时没有可调的设置",
    "go_live_layout": "实时拖动布局",
    "screen_note": "A库 用 screen_look / web_open 时，这里会自动显示它看到的网页",
    "screen_detached_on": "小屏幕已弹出",
    "screen_detached_off": "小屏幕已收起", "screen_esc_hint": "再按一次 Esc 关闭小屏幕",
    "screen_topmost_ok": "已置顶", "screen_topmost_bad": "置顶失败（系统不让）",
    "label_screen_window": "小屏幕窗口", "screen_open_here": "点这里打开小屏幕",
    "staff_detached_on": "员工栏已弹出成独立窗口，拖回主窗口自动归位",
    "staff_detached_off": "员工栏已归位",
    "staff_placeholder": "员工栏在独立窗口里", "staff_placeholder_hint": "把那个窗口拖回主窗口（或点这里）就自动归位",
    "staff_win_close": "收起独立员工栏", "staff_drag_out": "松开就成独立窗口",
    "panel_show": "界面主题", "panel_perf": "性能", "panel_lang": "语言", "panel_privacy": "隐私", "panel_talk": "对话", "panel_team": "团队", "panel_work": "干活",
    "panel_bar": "顶栏", "panel_layout": "布局", "panel_screen": "小屏幕",
    "panel_status": "状态", "panel_input": "输入",
    # 确认弹窗
    "confirm_needed": "需要你的确认", "allow": "允许 (Y)", "deny": "拒绝 (N)",
    "allow_all": "全部允许 (A)", "scroll_more": "滚轮查看更多",
    "confirm_clear_title": "清空对话？", "confirm_clear_body": "会把当前对话和记忆一起清掉，不能撤销",
    "confirm_clear_ok": "清空", "confirm_clear_cancelled": "已取消",
    "confirm_delete": "确认删除", "confirm_delete_enter": "确认删除 (Enter)",
    "confirm_delete_wait": "确认删除（{n} 秒后可点）", "cancel_esc": "取消 (Esc)",
    "items_total": "…共 {n} 项",
    # 左栏
    "staff": "员工", "staff_count": "{n} 个员工 · 在岗 {who}", "no_staff": "暂无员工",
    "small_screen": "小屏幕", "screen_sub": "网页实时画面", "screen_wait": "小屏幕：等待网页",
    "collapse": "收起", "click_original": "点击看原图",
    "tree_title": "文件夹结构", "tree_none": "Agent 还没有访问文件",
    "view": "查看", "preview": "预览", "panel_write": "写入面板", "panel_preview": "文件预览",
    "panel_none": "Agent 写文件时这里会实时显示内容",
    # 右栏
    "workflow": "工作流", "workflow_log": "工作流 · 日志", "workflow_round": "工作流 · 第 {n} 轮",
    "in_progress": " · 进行中",
    "workflow_none": "Agent 工作时，这里会实时显示思考和工具调用",
    "log_btn": "日志", "back_flow": "返回工作流", "open_file": "打开文件", "to_latest": "回到最新",
    "waiting_model": "等待模型响应…",
    "no_logs": "还没有日志：Agent 干活时每一步都会记在这里",
    "log_lines": "{f} · {n} 行（最近的在最下面）",
    # 输入框
    "placeholder": "描述你的需求，Enter 发送，Shift+Enter 换行",
    "placeholder_busy": "正在干活，边干边聊：问进度、说暂停 / 继续、提新要求都行（/pause /resume /plan 也可以）",
    # 语音输入（输入框左边的麦克风按钮 / F2）
    "voice_btn": "麦克风", "voice_recording": "录音中…再点一次结束（F2）", "voice_wait": "识别中…",
    "voice_ok": "语音已转成文字，检查一下再发送", "voice_empty": "没听清，再说一遍",
    "voice_fail": "语音识别失败：",
    "candy_hint": "给你发颗糖",
    "candy_btn": "糖果按钮",
    "projection_shell_on": "开（投影壳，重启不闪）", "projection_shell_off": "关（窗口直接显示在屏幕上）",
    # 员工栏分组 / 批评菜单 / /criticize
    "staff_group_front": "前台", "staff_group_lead": "工作组组长", "staff_group_builder": "改造层",
    "staff_group_worker": "执行成员", "staff_group_other": "其它",
    "staff_menu_criticize": "批评", "staff_menu_cancel": "取消",
    # 员工信息卡
    "staff_card_title": "员工信息", "staff_card_close": "关闭", "staff_card_take": "上岗",
    "staff_card_edit": "编辑", "staff_new": "＋ 新角色",
    "staff_card_on": "已在岗", "staff_card_state_on": "当前上岗", "staff_card_state_off": "未上岗",
    "staff_card_duty": "职责",
    "criticize_usage": "用法：/criticize <员工名> <要说的话>",
    "criticize_need_text": "要批评谁、批评什么，都写上",
    "criticize_ok": "已记下对 {who} 的批评，A库 下一轮会读到",
    "criticize_no_agent": "还没接上 Agent，批评先记在聊天里",
    "criticize_prefill": "接在后面说对 {who} 的批评，回车就记下",
    # /set 与 set_ui
    "ui_settings_header": "界面设置（/set 名字 值）：", "no_such_setting": "没有这个界面设置：{k}",
    "ui_applied": "界面设置：", "opt_sep": "、",
    "resetpenalty_hint": "输入 /resetpenalty（或 /重置奖惩）重置 A库/B库 的惩罚和奖励分",
    # 聊天栏消息时间（鼠标悬浮气泡）
    "time_today": "今天", "time_yesterday": "昨天", "msg_time_tip": "消息时间：{t}",
}
LANG_EN = {
    # 顶栏
    "settings": "Settings", "fullscreen": "Fullscreen", "clear_chat": "Clear chat",
    "clear_view": "Clear view", "cleared_view": "Chat cleared; memory and context kept",
    "auto_on": "Auto-confirm: on", "auto_off": "Auto-confirm: off", "stop": "Stop",
    "stop_workflow": "Stop workflow",
    "restart": "Restart", "send": "Send", "chat": "Chat",
    "team_running": "Team: {n} × {m} working  ▼", "team_lead": "Team: {m} leading  ▼",
    "model_line": "Model: {m}  ▼", "no_folder": "No folder open",
    "server_model": "Server model: {m}", "memory_usage": "Memory {used} / {limit}",
    "running": "Running…", "ready": "Ready",
    "score_line": "Penalty A{a} · B{b}  Reward A+{ra} · B+{r}",
    # 设置弹窗与选项
    "api_key": "API key", "change": "Change", "clear_key": "Clear", "clear_key_confirm": "Confirm clear", "reset_builtin": "Reset to built-in", "save": "Save",
    "cancel": "Cancel", "try_saving": "Testing…", "done": "Done",
    "settings_hint1": "F11 toggles fullscreen at any time.",
    "settings_hint2": "Scaling changes fonts and layout together; settings are saved automatically.",
    "window": "Window", "auto_scale": "Auto ({p}%)", "auto_restart_on": "Auto restart",
    "auto_restart_off": "Manual", "on_duty": "On duty", "off_duty": "Off duty",
    "show": "Show", "hide": "Hide", "px": "px", "assistants_n": "{n} assistants",
    "theme_light": "Light", "theme_dark": "Dark", "theme_green": "Green", "theme_sepia": "Sepia",
    "label_fullscreen": "Display mode", "label_scale": "UI scale", "label_theme": "Theme",
    "label_auto_restart": "After upgrade", "label_front_desk": "Front desk fish",
    "label_projection_shell": "Projection window",
    "label_b_assistants": "B-desk assistants", "label_hud": "Workflow live",
    "label_staff_panel": "Staff panel",
    "label_auto_hide_panels": "Panels on demand",
    "label_anim": "Animation", "label_anim_speed": "Animation speed",
    "label_panel_left_w": "Left panel width", "label_panel_right_w": "Right panel width",
    "label_input_height": "Input height", "label_language": "Language",
    "zh": "Chinese", "en": "English",
    # 设置面板：分组、滑杆、数值输入、顶栏开关、实时拖动布局
    # 网页要账号密码时的弹窗
    "cred_title": "Sign-in required", "cred_user": "Username", "cred_pass": "Password",
    "cred_remember": "Remember password", "cred_give": "Provide", "cred_deny": "Decline",
    "cred_saved": "Saved to local key store",
    "group_look": "Appearance", "group_layout": "Layout", "group_staff": "Staff",
    "group_work": "Work", "group_topbar": "Top bar", "group_api": "API", "group_other": "More",
    "settings_edit_hint": "Type a value and press Enter", "settings_edit_err": "Invalid value",
    "layout_live": "Drag layout live",
    "layout_live_hint": "Live layout: drag the left / right / input dividers, Esc or right click to finish",
    "topbar_hint": "Click to show / hide a top bar button (Stop always stays)",
    "topbar_empty": "The top bar is now empty. Use /clear to clear the chat view; /clear memory really clears memory and asks first",
    "nav_model": "Model", "nav_clear": "Clear chat", "nav_clearview": "Clear view",
    "nav_auto": "Auto-confirm", "nav_settings": "Settings", "nav_stop": "Stop",
    # 每个 UI 区块自己的设置面板（藏在右栏里，不再是居中弹窗）
    "settings_icon": "Settings", "settings_panel": "Settings", "back": "‹ Back",
    "panel_note": "Changes apply instantly and are saved automatically",
    "no_settings_here": "Nothing to tune here yet",
    "go_live_layout": "Drag layout live",
    "screen_note": "When the A desk uses screen_look / web_open, the page it sees shows up here",
    "screen_detached_on": "Live screen popped out",
    "screen_detached_off": "Live screen closed",
    "screen_esc_hint": "Press Esc once more to close the live screen",
    "screen_topmost_ok": "Pinned on top", "screen_topmost_bad": "Pin failed",
    "label_screen_window": "Live screen window", "screen_open_here": "Click here to open the live screen",
    "staff_detached_on": "Staff bar popped out into its own window; drag it back to dock",
    "staff_detached_off": "Staff bar docked back",
    "staff_placeholder": "The staff bar lives in its own window",
    "staff_placeholder_hint": "Drag that window back onto the main window (or click here) to dock it",
    "staff_win_close": "Close the detached staff bar", "staff_drag_out": "Release to pop it out",
    "panel_show": "Appearance", "panel_perf": "Performance", "panel_lang": "Language", "panel_privacy": "Privacy",
    "panel_talk": "Chat", "panel_team": "Team", "panel_work": "Work",
    "panel_bar": "Top bar", "panel_layout": "Layout", "panel_screen": "Live screen",
    "panel_status": "Status", "panel_input": "Input",
    # 确认弹窗
    "confirm_needed": "Needs your confirmation", "allow": "Allow (Y)", "deny": "Deny (N)",
    "allow_all": "Allow all (A)", "scroll_more": "Scroll for more",
    "confirm_clear_title": "Clear chat?", "confirm_clear_body": "This clears the current chat and memory. Cannot be undone.",
    "confirm_clear_ok": "Clear", "confirm_clear_cancelled": "Cancelled",
    "confirm_delete": "Confirm delete", "confirm_delete_enter": "Confirm delete (Enter)",
    "confirm_delete_wait": "Confirm delete (ready in {n}s)", "cancel_esc": "Cancel (Esc)",
    "items_total": "…{n} items in total",
    # 左栏
    "staff": "Staff", "staff_count": "{n} staff · on duty {who}", "no_staff": "No staff yet",
    "small_screen": "Live screen", "screen_sub": "Live browser view",
    "screen_wait": "Live screen: waiting for a page",
    "collapse": "Hide", "click_original": "Click to view original",
    "tree_title": "Files", "tree_none": "The agent has not touched any file yet",
    "view": "View", "preview": "Preview", "panel_write": "Write panel", "panel_preview": "File preview",
    "panel_none": "File contents show up here as the agent writes",
    # 右栏
    "workflow": "Workflow", "workflow_log": "Workflow · Log", "workflow_round": "Workflow · round {n}",
    "in_progress": " · running",
    "workflow_none": "Thinking and tool calls show up here while the agent works",
    "log_btn": "Log", "back_flow": "Back to workflow", "open_file": "Open file", "to_latest": "Latest",
    "waiting_model": "Waiting for the model…",
    "no_logs": "No logs yet: every step the agent takes is recorded here",
    "log_lines": "{f} · {n} lines (newest at the bottom)",
    # 输入框
    "placeholder": "Describe what you need. Enter to send, Shift+Enter for a new line",
    "placeholder_busy": "Working - keep chatting: ask for progress, say pause / resume, or add new requests "
                        "(/pause /resume /plan also work)",
    # voice input (microphone button on the left of Send / F2)
    "voice_btn": "Microphone", "voice_recording": "Recording… click again to stop (F2)",
    "voice_wait": "Recognizing…", "voice_ok": "Speech turned into text, check it before sending",
    "voice_empty": "Didn't catch that, try again", "voice_fail": "Speech recognition failed: ",
    "candy_hint": "Send a candy",
    "candy_btn": "Candy button",
    "projection_shell_on": "On (projection shell, no flicker on restart)",
    "projection_shell_off": "Off (window shown on screen directly)",
    # staff groups / criticize menu / /criticize
    "staff_group_front": "Front desk", "staff_group_lead": "Workgroup lead", "staff_group_builder": "Builders",
    "staff_group_worker": "Workers", "staff_group_other": "Other",
    "staff_menu_criticize": "Criticize", "staff_menu_cancel": "Cancel",
    # staff card
    "staff_card_title": "Staff card", "staff_card_close": "Close", "staff_card_take": "Take post",
    "staff_card_edit": "Edit", "staff_new": "+ New role",
    "staff_card_on": "On post", "staff_card_state_on": "On duty", "staff_card_state_off": "Off duty",
    "staff_card_duty": "Duty",
    "criticize_usage": "Usage: /criticize <staff> <what to say>",
    "criticize_need_text": "Say who to criticize and what about",
    "criticize_ok": "Criticism of {who} noted, A1 will read it next round",
    "criticize_no_agent": "No agent yet, criticism kept in the chat",
    "criticize_prefill": "Type your criticism of {who} and press Enter",
    # /set 与 set_ui
    "ui_settings_header": "UI settings (/set name value):",
    "no_such_setting": "No such UI setting: {k}",
    "ui_applied": "UI settings: ", "opt_sep": ", ",
    "resetpenalty_hint": "Type /resetpenalty to reset the A-desk / B-desk penalty and reward scores",
    # message time bubble (hover)
    "time_today": "Today", "time_yesterday": "Yesterday", "msg_time_tip": "Sent: {t}",
}
_LANG = "zh"          # 当前界面语言：zh / en（启动时由设置文件决定，见 _read_language）

# 换成英文时只替换 STYLE / ACTIONS 的第 0 项文字，颜色和折叠标记不变
STYLE_EN_LABELS = {"user": "You", "assistant": "Fish", "workflow": "Workflow", "reasoning": "Thinking",
                   "tool": "Tool call", "result": "Tool result", "info": "Info", "escalate": "Handoff",
                   "memory": "Memory", "b_stage": "B-desk", "b_reasoning": "B-desk · Thinking",
                   "b_assistant": "B-desk · Notes", "b_tool": "B-desk · Tool call",
                   "b_result": "B-desk · Result", "worker": "Worker", "error": "Error",
                   "image": "Image", "chat": "Chat"}
ACTIONS_EN = {"list_dir": "Browse", "read_file": "Read", "file_stats": "Stat", "search": "Search",
              "write_file": "Write", "edit_file": "Edit", "delete_file": "Delete", "move_file": "Move",
              "run_command": "Run", "escalate": "Handoff", "request_upgrade": "Upgrade",
              "dispatch": "Dispatch"}

# 界面设置显示名 -> 词表键（设置弹窗和 /set 列表里的名字跟着语言走，注册表里存的仍是中文名）
SETTING_LABEL_KEYS = {
    "fullscreen": "label_fullscreen", "scale": "label_scale", "theme": "label_theme",
    "language": "label_language", "auto_restart": "label_auto_restart", "front_desk": "label_front_desk",
    "b_assistants": "label_b_assistants", "hud": "label_hud", "staff_panel": "label_staff_panel",
    "auto_hide_panels": "label_auto_hide_panels",
    "anim": "label_anim", "anim_speed": "label_anim_speed", "糖果按钮": "candy_btn",
    "projection_shell": "label_projection_shell",
    "panel_left_w": "label_panel_left_w", "panel_right_w": "label_panel_right_w",
    "input_height": "label_input_height",
    "screen_window": "label_screen_window",
}


def reset_penalty_scores() -> str:
    """重置 A库 / B库 的惩罚和奖励分，返回重置前后的中文说明（任何前台都能直接调）。"""
    try:
        before = lib_b.penalty.scores()
        lib_b.penalty.reset()
        after = lib_b.penalty.scores()
        return (f"已重置 A库/B库 的惩罚和奖励：重置前 A扣{before['A']} B扣{before['B']} "
                f"R奖{before['R']} RA奖{before['RA']} → 现在全部为 0"
                f"（A扣{after['A']} B扣{after['B']} R奖{after['R']} RA奖{after['RA']}）。")
    except Exception as e:          # noqa: BLE001 - 重置失败也要让聊天栏看到原因
        return f"重置失败：{e}"


def lang(key: str, default: str | None = None) -> str:
    """按当前界面语言取词；词表里没有就用 default，再没有就返回 key。"""
    return (LANG_EN if _LANG == "en" else LANG_ZH).get(key) or default or key


def setting_label(key: str, entry: dict) -> str:
    """设置项在界面上显示的名字（跟随界面语言，认不出就退回注册表里的名字）。"""
    return lang(SETTING_LABEL_KEYS.get(key, ""), entry["label"])


def apply_theme(name: str):
    """把 C / STYLE / ACTIONS / MARKS / DIFF 整体切换为目标主题；未知名字静默回落到 light。"""
    global C, STYLE, ACTIONS, MARKS, DIFF
    theme = THEMES.get(name, THEMES["light"])
    C = dict(theme["C"])
    STYLE = dict(theme["STYLE"])
    ACTIONS = dict(theme["ACTIONS"])
    DIFF = dict(theme["DIFF"])
    MARKS = {"read": ("R", C["hdr"]), "modified": ("M", C["warn"]), "new": ("+", C["add"])}
    # 对话里的图片卡片：各主题沿用 assistant 卡片的配色
    STYLE.setdefault("image", ("图", STYLE["assistant"][1], STYLE["assistant"][2], C["text"], False))
    # 闲聊 Agent 的气泡：配色跟着主题（标签在画的时候换成当前前台员工名）
    STYLE.setdefault("chat", ("闲聊", C["dim"], C["panel"], C["text"], False))
    # 让主人勾选的选择卡片：配色跟着主题
    STYLE.setdefault("choice", ("选一个", C["hdr"], STYLE["assistant"][2], C["text"], False))
    for k, v in _BASE_STYLE.items():     # 兜底：以后新加的消息类型主题里忘了写，就用默认配色，别让整个程序崩掉
        STYLE.setdefault(k, v)
    if _LANG == "en":      # 英文模式：只换标签文字，颜色和折叠标记不变
        for k, text in STYLE_EN_LABELS.items():
            if k in STYLE:
                STYLE[k] = (text,) + tuple(STYLE[k][1:])
        for k, text in ACTIONS_EN.items():
            if k in ACTIONS:
                ACTIONS[k] = (text,) + tuple(ACTIONS[k][1:])


apply_theme("light")


def relabel_ui(theme: str | None = None):
    """按当前界面语言重新套用主题：STYLE / ACTIONS 的标签立刻换成对应语言。"""
    if theme is None:
        try:
            theme = str(load_settings().get("theme") or "light")
        except Exception:
            theme = "light"
    apply_theme(theme)


# ============================================================
# 界面设置注册表：每个设置在这里登记一次，A库 的 set_ui 工具、/set 命令、右侧各区块的设置面板
# 都由它自动生成。新增界面设置只要加一个 ui_setting(...)，其他地方都不用改。
# ============================================================
UI_SETTINGS: dict[str, dict] = {}


def ui_setting(key: str, label: str, options, apply, aliases: dict | None = None, free=None,
               group: str = "", panel: str = "", icon: str = "", verb: str = ""):
    """登记一个界面设置（值保存在 settings[key]）。
    options: callable(app) -> [(显示文字, 值), ...]：面板里的按钮，也是 set_ui 的可选值
    apply:   callable(app, 值)：让它生效并保存设置
    aliases: 额外接受的写法 -> 值，例如 {"深色": "dark"}
    free:    callable(原始值) -> 值：接受选项以外的值（例如任意缩放比例），不合法就抛 ValueError
    panel:   藏在哪个 UI 区块的设置面板里（show / talk / team / work / bar / layout / screen）
    group:   面板里的小分组名
    icon / verb: 面板图标和一句话说明（存档用，缺了也不影响）
    """
    UI_SETTINGS[key] = {"label": label, "options": options, "apply": apply,
                        "aliases": aliases or {}, "free": free, "group": group,
                        "panel": panel, "icon": icon, "verb": verb}


# 右侧各块的设置面板（顺序即左栏底部图标和标题标号）
PANEL_ORDER = ["show", "perf", "lang", "privacy"]      # 界面主题 / 性能（token 模式）/ 语言 / 隐私（API key）
PANEL_LABEL_KEYS = {"show": "panel_show", "perf": "panel_perf", "lang": "panel_lang", "privacy": "panel_privacy",
                    "talk": "panel_talk", "team": "panel_team",
                    "work": "panel_work", "bar": "panel_bar", "layout": "panel_layout",
                    "screen": "panel_screen", "status": "panel_status", "input": "panel_input"}
BLOCK_LABEL_KEYS = {"外观": "group_look", "成员": "group_staff", "干活": "group_work",
                    "布局": "group_layout", "其他": "group_other"}

# 右栏每一块标题上的设置图标 -> 打开哪个设置面板（和 PANEL_ORDER 里的键名对上）
SPOT_PANELS = {}      # 以前栏标题条上的齿轮指向各自的设置面板；那些面板删掉了，齿轮也不画了

# 用滑杆调的设置：按住拖动实时预览，松手保存（两边还有 − / + 各动一档）
SLIDER_KEYS = ("scale", "layout_left", "layout_right", "layout_input")

# 顶栏按钮：内部名 -> 词表键（“顶栏”面板里逐个显示 / 隐藏）；设置按钮已经去掉，改成每块标题上的设置图标
# 顶栏已精简到没有常驻按钮：「清空对话」不再放顶栏（太容易被误点），改走命令行 /clear，
# 而且必须先过二次确认（request_clear）；暂停 / 继续按钮干活时才出现（见 visible_top_buttons）
TOP_BUTTONS = {}


def panel_label(panel: str) -> str:
    """区块设置面板的名字（跟随界面语言）。"""
    return lang(PANEL_LABEL_KEYS.get(panel, ""), lang("group_other"))


def group_label(group: str) -> str:
    """面板里的小分组名（跟随界面语言，认不出就用登记的名字）。"""
    if not group:
        return lang("group_other")
    return lang(BLOCK_LABEL_KEYS.get(group, ""), group)


def settings_of(panel: str) -> list[tuple[str, dict]]:
    """某个区块归属的设置项（按登记顺序）。"""
    return [(k, e) for k, e in UI_SETTINGS.items() if e["panel"] == panel]


def stray_settings() -> list[tuple[str, str, dict]]:
    """没归到已知区块的设置 [(key, group, entry), ...]（注册表新加项忘了写 panel 时兜底显示）。"""
    return [(k, e["group"], e) for k, e in UI_SETTINGS.items() if e["panel"] not in PANEL_ORDER]


def top_button_choices(app) -> list[tuple[str, str]]:
    """“顶栏”面板里的按钮清单：[(内部名, 显示名), ...]。"""
    return [(name, lang(key)) for name, key in TOP_BUTTONS.items()]


def parse_ui_value(app, key: str, raw):
    """把用户 / 模型给的值（文字、数字、布尔）转成设置值；认不出就抛 ValueError。"""
    entry = UI_SETTINGS[key]
    s = str(raw).strip()
    for text, value in entry["options"](app):
        if s == text or s.lower() == str(value).lower():
            return value
    if s in entry["aliases"]:
        return entry["aliases"][s]
    if entry["free"]:
        return entry["free"](raw)
    raise ValueError(f"{entry['label']} 没有这个选项：{raw}")


def ui_value_text(app, key: str, value) -> str:
    return next((t for t, v in UI_SETTINGS[key]["options"](app) if v == value), str(value))


def ui_tool_schema(app) -> dict:
    """A库 的 set_ui 工具定义：按注册表现生成，所以新增的设置自动出现。"""
    props = {}
    for key, e in UI_SETTINGS.items():
        opts = "、".join(f"{v}（{t}）" for t, v in e["options"](app))
        props[key] = {"type": "string",
                      "description": f"{e['label']}，可选：{opts}" + ("；也可以写别的数值" if e["free"] else "")}
    return da._fn(
        "set_ui",
        "直接切换 Terminist 界面的设置，立刻生效、不改代码。用户想改这些设置时用这个，"
        "不要用 request_upgrade。只填要改的项。", props)


def _save_setting(app, key: str, value):
    app.settings[key] = value
    save_settings(app.settings)


def _apply_hud(app, value):
    """工作流现场显隐：存盘并清掉布局缓存，下一帧就按新的浮条高度重排。"""
    app.input_rect = None                          # 输入框位置缓存作废，下一帧重算
    _save_setting(app, "hud", bool(value))


def _apply_projection_shell(app, value):
    """投影主窗口开关：开了立刻起壳并把真窗口挪到屏幕外，关了立刻退回屏幕原位（都是静默降级）。"""
    _save_setting(app, "projection_shell", bool(value))
    try:
        if value:
            if not getattr(app, "shell_pid", None):
                app.start_projection()
        else:
            app.stop_projection()
            app.restore_on_screen()
    except Exception:
        pass


def _apply_theme_setting(app, value):
    apply_theme(value)
    _save_setting(app, "theme", value)


def _apply_fullscreen(app, value):
    if value != app.settings.get("fullscreen"):
        app.toggle_fullscreen()


def _parse_scale(raw) -> float:
    v = float(str(raw).strip().rstrip("%"))
    v = v / 100 if v > 5 else v                      # 150 / 150% → 1.5
    if not 0.75 <= v <= 3.0:
        raise ValueError(f"界面缩放要在 75%~300% 之间：{raw}")
    return v


def _parse_anim_speed(raw) -> float:
    """动画速度：接受 2× / 2x / 2 这类写法，限制在 0.25~4 倍之间。"""
    v = float(str(raw).strip().rstrip("×xX%"))
    if not 0.25 <= v <= 4.0:
        raise ValueError(f"动画速度要在 0.25~4 倍之间：{raw}")
    return v


ui_setting("fullscreen", "显示模式",
           lambda app: [(lang("window"), False), (lang("fullscreen"), True)], _apply_fullscreen,
           aliases={"窗口": False, "全屏": True, "窗口模式": False, "window": False, "fullscreen": True},
           group="外观", panel="show", icon="expand", verb="display")
ui_setting("scale", "界面缩放",
           lambda app: [(lang("auto_scale").format(p=round(app.sys_scale * 100)), "auto")] +
                       [(f"{round(v * 100)}%", v) for v in SCALE_OPTIONS],
           lambda app, v: app.set_scale(v), aliases={"自动": "auto"}, free=_parse_scale, group="外观",
           panel="show", icon="缩放", verb="display")
ui_setting("theme", "会话主题",
           lambda app: [(lang("theme_" + k, THEME_LABELS.get(k, k)), k) for k in THEMES],
           _apply_theme_setting, aliases=THEME_ALIASES, group="外观",
           panel="show", icon="palette", verb="display")



def staff_label(name: str) -> str:
    """员工的显示名，取不到就用名字本身。"""
    try:
        s = load_staff().get(name)
        return str(s.get("label") or name) if isinstance(s, dict) else str(name)
    except Exception:
        return str(name)


# 分组顺序号 -> 词条（员工栏的分组小标题）
STAFF_GROUP_KEYS = {0: "staff_group_front", 1: "staff_group_lead", 2: "staff_group_builder",
                    3: "staff_group_worker", 4: "staff_group_other"}


def staff_group(name: str, info=None) -> tuple:
    """员工的岗位分组：(顺序号, 分组名)。优先用 lib_a/staff.py 的 role_group，取不到就按 role 兜底。"""
    try:
        from lib_a.staff import role_group
        order, group = role_group(name, info)
        return int(order), str(group)
    except Exception:
        pass
    try:
        role = str(info.get("role") or "") if isinstance(info, dict) else ""
        key = str(name or "")
        if role == "front" or key in ("fish", "cat"):
            return 0, "前台"
        if key == "lead" or role == "lead":
            return 1, "工作组组长"
        if role.startswith("builder") or role == "lib_b":
            return 2, "改造层"
        if role == "worker":
            return 3, "执行成员"
    except Exception:
        pass
    return 4, "其它"


def _apply_front_desk(app, on: bool):
    """前台在岗 / 下班，并记进设置（重启后保持）。用当前上岗员工的人设。"""
    _save_setting(app, "front_desk", on)
    if app.agent:
        app.agent.set_persona(active_persona() if on else "")


def _parse_assistants(raw) -> int:
    n = int(str(raw).strip().rstrip("个"))
    if not 1 <= n <= lib_b.builder.MAX_ASSISTANTS:
        raise ValueError(f"B库 助手要在 1~{lib_b.builder.MAX_ASSISTANTS} 个之间：{raw}")
    return n





def _apply_perf_mode(app, value):
    _save_setting(app, "perf_mode", value)


ui_setting("perf_mode", "性能模式",
           lambda app: [("省token模式", "save"), ("正常token模式", "normal"),
                        ("高均衡模式", "balanced"), ("Ultra*", "ultra")],
           _apply_perf_mode,
           aliases={"省token": "save", "节约": "save", "正常": "normal", "标准": "normal",
                    "均衡": "balanced", "高均衡": "balanced", "ultra": "ultra", "极限": "ultra"},
           group="性能", panel="perf", icon="性能")
def _apply_screen_window(app, value):
    """小屏幕窗口模式：存盘，并让下次上网（或立刻）按新模式处理。"""
    v = str(value or "on").lower()
    _save_setting(app, "screen_window", v)
    fn = getattr(app, "_screen_auto", None)
    if v == "off":                              # 改回嵌在左栏：独立窗口顺手关掉
        close = getattr(app, "close_screen_window", None)
        if close and getattr(app, "screen_win_open", False):
            try:
                close()
            except Exception:
                pass
    if fn and v == "on":
        try:
            fn()
        except Exception:
            pass


ui_setting("anim", "界面动画",
           lambda app: [(lang("show"), True), (lang("hide"), False)],
           lambda app, v: _save_setting(app, "anim", bool(v)),
           aliases={"开": True, "关": False, "on": True, "off": False, "显示": True, "隐藏": False,
                    "show": True, "hide": False}, group="外观", panel="show", icon="动效", verb="display")
ui_setting("anim_speed", "动画速度",
           lambda app: [(t, v) for t, v in (("0.5×", 0.5), ("1×", 1.0), ("1.5×", 1.5), ("2×", 2.0))],
           lambda app, v: _save_setting(app, "anim_speed", float(v)),
           aliases={"慢": 0.5, "正常": 1.0, "快": 2.0, "slow": 0.5, "fast": 2.0},
           free=_parse_anim_speed, group="外观", panel="show", icon="速度", verb="display")
ui_setting("candy_btn", "糖果按钮",
           lambda app: [(lang("show"), True), (lang("hide"), False)],
           lambda app, v: _save_setting(app, "candy_btn", bool(v)),
           aliases={"开": True, "关": False, "on": True, "off": False, "显示": True, "隐藏": False,
                    "show": True, "hide": False}, group="外观", panel="show", icon="糖果", verb="display")
ui_setting("projection_shell", "投影主窗口",
           lambda app: [(lang("projection_shell_on"), True), (lang("projection_shell_off"), False)],
           lambda app, v: _apply_projection_shell(app, v),
           aliases={"投影": True, "投影壳": True, "投影主窗口": True, "projection": True, "shell": True,
                    "开": True, "关": False, "on": True, "off": False, "显示": True, "隐藏": False,
                    "show": True, "hide": False}, group="外观", panel="show", icon="cycle", verb="display")



def _lang_options(app):
    """语言选项当前语言显示（中文界面写 English，英文界面写 Chinese）。"""
    return [(lang("zh"), "zh"), (lang("en"), "en")]


def _apply_language(app, value):
    """切换界面语言：立刻重贴标签并保存，重启后保持。只换显示文字，不动任何设置值。"""
    global _LANG
    v = "en" if str(value).strip().lower() in ("en", "english", "英文", "en-us") else "zh"
    _LANG = v
    _save_setting(app, "language", v)
    relabel_ui(app.settings.get("theme", "light"))


ui_setting("language", "界面语言", _lang_options, _apply_language,
           aliases={"chinese": "zh", "中文": "zh", "english": "en", "英文": "en",
                    "en-us": "en", "en_us": "en", "zh-cn": "zh"}, group="语言",
           panel="lang", icon="中/EN", verb="display")


def _apply_sizes(app, v):
    """改栏宽 / 输入框高度：只动 app.sizes，下一帧按新尺寸重画并存盘。"""
    if isinstance(v, dict):
        for k, val in v.items():
            if k in app.sizes:
                app.sizes[k] = int(val)
        app.sizes = app.clamp_sizes(app.sizes)
        app.save_drag_sizes()


def _size_pct(app, p) -> int:
    """窗口宽度的百分比 -> 像素（和分隔条拖动同一个范围）。"""
    return app.screen.get_width() * int(p) // 100





# ============================================================
# 工具函数
# ============================================================
def load_font(size: int) -> pygame.font.Font:
    candidates = [
        r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simhei.ttf",
        "/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Medium.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    ]
    for p in candidates:
        if os.path.exists(p):
            return pygame.font.Font(p, size)
    return pygame.font.SysFont("microsoftyahei,pingfangsc,notosanscjksc,simhei,arial", size)


TEXT_CACHE_MAX = 2000
_TEXT_CACHE: dict = {}


def utext(font, text, color):
    """带缓存的字体渲染：同样的字号/文字/颜色只 render 一次，之后直接 blit。"""
    if text is None or text == "":
        return pygame.Surface((1, 1), pygame.SRCALPHA)
    try:
        ckey = tuple(color[:3]) if isinstance(color, (tuple, list)) else color
    except TypeError:
        ckey = color
    key = (font, str(text), ckey)          # 用字体对象本身当 key：id() 会被复用，会渲染成别的字号
    surf = _TEXT_CACHE.get(key)
    if surf is not None:
        return surf
    surf = font.render(text, True, color)
    if len(_TEXT_CACHE) > TEXT_CACHE_MAX:
        _TEXT_CACHE.clear()
    _TEXT_CACHE[key] = surf
    return surf


def clear_text_cache():
    _TEXT_CACHE.clear()


_CHAR_W: dict = {}


def _char_w(font, ch) -> int:
    """单个字符的像素宽度，按 (字体对象, 字符) 缓存，避免逐字 font.size。
    别用 id(font) 当 key：旧字体被回收后 id 会复用，新字体会读到别的字号的宽度，
    折行算错就会出格。"""
    key = (font, ch)
    w = _CHAR_W.get(key)
    if w is None:
        w = font.size(ch)[0]
        if len(_CHAR_W) > 20000:
            _CHAR_W.clear()
        _CHAR_W[key] = w
    return w


def wrap(font: pygame.font.Font, text: str, width: int) -> list[str]:
    """按像素宽度逐字折行（中英文混排都适用）。"""
    if width <= 0:                      # 宽度不合理时原样返回，免得每字符一行把行数炸了
        return text.replace("\r", "").split("\n")
    out = []
    for para in text.replace("\t", "    ").replace("\r", "").split("\n"):
        if font.size(para)[0] <= width:     # 大多数行不用折，先整行量一次
            out.append(para)
            continue
        cur, cur_w = "", 0
        for ch in para:
            w = _char_w(font, ch)
            if cur and cur_w + w > width:
                out.append(cur)
                cur, cur_w = ch, w
            else:
                cur += ch
                cur_w += w
        out.append(cur)
    return out


_ELLIPSIZE_CACHE: dict = {}


def ellipsize(font, text: str, width: int) -> str:
    """文字超宽就截断加省略号；宽度连省略号都放不下时返回空串（否则 '…' 自己会出格）。
    结果按（字体, 文字, 宽度）缓存，截断位置用二分找：以前每帧一个字一个字地删、每删一个量一次，员工栏一帧要量 70 次（6ms）。"""
    if width <= 0:
        return ""
    key = (id(font), text, width)
    hit = _ELLIPSIZE_CACHE.get(key)
    if hit is not None:
        return hit
    if font.size(text)[0] <= width:
        out = text
    elif font.size("…")[0] > width:
        out = ""
    else:
        lo, hi = 0, len(text)                    # 保留结尾 k 个字：找最大的 k，使「…」+ 结尾 k 个字放得下
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if font.size("…" + text[len(text) - mid:])[0] <= width:
                lo = mid
            else:
                hi = mid - 1
        out = "…" + text[len(text) - lo:]
    if len(_ELLIPSIZE_CACHE) > 4000:
        _ELLIPSIZE_CACHE.clear()
    _ELLIPSIZE_CACHE[key] = out
    return out


# ---------------- 自己画的图标 / 糖果特效（不加载外部图片，也不靠 emoji 字形） ----------------

import random                                    # 糖果的随机颜色 / 速度用

CADDY_COLORS = [(240, 110, 160), (255, 180, 90), (120, 200, 160), (150, 150, 240),
                (240, 150, 200), (255, 210, 120)]      # 糖果颜色池


def draw_mic(surf, box, color):
    """麦克风：圆头矩形 + 下面半圆 + 支架和底座（整个图形在 box 里居中）。"""
    try:
        box = pygame.Rect(box)
        w = max(1, box.w // 14)
        cap_w = max(4, int(box.w * 0.38))
        cap_h = max(6, int(box.h * 0.42))
        cx = box.centerx
        top = box.y + max(0, int(box.h * 0.14))
        pygame.draw.rect(surf, color, pygame.Rect(cx - cap_w // 2, top, cap_w, cap_h),
                         border_radius=max(1, cap_w // 2))
        r = cap_w // 2 + max(1, w)
        pygame.draw.arc(surf, color, pygame.Rect(cx - r, top + cap_h - r + 1, r * 2, r * 2),
                        math.pi, math.pi * 2, max(2, w))
        stand = max(2, box.h // 12)
        base_y = top + cap_h + r
        pygame.draw.line(surf, color, (cx, base_y), (cx, base_y + stand), max(1, w))
        half = max(3, cap_w // 2)
        pygame.draw.line(surf, color, (cx - half, base_y + stand), (cx + half, base_y + stand), max(1, w))
    except Exception:
        pass


def draw_pause(surf, box, color):
    """暂停：两条圆头竖线（居中在 box 里）。"""
    try:
        box = pygame.Rect(box)
        side = max(6, min(box.w, box.h))
        bar_w = max(2, int(side * 0.22))
        bar_h = max(6, int(side * 0.62))
        gap = max(2, int(side * 0.16))
        cx, cy = box.center
        for sx in (-1, 1):
            x = cx + sx * (gap // 2 + bar_w // 2) - bar_w // 2
            pygame.draw.rect(surf, color, pygame.Rect(x, cy - bar_h // 2, bar_w, bar_h),
                             border_radius=max(1, bar_w // 2))
    except Exception:
        pass


def draw_play(surf, box, color):
    """继续：一个朝右的三角。"""
    try:
        box = pygame.Rect(box)
        side = max(6, min(box.w, box.h))
        cx, cy = box.center
        h = max(6, int(side * 0.62))
        w = max(5, int(side * 0.52))
        x = cx - w // 2
        pygame.draw.polygon(surf, color, [(x, cy - h // 2), (x, cy + h // 2), (x + w, cy)])
    except Exception:
        pass


def draw_candy(surf, cx, cy, r, color=None):
    """一颗糖果：两侧糖纸三角 + 中间圆 + 左上高光。"""
    try:
        color = tuple(color if color else CADDY_COLORS[0])
        r = max(2, int(r))
        dark = tuple(max(0, int(c * 0.75)) for c in color[:3])
        wing = max(1, int(r * 0.9))
        pygame.draw.polygon(surf, dark, [(cx - r, cy), (cx - r - wing, cy - int(r * 0.8)),
                                        (cx - r - wing, cy + int(r * 0.8))])
        pygame.draw.polygon(surf, dark, [(cx + r, cy), (cx + r + wing, cy - int(r * 0.8)),
                                        (cx + r + wing, cy + int(r * 0.8))])
        pygame.draw.circle(surf, color[:3], (cx, cy), r)
        pygame.draw.circle(surf, (255, 255, 255), (cx - r // 3, cy - r // 3), max(1, r // 3))
    except Exception:
        pass


def draw_heart(surf, rect, color):
    """爱心：两个圆 + 下面一个三角。"""
    try:
        rect = pygame.Rect(rect)
        rad = max(2, rect.w // 4)
        cy = rect.y + int(rect.h * 0.33)
        pygame.draw.circle(surf, color, (rect.x + rad, cy), rad)
        pygame.draw.circle(surf, color, (rect.right - rad, cy), rad)
        pygame.draw.polygon(surf, color, [(rect.x, cy + rad // 2), (rect.right, cy + rad // 2),
                                         (rect.centerx, rect.bottom - 1)])
    except Exception:
        pass


def draw_cat(surf, rect, color):
    """猫脸：两个三角耳 + 圆脸 + 两只深色眼睛。"""
    try:
        rect = pygame.Rect(rect)
        face_r = max(4, min(rect.w, rect.h) // 2 - max(1, min(rect.w, rect.h) // 12))
        cx, cy = rect.center
        ear = max(3, face_r // 2)
        for sx in (-1, 1):
            ex = cx + sx * (face_r // 2)
            pygame.draw.polygon(surf, color, [(ex - ear // 2, cy - face_r // 2), (ex + ear // 2, cy - face_r // 2),
                                            (ex, cy - face_r - ear // 2)])
        pygame.draw.circle(surf, color, (cx, cy), face_r)
        dark = tuple(max(0, int(c * 0.35)) for c in color[:3])
        eye = max(1, face_r // 4)
        for sx in (-1, 1):
            pygame.draw.circle(surf, dark, (cx + sx * (face_r // 3), cy - face_r // 4), eye)
    except Exception:
        pass


def draw_gear(surf, box, color):
    """齿轮：一圈齿 + 外圈 + 中间实心（设置图标）。"""
    try:
        box = pygame.Rect(box)
        cx, cy = box.center
        side = max(6, min(box.w, box.h))
        r = max(3, side // 2 - max(1, side // 16))
        w = max(1, r // 4)
        for i in range(8):
            a = math.pi * 2 * i / 8
            pygame.draw.line(surf, color, (cx + int(math.cos(a) * r * 0.6), cy + int(math.sin(a) * r * 0.6)),
                             (cx + int(math.cos(a) * r), cy + int(math.sin(a) * r)), w)
        pygame.draw.circle(surf, color, (cx, cy), max(2, int(r * 0.68)), max(2, w))
        pygame.draw.circle(surf, color, (cx, cy), max(1, r // 4))
    except Exception:
        pass


def draw_fish(surf, box, color):
    """鱼（前台肥鱼）：椭圆身子 + 尾巴三角 + 眼睛。"""
    try:
        box = pygame.Rect(box)
        h = max(6, box.h)
        body = pygame.Rect(box.x, box.centery - max(2, h // 4), max(6, int(box.w * 0.72)), max(4, h // 2))
        pygame.draw.ellipse(surf, color, body)
        pygame.draw.polygon(surf, color, [(body.right - 1, body.centery), (box.right, body.centery - h // 3),
                                         (box.right, body.centery + h // 3)])
        pygame.draw.circle(surf, (20, 20, 26), (body.x + body.w // 4, body.y + body.h // 3),
                           max(1, body.h // 6))
    except Exception:
        pass


def draw_palette(surf, box, color):
    """调色盘：圆盘 + 三个颜料点（主题用）。"""
    try:
        box = pygame.Rect(box)
        side = max(8, min(box.w, box.h))
        r = max(3, side // 2 - max(1, side // 10))
        pygame.draw.circle(surf, color, box.center, r, max(2, side // 8))
        for i in range(3):
            a = math.pi * 2 * i / 3 - math.pi / 2
            pygame.draw.circle(surf, color, (box.centerx + int(math.cos(a) * r * 0.42),
                                             box.centery + int(math.sin(a) * r * 0.42)),
                               max(1, side // 8))
    except Exception:
        pass


def draw_check(surf, box, color):
    """对勾（自动确认用）。"""
    try:
        box = pygame.Rect(box)
        w = max(2, min(box.w, box.h) // 6)
        pygame.draw.lines(surf, color, False, [(box.x + box.w // 6, box.centery),
                                               (box.centerx - box.w // 12, box.bottom - box.h // 5),
                                               (box.right - box.w // 6, box.y + box.h // 4)], w)
    except Exception:
        pass


def draw_expand(surf, box, color):
    """四角箭头（全屏用）。"""
    try:
        box = pygame.Rect(box)
        w = max(2, min(box.w, box.h) // 8)
        a = max(2, min(box.w, box.h) // 3)
        for sx, sy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
            x = box.centerx + sx * box.w // 2
            y = box.centery + sy * box.h // 2
            pygame.draw.line(surf, color, (x, y), (x - sx * a, y), w)
            pygame.draw.line(surf, color, (x, y), (x, y - sy * a), w)
    except Exception:
        pass


def draw_cycle(surf, box, color):
    """循环箭头（自动重启用）。"""
    try:
        box = pygame.Rect(box)
        side = max(8, min(box.w, box.h))
        r = max(3, side // 2 - max(1, side // 8))
        w = max(2, side // 8)
        pygame.draw.arc(surf, color, pygame.Rect(box.centerx - r, box.centery - r, r * 2, r * 2),
                        0.4, math.pi * 1.8, w)
        pygame.draw.polygon(surf, color, [(box.centerx + r, box.centery - r),
                                         (box.centerx + r - w * 3, box.centery - r),
                                         (box.centerx + r, box.centery - r + w * 3)])
    except Exception:
        pass


def draw_spinner(surf, center_xy, r, color, t_ms):
    """聊天栏进度文字前面的旋转加载圈：一段 270° 的弧，起始角随时间转。"""
    try:
        r = max(3, int(r))
        box = pygame.Rect(0, 0, r * 2, r * 2)
        box.center = (int(center_xy[0]), int(center_xy[1]))
        start = (float(t_ms) / 1000.0 * 2.5) % (math.pi * 2)
        end = (start + math.pi * 1.5) % (math.pi * 2)
        width = max(2, r // 3)
        if start <= end:                       # pygame 的弧不跨 0 度：跨了就先画到 0 度再补前一段
            pygame.draw.arc(surf, color, box, start, end, width)
        else:
            pygame.draw.arc(surf, color, box, start, math.pi * 2, width)
            if end > 0:
                pygame.draw.arc(surf, color, box, 0, end, width)
    except Exception:
        pass


GLYPH_KINDS = ("mic", "candy", "heart", "cat", "gear", "fish", "palette", "check", "expand", "cycle",
               "pause", "play")

CANDY_SLOT_D = 46          # 糖果按钮的直径（逻辑像素，和原来 S(46) 一致）
CANDY_SCREEN_PAD = 8       # 离窗口边缘的最小内缩（逻辑像素）


def sweep_candy_slot(W, H, pad, used=None, size=None, margin=None):
    """窗口右下角的圆槽位：从右下角往左上依次找第一个不和 used 相交的位置。
    used: [(x, y, w, h), ...] 已被占用的矩形（屏幕坐标，优先用界面实际尺寸）。
    返回 (x, y, w, h)，放不下就返回 None。"""
    size = max(4, int(size or S(CANDY_SLOT_D)))
    margin = max(0, int(margin if margin is not None else
                        (pad if pad is not None else S(CANDY_SCREEN_PAD))))
    step = size + margin
    taken = []
    for u in (used or []):
        try:
            taken.append(pygame.Rect(*u))
        except Exception:
            continue
    x0 = max(0, int(W) - size - margin)                  # 右下角的内缩位置（窗口太小就贴左上）
    y0 = max(0, int(H) - size - margin)
    y = y0
    while y >= 0:
        x = x0
        while x >= 0:
            r = pygame.Rect(x, y, size, size)
            if not any(r.colliderect(t) for t in taken):
                return (r.x, r.y, r.w, r.h)
            x -= step
        y -= step
    return None


def glyph_kind(icon) -> str:
    """设置项存档里的图标名 -> 自绘图形的 kind（不是自绘图形就返回空串，不画图标）。"""
    k = str(icon or "").strip()
    return k if k in GLYPH_KINDS else ""


class Glyph:
    """按钮上用的自绘图标：不依赖字体里有没有 emoji 字形。"""

    def __init__(self, kind, size=18):
        self.kind, self.size = str(kind), int(size)

    def render(self, surf, rect, color):
        try:
            rect = pygame.Rect(rect)
            if self.kind == "mic":
                draw_mic(surf, rect, color)
            elif self.kind == "candy":
                draw_candy(surf, rect.centerx, rect.centery, max(3, min(rect.w, rect.h) // 2))
            elif self.kind == "heart":
                draw_heart(surf, rect, color)
            elif self.kind == "cat":
                draw_cat(surf, rect, color)
            elif self.kind == "gear":
                draw_gear(surf, rect, color)
            elif self.kind == "fish":
                draw_fish(surf, rect, color)
            elif self.kind == "palette":
                draw_palette(surf, rect, color)
            elif self.kind == "check":
                draw_check(surf, rect, color)
            elif self.kind == "expand":
                draw_expand(surf, rect, color)
            elif self.kind == "cycle":
                draw_cycle(surf, rect, color)
            elif self.kind == "pause":
                draw_pause(surf, rect, color)
            elif self.kind == "play":
                draw_play(surf, rect, color)
        except Exception:
            pass

    def __str__(self):
        return ""


_GLYPH_W = {"mic": 0.5}


def glyph_width(font, g) -> int:
    """自绘图标按钮要占的宽度（按图标字号算，mic 窄一点）。"""
    try:
        return max(6, int(g.size * _GLYPH_W.get(g.kind, 1.0)))
    except Exception:
        return 6


class CandyParticle:
    """一颗往下落的糖果（有时是爱心）。"""

    def __init__(self, x, y, vx=None, vy=None, r=None, color=None):
        self.color = tuple(color if color else random.choice(CADDY_COLORS))
        self.x, self.y = float(x), float(y)
        self.vx = float(vx if vx is not None else random.uniform(-1.6, 1.6))
        self.vy = float(vy if vy is not None else random.uniform(-6.0, -2.0))
        self.rot = random.uniform(0, math.pi * 2)
        self.spin = random.uniform(-0.2, 0.2)
        self.size = int(r if r else random.randint(3, 5))   # 粒子减量：默认变小到 3~5
        self.heart = random.random() < 0.22           # 两成是粉色爱心
        self.life = random.randint(34, 52)            # 粒子减量：活得更短，飘完就收

    def tick(self) -> bool:
        self.vy += 0.30                               # 重力：先往上抛，再落下来（落得更干脆）
        self.x += self.vx + math.sin(self.rot) * 0.35   # 左右摆动减半，不糊屏
        self.y += self.vy
        self.rot += self.spin
        self.life -= 1
        return self.life > 0

    def draw(self, surf):
        try:
            x, y = int(self.x), int(self.y)
            if self.heart:
                draw_heart(surf, pygame.Rect(x - self.size, y - self.size, self.size * 2, self.size * 2),
                           (240, 120, 170))
            else:
                draw_candy(surf, x, y, self.size, self.color)
        except Exception:
            pass


class CandyBurst:
    """点糖果按钮时放出来的一团糖果：从一个点往上抛，然后往主窗口里落。"""

    def __init__(self, cx, cy, n=None):
        self.parts = []
        cnt = n if n else random.randint(7, 11)   # 粒子数量：默认减量到 7~11 颗，点一下不再糊满屏
        for i in range(cnt):
            a = math.pi * 2 * i / max(1, cnt) + random.uniform(-0.3, 0.3)
            sp = random.uniform(2.0, 5.5)
            self.parts.append(CandyParticle(cx, cy, math.cos(a) * sp,
                                            -abs(math.sin(a) * sp) - random.uniform(1.0, 4.0)))

    def tick(self) -> bool:
        self.parts = [p for p in self.parts if p.tick()]
        return bool(self.parts)

    def draw(self, surf):
        for p in self.parts:
            p.draw(surf)


_ESC = {"n": "\n", "t": "\t", "r": "", '"': '"', "\\": "\\", "/": "/", "b": "", "f": ""}


def partial_json_str(raw: str, key: str) -> str | None:
    """从一段可能还没传完的 JSON 里，尽量解析出某个字符串字段的值（用于流式预览）。"""
    m = re.search(r'"%s"\s*:\s*"' % re.escape(key), raw)
    if not m:
        return None
    out, i, n = [], m.end(), len(raw)
    while i < n:
        c = raw[i]
        if c == '"':
            break
        if c == "\\":
            if i + 1 >= n:
                break
            e = raw[i + 1]
            if e == "u":
                h = raw[i + 2:i + 6]
                if len(h) < 4:
                    break
                try:
                    out.append(chr(int(h, 16)))
                except ValueError:
                    pass
                i += 6
                continue
            out.append(_ESC.get(e, e))
            i += 2
            continue
        out.append(c)
        i += 1
    return "".join(out)


def parse_args(raw: str) -> dict:
    try:
        v = json.loads(raw or "{}", strict=False)
        return v if isinstance(v, dict) else {}
    except ValueError:
        return {}


def get_clipboard() -> str:
    try:                                    # SDL 自带的剪贴板（pygame-ce），不行再用 tkinter
        s = pygame.scrap.get_text()
        if s:
            return s
    except Exception:
        pass
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        s = r.clipboard_get()
        r.destroy()
        return s
    except Exception:
        return ""


def get_clipboard_image():
    """读剪贴板里的图片，返回 PNG bytes；没有图片返回 None。三层兜底，绝不抛异常。"""
    # 1) tkinter：部分平台 clipboard_get 能直接给 image 对象
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        try:
            obj = r.clipboard_get(type="image/png")
        except Exception:
            obj = None
        if obj is None:
            try:
                obj = r.selection_get(selection="CLIPBOARD", type="image/png")
            except Exception:
                obj = None
        r.destroy()
        if isinstance(obj, (bytes, bytearray)) and obj[:8] == b"\x89PNG\r\n\x1a\n":
            return bytes(obj)
    except Exception:
        pass
    # 2) PIL.ImageGrab：Windows / macOS 上最省事
    try:
        from PIL import ImageGrab
        img = ImageGrab.grabclipboard()
        if img is not None and hasattr(img, "save"):
            import io
            buf = io.BytesIO()
            img.convert("RGBA").save(buf, "PNG")
            return buf.getvalue()
    except Exception:
        pass
    # 3) ctypes 读 Windows 剪贴板 CF_DIB，补 BMP 头后交给 PIL 转 PNG
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        CF_DIB = 8
        if user32.OpenClipboard(None):
            try:
                if user32.IsClipboardFormatAvailable(CF_DIB):
                    h = user32.GetClipboardData(CF_DIB)
                    if h:
                        ptr = kernel32.GlobalLock(h)
                        if ptr:
                            try:
                                size = kernel32.GlobalSize(h)
                                if size and size > 0:
                                    dib = ctypes.string_at(ptr, size)
                                    if dib[:4] == b"BM":
                                        data = dib
                                    else:
                                        import struct
                                        off = 14 + len(dib)
                                        header = struct.pack("<2sIHHI", b"BM", off, 0, 0, 54)
                                        data = header + dib
                                    import io
                                    from PIL import Image
                                    img = Image.open(io.BytesIO(data))
                                    buf = io.BytesIO()
                                    img.convert("RGBA").save(buf, "PNG")
                                    return buf.getvalue()
                            finally:
                                kernel32.GlobalUnlock(h)
            finally:
                user32.CloseClipboard()
    except Exception:
        pass
    return None


def set_clipboard(text: str):
    try:
        pygame.scrap.put_text(text)
        return
    except Exception:
        pass
    try:
        import tkinter
        r = tkinter.Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
        r.destroy()
    except Exception:
        pass


def pick_folder() -> str:
    try:
        import tkinter
        from tkinter import filedialog
        r = tkinter.Tk()
        r.withdraw()
        r.attributes("-topmost", True)
        path = filedialog.askdirectory(title="选择要让 Agent 编辑的文件夹")
        r.destroy()
        return path
    except Exception:
        return ""


def load_settings() -> dict:
    s = dict(DEFAULT_SETTINGS)
    try:
        s.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    for k in STALE_SETTINGS:
        s.pop(k, None)
    return s


def save_settings(s: dict):
    try:
        SETTINGS_FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def _read_language() -> str:
    """从设置文件里读界面语言：重启后仍是上次选的语言。"""
    try:
        v = str(load_settings().get("language") or "zh").strip().lower()
    except Exception:
        return "zh"
    return "en" if v in ("en", "english", "英文", "en-us") else "zh"


_LANG = _read_language()      # 模块加载时按保存的设置决定界面语言
relabel_ui()                  # 顺便把 STYLE / ACTIONS 的标签套成对应语言


def system_scale() -> float:
    """系统显示缩放比例（Windows 的 125%/150%/200% 等），需在 pygame.init() 之后调用。"""
    try:
        import ctypes
        return ctypes.windll.user32.GetDpiForSystem() / 96
    except Exception:
        return 1.0


def lerp(a, b, t):
    """按 t（0~1）在两个数之间线性插值。"""
    return a + (b - a) * t


def _dash_dotted_rect(surf, color, rect, width=2, dash=8):
    """按虚线画圆角矩形边框（四边逐段画短线），用于拖拽提示这类临时高亮。"""
    w = max(1, int(width))
    seg = max(2, int(dash))
    rad = min(int(seg), rect.h // 2, rect.w // 2)
    r = rect.copy()
    # 四条边：去掉圆角的两段，逐个画 dash 长的短线
    edges = [
        ((r.x + rad, r.y), (r.right - rad, r.y)),
        ((r.x + rad, r.bottom - 1), (r.right - rad, r.bottom - 1)),
        ((r.x, r.y + rad), (r.x, r.bottom - rad)),
        ((r.right - 1, r.y + rad), (r.right - 1, r.bottom - rad)),
    ]
    for (x1, y1), (x2, y2) in edges:
        length = abs(x2 - x1) + abs(y2 - y1)
        pos = 0
        while pos < length:
            end = min(pos + seg, length)
            if x1 == x2:
                pygame.draw.line(surf, color, (x1, y1 + pos), (x1, y1 + end), w)
            else:
                pygame.draw.line(surf, color, (x1 + pos, y1), (x1 + end, y1), w)
            pos += seg * 2
    # 四个圆角用小段弧线补齐
    for cx, cy, a0 in ((r.x + rad, r.y + rad, math.pi), (r.right - rad, r.y + rad, -math.pi / 2),
                       (r.right - rad, r.bottom - rad, 0.0), (r.x + rad, r.bottom - rad, math.pi / 2)):
        if rad > 0:
            pygame.draw.arc(surf, color, pygame.Rect(cx - rad, cy - rad, rad * 2, rad * 2),
                            a0, a0 + math.pi / 2, w)


def mix(c1, c2, t):
    """两个颜色按 t（0~1）混合，返回 3 元组 int。"""
    return tuple(int(round(lerp(c1[i], c2[i], t))) for i in range(3))


def rounded(surf, rect, color, radius=None, border=None, width=1):
    """填充一个圆角矩形；给了 border 就再描一圈边框，圆角统一默认 S(10)。"""
    radius = S(10) if radius is None else radius
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border is not None:
        pygame.draw.rect(surf, border, rect, width, border_radius=radius)


_SHADOW_CACHE: dict = {}
_CODE_LINE_CACHE: dict = {}      # 右栏代码/写入面板的行渲染缓存 {(字体 id, 行号/文本, 样式, 颜色): (Surface, 宽度)}


def _code_line(font, text, kind, color):
    """代码面板的一行：同样字体的同一行同一颜色只 render 一次。"""
    try:
        ckey = tuple(color[:3]) if isinstance(color, (tuple, list)) else color
    except TypeError:
        ckey = color
    key = (font, kind, text, ckey)
    hit = _CODE_LINE_CACHE.get(key)
    if hit is None:
        surf = utext(font, text, color)
        hit = (surf, surf.get_width())
        if len(_CODE_LINE_CACHE) > 6000:
            _CODE_LINE_CACHE.clear()
        _CODE_LINE_CACHE[key] = hit
    return hit


def soft_shadow(surf, rect, radius=None, depth=None, alpha=40):
    """在 rect 周围叠几层逐渐变淡的半透明圆角矩形，做一层柔和阴影（同尺寸的阴影层缓存复用）。"""
    radius = S(10) if radius is None else radius
    depth = S(6) if depth is None else depth
    key = (rect.w, rect.h, radius, depth, alpha, tuple(C["text"][:3]))
    lay = _SHADOW_CACHE.get(key)
    if lay is None:
        lay = pygame.Surface((max(1, rect.w + depth * 2), max(1, rect.h + depth * 2)), pygame.SRCALPHA)
        for i in range(6):
            g = depth * (6 - i) // 6                     # 越靠外张得越大、越淡
            r = pygame.Rect(depth - g, depth - g + S(1), rect.w + g * 2, rect.h + g * 2)
            pygame.draw.rect(lay, (*C["text"], max(4, alpha * (i + 1) // 6)), r,
                             border_radius=radius + g)
        if len(_SHADOW_CACHE) > 3000:
            _SHADOW_CACHE.clear()
        _SHADOW_CACHE[key] = lay
    surf.blit(lay, (rect.x - depth, rect.y - depth))


def clear_surface_caches():
    """字号/主题变化后清空所有位图缓存，避免旧画面残留。"""
    _TEXT_CACHE.clear()
    _CHAR_W.clear()
    _SHADOW_CACHE.clear()
    _CODE_LINE_CACHE.clear()


def draw_scrollbar(surf, area: pygame.Rect, total: int, scroll: int):
    if total <= area.h:
        return
    bar_h = max(S(30), area.h * area.h // total)
    bar_y = area.y + (area.h - bar_h) * scroll // max(1, total - area.h)
    pygame.draw.rect(surf, mix(C["scroll"], C["panel"], 0.25),
                     (area.right - S(9), bar_y, S(8), bar_h), border_radius=S(4))


def is_dark(color) -> bool:
    """按亮度判断底色是否偏深，浅色主题下用来决定按钮配白字还是深字。"""
    r, g, b = color[:3]
    return 0.299 * r + 0.587 * g + 0.114 * b < 150


# ============================================================
# 与 Agent 线程的桥接
# ============================================================
class DeleteRequest:
    """base.guard 的删除确认：弹窗出现 wait 秒后才能点确认。"""

    def __init__(self, items: list[str], reason: str, wait: float):
        self.items, self.reason, self.wait = items, reason, wait
        self.shown_at = 0          # 弹窗真正显示出来的时间（pygame ticks），倒计时从这里开始
        self.event = threading.Event()
        self.result = False


class ConfirmRequest:

    def __init__(self, msg: str, detail: str, kind: str = "", title: str = "",
                 ok_text: str = "", cancel_text: str = "", items=None):
        self.msg, self.detail = msg, detail
        self.kind = kind                 # "clear" = 清空对话的二次确认（按钮只有「清空」「取消」）
        self.title, self.ok_text, self.cancel_text = title, ok_text, cancel_text
        self.items, self.picked = list(items or []), set(items or [])   # 勾选式选择：条目 + 已勾中的
        self.event = threading.Event()
        self.result = False

    def result_text(self) -> str:
        """勾选式选择的返回文字：只列勾中的条目；没勾 / 拒绝返回空串（普通确认也返回空串）。"""
        if not self.result or not self.items:
            return ""
        picked = [t for t in self.items if t in self.picked]
        if not picked:
            return ""
        return "主人勾选了这些（照做，没列出的不要做）：\n" + "\n".join(f"- {t}" for t in picked)


CHOICE_WAIT = 1500          # 选择卡片最多等多久（秒）：Agent 一轮最长 30 分钟，留点余量给后面的活


class ChoiceRequest:

    def __init__(self, msg, options, multi: bool = True):
        self.msg = msg
        self.options = options
        self.multi = multi       # True：勾选框 + 「确定」「都不要」；False：点一条就提交
        self.event = threading.Event()
        self.result: list[int] | None = None    # 选中的下标；None = 没选（过期 / 被停止）
        self.custom = ""         # 主人自己写的回答（卡片最后一行「自己写一个」）
        self.expired = False


class CredentialsRequest:
    """网页要求注册/登录时向主人要账号密码：等待弹窗给出答案。"""

    def __init__(self, site: str, note: str = ""):
        self.site, self.note = site, note
        self.event = threading.Event()
        self.result = {"ok": False}      # 默认按拒绝处理
        self.user = ""
        self.pwd = ""
        self.remember = True
        self.focus = 0                   # 0 = 账号，1 = 密码


AVATAR_KINDS = ("assistant", "chat")      # 前台说的话：卡片左上角画头像
NOTICE_KINDS = {"info", "memory", "b_stage"}   # 系统提示：不进聊天框，进日志 + 左下角小通知（App.add / App.notice）


class NeedRequest:
    """Agent 把任务标成卡住、说要主人给东西：弹窗向主人要（填了就放回队列接着做）。"""

    def __init__(self, tid: str, title: str, reason: str):
        self.tid, self.title, self.reason = tid, title, reason
        self.text = ""


class ScreenShotRequest:
    """小屏幕截图请求：后台线程截完图把 jpeg 字节放进来，主循环收下。"""

    def __init__(self):
        self.event = threading.Event()
        self.data = b""


def _web_viewport():
    """网页视口尺寸（小屏幕坐标换算用）。"""
    try:
        from base.config import WEB_VIEWPORT
        return int(WEB_VIEWPORT[0]), int(WEB_VIEWPORT[1])
    except Exception:
        return 1280, 800


CHAT_SCREEN_HINT = ("\n\n你还能直接开 / 关小屏幕独立窗口：主人说「开小窗口」「弹出小屏幕」「关掉小窗口」「收起小屏幕」时，"
                    "直接调 screen_window（action=open / close / toggle），立刻生效，不用派 Agent、不用调 open_folder。")


class GuiWorkspace(da.Workspace):
    """确认请求不再走 input()，而是发给 GUI 弹窗，阻塞等待用户点击。"""

    def __init__(self, root: Path, events: queue.Queue, auto_yes=False):
        super().__init__(root, auto_yes)
        self.events = events
        self.agent = None

    def confirm(self, msg: str, detail: str = "", items=None):
        """弹窗等主人点：items 为空返回 bool（老行为）；items 非空返回勾选文字（没勾 / 拒绝返回空串）。"""
        if self.auto_yes:
            return True
        req = ConfirmRequest(msg, detail, items=items)
        self.events.put(("confirm", req))
        while not req.event.wait(0.1):
            if self.agent and self.agent.stop_requested:
                return False
        return req.result_text() if req.items else req.result

    def ask_credentials(self, site: str, note: str = "") -> dict:
        """网页要注册/登录：发给 GUI 弹窗，阻塞等主人填账号密码或拒绝。"""
        req = CredentialsRequest(site, note)
        self.events.put(("credentials", req))
        while not req.event.wait(0.1):
            if self.agent and self.agent.stop_requested:
                return {"ok": False}
        return req.result or {"ok": False}


# ============================================================
# 界面组件
# ============================================================
def fmt_msg_time(ts, now: float | None = None) -> str:
    """消息时间：今天 -> 「今天 HH:MM」，昨天 -> 「昨天 HH:MM」，更早 -> 「YYYY-MM-DD HH:MM」（本地时间）。"""
    try:
        if not ts:
            return ""
        ts = float(ts)
    except (TypeError, ValueError):
        return ""
    if not ts:
        return ""
    try:
        now = time.time() if now is None else float(now)
    except (TypeError, ValueError):
        now = time.time()
    t, d = time.localtime(ts), time.localtime(now)
    hm = f"{t.tm_hour:02d}:{t.tm_min:02d}"
    today, day = d.tm_year * 366 + d.tm_yday, t.tm_year * 366 + t.tm_yday   # 用日期序号判断，跨月跨年都对
    if day == today:
        return f"{lang('time_today', '今天')} {hm}"
    if day == today - 1:
        return f"{lang('time_yesterday', '昨天')} {hm}"
    return f"{t.tm_year:04d}-{t.tm_mon:02d}-{t.tm_mday:02d} {hm}"


class Message:

    def __init__(self, kind: str, text: str = "", ts: float | None = None):
        self.kind = kind
        self.text = text if isinstance(text, str) else str(getattr(text, "msg", text) or "")   # 兜底：只收文字
        self.ts = time.time() if ts is None else float(ts)   # 消息时间戳（本地时间显示用）
        self.collapsed = STYLE.get(kind, STYLE["info"])[4]
        self.children: list[Message] = []    # 仅 workflow 使用：本轮的思考、工具调用和结果
        self.members: list[str] = []         # 仅 workflow 使用：本轮依次出手的工作组成员
        self.who = ""                        # 仅 assistant 使用：给出这段话的成员
        self.staff = ""                      # assistant / chat：说这段话的前台（聊天里画它的头像和名字）
        if kind in AVATAR_KINDS:
            try:
                self.staff = active_staff()
            except Exception:
                self.staff = "fish"
        self.image = ""                      # 仅 image 使用：图片路径（点卡片用系统看图软件打开）
        self._img_key = None
        self._img = None
        self._cache_key = None
        self.options: list[str] = []      # choice 消息：选项列表
        self.checked: set[int] = set()    # choice 消息：勾中的选项下标
        self.custom = ""                  # choice 消息：主人自己写的回答
        self.done = False                 # choice 消息：已经提交了
        self.req = None                   # choice 消息：等待结果的 ChoiceRequest
        self._lines = []

    def image_surface(self, max_w: int, max_h: int):
        """按卡片大小缩放后的图片（缓存）；读不出来返回 None。"""
        if self._img_key != (max_w, max_h):
            self._img_key = (max_w, max_h)
            try:
                raw = pygame.image.load(self.image)
                k = min(1.0, max_w / raw.get_width(), max_h / raw.get_height())
                self._img = pygame.transform.smoothscale(
                    raw.convert_alpha() if pygame.display.get_surface() else raw,
                    (max(1, int(raw.get_width() * k)), max(1, int(raw.get_height() * k))))
            except (pygame.error, OSError, ZeroDivisionError):
                self._img = None
        return self._img

    def lines(self, font, width) -> list[str]:
        key = (len(self.text), width, font)
        if key != self._cache_key:
            self._lines = wrap(font, self.text.rstrip("\n"), width)
            self._cache_key = key
        return self._lines


class Button:

    def __init__(self, label, callback, color=None):
        self.label, self.callback = label, callback
        self.color = color
        self.rect = pygame.Rect(0, 0, 0, 0)
        self.enabled = True

    def draw(self, surf, font, mouse):
        base = self.color or C["btn"]
        if not self.enabled:
            base = tuple(int(c * 0.6) for c in base)
        elif self.rect.collidepoint(mouse):
            base = mix(base, C["hdr"], 0.15)
        pygame.draw.rect(surf, base, self.rect, border_radius=S(8))
        if not self.enabled:
            text_c = (150, 150, 150) if is_dark(base) else (180, 180, 180)
        else:
            text_c = C["on_text"] if is_dark(base) else C["text"]
        if isinstance(self.label, Glyph):           # 自绘图标：不渲染字形，直接画图形
            side = max(6, min(self.rect.w, self.rect.h) - S(12))
            box = pygame.Rect(0, 0, side, side)
            box.center = self.rect.center
            self.label.render(surf, box, text_c)
            return
        t = utext(font, self.label, text_c)
        surf.blit(t, t.get_rect(center=self.rect.center))

    def click(self, pos):
        if self.enabled and self.rect.collidepoint(pos):
            self.callback()
            return True
        return False


class ScrollView:
    """一个可滚动卡片区的滚动状态；stick=True 时自动跟到底部。"""

    def __init__(self):
        self.scroll = 0
        self.stick = True

    def wheel(self, dy: int):
        self.scroll -= dy
        self.stick = False


class FileTree:
    """左栏：工作区目录树。只展开 Agent 访问过的目录和用户点开的目录。"""

    def __init__(self):
        self.root: Path | None = None
        self.expanded: set[str] = set()
        self.rows: list[tuple[str, int, bool]] = []   # (相对路径, 深度, 是否目录)
        self.status: dict[str, str] = {}              # 相对路径 -> read / modified / new
        self.focus: str | None = None
        self.focus_tool = ""
        self.scroll = 0
        self.scroll_to_focus = False
        self.dirty = True

    def set_root(self, root: Path):
        self.root = root
        self.expanded = {""}
        self.status.clear()
        self.focus = None
        self.scroll = 0
        self.dirty = True

    def rel(self, path: str) -> str | None:
        """把 Agent 给的路径规范成相对 posix 路径；越界返回 None。"""
        if not self.root:
            return None
        try:
            p = (self.root / (path or ".")).resolve().relative_to(self.root)
        except (ValueError, OSError):
            return None
        s = p.as_posix()
        return "" if s == "." else s

    def rebuild(self):
        rows = []

        def walk(rel: str, depth: int):
            try:
                entries = sorted(os.scandir(self.root / rel if rel else self.root),
                                 key=lambda e: (not e.is_dir(), e.name.lower()))
            except OSError:
                return
            for e in entries:
                if e.name in da.IGNORE_DIRS or len(rows) > 3000:
                    continue
                r = f"{rel}/{e.name}" if rel else e.name
                is_dir = e.is_dir()
                rows.append((r, depth, is_dir))
                if is_dir and r in self.expanded:
                    walk(r, depth + 1)

        if self.root:
            walk("", 0)
        self.rows = rows
        self.dirty = False

    def reveal(self, rel: str, tool: str, is_dir: bool):
        parts = rel.split("/") if rel else []
        for i in range(len(parts)):
            self.expanded.add("/".join(parts[:i]))
        if is_dir:
            self.expanded.add(rel)
        self.focus, self.focus_tool = rel, tool
        self.scroll_to_focus = True
        self.dirty = True

    def toggle(self, rel: str):
        self.expanded.symmetric_difference_update({rel})
        self.dirty = True


def _hex_rgb(text, default=(60, 60, 60)):
    """把 "#RRGGBB" / "R,G,B" 解析成 (r, g, b)；认不出来就用 default。"""
    try:
        t = str(text).strip()
        if t.startswith("#"):
            t = t[1:]
            if len(t) >= 6:
                return tuple(int(t[i:i + 2], 16) for i in (0, 2, 4))
        elif "," in t:
            parts = [int(float(v)) for v in t.split(",")[:3]]
            if len(parts) == 3:
                return tuple(max(0, min(255, v)) for v in parts)
    except (TypeError, ValueError):
        pass
    return default


BOARD_TOOL_NAMES = {"brush": "毛笔", "pencil": "铅笔", "marker": "马克笔", "airbrush": "喷枪",
                    "fill": "油漆桶", "shape": "图形", "text": "文字", "eraser": "橡皮",
                    "swap": "换色", "palette": "配色", "undo": "撤销", "clear": "清空", "canvas": "画布"}


class BoardPanel:
    """右栏：画板。显示 ~/.terminist/board/board.png 和当前画笔信息。
    图片按文件 mtime 缓存（变了才重新加载），路径写死成用户目录，不 import base。"""

    def __init__(self):
        self.dir = Path.home() / ".terminist" / "board"
        self.path = self.dir / "board.png"
        self.strokes = self.dir / "strokes.json"
        self.open = False        # 画板区块当前是否展开（由 A库 的 board 事件开关）
        self.scroll = 0          # 图比区块高时的滚动量
        self._key = None         # 缓存签名 (mtime_ns, max_w, max_h)
        self._img = None

    def set_open(self, value: bool):
        """开 / 收画板；展开时滚动回到顶部。"""
        self.open = bool(value)
        if self.open:
            self.scroll = 0

    def surface(self, max_w: int, max_h: int):
        """按比例缩放到放得下并居中用的 Surface；文件不存在或读不出来返回 None。"""
        try:
            st = self.path.stat()
        except OSError:
            self._key, self._img = None, None
            return None
        key = (st.st_mtime_ns, max_w, max_h)
        if key == self._key:
            return self._img
        self._key = key
        try:
            raw = pygame.image.load(str(self.path))
            k = min(1.0, max_w / max(1, raw.get_width()), max_h / max(1, raw.get_height()))
            self._img = pygame.transform.smoothscale(
                raw.convert_alpha() if pygame.display.get_surface() else raw,
                (max(1, int(raw.get_width() * k)), max(1, int(raw.get_height() * k))))
        except (pygame.error, OSError, ZeroDivisionError, ValueError):
            self._img = None
        return self._img

    def info(self) -> tuple:
        """(工具名, 颜色 #RRGGBB, 画布 "1024×768", 笔数)：读 strokes.json，读不出来给默认值。"""
        tool, color, size, n = "毛笔", "#333333", "1024×768", 0
        try:
            doc = json.loads(self.strokes.read_text(encoding="utf-8"))
            if isinstance(doc, dict):
                size = f"{int(doc.get('width') or 1024)}×{int(doc.get('height') or 768)}"
                color = str(doc.get("color") or color)
                ops = doc.get("strokes") or []
                n = len(ops)
                name = doc.get("tool") or (ops[-1].get("tool") if ops and isinstance(ops[-1], dict) else "")
                tool = BOARD_TOOL_NAMES.get(name, tool)
        except (OSError, ValueError, TypeError):
            pass
        return tool, color, size, n


class WritePanel:
    """右栏：显示 Agent 正在写入的内容（流式），或文件预览。"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.tool = ""          # write_file / edit_file / preview
        self.raw = ""           # 工具参数原始 JSON（可能不完整）
        self.path = ""
        self.status = ""
        self.preview_text = ""
        self.scroll = 0
        self.stick = True
        self.version = 0
        self._cache = (None, [])

    def start(self, tool: str, raw: str = ""):
        self.reset()
        self.tool, self.raw = tool, raw
        self.status = "生成中…"
        self.version += 1

    def feed(self, delta: str):
        self.raw += delta
        self.version += 1

    def show_preview(self, path: str, text: str):
        self.reset()
        self.tool, self.path, self.preview_text, self.status = "preview", path, text, "预览"
        self.stick = False

    def segments(self) -> list[tuple[str, str]]:
        """返回 [(类型, 文本)]，类型: new / old / plain"""
        if self.tool == "preview":
            return [("plain", self.preview_text)]
        self.path = partial_json_str(self.raw, "path") or self.path
        if self.tool == "write_file":
            return [("new", partial_json_str(self.raw, "content") or "")]
        old = partial_json_str(self.raw, "old_str")
        new = partial_json_str(self.raw, "new_str")
        segs = []
        if old is not None:
            segs.append(("old", old))
        if new is not None:
            segs.append(("new", new))
        return segs

    def lines(self, font, width) -> list[tuple[str, str, str]]:
        """折行后的 [(行号文本, 类型, 内容)]，按 (版本, 宽度) 缓存。"""
        key = (self.version, width, CODE_SIZE)
        if self._cache[0] == key:
            return self._cache[1]
        out = []
        for kind, text in self.segments():
            for n, line in enumerate(text.split("\n"), 1):
                for j, seg in enumerate(wrap(font, line, width)):
                    if j:
                        num = ""
                    elif self.tool == "edit_file":     # 修改时标 -/+，写入/预览时标行号
                        num = "-" if kind == "old" else "+"
                    else:
                        num = str(n)
                    out.append((num, kind, seg))
        self._cache = (key, out)
        return out


# ============================================================
# 投影主窗口：屏幕上留一块常驻投影壳，真窗口在屏幕外送帧 / 收转发输入
# ============================================================

_PROJ_EVENTS = {"mousemotion": pygame.MOUSEMOTION, "mousedown": pygame.MOUSEBUTTONDOWN,
                "mouseup": pygame.MOUSEBUTTONUP, "mousewheel": pygame.MOUSEWHEEL,
                "keydown": pygame.KEYDOWN, "keyup": pygame.KEYUP,
                "textinput": pygame.TEXTINPUT, "textediting": pygame.TEXTEDITING}


def _proj_dir(name: str, default: Path) -> Path:
    """取 project 里定义的路径常量（壳和真窗口约定好的目录），没有就按约定拼。"""
    try:
        return Path(getattr(project, name, default))
    except Exception:
        return Path(default)


def proj_base_dir() -> Path:
    return _proj_dir("PROJ_DIR", Path.home() / ".terminist" / "proj")


def proj_frame_file(pid: int) -> Path:
    """帧文件：真窗口写 <pid>.bmp，投影壳读它（写完改名，壳永远读到完整的一帧）。"""
    try:
        fn = getattr(project, "frame_path", None)
        if fn is not None:
            return Path(fn(pid))
    except Exception:
        pass
    return _proj_dir("FRAME_DIR", proj_base_dir() / "frames") / f"{pid}.bmp"


def proj_ev_file(pid: int) -> Path:
    """事件文件：壳把鼠标/键盘事件 append 成 JSON 行，真窗口 poll 后清空。"""
    return _proj_dir("EV_DIR", proj_base_dir() / "ev") / f"{pid}.jsonl"


def proj_write_target(pid: int) -> None:
    """告诉壳把转发的事件写给哪个真窗口（pid 变了壳就换文件）。"""
    try:
        path = _proj_dir("TARGET", proj_base_dir() / "target.pid")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(int(pid)), encoding="utf-8")
    except Exception:
        pass


def proj_cleanup_frames(folder: Path, keep: str, age: float = 5.0) -> None:
    """清掉别的进程留下的旧帧：只删比 keep 这份老 age 秒以上的，保证壳随时有一张完整的 .bmp 可读。"""
    try:
        now = time.time()
        for p in folder.iterdir():
            if p.name == keep or p.suffix not in (".bmp", ".done"):
                continue
            try:
                if now - p.stat().st_mtime > age:
                    p.unlink()
            except OSError:
                pass
    except Exception:
        pass


_PROJ_TEXT_KEYS = {"space": " ", "return": "\r", "tab": "\t", "backspace": "\b", "period": ".",
                   "comma": ",", "minus": "-", "plus": "+", "slash": "/", "backslash": "\\",
                   "semicolon": ";", "quote": "'", "left bracket": "[", "right bracket": "]",
                   "equals": "=", "backquote": "`"}


def proj_text_of(d) -> str:
    """壳转发的一条 keydown -> 该插入的字符（认单字符键和常见标点键，其余返回空串）。"""
    try:
        name = str(d.get("key", ""))
        mod = int(d.get("mod", 0) or 0)
        ch = _PROJ_TEXT_KEYS.get(name)
        if ch is not None:
            return ch
        if len(name) == 1:
            if mod & pygame.KMOD_SHIFT or mod & getattr(pygame, "KMOD_CAPS", 0):
                return name.upper()
            return name
        return ""
    except Exception:
        return ""


def proj_to_event(d) -> object:
    """壳转发的 JSON 事件 -> pygame 事件（只认鼠标/键盘六种，其它返回 None）。"""
    try:
        kind = _PROJ_EVENTS.get(str(d.get("type", "")))
        if kind is None:
            return None
        x, y = int(d.get("x", 0)), int(d.get("y", 0))
        btn = int(d.get("button", 0))
        if kind == pygame.MOUSEMOTION:
            return pygame.event.Event(kind, {"pos": (x, y), "rel": (0, 0), "buttons": (0, 0, 0)})
        if kind in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            return pygame.event.Event(kind, {"pos": (x, y), "button": btn})
        if kind == pygame.MOUSEWHEEL:                           # 以前从 button 取滚动量（永远是 0），滚轮没反应
            return pygame.event.Event(kind, {"x": x, "y": y})
        if kind == pygame.TEXTINPUT:                            # 输入法上屏 / 普通打字：壳转来的真文字
            return pygame.event.Event(kind, {"text": str(d.get("text", ""))})
        if kind == pygame.TEXTEDITING:                          # 输入法拼写中
            return pygame.event.Event(kind, {"text": str(d.get("text", "")), "start": int(d.get("start", 0)),
                                             "length": int(d.get("length", 0))})
        raw = d.get("key", 0)
        try:
            key = int(raw)
        except (TypeError, ValueError):                     # 壳转发的是键名（"a"、"space"）：换成键码
            try:
                key = pygame.key.key_code(str(raw))
            except Exception:
                key = 0
        return pygame.event.Event(kind, {"key": key, "mod": int(d.get("mod", 0)),
                                         "unicode": proj_text_of(d)})
    except Exception:
        return None


def proj_events_for(d) -> list:
    """一条壳转发的事件 -> 要注入自己的事件列表。
    文字只认壳转来的 TEXTINPUT / TEXTEDITING（输入法和普通打字都走它）；以前从按键自己编出字母来，
    打拼音时会把 n-i-h-a-o 当成字母直接塞进输入框。"""
    pe = proj_to_event(d)
    return [] if pe is None else [pe]


def set_window_identity(hwnd: int) -> bool:
    """给窗口设 AUMID + 重新启动信息（名字 / 图标 / 命令）：任务栏按钮悬停显示「Terminist」而不是 pythonw.exe 里写的
    「Python」，固定到任务栏后点开跑的是 Terminist.exe。必须在窗口第一次显示之前设，显示以后再设任务栏不认。"""
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        import ctypes
        import uuid
        from ctypes import wintypes

        class GUID(ctypes.Structure):
            _fields_ = [("d1", ctypes.c_uint32), ("d2", ctypes.c_uint16), ("d3", ctypes.c_uint16),
                        ("d4", ctypes.c_ubyte * 8)]

        class PKEY(ctypes.Structure):
            _fields_ = [("fmtid", GUID), ("pid", wintypes.DWORD)]

        class PROPVARIANT(ctypes.Structure):
            _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort),
                        ("r3", ctypes.c_ushort), ("val", ctypes.c_void_p), ("pad", ctypes.c_void_p)]

        def guid(s):
            u = uuid.UUID(s)
            return GUID(u.fields[0], u.fields[1], u.fields[2], (ctypes.c_ubyte * 8)(*u.bytes[8:]))

        root = da.APP_ROOT
        exe = root / "Terminist.exe"
        if exe.is_file():
            command = f'"{exe}"'
        else:                                        # 源码版没有启动器：用 pythonw 跑 run.py
            py = Path(sys.executable)
            py = py.with_name("pythonw.exe") if py.with_name("pythonw.exe").is_file() else py
            command = f'"{py}" "{root / "run.py"}"'
        ico = root / "icon.ico"
        values = [(2, command), (4, "Terminist"), (5, "Terminist")]   # RelaunchCommand / DisplayName / ID（ID 最后设）
        if ico.is_file():
            values.insert(1, (3, f"{ico},0"))          # RelaunchIconResource
        ctypes.windll.ole32.CoInitialize(None)
        shell32 = ctypes.windll.shell32
        shell32.SHGetPropertyStoreForWindow.argtypes = [wintypes.HWND, ctypes.POINTER(GUID),
                                                         ctypes.POINTER(ctypes.c_void_p)]
        store = ctypes.c_void_p()
        iid = guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")          # IID_IPropertyStore
        if shell32.SHGetPropertyStoreForWindow(int(hwnd), ctypes.byref(iid), ctypes.byref(store)) != 0 or not store:
            return False
        vtbl = ctypes.cast(ctypes.cast(store, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
        set_value = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(PKEY),
                                       ctypes.POINTER(PROPVARIANT))(vtbl[6])
        commit = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vtbl[7])
        release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
        ok = True
        try:
            for pid, text in values:
                buf = ctypes.create_unicode_buffer(text)
                pv = PROPVARIANT(vt=31, val=ctypes.cast(buf, ctypes.c_void_p))          # VT_LPWSTR（存储会自己拷一份）
                key = PKEY(guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid)          # PKEY_AppUserModel_*
                ok = set_value(store, ctypes.byref(key), ctypes.byref(pv)) == 0 and ok
            ok = commit(store) == 0 and ok
        finally:
            release(store)
        return ok
    except Exception:
        return False


# ============================================================
# 主程序
# ============================================================
class App:

    def __init__(self, folder: str | None):
        pygame.init()
        # 进程 AUMID 和 toast 脚本用的一致，点通知才能唤回本进程（无快捷方式也能弹自定义来源）
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Terminist")
        except Exception:
            pass
        pygame.display.set_caption("Terminist")
        icon = da.APP_ROOT / "icon.png"
        if icon.exists():
            try:
                pygame.display.set_icon(pygame.image.load(str(icon)))
            except pygame.error:
                pass
        self.settings = load_settings()
        self.plugin_rects = {}                         # 本帧外接模块的内容区 {key: (surface, Rect)}（点击用）
        self._plugin_hover = None                      # 鼠标当前悬停在外接模块的哪个 key（None=不在任何模块上）
        self.load_modules(quiet=True)                  # 外接模块（modules/ 文件夹）：先登记，停靠状态里才认得它们
        self.dock_state = panels.load_dock(self.settings)   # 面板停靠编排状态（阶段二拖拽嵌入用）
        self._dock_hover = None                        # 拖动时鼠标落在哪个槽 (side, slot_idx)，None=栏外
        self._dock_left_rects = []                     # 本帧左栏各槽 [(key, Rect)]，视觉顺序
        self._dock_right_rects = []                    # 本帧右栏各槽 [(key, Rect)]
        self._dock_hide_rects = []                     # 停靠槽标题条上的 X [(Rect, key)]：draw() 每帧清一次
        self.modules_open = False                      # 左下角「模块管理」面板开着
        self.modules_btn_rect = pygame.Rect(0, 0, 0, 0)
        self.modules_rects = []                        # 模块管理里每条 hidden 面板 [(Rect, key)]
        apply_theme(self.settings.get("theme", "light"))
        self.sys_scale = system_scale()
        self.settings_open = False
        self._panel_anim = 0.0                        # 右栏展开程度：0=收起 1=全展开
        self._panel_tween = _Tween(0.0, 20)           # 右栏展开的帧驱动缓动
        self._right_w_last = None                     # 上一帧右栏实宽（滑出时按它插值）
        self._left_w_last = None                      # 上一帧左栏实宽
        self._left_fade = _Tween(1.0, 1)              # 左栏入场淡入
        self._card_t0: dict = {}                      # 卡片第一次出现的时刻 {id(msg): ticks}
        self._prog_done_tween = _Tween(0.0, 1)        # 进度条已完成格子的快进
        self._dropdown_tween = _Tween(0.0, 14)        # 模型模式下拉框展开
        self._fade_cache: dict = {}                   # 淡入缓存 {key: [签名, Surface, alpha]}
        self.reduce_motion = False                    # 环境要求减少动效（预留，默认关）
        self.flow_log = False                         # 右栏显示工作流日志（默认关，每次滑出都复位）
        self._panel_last_motion = 0.0                 # 上一次鼠标移动的时刻（毫秒）
        self.settings_panel = ""                      # 右栏设置面板正在显示哪个区块（"" = 没选）
        self.settings_focus = None                    # 面板里要滚到并高亮的那一项 key
        self.settings_rects: list[tuple[pygame.Rect, str, object]] = []
        self.settings_scroll = 0                      # 设置面板内容的滚动量
        self.settings_scroll_max = 0                  # 滚动上限（每帧按内容高算）
        self.settings_value_edit = None                # 正在用输入框改哪个设置（None = 没有）
        self.settings_edit_text = ""                   # 数值输入框里的文字
        self.settings_edit_err = ""                    # 数值输入不合法的红字提示
        apply_scale(self.ui_scale())
        self.apply_display()
        self.load_fonts()
        pygame.key.set_repeat(400, 35)
        pygame.key.start_text_input()
        self.clock = pygame.time.Clock()

        self.events: queue.Queue = queue.Queue()
        self.messages: list[Message] = []
        self.chat_btns: list[tuple[pygame.Rect, str]] = []   # 聊天栏右上角的工具按钮 (区域, "clear"/"history")
        self.agent: da.Agent | None = None
        self.chat_agent: da.Agent | None = None    # 第二个常驻 Agent：干活时陪主人闲聊（记忆单独一份）
        self._chat_buf = ""                        # 闲聊 Agent 正在流式输出的文字
        self.ws: GuiWorkspace | None = None
        self.auto_yes = bool(self.settings.get("auto_yes", True))
        self.context = (0, da.CONTEXT_LIMIT)       # 当前上下文 (估算 tokens, 上限)
        self.busy = False
        self.progress = {"total": 0, "done": 0, "label": ""}    # 工作流进度（输入框上方的进度条）
        self.pending_confirm: ConfirmRequest | None = None
        self.pending_credentials: CredentialsRequest | None = None
        self.cred_queue: list = []           # 多个成员同时要账号密码时排队
        self.cred_cursor = 0
        self.cred_rects: list[pygame.Rect] = []
        self.cred_give_rect = pygame.Rect(0, 0, 0, 0)
        self.cred_deny_rect = pygame.Rect(0, 0, 0, 0)
        self.cred_check_rect = pygame.Rect(0, 0, 0, 0)
        self.modal_scroll = 0

        self.model = da.TEAM_MODE                  # 默认工作组模式
        self.models = list(da.MODELS)
        self.current_member = ""                   # 工作组里当前在干活的成员
        self.actual_model = ""
        self.dropdown_open = False
        self.dropdown_rects: list[tuple[pygame.Rect, str]] = []

        self.tree = FileTree()
        self.panel = WritePanel()
        self.board = BoardPanel()                  # 右栏画板区块（A库 抽画板时出现）
        self.stream_calls: dict[int, str] = {}     # 本轮流式工具调用 index -> 工具名
        self.current_call: dict | None = None      # 正在执行的工具 {name, args}
        self.turn_flow: Message | None = None      # 本轮的工作流卡片（思考/工具调用都收在里面）
        self.turn_answer: Message | None = None    # 本轮正在输出的结论

        self.input_text = ""
        self.cursor = 0
        self.composing = ""          # 输入法正在拼写的内容
        self.pending_images: list[str] = []              # 待发图片（发出去才清空）
        self._pending_session_id = str(int(time.time() * 1000000))   # 本次会话的临时图片子目录名，换会话即删旧目录
        self._drop_hover = False   # 有文件拖进窗口但还没松手，聊天栏显示「拖拽到此处」
        self.pending_img_close_rects: list[tuple[pygame.Rect, int]] = []   # 缩略图右上角小✕ (矩形, 下标)，每帧重建
        self.chat_view = ScrollView()
        self.flow_view = ScrollView()
        self.selected_flow: Message | None = None   # 右栏显示哪一轮的工作流；None = 最新一轮
        self.shown_flow_last: Message | None = None
        self.msg_rects: list[tuple[pygame.Rect, Message]] = []
        self.choice_rects: list[tuple[pygame.Rect, Message, int]] = []   # 聊天框内嵌选项按钮 (矩形, 消息, 选项索引)
        self._card_h_cache: dict[tuple, tuple] = {}   # 卡片高度缓存 {key: (消息, 高度)}：历史长时不用每帧全部折行
        self.flow_rects: list[tuple[pygame.Rect, Message]] = []
        self.flow_rect = pygame.Rect(0, 0, 0, 0)
        self.write_rect = pygame.Rect(0, 0, 0, 0)
        self.panel_close_rect = pygame.Rect(0, 0, 0, 0)
        self.tree_rects: list[tuple[pygame.Rect, str, bool]] = []
        self.sizes = self.clamp_sizes(self.default_sizes())   # 存档脏数据也拖不出窗口
        self.drag_mode = ""                    # 正在拖哪条分隔条："" / "left" / "right" / "input"
        self.drag_cursor = None

        self.btn_model = Button("", self.on_toggle_dropdown)
        self.btn_clear = Button(lang("clear_chat"), self.on_clear)
        self.btn_clearview = Button(lang("clear_view"), self.on_clear_view)
        self.btn_stop = Button(lang("stop"), self.on_stop, C["btn_danger"])
        self.btn_restart = Button(lang("restart"), self.on_restart, (170, 120, 40))
        self.restart_needed = False          # B库 交工了需要重启的改动
        self.quit_requested = False
        self.restart_version = ""            # 交工前的存档名：新版本启动失败时 run.py 用它回滚
        self.restart_at = 0                  # 自动重启的时间点（pygame ticks），0 = 不自动重启
        self.worker_cards: dict[int, Message] = {}   # 执行成员编号 -> 右栏卡片
        self.worker_calls: dict[int, dict] = {}      # 执行成员编号 -> 正在执行的工具
        self.active_workers: set[int] = set()
        self.pending_stops: list = []        # 在子线程里请求停止：排到主线程下一帧再做
        self.confirm_queue: list = []        # 多个执行成员同时请求确认时排队
        self.btn_send = Button(lang("send"), self.on_send, (50, 100, 190))
        self.btn_candy = Button(Glyph("candy", S(18)), self.on_candy)      # 发送按钮右边的发糖果按钮
        self._candy_bursts = []                  # 正在飘的糖果特效（点糖果按钮时放）
        self.top_buttons = [self.btn_model, self.btn_clear, self.btn_clearview, self.btn_stop]
        self.modal_buttons = [
            Button(lang("allow"), lambda: self.answer_confirm(True), C["btn_on"]),
            Button(lang("deny"), lambda: self.answer_confirm(False), C["btn_danger"]),
            Button(lang("allow_all"), lambda: self.answer_confirm(True, always=True)),
        ]

        notice = os.environ.pop("TERMINIST_NOTICE", "")
        import run as _launcher
        _launcher.splash(0.55, "正在启动 Agent 进程")
        if folder:
            self.set_workspace(folder)
        else:
            self.add("info", "没有打开文件夹：可以直接聊天。要让 Terminist 改文件，直接说‘打开桌面的某个文件夹’。")
            self.ensure_agent()
        if notice:
            self.add("b_stage", notice)
        self.hot_state()

    def hot_state(self):
        """界面状态的默认值。启动时和每次热刷新后都会调用：新加的界面状态写在这里（用 setdefault），已有的不受影响。"""
        d = self.__dict__
        d.setdefault("toast", None)              # 左下角全局通知 {text, at}，None=没有
        d.setdefault("economy", None)            # 经济栏数据（context 事件下发的 token 累计），None=还没收到
        d.setdefault("penalty", lib_b.penalty.scores())
        d.setdefault("progress", {"total": 0, "done": 0, "label": ""})   # 工作流进度（A库 用 worker_progress 上报）
        d.setdefault("takeover_active", False)       # 接管模式开着没（黄色按钮 / /接管）
        d.setdefault("takeover_paused", False)       # 接管中按 P 暂停
        d.setdefault("refresh_count", 0)
        d.setdefault("sel_anchor", None)             # 输入框选择的起点（None = 没有选择）
        d.setdefault("dragging_input", False)        # 正在用鼠标在输入框里拖选
        d.setdefault("sizes", self.default_sizes())  # 左栏宽 / 右栏宽 / 输入框高（设置里存过就用设置）
        d.setdefault("drag_mode", "")                # 正在拖分隔条："" / "left" / "right" / "input"
        d.setdefault("drag_cursor", None)            # 上次给分隔条设的光标（None = 普通箭头）
        d.setdefault("input_rect", None)             # 输入框位置（画的时候记下来，点击时用）
        d.setdefault("input_first", 0)               # 输入框里第一行显示的是第几行
        d.setdefault("input_text_x", None)           # 输入框文字区左边界（左边有图片缩略图时右移）
        d.setdefault("btn_voice", Button(Glyph("mic", S(18)), self.on_voice))   # 输入框右边的语音输入按钮
        d.setdefault("btn_image", Button("+", self.on_pick_image))               # 语音按钮左边的选图按钮
        d.setdefault("btn_candy", Button(Glyph("candy", S(18)), self.on_candy))  # 发送按钮右边的发糖果按钮
        d.setdefault("_candy_bursts", [])            # 正在飘的糖果特效
        d.setdefault("_candy_slot", None)            # 糖果按钮的槽位（None = 下一帧重新找）
        d.setdefault("_voice_rec", None)             # 正在录音的 VoiceRecorder（None = 没在录）
        d.setdefault("_voice_busy", False)           # 正在后台把录音转成文字
        d.setdefault("ibeam", False)
        d.setdefault("restarting", None)             # 正在进行的重启（等新窗口就绪）
        d.setdefault("shell_pid", None)              # 屏幕上那块投影壳的 pid（None = 没开投影，真窗口自己显示）
        d.setdefault("proj_last_send", 0)            # 上一次把画面帧送给壳的时刻（限流 30fps）
        d.setdefault("shell_rect_now", None)         # 壳在屏幕上的位置尺寸 (x, y, w, h)
        d.setdefault("restart_after_turn", False)    # Agent 要求重启：等这一轮回复完
        d.setdefault("pending_delete", None)         # 正在显示的删除确认
        d.setdefault("delete_queue", [])
        d.setdefault("delete_rects", [])
        d.setdefault("pending_credentials", None)    # 正在显示的账号密码弹窗
        d.setdefault("pending_need", None)           # Agent 卡住要东西的弹窗
        d.setdefault("need_queue", [])
        d.setdefault("cred_queue", [])               # 排队等的账号密码请求
        d.setdefault("cred_cursor", 0)               # 弹窗里当前焦点：0 = 账号，1 = 密码
        d.setdefault("cred_rects", [])               # 两个输入框的位置（点击时用）
        d.setdefault("cred_give_rect", pygame.Rect(0, 0, 0, 0))
        d.setdefault("cred_deny_rect", pygame.Rect(0, 0, 0, 0))
        d.setdefault("cred_check_rect", pygame.Rect(0, 0, 0, 0))
        d.setdefault("modal_scroll", 0)              # 弹窗里详情 / 勾选列表的滚动量
        d.setdefault("modal_item_rects", [])         # 勾选式弹窗里每条条目的可点区域 [(矩形, 条目)]
        d.setdefault("modal_all_rect", pygame.Rect(0, 0, 0, 0))   # 「全选 / 全不选」小按钮
        d.setdefault("pending_stops", [])            # 子线程请求的停止：排到主线程下一帧再做
        if "modal_notice_buttons" not in d:          # 提示弹窗（例如「已退出接管」）：只有一个「知道了」
            d["modal_notice_buttons"] = [Button("知道了", lambda: self.answer_confirm(True), C["btn_on"])]
        if "modal_takeover_buttons" not in d:        # 接管模式的确认框：只有「确定」和「取消」两个按钮
            d["modal_takeover_buttons"] = [Button(lang("cancel"), lambda: self.answer_confirm(False)),
                                           Button("确定", lambda: self.answer_confirm(True), C["btn_on"])]
        if "modal_clear_buttons" not in d:           # 清空对话的确认框：只有「清空」和「取消」两个按钮
            d["modal_clear_buttons"] = [Button(lang("cancel"), lambda: self.answer_confirm(False)),
                                        Button(lang("confirm_clear_ok"),
                                               lambda: self.answer_confirm(True), C["btn_danger"])]
        self.staff_panel = True                      # 旧的「员工栏 显示 / 隐藏」设置删了：显示 / 隐藏归模块管理   # 左栏顶部显示员工面板
        d.setdefault("board", BoardPanel())          # 右栏画板区块（热刷新后补上）
        d.setdefault("board_hide_rect", pygame.Rect(0, 0, 0, 0))   # 画板区块右上角「收起」按钮
        d.setdefault("board_img_rect", pygame.Rect(0, 0, 0, 0))    # 画板图的显示区域（滚动 / 命中用）
        d.setdefault("board_rect", pygame.Rect(0, 0, 0, 0))        # 画板区块整块的区域（滚轮命中用）
        d.setdefault("auto_hide_panels", False)      # 右栏（工作流栏）默认常驻；开着才按需收起
        d.setdefault("_panel_anim", 0.0)             # 右栏展开程度：0=收起 1=全展开（动画中间值）
        d.setdefault("_panel_tween", _Tween(0.0, 20))    # 右栏展开的帧驱动缓动
        d.setdefault("_right_w_last", None)              # 上一帧右栏实宽（滑出时按它插值）
        d.setdefault("_left_w_last", None)               # 上一帧左栏实宽
        d.setdefault("_left_fade", _Tween(1.0, 1))       # 左栏入场淡入
        d.setdefault("_card_t0", {})                     # 卡片第一次出现的时刻 {id(msg): ticks}
        d.setdefault("_prog_done_tween", _Tween(0.0, 1))  # 进度条已完成格子的快进
        d.setdefault("_dropdown_tween", _Tween(0.0, 14))  # 模型模式下拉框展开
        d.setdefault("_fade_cache", {})                   # 淡入缓存 {key: [签名, Surface, alpha]}
        d.setdefault("reduce_motion", False)              # 环境要求减少动效（预留，默认关）
        d.setdefault("_prog_total_last", 0)               # 上一帧进度条的总格数（换轮时把快进对齐）
        d.setdefault("_panel_last_motion", 0.0)      # 上一次鼠标移动的时刻（毫秒）
        d.setdefault("_panel_tick_at", 0)            # 上次推进显隐动画的时刻（毫秒）
        d.setdefault("_avatar_cache", {})            # 员工头像缓存 {(员工, 尺寸): Surface 或 False}
        d.setdefault("pending_turns", [])            # 重启后自检等要自动发的消息
        d.setdefault("side", None)                   # 边干活边聊：旁聊 Agent（和干活的 Agent 共用记忆和现场）
        d.setdefault("paused", False)                # 工作流暂停中
        d.setdefault("btn_pause", Button("暂停", self.on_pause_toggle, C["warn"]))
        d.setdefault("selftest_done", False)         # 本次进程是否已经处理过自检标记
        d.setdefault("_selftest_turn", False)        # 正在跑的这一轮是重启后自检（结论只进工作流日志）
        d.setdefault("_selftest_note", "")           # 这次自检要重点验证什么（写进工作流日志用）
        d.setdefault("chat_agent", None)             # 第二个常驻 Agent：干活时陪主人闲聊
        d.setdefault("_chat_buf", "")                # 闲聊 Agent 正在流式输出的文字
        d.setdefault("flow_log", False)              # 右栏显示工作流日志（默认关：右栏只显示这一轮的卡片）
        d.setdefault("log_view", ScrollView())
        d.setdefault("log_cache", None)              # (日志文件修改时间, 宽度, 折好行的 [(行, 颜色)])
        d.setdefault("log_checked", 0)               # 上次检查日志文件的时间（毫秒），不每帧都去读
        d.setdefault("_card_h_cache", {})            # 卡片高度缓存：只对可见区附近的消息真折行
        d.setdefault("log_rects", [])                # 右栏标题上的 "日志" / "打开文件" 按钮
        d.setdefault("key_edit", None)               # 设置里正在输入的新 API key（None = 没在改）
        d.setdefault("key_msg", ("", "dim"))         # 换 key 的结果提示 (文字, 颜色名)
        d.setdefault("key_checking", False)          # 正在后台试新 key
        d.setdefault("screen_shot", None)            # 左栏小屏幕现在显示的网页截图
        d.setdefault("screen_next", 0)               # 下次该截图的时间（毫秒）
        d.setdefault("screen_last", None)            # 截图图像的引用，防止被回收
        d.setdefault("screen_rect", pygame.Rect(0, 0, 0, 0))   # 小屏幕区域
        d.setdefault("screen_pending", [])           # 小屏幕上手动排队的动作（A库 下次调用时取走）
        d.setdefault("screen_mark", None)            # 小屏幕上标好的网页坐标 (x, y)
        d.setdefault("screen_img_rect", pygame.Rect(0, 0, 0, 0))   # 画面在窗口里的位置（坐标换算用）
        d.setdefault("screen_req", None)             # 正在等结果的截图请求
        d.setdefault("screen_win", None)             # 独立小屏幕窗口（pygame 的第二个 Window 对象）
        d.setdefault("screen_win_open", False)       # 独立窗口当前开没开
        d.setdefault("screen_win_ready", False)      # 已经尝试过创建（失败就不再反复试）
        d.setdefault("screen_topmost", False)        # 是否成功置顶
        d.setdefault("screen_topmost_rect", pygame.Rect(0, 0, 0, 0))   # 自绘标题条里的置顶按钮矩形（命中判定用）
        d.setdefault("screen_close_rect", pygame.Rect(0, 0, 0, 0))     # 自绘标题条里的关闭按钮矩形（命中判定用）
        d.setdefault("screen_esc_at", 0)             # 上一次按 Esc 的时刻（连按两次才算关）
        d.setdefault("screen_esc_hint_at", 0)        # 提示「再按一次 Esc」的时刻
        d.setdefault("screen_mouse_pos", None)       # 独立窗口里最后的鼠标位置（滚轮换算用）
        d.setdefault("screen_panel_rect", pygame.Rect(0, 0, 0, 0))   # 左栏的小屏幕提示面板
        d.setdefault("screen_open_btn_rect", pygame.Rect(0, 0, 0, 0))   # 左栏小屏幕区块已不再有按钮，恒为空 Rect
        d.setdefault("screen_fail_at", 0)            # 上次截图失败的时刻（预留）
        d.setdefault("screen_result", None)          # 小屏幕底部提示条现在要显示的 (文字, 是否成功, 时刻)
        d.setdefault("screen_status", None)          # 小屏幕最近一次操作的 (文字, 是否成功, 时刻)
        d.setdefault("screen_resizing", False)       # 正在拖右下角手柄缩独立窗口
        d.setdefault("screen_resize_from", (0, 0, 0, 0))   # 缩放起点 (宽, 高, 鼠标 x, 鼠标 y)
        d.setdefault("screen_status_until", 0)       # 提示条上的结果留到什么时候（毫秒）
        d.setdefault("settings_scroll", 0)           # 设置面板内容的滚动量
        d.setdefault("settings_open", False)         # 右栏正在显示设置面板
        d.setdefault("settings_panel", "")           # 设置面板显示的是哪个区块
        d.setdefault("settings_focus", None)         # 面板里要高亮的那一项
        d.setdefault("spot_rects", [])               # 右栏每块标题上的设置图标 [(Rect, panel, title)]
        d.setdefault("panel_icon_rects", [])         # 左栏底部那排区块图标 [(Rect, panel)]
        d.setdefault("_dock_hide_rects", [])         # 停靠槽标题条上的 X [(Rect, key)]，draw() 每帧只清一次
        d.setdefault("modules_open", False)          # 左下角「模块管理」面板开着
        d.setdefault("modules_btn_rect", pygame.Rect(0, 0, 0, 0))   # 左下角「模块」按钮
        d.setdefault("modules_rects", [])            # 模块管理面板里每条 hidden 面板 [(Rect, key)]
        d.setdefault("staff_rects", [])              # 员工面板每一行的矩形 [(Rect, name)]
        d.setdefault("staff_scroll", 0)              # 员工列表的滚动量
        d.setdefault("staff_content_h", 0)           # 员工列表内容总高（滚轮夹取用）
        d.setdefault("staff_last_rect", pygame.Rect(0, 0, 0, 0))   # 员工面板可视区
        d.setdefault("staff_menu", None)             # 员工批评菜单是给谁开的 (name, label)，None = 没开
        d.setdefault("staff_menu_at", None)          # 批评菜单挂在那一行的矩形上
        d.setdefault("staff_menu_rects", [])         # 批评菜单每一项的矩形 [(Rect, action)]
        d.setdefault("staff_info", {})               # 员工栏这一帧画的员工信息 name -> info
        d.setdefault("staff_head_rect", pygame.Rect(0, 0, 0, 0))    # 员工栏标题条（拖动它就拖出成独立窗口）
        d.setdefault("staff_panel_rect", pygame.Rect(0, 0, 0, 0))   # 员工栏整块矩形
        d.setdefault("staff_placeholder_rect", pygame.Rect(0, 0, 0, 0))   # 拖出去后左栏的占位虚影
        d.setdefault("staff_drag", None)             # 正在从标题条拖员工栏 (起点, 有没有真的拖动)
        d.setdefault("staff_ghost", None)            # 拖动中的虚影矩形
        d.setdefault("staff_win", None)              # 独立员工栏窗口（PanelWindow，只做渲染投影）
        d.setdefault("staff_win_open", False)        # 独立员工栏窗口开没开
        d.setdefault("staff_win_rects", [])          # 独立窗口里每一行的矩形（窗口内坐标）
        d.setdefault("staff_win_menu_rects", [])     # 独立窗口里批评菜单每一项的矩形
        d.setdefault("staff_win_area", pygame.Rect(0, 0, 0, 0))     # 独立窗口的内容区（窗口内坐标）
        d.setdefault("staff_win_content_h", 0)       # 独立窗口里员工列表内容总高（滚轮夹取用）
        d.setdefault("staff_win_mouse", None)        # 独立窗口里最后的鼠标位置
        d.setdefault("staff_win_close_rect", pygame.Rect(0, 0, 0, 0))   # 独立窗口标题条上的收起按钮
        d.setdefault("win_drag", None)               # 正在自己拖的小窗口 {key, pw, dx, dy}（_tick_win_drag 每帧推）
        d.setdefault("dock_preview", None)           # 拖着小窗口压在哪一侧：那一侧的栏先滑出来（left / right / None）
        d.setdefault("panel_windows", {})            # key -> 面板独立窗口状态 {win,open,key,close_rect,title_rect}
        d.setdefault("panel_heads", {})              # key -> 该面板标题条矩形（每帧刷新，拖出判定用）
        d.setdefault("panel_drag", None)             # 正在从标题条拖面板 (key, 起点, 有没有真的拖)
        d.setdefault("panel_offsets", {})            # key -> 拖出去的区块在主窗口里空出来的位置（w=0 表示让位）
        d.setdefault("panel_ghost", None)            # 拖动中的虚影矩形（大小跟着被拖的面板）
        d.setdefault("panel_ghost_key", None)        # 虚影是哪个 key 的
        d.setdefault("_dock_hover", None)            # 拖动中鼠标落在哪个槽 (side, slot_idx)
        d.setdefault("_dock_left_rects", [])         # 本帧左栏各槽 [(key, Rect)]
        d.setdefault("_dock_right_rects", [])        # 本帧右栏各槽 [(key, Rect)]
        d.setdefault("_dock_right_rects", [])        # 本帧右栏各槽 [(key, Rect)]
        d.setdefault("_panel_last_drag", None)       # 上一次拖拽状态（读 staff_drag 惰性同步用）
        d.setdefault("staff_win_title_rect", pygame.Rect(0, 0, 0, 0))   # 独立窗口标题条（拖窗口用）
        d.setdefault("staff_card", None)             # 员工信息卡是给谁开的 name，None = 没开
        d.setdefault("staff_card_rects", [])         # 信息卡上的按钮 [(Rect, action)]
        d.setdefault("staff_card_modal", pygame.Rect(0, 0, 0, 0))   # 信息卡底板矩形（点遮罩就关）
        d.setdefault("_staff_dock_at", 0)            # 上次检查「窗口拖回主窗口没有」的时刻
        d.setdefault("goal_q_rects", [])             # 右栏目标队列每条行上的按钮 [(action, 序号, Rect)]
        d.setdefault("settings_scroll_max", 0)       # 设置面板滚动上限
        d.setdefault("settings_value_edit", None)    # 正在用输入框改哪个设置（None = 没有）
        d.setdefault("settings_edit_text", "")       # 数值输入框里的文字
        d.setdefault("settings_edit_err", "")        # 数值输入不合法的红字提示
        d.setdefault("settings_open_dd", None)       # 展开着的下拉式设置项 key
        d.setdefault("settings_slider_drag", None)   # 正在拖的滑杆 key
        d.setdefault("settings_sb_drag", False)      # 正在拖设置面板的滚动条
        d.setdefault("settings_slider_rect", {})     # 滑杆轨道 {key: (轨道 Rect, 选项)}
        d.setdefault("settings_sb_rect", pygame.Rect(0, 0, 0, 0))   # 滚动条轨道
        d.setdefault("settings_body_rect", pygame.Rect(0, 0, 0, 0))  # 设置面板的内容区
        d.setdefault("settings_dd_pending", None)    # 这一帧要展开的下拉 (key, Rect, 选项)
        d.setdefault("live_layout", False)           # 实时拖动布局状态
        base.guard.set_handler(self._delete_handler)  # 所有删除都走这个弹窗（热刷新后换成新代码）
        for k in modules_api.keys():                  # 界面热刷新会把模块列表重置：外接模块重新登记
            if k not in self.PANEL_WINDOW_KEYS:
                self.PANEL_WINDOW_KEYS.append(k)
            p = modules_api.get(k)
            panels.PANELS.setdefault(k, {"side": p["side"], "hidden": True, "title": p["title"]})
        d.setdefault("plugin_rects", {})

    def hot_reload(self, files: list[str], title: str, root: str | None = None):
        """B库 改了界面：重新执行 surface/gui.py，把正在运行的窗口换成新代码。失败就原样退回。
        root 是 B库 临时副本的根目录（从副本加载）；None 表示加载正式版本。"""
        mod = sys.modules[type(self).__module__]
        saved_globals = dict(mod.__dict__)
        old_cls = type(self)
        live_file = Path(mod.__file__)
        src_file = Path(root) / "surface" / "gui.py" if root else live_file
        try:
            exec(compile(src_file.read_text(encoding="utf-8"), str(live_file), "exec"), mod.__dict__)
            new = mod
            new.SETTINGS_FILE = saved_globals["SETTINGS_FILE"]
            new.apply_scale(self.ui_scale())
            new.apply_theme(self.settings.get("theme", "light"))
            self.__class__ = new.App
            self.hot_state()
            self.load_fonts()
            self.draw()                                  # 先试画一帧，画不出来就退回
        except Exception as e:
            mod.__dict__.clear()
            mod.__dict__.update(saved_globals)
            self.__class__ = old_cls
            import traceback
            lib_b.worklog.write("界面", "error", "B库 改到一半的界面试画失败（正式版本没动）：\n" + traceback.format_exc()[-1500:])
            self.add("b_stage", f"界面刷新失败（{type(e).__name__}: {e}），保持原界面；交工重启后再看")
            return
        self.refresh_count += 1
        self.add("b_stage", f"界面已刷新（{title}）：{', '.join(files)}")

    # ---------------- 显示设置 ----------------

    def ui_scale(self) -> float:
        s = self.settings.get("scale", "auto")
        try:
            return self.sys_scale if s == "auto" else float(s)
        except (TypeError, ValueError):
            return self.sys_scale

    def load_fonts(self):
        self.font = load_font(FONT_SIZE)
        self.small = load_font(FONT_SIZE - S(3))
        self.code = load_font(CODE_SIZE)
        self.line_h = self.font.get_linesize()
        self.code_h = self.code.get_linesize()

    @staticmethod
    def _hidden_flag() -> int:
        """开机特效还在放：窗口先藏着建好（照常画），特效放完再露面。"""
        import run as launcher
        return pygame.HIDDEN if launcher.splash_holding() else 0

    def show_after_splash(self) -> None:
        """开机特效放完：起投影壳（或放回原位），再把藏着的真窗口显示出来。"""
        self.start_projection()
        try:
            import warnings
            with warnings.catch_warnings():            # from_display_module 在 pygame-ce 里标了弃用，但还是唯一的现成办法
                warnings.simplefilter("ignore", DeprecationWarning)
                pygame.Window.from_display_module().show()
        except Exception:
            pass
        self._schedule_taskbar_icon()                  # 刚露面：任务栏按钮刚建，图标再补发几次
        self._dirty = True

    def _schedule_taskbar_icon(self) -> None:
        """接下来 1 / 3 / 8 秒各补发一次窗口图标。"""
        now = pygame.time.get_ticks()
        self._icon_fix_at = [now + 1000, now + 3000, now + 8000]

    def _tick_taskbar_icon(self) -> None:
        """任务栏按钮是在窗口刚出现时问窗口要图标的；那会儿主线程还在忙着初始化，问不到就退回 pythonw.exe 的图标，
        之后也不会再问。这里在主循环跑起来以后再用 WM_SETICON 发几次（每次新的图标句柄，任务栏才会刷新），
        顺便把窗口类图标也换掉，任何退回类图标的地方都是 Terminist 的。"""
        if sys.platform != "win32":
            return
        todo = getattr(self, "_icon_fix_at", None)
        if todo is None:
            self._schedule_taskbar_icon()
            return
        now = pygame.time.get_ticks()
        if not todo or now < todo[0]:
            return
        while todo and now >= todo[0]:
            todo.pop(0)
        try:
            import ctypes
            from ctypes import wintypes
            ico = da.APP_ROOT / "icon.ico"
            hwnd = int(pygame.display.get_wm_info().get("window", 0) or 0)
            if not hwnd or not ico.is_file():
                return
            u = ctypes.windll.user32
            u.LoadImageW.restype = wintypes.HANDLE
            u.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int,
                                     wintypes.UINT]
            u.SendMessageW.restype = ctypes.c_ssize_t
            u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
            set_cls = getattr(u, "SetClassLongPtrW", None) or u.SetClassLongW
            set_cls.restype = ctypes.c_size_t
            set_cls.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
            image_icon, load_from_file = 1, 0x10
            big_px = u.GetSystemMetricsForDpi(11, u.GetDpiForWindow(hwnd)) if hasattr(u, "GetDpiForWindow") else 0
            small_px = u.GetSystemMetricsForDpi(49, u.GetDpiForWindow(hwnd)) if hasattr(u, "GetDpiForWindow") else 0
            big = u.LoadImageW(None, str(ico), image_icon, big_px or u.GetSystemMetrics(11),
                               big_px or u.GetSystemMetrics(12), load_from_file)        # SM_CXICON / SM_CYICON
            small = u.LoadImageW(None, str(ico), image_icon, small_px or u.GetSystemMetrics(49),
                                 small_px or u.GetSystemMetrics(50), load_from_file)    # SM_CXSMICON / SM_CYSMICON
            if not big or not small:
                return
            u.SendMessageW(hwnd, 0x0080, 1, big)        # WM_SETICON, ICON_BIG
            u.SendMessageW(hwnd, 0x0080, 0, small)      # WM_SETICON, ICON_SMALL
            set_cls(hwnd, -14, big)                     # GCLP_HICON
            set_cls(hwnd, -34, small)                   # GCLP_HICONSM
            keep = getattr(self, "_icon_handles", [])   # 句柄要一直留着：窗口还在用；旧的两组以前的再释放
            keep.append((big, small))
            while len(keep) > 2:
                for h in keep.pop(0):
                    u.DestroyIcon(wintypes.HANDLE(h))
            self._icon_handles = keep
        except Exception:
            pass

    def apply_display(self):
        # 第一次建窗口：先藏着建好，设完任务栏身份（名字 / 图标 / 固定后的启动命令）再露面——显示以后再设任务栏不认
        first = sys.platform == "win32" and pygame.display.get_surface() is None
        hidden = self._hidden_flag() | (pygame.HIDDEN if first else 0)
        if self.settings["fullscreen"]:
            # (0,0) = 桌面原生分辨率，SDL 会用"桌面全屏"，不切换显示器分辨率
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN | hidden)
        else:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            w, h = WIN_W, WIN_H
            saved = self.settings.get("window_size")
            use_saved = False                        # 存过的可用尺寸 = True，脏数据/首次默认 = False
            try:                                     # 脏数据（None、字符串、0）当没存过，别把窗口开成 0x0
                if isinstance(saved, (list, tuple)) and len(saved) == 2:
                    w, h = int(saved[0]), int(saved[1])
                    if w <= 0 or h <= 0:
                        w, h = WIN_W, WIN_H
                    else:
                        use_saved = True
            except (TypeError, ValueError):
                w, h = WIN_W, WIN_H
            if use_saved:
                # 用户存过的尺寸原样恢复，不再按桌面比例二次压小：只做物理限制（不超桌面、不小于 960x600）
                w = max(960, min(int(w), int(desk_w)))
                h = max(600, min(int(h), int(desk_h)))
            else:                                    # 首次默认尺寸才按桌面比例夹，避免默认窗口超出屏幕
                w = min(int(w), int(desk_w * 0.92))
                h = min(int(h), int(desk_h * 0.88))
            size = (int(w), int(h))
            self.screen = pygame.display.set_mode(size, pygame.RESIZABLE | hidden)
            self.restore_window_pos(size)            # 上次的窗口位置（夹到桌面范围内再挪）
        if first:
            try:
                set_window_identity(int(pygame.display.get_wm_info().get("window", 0) or 0))
            except Exception:
                pass
            if not self._hidden_flag():               # 开机特效在放时照旧等特效放完再露面
                try:
                    import warnings
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", DeprecationWarning)
                        pygame.Window.from_display_module().show()
                except Exception:
                    try:                              # 兜底：绝不能让窗口一直藏着
                        import ctypes
                        ctypes.windll.user32.ShowWindow(int(pygame.display.get_wm_info().get("window", 0) or 0), 5)
                    except Exception:
                        pass
        self._schedule_taskbar_icon()                # 窗口换了模式：任务栏图标再补发几次

    def restore_window_pos(self, size) -> None:
        """启动时把窗口挪回上次的位置：夹到桌面范围内，拿不到位置就保持系统默认，绝不抛异常。"""
        pos = self.settings.get("window_pos")
        try:
            if not (isinstance(pos, (list, tuple)) and len(pos) == 2):
                return
            x, y = int(pos[0]), int(pos[1])
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            w, h = int(size[0]), int(size[1])
            x = max(0, min(x, max(0, int(desk_w) - w)))     # 别把窗口挪到屏幕外
            y = max(0, min(y, max(0, int(desk_h) - h)))
            setter = getattr(pygame.display, "set_window_position", None)
            if setter is None:                               # 旧版 pygame 没有这个接口：跳过
                return
            setter((x, y))
        except Exception:
            pass

    def toggle_fullscreen(self):
        if not self.settings["fullscreen"]:
            self.settings["window_size"] = list(self.screen.get_size())
        self.settings["fullscreen"] = not self.settings["fullscreen"]
        self.apply_display()
        self.save_layout()                      # 全屏状态和窗口尺寸一起立刻落盘

    def window_pos(self):
        """当前窗口位置 [x, y]：拿不到（旧版 pygame / 没有窗口）就返回 None。"""
        try:
            getter = getattr(pygame.display, "get_window_position", None)
            if getter is None:
                return None
            pos = getter()
            if isinstance(pos, (list, tuple)) and len(pos) == 2:
                return [int(pos[0]), int(pos[1])]
        except Exception:
            pass
        return None

    def remember_window_size(self):
        """把当前主窗口尺寸和位置记进 settings 并落盘（全屏时不记，保留全屏前的尺寸和位置）。"""
        try:
            if self.settings.get("fullscreen"):
                return
            surf = pygame.display.get_surface()
            w, h = surf.get_size() if surf is not None else self.screen.get_size()
            w, h = int(w), int(h)
            if w <= 0 or h <= 0:
                return
            changed = False
            if self.settings.get("window_size") != [w, h]:
                self.settings["window_size"] = [w, h]
                changed = True
            pos = None if self.projection_on() else self.window_pos()   # 投影开着：真窗口在屏幕外，别把 -32000 存进去
            if pos and self.settings.get("window_pos") != pos:
                self.settings["window_pos"] = pos
                changed = True
            if changed:                              # 变了才写盘（和尺寸同样节流）
                save_settings(self.settings)
        except Exception:
            pass

    def anim_on(self) -> bool:
        """界面动画开没开（设置里 anim=True 且环境没要求减少动效）。"""
        return bool(self.settings.get("anim", True)) and not getattr(self, "reduce_motion", False)

    def anim_frames(self, frames: int = 20) -> int:
        """把 100% 下的帧数按动画速度换算成实际帧数（关掉动画时返回 1 = 一步到位）。"""
        if not self.anim_on():
            return 1
        sp = float(self.settings.get("anim_speed") or 1.0)
        return max(1, round(frames / max(0.25, min(4.0, sp))))

    def set_scale(self, value):
        """value: "auto" 或缩放比例。"""
        self.settings["scale"] = value
        apply_scale(self.ui_scale())
        self.load_fonts()
        self.clear_card_h_cache()               # 缩放变了：折行宽度和字号都变了
        clear_surface_caches()                  # 旧字号的字图/阴影层一起清掉
        self.panel.version += 1
        save_settings(self.settings)

    # ---------------- 布局 ----------------

    def _auto_hide_on(self) -> bool:
        """（旧的「按需显示两侧栏」设置已删掉：两侧栏现在按有没有模块显示，见 layout()）"""
        return False

    def _panels_need_show(self, left_rect=None, right_rect=None) -> bool:
        """该不该展开右栏：有内容才算有，鼠标悬停不触发。"""
        if not self._auto_hide_on():
            return True
        if self.busy or self.pending_confirm or self.pending_delete or self.settings_open:
            return True
        if self._flow_has_content():
            return True
        return False

    def _flow_has_content(self) -> bool:
        """右栏要显示的那一轮工作流里有没有真内容（只看过程卡片，整屏截图不算）：只有图片卡片的轮次不算有内容。"""
        if self.busy:
            return True
        try:
            flow = self.shown_flow()
        except Exception:
            return True
        if flow is None:
            return False
        return any(getattr(c, "kind", "") != "image" for c in getattr(flow, "children", []) or [])

    def tick_panels(self) -> None:
        """按帧把右栏展开程度推进到目标值（平滑进出，约 120ms 走完），别闪。左栏常驻，不参与收起动画。"""
        if not self._auto_hide_on():
            self._panel_tween.value = self._panel_tween.target = 1.0
            return
        target = 1.0 if self._panels_need_show() else 0.0
        if target != self._panel_tween.target:
            if target >= 1.0 and self._panel_tween.value <= 0.05:
                self.flow_log = False              # 右栏刚滑出：回到工作流视图
            self._panel_tween.to(target, self.anim_frames(20))
        self._panel_tween.tick()
        self._panel_anim = self._panel_tween.smoothed()   # 老字段跟着走（别处只读它做判断）

    def layout(self):
        W, H = self.screen.get_size()
        # 左栏常驻（一旦显示就直接显示，不参与按需动画），窗口太窄时才收
        preview = getattr(self, "dock_preview", None)      # 正拖着小窗口压在哪一侧：那一侧先展开
        lw = self.sizes["left"] if W >= S(1250) and (self._dock_side_keys("left") or preview == "left") else 0     # 左栏没模块就收起
        rw0 = max(S(360), self.sizes["right"]) if W >= S(900) and (
            self._dock_side_keys("right") or self.settings_open or preview == "right") else 0   # 右栏同理（打开设置面板时也要展开）
        if W - lw - rw0 < S(320):                # 中心区太窄：先收右栏，再收左栏
            rw0 = 0
            if W - lw < S(320):
                lw = 0
        rw = rw0
        anim = self._panel_tween.smoothed()             # 0=完全收起 1=完全展开（已经过缓动）
        prev = self._right_w_last
        tgt_w = rw0 if (not self._auto_hide_on() or self._panel_tween.target >= 1.0) else 0
        if not self.anim_on() or prev is None:          # 关掉动画 / 第一帧：直接按目标宽度
            rw = tgt_w
        elif abs(prev - tgt_w) > 1:                     # 在上一帧实宽和当前目标宽之间插值：横向滑出
            prog = anim if tgt_w >= prev else 1.0 - anim
            rw = int(round(prev + (tgt_w - prev) * prog))
        else:
            rw = tgt_w
        rw = max(0, min(rw0, rw))
        if self.anim_on() and lw and prev is not None and tgt_w > rw:
            lw = lw + (tgt_w - rw)                      # 右栏让出的宽度补给左栏：中间栏只让出真正差值
        left = pygame.Rect(0, TOP_H, lw, H - TOP_H)
        right = pygame.Rect(W - rw, TOP_H, rw, H - TOP_H)
        center = pygame.Rect(lw, TOP_H, W - lw - rw, H - TOP_H)
        return left, center, right

    def clamp_sizes(self, sizes: dict) -> dict:
        """把栏宽和输入框高度夹到合法范围，保证拖不出窗口也拖不到 0。"""
        H = self.screen.get_height()
        try:
            sizes["left"] = max(S(160), min(S(500), int(sizes.get("left", LEFT_W))))
            sizes["right"] = max(S(160), min(S(700), int(sizes.get("right", RIGHT_W))))
            sizes["input_h"] = max(S(70), min(max(S(70), H * 3 // 5), int(sizes.get("input_h", INPUT_H))))
        except (TypeError, ValueError):
            return {"left": LEFT_W, "right": RIGHT_W, "input_h": INPUT_H}
        return sizes

    def default_sizes(self) -> dict:
        """启动时的栏宽和输入框高度：settings 里存过就用，否则用默认值。"""
        sizes = {"left": LEFT_W, "right": RIGHT_W, "input_h": INPUT_H}
        saved = self.settings.get("sizes")
        if isinstance(saved, dict):
            for k in sizes:
                try:
                    sizes[k] = int(saved[k])
                except (KeyError, TypeError, ValueError):
                    pass
        for k, key in (("left", "panel_left_w"), ("right", "panel_right_w"), ("input_h", "input_height")):
            try:
                sizes[k] = int(self.settings[key])
            except (KeyError, TypeError, ValueError):
                pass
        return self.clamp_sizes(sizes)

    def drag_handles(self):
        """三条分隔条的热区（宽 S(6)）：左栏右边线、右栏左边线、输入框上边线。栏收起时是空 Rect。"""
        W, H = self.screen.get_size()
        left, center, right = self.layout()
        lh = pygame.Rect(left.right - S(3), TOP_H, S(6), H - TOP_H) if left.w else pygame.Rect(0, 0, 0, 0)
        rh = pygame.Rect(right.x - S(3), TOP_H, S(6), H - TOP_H) if right.w else pygame.Rect(0, 0, 0, 0)
        ih = pygame.Rect(center.x + S(3), center.bottom - self.sizes["input_h"] - S(3),
                         max(0, center.w - S(6)), S(6))
        return lh, rh, ih

    def drag_sizes(self, pos):
        """拖动分隔条：改 self.sizes 并夹紧（下一帧就按新尺寸重画）。"""
        W, H = self.screen.get_size()
        if self.drag_mode == "left":
            self.sizes["left"] = max(S(160), min(S(500), pos[0]))
        elif self.drag_mode == "right":
            self.sizes["right"] = max(S(160), min(S(700), W - pos[0]))
        elif self.drag_mode == "input":
            self.sizes["input_h"] = max(S(70), min(max(S(70), H * 3 // 5), H - pos[1]))

    def save_layout(self):
        """把布局类状态一次性写进 settings 并落盘：三栏尺寸 + 各显隐开关。
        布局一改就调它（拖分隔条、设置面板改尺寸、显隐按钮、全屏切换），不靠退出那一次保存。"""
        self.settings["sizes"] = dict(self.sizes)
        self.settings["panel_left_w"] = self.sizes["left"]
        self.settings["panel_right_w"] = self.sizes["right"]
        self.settings["input_height"] = self.sizes["input_h"]
        self.settings["top_hidden"] = list(self.settings.get("top_hidden", []) or [])
        save_settings(self.settings)

    def save_drag_sizes(self):
        """把拖出来的三条尺寸写进设置（重启后保持），栏宽也同步到界面设置值。"""
        return self.save_layout()

    def handle_live_layout(self, e):
        """实时拖动布局状态：只认分隔条拖动和退出（Esc / Enter / 右键），不往输入框打字。"""
        if e.type in (pygame.KEYDOWN, pygame.KEYUP) and getattr(e, "key", 0) in (
                pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
            if e.type == pygame.KEYDOWN:
                self.exit_live_layout()
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:
            self.exit_live_layout()
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for mode, r in zip(("left", "right", "input"), self.drag_handles()):
                if r.w and r.collidepoint(e.pos):
                    self.drag_mode = mode
                    break
            return True
        if e.type == pygame.MOUSEMOTION and self.drag_mode:
            self.drag_sizes(e.pos)
            return True
        if e.type == pygame.MOUSEBUTTONUP and e.button == 1 and self.drag_mode:
            self.drag_mode = ""
            self.save_drag_sizes()
            return True
        return True

    def exit_live_layout(self):
        """退出实时拖动布局：尺寸存进设置并回到普通界面。"""
        self.drag_mode = ""
        self.live_layout = False
        self.save_drag_sizes()

    def draw_live_layout_hint(self, W):
        """实时调布局时顶部的一条提示浮条。"""
        max_w = max(S(120), W - S(80))
        t = utext(self.small, ellipsize(self.small, lang("layout_live_hint"), max_w - S(24)), C["text"])
        r = pygame.Rect(0, TOP_H + S(50), t.get_width() + S(24), self.small.get_linesize() + S(12))
        r.centerx = W // 2
        pygame.draw.rect(self.screen, mix(C["top"], C["hdr"], 0.15), r, border_radius=S(8))
        self.screen.blit(t, t.get_rect(center=r.center))

    def draw_drag_handles(self, mouse):
        """画三条 1px 分隔线，鼠标停在上面时换成左右/上下箭头。"""
        left, center, right = self.layout()
        color = mix(C["border"], C["panel"], 0.5)
        if left.w:
            pygame.draw.line(self.screen, color, (left.right - 1, left.y), (left.right - 1, left.bottom))
        if right.w:
            pygame.draw.line(self.screen, color, (right.x, right.y), (right.x, right.bottom))
        if center.w:
            y = center.bottom - self.sizes["input_h"]
            pygame.draw.line(self.screen, color, (center.x + PAD, y), (center.right - PAD, y))
        if self.drag_mode:
            cur = pygame.SYSTEM_CURSOR_SIZENS if self.drag_mode == "input" else pygame.SYSTEM_CURSOR_SIZEWE
        else:
            cur = None
            for mode, r in zip(("left", "right", "input"), self.drag_handles()):
                if r.w and r.collidepoint(mouse):
                    cur = pygame.SYSTEM_CURSOR_SIZENS if mode == "input" else pygame.SYSTEM_CURSOR_SIZEWE
                    break
        if cur == self.drag_cursor:
            return
        self.drag_cursor = cur
        if cur:
            self.ibeam = False                    # 分隔条上的光标由这里管，输入框的 I 形光标让位
        try:
            pygame.mouse.set_system_cursor(cur or pygame.SYSTEM_CURSOR_ARROW)
        except pygame.error:
            pass

    # ---------------- 状态 ----------------

    def add(self, kind, text):
        """往聊天框加一条。系统提示（提示 / 记忆 / B库 改造过程）不进聊天框——保持聊天框干净：
        记进工作流日志（右栏「日志」能翻），顶部弹 4 秒小通知。聊天框只留对话、图片、选择卡片和真正的报错。"""
        if kind in NOTICE_KINDS or kind.startswith("b_"):
            self.notice(kind, text)
            return None
        msg = Message(kind, text)
        self.messages.append(msg)
        return msg

    @staticmethod
    def _apply_meta(msg, rec) -> None:
        """从记忆里重新显示的消息：用当时记下的时间和员工（_ts / _staff），不用现在上岗的。
        老记忆里没记的就保持原样（现在的员工、读进来的时间）。"""
        if msg is None or not isinstance(rec, dict):
            return
        try:
            if rec.get("_ts"):
                msg.ts = float(rec["_ts"])
        except (TypeError, ValueError):
            pass
        if rec.get("_staff") and msg.kind in AVATAR_KINDS:
            msg.staff = str(rec["_staff"])
            msg._cache_key = None                      # 换了头像 / 名字：卡片重新排版

    def notice(self, kind, text):
        """系统提示：写工作流日志 + 顶部小通知（只显示第一行）。"""
        text = str(text or "").strip()
        if not text:
            return
        try:
            lib_b.worklog.write("界面", kind, text)
        except Exception:
            pass
        first = text.splitlines()[0]
        self.show_toast(first if len(first) <= 60 else first[:58] + "…")

    def show_toast(self, text):
        """顶部居中弹一条全局通知（不管当前在哪个页面），4 秒后自动消失。"""
        self.toast = {"text": text, "at": pygame.time.get_ticks()}
        self._dirty = True

    def draw_toast(self, W, H):
        """顶部居中的全局通知浮层：淡入淡出，4 秒后自动消失，画在最上层。"""
        t = getattr(self, "toast", None)
        if not t:
            return
        age = pygame.time.get_ticks() - t["at"]
        if age >= 4000:
            self.toast = None
            self._dirty = True
            return
        alpha = 255
        if age < 240:
            alpha = int(255 * age / 240)
        elif age > 3600:
            alpha = max(0, int(255 * (4000 - age) / 400))
        tsurf = utext(self.font, t["text"], C["text"])
        bw = tsurf.get_width() + S(28)
        bh = tsurf.get_height() + S(18)
        surf = pygame.Surface((bw, bh), pygame.SRCALPHA)
        surf.fill((*C["panel"][:3], 255))
        pygame.draw.rect(surf, C["border"], surf.get_rect(), S(1), border_radius=S(8))
        surf.blit(tsurf, (S(14), S(9)))
        surf.set_alpha(alpha)
        try:
            center = self.layout()[1]                    # 聊天区中间、顶上那排按钮下面：不挡输入框，也不压按钮
            x, y = center.centerx - bw // 2, center.y + S(44)
        except Exception:
            x, y = (W - bw) // 2, TOP_H + S(44)
        self.screen.blit(surf, (x, y))

    def set_workspace(self, folder: str):
        root = Path(folder)
        if not root.is_dir():
            self.add("error", f"文件夹不存在: {folder}")
            return
        self.auto_yes = True                    # 打开文件夹即授权修改
        self.settings["auto_yes"] = True
        save_settings(self.settings)
        self.ws = GuiWorkspace(root, self.events, True)
        self.agent = None
        self.side = None
        self.chat_agent = None                  # 换了文件夹：闲聊 Agent 跟着换（记忆按新工作区算）
        self.messages.clear()
        self._new_pending_session()              # 换了会话：删掉上一会话的临时图片目录
        self.clear_card_h_cache()               # 换了会话：卡片高度缓存作废
        self.tree.set_root(self.ws.root)
        self.panel.reset()
        self.add("info", f"工作区: {self.ws.root}（已授权修改）")
        self.ensure_agent()

    def use_agent_process(self) -> bool:
        """Agent 放到独立进程（默认）。冒烟测试和设置里关掉时还在界面进程里跑。"""
        return bool(self.settings.get("agent_process", True)) and not os.environ.get("TERMINIST_SMOKE")

    def ensure_agent(self) -> bool:
        if self.agent and getattr(self.agent, "alive", True):
            return True
        self.agent = None                       # 之前的 Agent 进程没了：重开一个
        gui_tools = {"set_ui": (lambda: ui_tool_schema(self), self._ui_tool),   # 每次请求按注册表现生成
                     "restart_terminist": (restart_tool_schema(), self._restart_tool),
                     "open_folder": (open_folder_schema(), self._open_folder_tool),
                     "choose": (choose_schema(), self._choose_tool),
                     "notify": (notify_schema(), self._notify_tool),
                     "request_takeover": (request_takeover_schema(), self._request_takeover_tool),
                     "end_takeover": (end_takeover_schema(), self._end_takeover_tool)}
        if self.use_agent_process():
            try:                                # Agent 进程：B库、base 工具、旁聊都在那边装好
                self.agent = AgentProxy(self, self.ws, self.model, gui_tools, self.events)
                if self.ws is not None:
                    self.ws.agent = self.agent
                self.side = self.agent.side
            except Exception as e:
                self.agent = None
                self.add("info", f"Agent 独立进程起不来（{type(e).__name__}: {e}），这次在界面进程里跑")
        if self.agent is None:
            try:                                # 没打开文件夹时 ws 为 None：只能聊天
                self.agent = da.Agent(self.ws, emit=lambda k, t: self.events.put((k, t)), model=self.model)
                if self.ws is not None:
                    self.ws.agent = self.agent
                    self.ws.screen_owner = self         # 扩展工具（小屏幕开关）顺着 ws 找到界面
            except Exception as e:
                self.add("error", f"创建 Agent 失败: {type(e).__name__}: {e}")
                return False
            agent = self.agent
            lib_b.attach(agent)
            web_guard.install()                  # 网页操作超时自动截图：先包好 base.web，再 attach 注册工具
            base.attach(agent)                   # 桌面文件 + 屏幕操作
            web_guard.describe_tools(agent)       # 让模型知道网页超时会自动带截图
            agent.custom_tools.update(gui_tools)
            agent.tool_providers.append(modules_api.LocalTools())   # 外接模块声明给 Agent 的工具
            # 边干活边聊：主人在干活时说的话交给旁聊 Agent；它读得到这边的对话和实时现场，能暂停 / 继续 / 停止 / 追加方案
            self.side = SideChat(agent, emit=lambda k, t: self.events.put(("chat_" + k, t)), on_stop=self.on_stop,
                                 label=lambda: staff_label(active_staff()))
        agent = self.agent
        if getattr(self, "takeover_active", False):   # Agent 进程重开了而接管还开着：眼睛接着看
            self._sync_takeover()
        if self.settings.get("front_desk"):      # 上次前台在岗：接着上岗（当前上岗员工的人设）
            agent.set_persona(active_persona())
        if not os.environ.get("TERMINIST_SMOKE"):
            threading.Thread(target=lambda: self.events.put(("models", agent.list_models())), daemon=True).start()
        if MEMORY_ROOT_ENV in os.environ:        # 重启前 AI 自己换过文件夹：接着读原来那份对话记忆
            mr = os.environ.pop(MEMORY_ROOT_ENV)
            agent._memory_root = Path(mr) if mr else None
        self.restore_memory()
        if not getattr(self, "selftest_done", False):    # 重启后（或进程第一次起）跑一遍本地自检
            self.selftest_done = True
            self.pending_turns = getattr(self, "pending_turns", [])
            try:                                    # 先记下这次要重点验证什么（标记读走就删了）
                data = json.loads(self_test_flag_path().read_text(encoding="utf-8"))
                req = str(data.get("request") or data.get("requested") or "") if isinstance(data, dict) else ""
                self._selftest_note = "" if req == "restart selftest" else req
            except Exception:
                self._selftest_note = ""
            cmd = run_self_test("restart")
            if cmd:
                from lib_a.core import NO_DRAIN_MARK
                self.pending_turns.append(NO_DRAIN_MARK + cmd)
            self.resume_queue = True             # 重启前没做完的队列：自检跑完、Agent 空着时接着做
        return True

    def ensure_chat_agent(self) -> bool:
        """干活时陪主人说话的旁聊 Agent（lib_a/sidechat.py）：和干活的 Agent 共用记忆和现场。"""
        if self.ensure_agent() and self.side is not None:
            return True
        if self.chat_agent:
            return True
        try:                                    # 没打开文件夹时 ws 为 None：闲聊照样能聊
            self.chat_agent = da.Agent(self.ws, emit=lambda k, t: self.events.put(("chat_" + k, t)),
                                       model=self.model, persist=True, memory_key="chat")
            self.chat_agent.set_persona(active_persona() + CHAT_SCREEN_HINT)
            self.chat_agent.load_memory()       # 先读上次的闲聊（没读过的记忆不会被存盘盖掉）
            try:                                # 开 / 关小屏幕窗口：闲聊前台自己调，立刻生效，不派 Agent
                from lib_a.extensions.screen_window_tool import tools as screen_window_tools
                self.chat_agent.custom_tools.update(screen_window_tools(self))
            except Exception:
                pass
            # 闲聊 Agent 想知道干活那一轮在做什么：给它一个读现场的回调（读的是干活 Agent 的现场）
            self.chat_agent.live_source = self._deal_agent_live
        except Exception as e:
            self.chat_agent = None
            self.add("error", f"创建闲聊 Agent 失败: {type(e).__name__}: {e}")
            return False
        return True

    def _deal_agent_live(self) -> str:
        """干活那一轮的工作流现场（闲聊 Agent 读这个）。"""
        a = self.agent
        if a is None:
            return ""
        try:
            return a.live_report()
        except Exception:
            return ""

    def _chat_turn(self, text: str):
        """A库 正在干活：以 # 开头的输入交给闲聊 Agent，不打断那一轮，也不进 inbox。"""
        self.input_text, self.cursor = "", 0
        self.sel_anchor = None
        if not self.ensure_chat_agent():
            self.add("info", "闲聊 Agent 没起来，稍后再试；A库 干活那一轮不受影响")
            return
        self.add("user", "（对话·工作流继续）" + text)
        self._chat_buf = ""
        threading.Thread(target=self._run_chat, args=(text,), daemon=True).start()

    def _run_chat(self, text: str):
        try:
            if self.side is not None:
                self.side.ask(text)
            else:
                self.chat_agent.chat(text)
        except Exception as e:
            self.events.put(("chat_error", str(e)))
        self.events.put(("chat_done", ""))

    def add_image(self, ev: dict):
        """在中间的对话里插入一张图（A库 画的图、截图等）。"""
        m = Message("image", ev.get("title", ""))
        m.image = ev.get("path", "")
        kind = {"flow": "流程图", "concept": "概念图"}.get(ev.get("kind", ""), "")
        m.who = " · ".join(x for x in (kind, ev.get("title", "")) if x)
        self.messages.append(m)
        self.chat_view.stick = True

    def on_drop_file(self, path: str):
        """拖进窗口的文件：是图片就插进对话，不是就提示原因（不让程序崩）。"""
        path = os.path.abspath(str(path or ""))
        exts = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp")
        if not os.path.isfile(path):
            self.add("error", f"拖进来的不是文件：{path or '(空)'}")
            return
        name = os.path.basename(path)
        if Path(path).suffix.lower() not in exts:
            self.add("error", f"不支持的图片格式：{name}（支持 png/jpg/jpeg/bmp/gif/webp）")
            return
        try:
            self.add_image({"path": path, "title": name})
        except Exception as e:
            self.add("error", f"图片读不出来：{name}（{type(e).__name__}: {e}）")
            return
        self.add("info", f"已插入图片：{name}")

    def restore_memory(self):
        """读取这个文件夹之前的对话，把需求和结论重新显示在中间栏。
        Agent 进程还没起来、读超时：记下来稍后再读（这期间 Agent 不会存盘，不会把上次的对话盖掉）。"""
        turns = self.agent.load_memory()
        if turns is None:
            self._mem_pending = True
            self._mem_retry_at = time.time() + 2
            return
        self._mem_pending = False
        self.context = (self.agent.context_tokens(), da.CONTEXT_LIMIT)
        if not turns:
            return
        msgs = self.agent.messages[1:]
        selftest = False                                      # 重启后自检那一轮：指令和汇报都不进聊天栏（只记工作流日志）
        for i, m in enumerate(msgs):
            c = m.get("content") or ""
            if m["role"] == "user":
                c = c.split(da.core.RECALL_MARK)[0]               # 自动检索附上的资料不显示
                if da.core.is_selftest_text(c):
                    selftest = True
                    continue
                if not c.startswith((da.core.CHECK_MARK, da.core.STEER_MARK)):
                    selftest = False
                if c.startswith(da.SUMMARY_MARK):
                    self.add("memory", "更早的对话已压缩成摘要，Terminist 仍记得其中的要点")
                elif not self.agent.is_internal(m):
                    self._apply_meta(self.add("user", c), m)
            elif m["role"] == "tool" and "[[image:" in c:        # 之前插进对话的图
                for path, title in re.findall(r"\[\[image:(.+?)\|(.*?)\]\]", c):
                    if Path(path).is_file():
                        src = Path(path).with_suffix(".mmd")          # 画的图旁边存了源码，能认出是流程图还是概念图
                        from base import draw
                        kind = draw.kind_of(src.read_text(encoding="utf-8")) if src.is_file() else ""
                        self.add_image({"path": path, "title": title, "kind": kind})
            elif m["role"] == "assistant" and c and not m.get("tool_calls") and not selftest:
                prev = msgs[i - 1] if i else {}
                if not (prev.get("content") or "").startswith(da.SUMMARY_MARK):   # 跳过摘要后的 "好的" 回复
                    self._apply_meta(self.add("assistant", c), m)       # 当时是谁说的、几点说的
        self.add("memory", f"已恢复记忆：{turns} 轮对话，约 {da.fmt_tokens(self.context[0])} tokens（清空对话会一并清掉）")

    def set_model(self, name: str):
        self.model = name
        self.actual_model = ""
        if self.agent:
            self.agent.set_model(name)
            if self.settings.get("front_desk"):  # 换模型时前台还在岗：人设照样挂上（只换语气，模型就用新选的）
                self.agent.set_persona(active_persona())
        if name == da.TEAM_MODE:
            self.add("info", f"已切换到工作组模式：{da.LEAD_MODEL} 拆任务、查工，多个 {da.WORKER_MODEL} 并行执行")
        else:
            self.add("info", f"已切换模型: {name}（单模型，自己拆、自己写）")

    @staticmethod

    def model_label(name: str) -> str:
        return f"工作组（{da.LEAD_MODEL} 指挥 + {da.WORKER_MODEL} 执行）" if name == da.TEAM_MODE else name

    # ---------------- 按钮回调 ----------------

    def on_open_folder(self):
        path = pick_folder()
        if path:
            self.set_workspace(path)

    def on_toggle_dropdown(self):
        self.dropdown_open = not self.dropdown_open
        if self.anim_on():                      # 打开时从 2 行高缓动展开，关掉时立刻收起
            self._dropdown_tween.value = 0.0 if self.dropdown_open else 1.0
            self._dropdown_tween.to(1.0 if self.dropdown_open else 0.0, self.anim_frames(14))
        else:
            self._dropdown_tween.value = self._dropdown_tween.target = \
                1.0 if self.dropdown_open else 0.0

    def visible_top_buttons(self) -> list:
        """按 TOP_BUTTONS 的顺序列出顶栏按钮；设置里隐藏的不显示。干活时末尾再多一个暂停 / 继续。"""
        buttons = {"model": self.btn_model, "clear": self.btn_clear, "clearview": self.btn_clearview,
                   "stop": self.btn_stop}
        hidden = self.settings.get("top_hidden", []) or []
        out = [buttons[n] for n in TOP_BUTTONS if n in buttons and (n == "stop" or n not in hidden)]
        if self.busy and self.agent is not None:      # 干活时：暂停 / 继续（画图形不画文字）
            key = (bool(self.paused), S(16))
            cache = getattr(self, "_top_glyphs", None)
            if not isinstance(cache, dict):
                cache = self._top_glyphs = {}
            self.btn_pause.label = cache.setdefault(key, Glyph("play" if self.paused else "pause", S(16)))
            out.append(self.btn_pause)
        if self.restart_needed:
            out.append(self.btn_restart)
        return out

    def on_restart(self):
        """用新代码重新启动 Terminist（记忆和设置都会保留）。
        屏幕上那块投影壳一直不动（不 kill），新窗口起来后接着往同一个壳送帧，看起来就是同一个窗口。"""
        import run
        if getattr(self, "restarting", None) is not None:
            return
        try:                                     # 重启前的准备出任何错都不能把窗口弄崩（以前一个异常就整窗死掉、也重启不了）
            save_settings(self.settings)
            if self.agent:
                if getattr(self, "_mem_pending", False):
                    self.restore_memory()                # 记忆还没读进来就要重启：先读，别带着空对话走
                ok = self.agent.save_memory(final=True)  # 重启前最后存一次（先备份），之后旧进程不再写这份记忆
                if not ok and not getattr(self, "_mem_pending", False):
                    ok = self.agent.save_memory(final=True)
                lib_b.worklog.write("Terminist", "info", f"重启前保存对话上下文：{'已存好' if ok else '没存上（磁盘上是上一轮结束时的那份）'}")
            if self.agent is not None and hasattr(self.agent, "_memory_root"):   # AI 换过文件夹：新窗口读同一份记忆
                os.environ[MEMORY_ROOT_ENV] = str(self.agent._memory_root or "")
        except Exception as e:
            self.add("error", f"重启前保存时出错（{type(e).__name__}: {e}），照样重启")
        args = [str(self.ws.root)] if self.ws else []
        if self.restart_version:
            args += ["--after-upgrade", self.restart_version]
        try:
            self.restarting = run.launch(args, notice=f"已重启到新版本（改造前的存档：{self.restart_version or '无'}）")
        except Exception as e:
            self.restarting = None
            if self.agent:
                self.agent.thaw_memory()                 # 这个窗口接着用：对话照常存
            self.add("error", f"重启失败：{type(e).__name__}: {e}。这个窗口先留着。")
            return
        self.add("info", ("正在启动新版本" if self.restart_version else "正在重启") + "，这个窗口马上交给新窗口…")

    def projection_on(self) -> bool:
        """投影主窗口开没开：设置里开着、不是全屏、拿得到窗口位置（拿不到就没法把真窗口挪到屏幕外）。"""
        try:
            if not self.settings.get("projection_shell", True) or getattr(self, "proj_disabled", False):
                return False
            if self.settings.get("fullscreen"):
                return False
            return pygame.display.get_surface() is not None and self.window_pos() is not None
        except Exception:
            return False

    def shell_rect(self):
        """屏幕上那块壳的位置尺寸：用上次记住的窗口位置尺寸，夹到桌面范围内。拿不到返回 None。"""
        try:
            size = self.settings.get("window_size") or list(self.screen.get_size())
            pos = self.settings.get("window_pos") or [120, 80]
            desk = pygame.display.get_desktop_sizes()[0]
            clamp = getattr(project, "shell_rect_for", None)
            rect = clamp(pos, size, desk) if clamp is not None else None
            if rect is None:
                w, h = project.shell_size_for(size, desk)
                rect = (0, 0, int(w), int(h))
            x, y, w, h = (int(v) for v in rect)
            if w <= 0 or h <= 0:
                return None
            return x, y, w, h
        except Exception:
            return None

    def start_projection(self) -> bool:
        """真窗口挪到屏幕外照常渲染，屏幕上留一块常驻投影壳显示它的画面。失败就静默降级回屏幕原位。"""
        self.shell_pid = None
        if not self.projection_on():
            return False
        try:                                          # ① 真窗口挪到屏幕外（还在后台照常渲染）
            setter = getattr(pygame.display, "set_window_position", None)
            if setter is not None:
                setter((-32000, -32000))
        except Exception:
            pass
        rect = self.shell_rect()                      # ② 壳放在上次记住的位置尺寸上
        if rect is None:
            self.restore_on_screen()
            return False
        try:
            pid = project.spawn_shell(list(rect))     # ③ 起壳（已经活着就复用，重启时壳一直在）
        except Exception:
            pid = None
        if not pid:
            self.restore_on_screen()                  # 壳起不来：真窗口自己显示在屏幕原位（等于没开投影）
            return False
        self.shell_pid = int(pid)
        self.shell_rect_now = tuple(rect)
        try:                                          # 重启后的新进程读它接上同一个壳
            os.environ[getattr(project, "SHELL_ENV", "TERMINIST_SHELL_ENV")] = str(int(pid))
        except Exception:
            pass
        proj_write_target(os.getpid())                # 壳把转发的事件写给我
        self.proj_last_send = 0
        return True

    def restore_on_screen(self) -> None:
        """降级：把真窗口放回屏幕原位自己显示（投影壳没起来时用，绝不出现什么都没有的黑屏）。"""
        self.shell_pid = None
        try:
            pos = self.settings.get("window_pos")
            if not (isinstance(pos, (list, tuple)) and len(pos) == 2) or min(int(pos[0]), int(pos[1])) < -1000:
                pos = [80, 60]                         # 没记住位置 / 记成了屏幕外：放到左上角附近，绝不留在屏幕外
            setter = getattr(pygame.display, "set_window_position", None)
            if setter is not None:
                setter((int(pos[0]), int(pos[1])))
        except Exception:
            pass

    def projection_fallback(self, why: str) -> None:
        """投影出了问题：关掉壳，真窗口回到屏幕原位自己显示，这次运行不再开投影（不能让用户对着黑屏）。"""
        try:
            project.kill_shell()
        except Exception:
            pass
        self.restore_on_screen()
        self.proj_disabled = True
        try:
            self.add("info", f"{why}，已经把窗口放回屏幕上直接显示（这次运行不再用投影壳）。")
        except Exception:
            pass

    def stop_projection(self, keep: bool = False) -> None:
        """正常退出时关掉投影壳；重启中（keep=True 或正在重启）不关，壳留给新窗口接着用。"""
        if keep or getattr(self, "restarting", None) is not None:
            return
        if not getattr(self, "shell_pid", None):
            return
        try:
            project.kill_shell()
        except Exception:
            pass
        self.shell_pid = None

    def pump_projection(self) -> None:
        """draw() 画完一帧时调：这一帧要送给投影壳（限流的话先记着，proj_tick 到点再送，绝不丢最后一帧）。"""
        if not getattr(self, "shell_pid", None):
            return
        self.proj_pending = True
        self.proj_tick()

    def proj_tick(self) -> bool:
        """主循环每一圈都调（不管这一圈画没画）：收壳转来的输入；有攒着没送的帧、到点就送；每秒一次心跳。
        以前收输入和送帧都藏在 draw() 里、而且限流时直接 return：空闲时打的字要等 0.7 秒的兜底重画才被读到，
        限流掉的最后一帧也一直不送，屏幕上就停在旧画面（「停帧」）。返回这一圈有没有收到输入。"""
        if not getattr(self, "shell_pid", None):
            return False
        got = False
        try:
            ev = proj_ev_file(os.getpid())
            if ev.exists() and ev.stat().st_size:
                text = ev.read_text(encoding="utf-8", errors="ignore")
                if text.strip():
                    ev.write_text("", encoding="utf-8")             # 读走就清空（壳接着往里 append）
                    self.proj_input_at = pygame.time.get_ticks()   # 有输入：接下来 2 秒按 60fps 送帧
                    for d in project.decode_events(text):
                        for pe in proj_events_for(d):
                            pygame.event.post(pe)
                    got = True
        except Exception:
            pass
        try:
            now = pygame.time.get_ticks()
            if now - getattr(self, "proj_check_at", 0) >= 1000:     # 每秒看一眼壳：死了 / 自己报失败 → 回到屏幕上
                self.proj_check_at = now
                if not project.shell_alive() or project.shell_failed():
                    self.projection_fallback("投影壳没在正常显示")
                    return got
            # 刚有输入：60fps；在干活（文字流式往外冒）：30fps；其余 10fps。没变化就不送，只每秒送一次心跳给壳的看门狗
            typing = now - getattr(self, "proj_input_at", -10000) < 2000
            gap = 16 if typing else 33 if self.busy else 100
            since = now - getattr(self, "proj_last_send", 0)
            if (getattr(self, "proj_pending", False) and since >= gap) or since >= 1000:
                if getattr(self, "proj_writer", None) is None:
                    self.proj_writer = project.FrameWriter(os.getpid())
                    if getattr(self, "_ime_rect", None):
                        self.proj_writer.set_ime_rect(self._ime_rect)
                self.proj_writer.write(self.screen)               # 共享内存，不落盘不编码（~10ms）
                self.proj_last_send = now
                self.proj_pending = False
        except Exception:
            pass
        return got

    def check_restart(self):
        """每帧检查重启进度：新窗口就绪就退出；新进程没起来就说明原因。
        已经关窗（交给新窗口了）的情况下聊天区写不了，只写进 ~/.terminist/logs。"""
        r = getattr(self, "restarting", None)
        if r is None:
            return
        state = r.state()
        if state == "ready":
            self.quit_requested = True
        elif state == "failed" or time.time() - r.started > 90:
            self.restarting = None
            if self.agent and not self.quit_requested:
                self.agent.thaw_memory()                 # 这个窗口接着用：对话照常存
            why = "新进程退出了" if state == "failed" else "等了 90 秒新窗口还没出来"
            tail = r.log_tail()
            if self.quit_requested:                       # 窗口马上要关：写日志就够了
                project.log_restart_fail(f"重启没成功（{why}）。", str(r.log))
                return
            self.add("error", f"重启没成功（{why}），这个窗口先留着，可以继续用或者再点 \"重启生效\"。\n"
                              f"日志：{r.log}" + (f"\n{tail}" if tail else ""))

    def open_settings_panel(self, panel: str, key: str | None = None):
        """在右侧那一列里打开某个区块的设置面板（key 不为空就滚到那一项、并让它闪一下）。"""
        if not self.sizes.get("right"):           # 右栏收起了：先恢复成默认宽度，面板才有地方放
            self.sizes["right"] = RIGHT_W
        self.dropdown_open = False
        self.settings_open = True
        self.settings_panel = panel
        self.settings_focus = key
        self.settings_scroll = 0
        self.mark_dirty()

    def __getattr__(self, name):
        """兼容旧调用：以前叫 on_open_settings（旧自检脚本还在用），现在统一打开右栏里的设置面板。"""
        if name in ("on_open_settings", "open_settings"):
            return lambda *_a, **_k: self.open_settings_panel("show")
        raise AttributeError(name)

    def on_clear(self):
        """清空对话：不直接清，先弹二次确认（外部旧调用也走这里）。"""
        self.request_clear()

    def request_clear(self):
        """弹「清空对话？」确认框：复用 allow/deny 那套模态框，点「清空」才真的清。"""
        req = ConfirmRequest(lang("confirm_clear_body"), "", kind="clear",
                             title=lang("confirm_clear_title"),
                             ok_text=lang("confirm_clear_ok"), cancel_text=lang("cancel"))
        if self.pending_confirm is not None:       # 已经有一个确认框在显示：排到后面
            self.confirm_queue.append(req)
        else:
            self.pending_confirm = req
            self.modal_scroll = 0
        self._dirty = True

    def request_takeover(self, reason: str = ""):
        """弹「进入接管模式？」确认框：复用现成的确认模态框，点了「确定」才真的进接管。
        reason：Agent 申请时写的理由（主人自己点按钮 / 打 /接管 时没有）。返回这个确认请求。"""
        msg = "进入接管模式后我会频繁截图+控制鼠标键盘自己干，确定吗"
        if reason:
            msg = f"Agent 申请进入接管模式：{reason}\n\n" + msg
        req = ConfirmRequest(msg, "", kind="takeover", title="Agent 申请接管" if reason else "进入接管模式？",
                             ok_text="确定", cancel_text=lang("cancel"))
        if self.pending_confirm is not None:       # 已经有一个确认框在显示：排到后面
            self.confirm_queue.append(req)
        else:
            self.pending_confirm = req
            self.modal_scroll = 0
        self._dirty = True
        return req

    def _do_clear(self):
        """真正的清空（原来是 on_clear 的整个函数体，逻辑一个字没改）。"""
        try:
            if self.agent:
                self.agent.clear_memory()
                self.context = (self.agent.context_tokens(), da.CONTEXT_LIMIT)
            if self.chat_agent:                      # 清空对话两个都清
                self.chat_agent.clear_memory()
            if self.side is not None:
                self.side.session.clear()
            self._chat_buf = ""
            inbox = getattr(self.agent, "inbox", None) if self.agent else None
            if isinstance(inbox, list):
                inbox.clear()
            self.messages = [m for m in self.messages[:1] if m.kind == "info"]
            self._new_pending_session()              # 会话结束：删掉上一会话的临时图片目录
            self.clear_card_h_cache()
            self.selected_flow = None
            self.add("info", "已清空对话和记忆")
        except Exception as e:                   # noqa: BLE001 - 清空失败也不许让主循环退出
            self.add("error", f"清空失败：{type(e).__name__}: {e}")

    def on_clear_view(self):
        """只清聊天栏显示，不动记忆和上下文（工作流继续跑）。"""
        try:
            self.chat_btns = []                  # 先丢掉旧的按钮矩形，避免拿旧坐标
            self.messages.clear()
            self.clear_card_h_cache()
            self.selected_flow = None
            self.flow_rects = []
            self.scroll = 0
            self.add("info", lang("cleared_view"))
        except Exception as e:                   # noqa: BLE001 - 清屏失败也不许让主循环退出
            self.add("error", f"清屏失败：{type(e).__name__}: {e}")

    def on_reset_penalty(self):
        """重置 A库 / B库 的惩罚和奖励分，顶栏分数条跟着归零。"""
        msg = reset_penalty_scores()
        try:
            self.penalty = lib_b.penalty.scores()
        except Exception:                    # noqa: BLE001 - 拿不到就当全零
            self.penalty = {"A": 0, "B": 0, "R": 0, "RA": 0}
        self.add("info", msg)
        self.mark_dirty()

    def chat_history_tail(self, n: int = 5) -> list[tuple[str, str]]:
        """取当前 Agent 记忆里最近的 n 组对话（user + 紧随的 assistant），只读不改记忆。"""
        agent = self.agent
        if agent is None:
            return []
        return [(q.get("content") or "", a.get("content") or "") for q, a in self._history_pairs(n)]

    def _history_pairs(self, n: int = 5) -> list[tuple[dict, dict]]:
        """记忆里最近 n 组 (user 消息, 紧随的 assistant 消息) 原样的 dict（带 _ts / _staff）。"""
        agent = self.agent
        if agent is None:
            return []
        msgs = [m for m in agent.messages[1:] if isinstance(m, dict)]
        pairs = []
        pending = None
        for m in msgs:
            c = (m.get("content") or "")
            if m.get("role") == "user":
                if c.startswith(da.SUMMARY_MARK) or agent.is_internal(m):
                    pending = None
                    continue
                pending = m
            elif m.get("role") == "assistant" and pending is not None and c and not m.get("tool_calls"):
                pairs.append((pending, m))
                pending = None
        return pairs[-n:] if n > 0 else pairs

    def on_load_history(self, n: int = 5):
        """把记忆里最近 n 组对话补显示到聊天栏；已经在聊天栏里的不重复插入，不动记忆和上下文。"""
        pairs = self._history_pairs(n)
        if not pairs:
            self.add("info", "没有可载入的历史（当前记忆是空的）")
            return
        have = {(m.kind, m.text) for m in self.messages if m.kind in ("user", "assistant")}
        added = 0
        for qm, am in pairs:
            q, a = qm.get("content") or "", am.get("content") or ""
            if ("user", q) not in have:
                self._apply_meta(self.add("user", q), qm)
                added += 1
            if ("assistant", a) not in have:
                self._apply_meta(self.add("assistant", a), am)     # 当时是谁说的，不是现在上岗的
                added += 1
        self.chat_view.stick = True
        self.add("info", f"已载入最近 {len(pairs)} 组对话（{added} 条），记忆和上下文没有改动")

    def stop_workflow(self, agents=None) -> bool:
        """停掉正在跑的工作流：自己 + 工作组执行成员 + B库 改造成员 + 独立闲聊 Agent。
        agents 里的 Agent 会被一并停掉（闲聊 Agent 用）。返回有没有真的停掉什么。"""
        hit = False
        targets = [a for a in (getattr(self, "agent", None), getattr(self, "chat_agent", None)) if a is not None]
        targets += [a for a in (agents or []) if a is not None]
        for a in targets:
            fn = getattr(a, "stop_all", None) or getattr(a, "stop", None)   # 老版本没有 stop_all 就用 stop
            try:
                if fn():
                    hit = True
            except Exception:
                pass
        if self.pending_confirm:
            self.answer_confirm(False)
            hit = True
        if getattr(self, "pending_credentials", None):
            self.answer_credentials(False)
            hit = True
        while self.pending_delete:
            self.answer_delete(False)
            hit = True
        progress = getattr(self, "progress", None) or {}
        if (progress.get("total") or progress.get("label")):
            self.progress = {"total": 0, "done": 0, "label": ""}
            hit = True
        if getattr(self, "busy", False):
            self.busy = False                    # 干活那一轮的线程会自己退出，先放开口子
            hit = True
        return hit

    def on_pause_toggle(self):
        if self.agent is not None and self.busy:
            self._pause_set(not self.agent.paused)

    def _pause_set(self, on: bool):
        """暂停 / 继续。状态真的变了由 paused / resumed 事件提示；没变（本来就是）才把说明显示出来。"""
        was = self.agent.paused
        msg = self.agent.pause() if on else self.agent.resume()
        if self.agent.paused == was:
            self.add("info", msg)

    def _stop_now(self):
        """主线程里真正执行停止（必须由主线程调用）。"""
        self.expire_choices()                    # 还在等主人选的卡片作废，Agent 别卡在那儿
        hit = self.stop_workflow()
        if hit:
            self.add("info", "已停止当前工作流（对话照旧可以聊）")
        else:
            self.add("info", "现在没有正在跑的工作流")

    def on_stop(self):
        """停止按钮 / 斜杠命令：从子线程调用时排到主线程下一帧再做，保证界面状态只在主线程改。"""
        if threading.current_thread() is not threading.main_thread():
            self.pending_stops.append({"agents": []})
            return
        self._stop_now()

    # ---------------- 删除确认（base.guard）----------------

    def _delete_handler(self, items: list[str], reason: str, wait: float) -> bool:
        """在 Agent 线程里调用：交给主线程弹窗，阻塞到用户选择；Agent 被停止就算不同意。"""
        req = DeleteRequest(items, reason, wait)
        self.events.put(("delete_confirm", req))
        while not req.event.wait(0.1):
            if self.agent and self.agent.stop_requested:
                return False
        return req.result

    def show_delete(self, req: DeleteRequest):
        if self.pending_delete is not None:
            self.delete_queue.append(req)
            return
        self.pending_delete = req
        req.shown_at = pygame.time.get_ticks()
        self.bring_to_front()

    def answer_delete(self, ok: bool):
        req = self.pending_delete
        if req is None:
            return
        if ok and pygame.time.get_ticks() - req.shown_at < req.wait * 1000:
            return                                   # 倒计时没结束，不能确认
        req.result = ok
        req.event.set()
        self.pending_delete = None
        if self.delete_queue:
            self.show_delete(self.delete_queue.pop(0))

    def bring_to_front(self):
        """删除确认弹出时把 Terminist 窗口提到最前面（Agent 可能正在操作别的窗口）。"""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            hwnd = pygame.display.get_wm_info().get("window")
            if hwnd:
                user32 = ctypes.windll.user32
                if user32.IsIconic(hwnd):
                    user32.ShowWindow(hwnd, 9)
                user32.keybd_event(0x12, 0, 0, 0)
                user32.keybd_event(0x12, 0, 2, 0)
                user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def handle_delete(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for rect, ok in self.delete_rects:
                if rect.collidepoint(e.pos):
                    self.answer_delete(ok)
                    break
        elif e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_ESCAPE, pygame.K_n):
                self.answer_delete(False)
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_y):
                self.answer_delete(True)
        return True

    def draw_delete(self, W, H, mouse):
        req = self.pending_delete
        reason_lines = wrap(self.font, req.reason, min(S(760), W - S(60)) - PAD * 4)   # 锦衣卫的原因可能有好几行
        modal = self.draw_modal_frame(W, H, S(760), S(160) + (min(len(req.items), 10) + len(reason_lines)) * self.line_h
                                      + S(60))
        x0, y = modal.x + PAD * 2, modal.y + PAD
        self.screen.blit(utext(self.font, lang("confirm_delete"), C["del"]), (x0, y))
        y += self.line_h + S(6)
        for line in reason_lines:
            self.screen.blit(utext(self.font, line, C["text"]), (x0, y))
            y += self.line_h
        y += S(6)
        for item in req.items[:10]:
            t = ellipsize(self.small, "· " + item, modal.w - PAD * 4)
            self.screen.blit(utext(self.small, t, C["del"]), (x0, y))
            y += self.line_h
        if len(req.items) > 10:
            self.screen.blit(utext(self.small, lang("items_total").format(n=len(req.items)), C["dim"]), (x0, y))
        left = req.wait - (pygame.time.get_ticks() - req.shown_at) / 1000
        ready = left <= 0
        self.delete_rects = []
        bx = modal.right - PAD * 2
        for label, ok, color in ((lang("confirm_delete_enter") if ready
                                  else lang("confirm_delete_wait").format(n=int(left) + 1), True,
                                  C["btn_danger"] if ready else C["btn"]),
                                 (lang("cancel_esc"), False, C["btn"])):
            w = self.font.size(label)[0] + S(30)
            bx -= w
            r = pygame.Rect(bx, modal.bottom - S(54), w, S(40))
            hover = r.collidepoint(mouse) and (ready or not ok)
            pygame.draw.rect(self.screen, tuple(min(255, c + 20) for c in color) if hover else color, r,
                             border_radius=S(6))
            fg = C["on_text"] if (ok and ready) else (C["dim"] if ok else C["text"])
            t = utext(self.font, label, fg)
            self.screen.blit(t, t.get_rect(center=r.center))
            self.delete_rects.append((r, ok))
            bx -= S(10)

    def criticize_command(self, text: str):
        """斜杠命令 /criticize <员工名> <要说的话>：把批评送进干活那一轮，不写进 RAG 知识库。"""
        try:
            parts = str(text or "").split(None, 1)
            rest = parts[1].strip() if len(parts) > 1 else ""
            if not rest:
                self.add("info", lang("criticize_usage"))
                return
            who, _, say = rest.partition(" ")
            say = say.strip()
            if not who.strip() or not say:
                self.add("info", lang("criticize_need_text"))
                return
            name = canon(who.strip())
            label = staff_label(name)
            msg = f"主人批评{label}：{say}"
            agent = self.agent
            sent = False
            for api in ("add_instruction", "push_user_message"):     # 追加指示优先：工作流下一步就采纳
                fn = getattr(agent, api, None) if agent is not None else None
                if callable(fn):
                    fn(msg)
                    sent = True
                    break
            if sent:
                self.add("info", lang("criticize_ok").format(who=label))
            else:
                self.add("info", lang("criticize_no_agent"))
        except Exception as e:
            self.add("error", lang("criticize_no_agent") + f"（{type(e).__name__}: {e}）")

    def on_send(self):
        if getattr(self, "choice_typing", None) is not None:   # 正在给选择卡片写回答：回车交给卡片，不发消息
            self.submit_choice_custom()
            return
        text = self.input_text.strip()
        has_img = bool(getattr(self, "pending_images", None))
        if not text and not has_img:
            if self.busy:
                self._stop_now()                     # 干活时按钮被点、输入框没字：就是停止
            return
        if has_img:                                  # 待发图片先上屏（在文字之前），然后清空待发列表
            for path in list(self.pending_images):
                try:
                    self.add_image({"path": path, "title": os.path.basename(str(path))})
                except Exception:
                    pass
            self.pending_images = []
            self.pending_img_close_rects = []
            self.mark_dirty()
            if not text:                             # 只有图没字：图已上屏，不发空气泡、不调 Agent
                return
        if text in ("/stop", "/停止", "/停止工作流") or text.startswith("/stop "):
            self.input_text, self.cursor = "", 0
            self._stop_now()                         # 停止命令最先处理：干活时也不被斜杠拦截挡住
            return
        if self._local_intent(text):                 # 「停 / 暂停 / 继续 / 退出接管」这种一句话：本地直接办，不调模型
            return
        if self.busy and (text in ("/pause", "/暂停", "/resume", "/继续") or text.startswith(("/plan ", "/方案 "))):
            self.input_text, self.cursor = "", 0
            if text.startswith(("/plan ", "/方案 ")):
                self.add("user", text)
                self.agent.add_instruction(text.split(" ", 1)[1])     # 结果由 steer 事件显示
            else:
                self._pause_set(text in ("/pause", "/暂停"))
            return
        if text.startswith(("/criticize", "/批评")):     # 批评员工：能把话送进当前干活那一轮
            self.input_text, self.cursor = "", 0
            self.criticize_command(text)
            return
        if text.split()[:1] in (["/modules"], ["/模块"]):   # /modules reload：重新读 modules/ 文件夹
            self.input_text, self.cursor = "", 0
            self.add("assistant", self.load_modules(quiet=True)) if text.split()[1:2] in (["reload"], ["刷新"]) \
                else self.add("assistant", "用法：/modules reload（重新读 modules/ 文件夹里的外接模块）")
            return
        if text.startswith(("/queue", "/队列")):     # 目标队列：直接改目标文件（界面卡片「＋」也走这里）
            self.input_text, self.cursor = "", 0
            self.queue_command(text)
            return
        if text in ("/接管停止", "/停止接管", "/takeover stop"):     # 退出接管：不用确认，直接退
            self.input_text, self.cursor = "", 0
            self.stop_takeover()
            return
        if text in ("/接管", "/takeover"):           # 进接管：先弹确认，点了「确定」才真进
            self.input_text, self.cursor = "", 0
            self.request_takeover()
            return
        if text.startswith("/"):                     # 外接模块注册的命令（/前缀 参数）：内置命令之后、busy 拦截之前
            _parts = text.split(None, 1)
            _prefix = _parts[0][1:].strip().lower()
            _hit = modules_api.get_module_command(_prefix) if _prefix else None
            if _hit:
                _pkey, _fn = _hit
                self.input_text, self.cursor = "", 0
                _arg = _parts[1].strip() if len(_parts) > 1 else ""
                try:
                    _p = modules_api.get(_pkey) or {}
                    _ctx = modules_api.Ctx(self, _p, self.screen, pygame.Rect(0, 0, 0, 0), C, S, utext)
                    _res = _fn(_ctx, _arg)
                    if _res:
                        self.add("assistant", str(_res))
                except Exception as _e:
                    self.add("error", f"模块命令 /{_prefix} 出错：{type(_e).__name__}: {_e}")
                return
        if self.busy and text.startswith("/"):       # 干活时斜杠命令先不执行，插话不影响当前一轮
            self.input_text, self.cursor = "", 0
            self.add("info", "A库 正在跑工作流，斜杠命令等这一轮结束再用；想说话直接说，会走独立对话。")
            return
        if self.busy and text.startswith("#"):       # 干活时 # 开头：和闲聊 Agent 说，不打断当前这一轮
            msg = text[1:].lstrip()
            if msg:
                self._chat_turn(msg)
            elif text:
                self.input_text, self.cursor = "", 0
            return
        if text in ("/restart", "/重启"):
            self.input_text, self.cursor = "", 0
            self.on_restart()
            return
        if text == "/staff" or text.startswith("/staff "):
            self.input_text, self.cursor = "", 0
            arg = text[len("/staff"):].strip()
            if arg == "on":
                _apply_front_desk(self, True)
                label = staff_label(active_staff())
                self.add("info", f"前台{label}已上岗（只换说话语气，模型不变；重启后也在岗）。")
            elif arg == "off":
                _apply_front_desk(self, False)
                self.add("info", "前台已下班，恢复默认语气（重启后也不上岗）。")
            elif arg.startswith("use "):
                name = canon(arg[4:].strip())    # 旧名兼容：front_desk→fish、scaramouche→cat
                if not name or name.startswith("_") or name not in load_staff():
                    self.add("info", f"没有这个员工：{name}。用 /staff list 看花名册。")
                else:
                    set_active(name)
                    if self.settings.get("front_desk") and self.agent:   # 前台在岗：语气立刻切过去
                        self.agent.set_persona(active_persona())
                    handover = getattr(self.agent, "handover_memory", None) if self.agent else None
                    summary = handover() if callable(handover) else ""
                    if summary:
                        self.add("memory", "已交接：上一个前台的对话压成了摘要，新前台接着往下聊")
                    self.add("info", f"已切换到 {staff_label(name)} 上岗，正在重启…")
                    self.restart_at = pygame.time.get_ticks() + 1500   # 让新前台语气落地
            elif arg.startswith("add "):
                parts = arg[4:].split(None, 1)
                if len(parts) < 2:
                    self.add("info", "用法：/staff add <名字> <显示名>，例如 /staff add cat 散兵猫")
                else:
                    key, label = parts[0], parts[1].strip()
                    if key.startswith("_"):
                        self.add("info", "名字不能以下划线开头。")
                    else:
                        add_staff(key, label, "")
                        self.add("info", f"已新增员工 {label}（{key}），人设可以 /staff set {key} 粘贴，或直接改 memory/staff.json。")
            elif arg.startswith("set "):
                parts = arg[4:].split(None, 1)
                if len(parts) < 2:
                    self.add("info", "用法：/staff set <名字> <人设文本>，人设很长时直接改 memory/staff.json 更省事。")
                else:
                    set_staff_persona(parts[0], parts[1])
                    self.add("info", f"已更新 {staff_label(parts[0])} 的人设；切到它上岗时生效。")
            else:
                staff = load_staff()
                act = active_staff()
                names = [n for n in staff if not str(n).startswith("_") and isinstance(staff[n], dict)]
                lines = [f"员工列表（{len(names)} 个，当前上岗：{staff_label(act)}）："]
                for name in names:
                    s = staff[name]
                    on = "（在岗）" if name == act else ""
                    lines.append(f"{s.get('label', name)}（{name}）{on}：{s.get('duty', '')}")
                lines.append("命令：/staff list 列表，/staff use <名字> 切换上岗，/staff add <key> <label> 新增，"
                             "/staff set <名字> <人设>，/staff on 开前台，/staff off 关前台；"
                             "左栏点非前台的员工卡可「批评」（/criticize <员工名> <要说的话>）")
                self.add("info", "\n".join(lines))
            return
        if text in ("/help", "/帮助"):
            self.input_text, self.cursor = "", 0
            self.add("info", help_text() + "\n" + self.module_help_text() + lang("resetpenalty_hint"))
            return
        if text == "/rollback" or text.startswith("/rollback "):
            self.input_text, self.cursor = "", 0
            arg = text[len("/rollback"):].strip()
            if arg:
                ok, msg = rollback_to(arg)
                self.add("info", msg)
                self.restart_needed = self.restart_needed or ok
            else:
                self.add("info", lib_b.versions_command("/rollback"))
                self.restart_needed = True
            return
        if text == "/selftest" or text.startswith("/selftest "):
            self.input_text, self.cursor = "", 0
            arg = text[len("/selftest"):].strip()
            self.add("info", request_self_test(arg != "cancel"))
            return
        if text in ("/resetpenalty", "/重置奖惩", "/penaltyreset"):
            self.input_text, self.cursor = "", 0
            self.on_reset_penalty()
            return
        if text in ("/versions", "/penalty"):
            self.input_text, self.cursor = "", 0
            self.add("info", lib_b.versions_command(text))
            return
        if text in ("/cls", "/清屏"):
            self.input_text, self.cursor = "", 0
            self.on_clear_view()
            return
        if text in ("/clear memory", "/清空记忆"):
            self.input_text, self.cursor = "", 0
            self.request_clear()                 # 真清记忆：仍要先过二次确认
            return
        if text in ("/clear", "/清空"):
            self.input_text, self.cursor = "", 0
            self.on_clear_view()                 # 只清聊天栏显示，记忆和上下文都不动
            return
        if text == "/set" or text.startswith("/set "):
            self.input_text, self.cursor = "", 0
            self.set_command(text)
            return
        if text == "/theme":
            self.input_text, self.cursor = "", 0
            self.add("info", "可用主题：" + "、".join(f"{THEME_LABELS.get(t, t)}({t})" for t in THEMES))
            return
        if text.startswith("/theme "):
            arg = text[len("/theme "):].strip()
            name = THEME_ALIASES.get(arg) or (arg if arg in THEMES else None)    # 新加的主题没登记别名也能用
            if name:
                apply_theme(name)
                self.settings["theme"] = name
                save_settings(self.settings)
                self.add("info", f"已切换到 {THEME_LABELS.get(name, name)} 主题")
            else:
                self.add("info", "可用主题：light/白色/浅色、dark/深色/暗色、green/护眼绿/绿色、sepia/暖色/羊皮纸")
            self.input_text, self.cursor = "", 0
            return
        if not self.ensure_agent():
            return
        if self.busy:                            # A库 正在干活：这句话交给独立的对话线程，不打断那一轮
            self._side_chat(text)
            return
        self._submit_turn(text)

    def _side_chat(self, text: str):
        """A库 干活时主人接着说话：走独立的闲聊 Agent，工作流继续，不打断也不进它的 inbox。"""
        self._chat_turn(text)
        if not getattr(self, "_side_hinted", False):          # 第一次提示一下怎么用
            self._side_hinted = True
            self.add("info", "工作流继续在跑，前台在跟你聊：问进度、说「暂停 / 继续 / 别干了」、提新要求都可以直接跟它说；"
                             "新要求会转给干活的 Agent，下一步就采纳。")

    def _submit_turn(self, text: str, display: bool = True):
        """把一句话当成一轮需求提交给 A库（用户回车、重启后自检都走这里）。display=False 时不往聊天框放用户气泡。"""
        if getattr(self, "_mem_pending", False) and self.agent:
            self.restore_memory()                    # 上次的对话还没读进来：先读，再开这一轮
        self.input_text, self.cursor = "", 0
        if display:
            self.add("user", text)
        self.turn_flow = Message("workflow")
        self.messages.append(self.turn_flow)
        self.turn_answer = None
        self.selected_flow = None            # 右栏跟随最新一轮
        self.chat_view.stick = True
        self.busy = True
        self.turn_seq = getattr(self, "turn_seq", 0) + 1
        threading.Thread(target=self._run_agent, args=(text, self.turn_seq), daemon=True).start()

    def kick_queue(self):
        """任务队列里有活、Agent 闲着：开一轮，它会一直做到队列清空（core.Agent._drain_queue）。"""
        from lib_a import taskq
        if self.busy or not taskq.next_up():
            return
        from lib_a.core import QUEUE_MARK
        self._submit_turn(QUEUE_MARK + "任务队列里还有没做完的活，按顺序接着做，做到清空。", display=False)

    def _run_agent(self, text, seq=0):
        """跑一轮。Agent 自己在收尾时会发 done；这里出异常只发 turn_failed（带轮号），由主线程判断要不要补一个 done——
        以前不管三七二十一再发一次 done：被停掉的那一轮（停止是靠异常跳出来的）会多出一个 done，
        正好把紧接着开的下一轮当成结束了（界面显示就绪、工作流卡片收掉，思考过程一段段掉进聊天栏）。"""
        try:
            self.agent.chat(text)
        except Exception as e:
            if "StopRequested" not in f"{type(e).__name__}: {e}":     # 主人停掉的不算出错
                self.events.put(("error", f"{type(e).__name__}: {e}"))
            self.events.put(("turn_failed", seq))

    def _selftest_log_request(self):
        """重启后自检：请求写进工作流日志（不进聊天框），并标记这一轮是自检轮。"""
        self._selftest_turn = True
        try:
            flag = str(self_test_flag_path())
        except Exception:
            flag = ""
        line = "重启后自检：请求已排上"
        if flag:
            line += f"（标记 {flag}）"
        note = (getattr(self, "_selftest_note", "") or "").strip()
        if note:
            line += f" / 自定义重点：{note}"
        lib_b.worklog.write("Terminist", "info", line)

    @staticmethod

    def _selftest_bad(text: str) -> str:
        """从自检结论里挑出失败项（"0 项失败 / 没有失败" 之类不算），返回摘要，全通过就返回空串。"""
        bad = []
        for ln in (text or "").splitlines():
            ln = ln.strip()
            if not ln or not any(w in ln for w in ("失败", "未通过", "不通过")):
                continue
            if re.search(r"(0|零|无|没有|全部?\s*通过)\s*(项|个|处)?\s*(失败|未通过|不通过)", ln):
                continue
            bad.append(ln)
        if not bad and any(w in (text or "") for w in ("自检失败", "验证失败")):
            bad = ["（模型没有逐条列出失败项，请展开工作流日志看完整结论）"]
        return "\n".join(bad[:3])

    def _finish_selftest(self):
        """自检这一轮结束：结论写进工作流日志；只有出现失败项时才在聊天里说一句。"""
        text = self.turn_answer.text if self.turn_answer is not None else ""
        if not (text or "").strip() and self.turn_flow is not None:
            text = next((m.text for m in reversed(self.turn_flow.children)
                         if m.kind in ("assistant", "worker")), "")
        if self.turn_answer is not None and self.turn_answer in self.messages:
            self.messages.remove(self.turn_answer)          # 自检结论不占聊天框
        text = (text or "").strip()
        bad = self._selftest_bad(text)
        if bad:
            lib_b.worklog.write("Terminist", "info", f"重启后自检：失败 {bad}")
            self.add("assistant", f"重启后自检有失败项：{bad}")
        elif text:
            lib_b.worklog.write("Terminist", "info", "重启后自检：全部通过")
        else:
            lib_b.worklog.write("Terminist", "info", "重启后自检：没有拿到结论，详情看上面的工作流日志")
        self._selftest_note = ""
        self._selftest_turn = False
        self.turn_flow = self.turn_answer = None

    def answer_confirm(self, ok: bool, always=False):
        req = self.pending_confirm
        if not req:
            return
        is_clear = getattr(req, "kind", "") == "clear"   # 清空对话的确认：不吃“全部允许”
        if always and not is_clear:
            self.auto_yes = True
            if self.ws is not None:
                self.ws.auto_yes = True
        req.result = ok
        req.event.set()
        self.pending_confirm = None
        if always and not is_clear:                  # 排队中的确认一并允许（接管申请除外：必须主人单独点「确定」）
            keep = [q for q in self.confirm_queue if getattr(q, "kind", "") == "takeover"]
            for q in self.confirm_queue:
                if q not in keep:
                    q.result = True
                    q.event.set()
            self.confirm_queue[:] = keep
            if keep and self.pending_confirm is None:
                self.pending_confirm = self.confirm_queue.pop(0)
                self.modal_scroll = 0
        elif self.confirm_queue:
            self.pending_confirm = self.confirm_queue.pop(0)
            self.modal_scroll = 0
        if is_clear:                                 # 点了「清空」才真清，「取消」什么都不动
            if ok:
                self._do_clear()
            else:
                self.add("info", lang("confirm_clear_cancelled"))
        if getattr(req, "kind", "") == "takeover":   # 接管模式：点了「确定」才进，「取消」什么都不动
            if ok:
                self.start_takeover()
            else:
                self.add("info", "没有进入接管模式。")
        if self.panel.status == "等待确认":
            self.panel.status = "执行中…" if ok else "已拒绝"

    def answer_credentials(self, ok: bool):
        """账号密码弹窗的答案：提供就存到本地密钥库，拒绝就告诉 Agent 别猜。"""
        req = self.pending_credentials
        if not req:
            return
        if ok and (req.user or "").strip():
            result = {"ok": True, "site": req.site, "username": req.user,
                      "password": req.pwd if req.remember else "", "remember": bool(req.remember)}
            try:
                from lib_a.extensions import credentials_store
                credentials_store.save(req.site, req.site, req.user, req.pwd, bool(req.remember))
            except Exception:
                pass                       # 存不进本地也不影响这一轮填表
        else:
            result = {"ok": False}
        req.result = result
        req.event.set()
        self.pending_credentials = self.cred_queue.pop(0) if self.cred_queue else None
        self.cred_cursor = 0
        self._dirty = True

    # ---------------- Agent 事件 ----------------

    def drain_events(self):
        if self.pending_stops:                       # 子线程请求的停止：到主线程这一帧才真正做
            req = self.pending_stops.pop(0)
            self.stop_workflow(req.get("agents"))
        while True:
            try:
                kind, payload = self.events.get_nowait()
            except queue.Empty:
                return
            self._dirty = True                         # 后台有更新：这一帧必须重绘
            kind, payload = self._route(kind, payload)
            if kind == "__handled__":
                continue
            if kind in modules_api.AGENT_EVENTS:       # 外接模块的 on_agent：Agent 调了什么、这一轮做完了
                try:
                    modules_api.agent_event(kind, payload)
                except Exception:
                    pass
            if kind.startswith("chat_"):               # 闲聊 Agent 的事件：单独成气泡，不进工作流、不影响干活那一轮
                self.on_chat_event(kind[len("chat_"):], payload)
                continue
            if kind == "credentials":                  # 网页要账号密码：排队显示，没有在显示就直接弹
                if self.pending_credentials is not None:
                    self.cred_queue.append(payload)
                    continue
                self.pending_credentials = payload
                self.cred_cursor = 0
                continue
            if kind == "confirm":
                if self.pending_confirm is not None:
                    self.confirm_queue.append(payload)
                    continue
                self.pending_confirm = payload
                self.modal_scroll = 0
                if self.current_call and self.current_call["name"] in WRITE_TOOLS:
                    self.panel.status = "等待确认"
            elif kind == "toast":                      # 原生桌面通知没弹成：主线程里用界面内 toast 兜底
                self.show_toast(payload)
            elif kind == "takeover_expire":            # 申请没人理过期了：从确认框 / 排队里撤掉
                req = payload
                if self.pending_confirm is req:
                    self.pending_confirm = self.confirm_queue.pop(0) if self.confirm_queue else None
                elif req in self.confirm_queue:
                    self.confirm_queue.remove(req)
                self.add("info", "Agent 的接管申请 5 分钟没人回应，已撤回。")
            elif kind == "takeover_end":               # Agent 自己退出接管：主线程里退，弹窗告诉主人
                summary, box = payload
                box["was"] = bool(getattr(self, "takeover_active", False))
                self.stop_takeover(summary, by_agent=True)
                box["ready"].set()
            elif kind == "takeover_request":           # Agent 申请接管：主线程弹确认框，结果回给等着的工具
                reason, box = payload
                if getattr(self, "takeover_active", False):
                    box["req"] = None
                else:
                    box["req"] = self.request_takeover(reason)
                    self.bring_to_front()
                box["ready"].set()
            elif kind == "choice":
                req = payload
                msg = Message("choice", req.msg)
                msg.options = req.options
                msg.req = req
                self.messages.append(msg)
                self.chat_view.stick = True
                self._dirty = True
                continue
            elif kind == "workspace_opened":           # AI 自己打开了桌面上的文件夹：界面跟着换，并在聊天里告知
                self.ws = self.agent.ws if self.agent else self.ws
                if self.ws is not None:
                    self.tree.set_root(self.ws.root)
                    self.panel.reset()
                ev = json.loads(payload)
                verb = "新建并打开了" if ev.get("created") else "打开了"
                self.add("info", f"AI 自己{verb}文件夹：{ev.get('path')}\n"
                                 f"（只能是桌面里的文件夹；可以改里面的内容，删除仍要你确认；不想要可以点 \"打开文件夹\" 换掉）")
            elif kind == "api_key_checked":
                self.on_api_key_checked(*payload)
            elif kind == "front_report":               # B库 实在改不好：前台用自己的口吻来告诉你
                ev = json.loads(payload)
                m = Message("assistant", ev.get("text", ""))
                m.who = ev.get("who", "前台")
                self.messages.append(m)
            elif kind == "turn_failed":                # 这一轮异常退出：Agent 没来得及发 done 才补一个（已经开了下一轮就别管）
                if payload == getattr(self, "turn_seq", 0) and self.busy:
                    self.events.put(("done", ""))
            elif kind == "queue_kick":                 # 前台往队列加了活，Agent 正闲着：开工
                self.kick_queue()
            elif kind == "restart_request":            # Agent 调了 restart_terminist：这一轮结束就重启
                self.remember_window_size()            # 重启前把窗口尺寸落盘，新进程按这个开
                self.restart_after_turn = True
            elif kind in ("paused", "resumed"):
                self.paused = kind == "paused"
                if self.busy:
                    self.add("info", "⏸ 工作流已暂停：当前这一步做完就停住（点顶栏「继续」或跟前台说继续）"
                             if self.paused else "▶ 工作流继续")
            elif kind == "steer":
                self.add("info", f"新要求已转给干活的 Agent：{payload[:120]}"
                         + ("（下一步就采纳）" if self.busy else "（这一轮已经结束，会作为新的一轮）"))
            elif kind == "steer_applied":
                if self.turn_flow is not None:
                    self.turn_flow.children.append(Message("info", "采纳了追加的要求：\n" + payload))
            elif kind == "done":
                was_selftest = getattr(self, "_selftest_turn", False)
                self.paused = False
                self.progress = {"total": 0, "done": 0, "label": ""}   # 一轮结束：进度条清掉
                self.busy = False
                self.current_call = None
                self.active_workers.clear()
                if was_selftest:   # 自检轮：结论只进工作流日志，不刷聊天框
                    self._finish_selftest()
                if self.restart_after_turn:
                    self.remember_window_size()
                    self.restart_after_turn = False
                    self.restart_at = pygame.time.get_ticks() + 1500
                    self.add("info", "马上重启…（新窗口出来后这个窗口自己关）")
                if self.restart_version and self.settings.get("auto_restart", True):
                    self.remember_window_size()
                    self.restart_at = pygame.time.get_ticks() + 2500     # 留一点时间让人看到结论
                    self.add("info", "新版本已交工，2 秒后自动重启…（设置里可改成手动重启）")
                if self.turn_flow and not self.turn_flow.children and self.turn_flow in self.messages:
                    self.messages.remove(self.turn_flow)
                if self.turn_answer is None and self.turn_flow is not None:
                    last = next((m for m in reversed(self.turn_flow.children)
                                 if m.kind in ("assistant", "worker")), None)
                    if last is not None and (last.text or "").strip():
                        self.messages.append(Message("assistant", last.text))
                self.turn_flow = self.turn_answer = None
                if not was_selftest and not self.restart_after_turn and not self.restart_at:
                    self.show_toast("任务完成")
                if self.side is not None:                # 干活期间的旁聊并进记忆：两边是同一段历史
                    self.side.merge_into_main()
                left = self.agent.take_steer() if self.agent else []
                if left and not self.restart_after_turn and not self.restart_at:   # 没来得及采纳的新要求：接着干
                    self._submit_turn("（刚才干活时追加、还没来得及处理的要求）\n" + "\n".join(f"- {t}" for t in left))
            elif kind == "penalty":
                self.penalty = json.loads(payload)
            elif kind == "ui_command":
                self.apply_ui(json.loads(payload))
            elif kind == "web_seen":                   # 网页刚被打开/操作过：该开独立小屏幕就开
                try:
                    self._screen_auto()
                    self.screen_next = 0                   # 马上重截一张
                    if getattr(self, "screen_win_open", False):
                        self._screen_topmost()             # 每次上网都把独立窗口重新顶到最前
                    self.mark_dirty()
                except Exception:
                    pass
            elif kind == "screen_shot":                # 小屏幕截图：独立线程去截，主循环收结果
                if getattr(self, "screen_req", None) is None:
                    self.screen_req = payload
                    self.handle_screen_shot(payload)
            elif kind == "voice_done":                 # 语音转写结果：填进输入框，不自动发送
                self.on_voice_done(payload)
            elif kind == "image":
                self.add_image(json.loads(payload))
            elif kind == "board":                      # A库 抽画板 / 收起画板：{"open": true, "tool": "brush"}
                self.on_board_event(payload)
            elif kind == "delete_confirm":
                self.show_delete(payload)
            elif kind == "model_info":
                self.actual_model = payload
            elif kind == "progress":                      # A库 上报工作流进度（{total, done, label}）
                try:
                    p = json.loads(payload)
                    self.progress = {"total": int(p.get("total", 0) or 0),
                                     "done": int(p.get("done", 0) or 0),
                                     "label": str(p.get("label", "") or "")}
                except Exception:
                    self.progress = {"total": 0, "done": 0, "label": ""}
            elif kind == "models":
                self.models = payload if self.model in payload or self.model == da.TEAM_MODE \
                    else [self.model] + payload
            elif kind == "member":
                self.current_member = payload
                flow = self.turn_flow
                if flow is not None and (not flow.members or flow.members[-1] != payload):
                    flow.members.append(payload)
            elif kind == "context":
                ev = json.loads(payload)
                self.context = (ev["tokens"], ev["limit"])
                self.economy = {
                    "total_prompt": int(ev.get("total_prompt", 0) or 0),
                    "total_output": int(ev.get("total_output", 0) or 0),
                    "rate": ev.get("rate", 0.0) or 0.0,
                    "lifetime_prompt": int(ev.get("lifetime_prompt", 0) or 0),
                    "lifetime_output": int(ev.get("lifetime_output", 0) or 0),
                    "series_5s": list(ev.get("series_5s", []) or []),
                    "series_1min": list(ev.get("series_1min", []) or []),
                    "series_1h": list(ev.get("series_1h", []) or []),
                    "series_5s_in": list(ev.get("series_5s_in", []) or []),
                    "series_5s_out": list(ev.get("series_5s_out", []) or []),
                    "series_1min_in": list(ev.get("series_1min_in", []) or []),
                    "series_1min_out": list(ev.get("series_1min_out", []) or []),
                    "series_1h_in": list(ev.get("series_1h_in", []) or []),
                    "series_1h_out": list(ev.get("series_1h_out", []) or []),
                    "utilization": ev.get("utilization", 0.0) or 0.0,
                    "util_formula": ev.get("util_formula", "利用率 = 输出 ÷ (输入+输出)"),
                    "cost_session": float(ev.get("cost_session", 0.0) or 0.0),
                    "cost_window": float(ev.get("cost_window", 0.0) or 0.0),
                    "series_1min_cost": list(ev.get("series_1min_cost", []) or []),
                    "series_1h_cost": list(ev.get("series_1h_cost", []) or []),
                    "cost_last_min": float(ev.get("cost_last_min", 0.0) or 0.0),
                    "cost_last_hour": float(ev.get("cost_last_hour", 0.0) or 0.0),
                    "cost_lifetime": float(ev.get("cost_lifetime", 0.0) or 0.0),
                }
            elif kind == "memory":
                self.add("memory", payload)
            elif kind.startswith("b_"):
                self.on_b_event(kind, payload)
            elif kind == "worker":
                self.on_worker_event(json.loads(payload))
            elif kind == "escalate":
                self.demote_answer()
                if self.turn_flow is not None:
                    self.turn_flow.children.append(Message("escalate", payload))
                else:
                    self.add("escalate", payload)
            elif kind == "tool_args":
                self.demote_answer()
                self.on_tool_args(json.loads(payload))
            elif kind == "tool_call":
                self.on_tool_call(json.loads(payload))
            elif kind == "assistant":
                if not payload:
                    continue
                if self.turn_answer is None:           # 结论卡片放在工作流下面
                    self.turn_answer = Message("assistant")
                    self.turn_answer.who = self.current_member if self.model == da.TEAM_MODE else ""
                    self.messages.append(self.turn_answer)
                self.turn_answer.text += payload
            elif kind in ("reasoning", "tool", "result") and not self.turn_flow and payload:
                self.turn_flow = Message("workflow")       # 界面以为这一轮结束了、Agent 其实还在干：接着开一张工作流卡片
                self.messages.append(self.turn_flow)
                self.busy = True
                if kind == "result":
                    self.on_tool_result(payload)
                self.turn_flow.children.append(Message(kind, payload))
            elif kind in ("reasoning", "tool", "result") and self.turn_flow:
                if kind == "reasoning" and not payload:
                    continue
                if kind != "reasoning":
                    self.demote_answer()
                if kind == "result":
                    self.on_tool_result(payload)
                    payload = payload or "(空)"
                kids = self.turn_flow.children
                if kind == "reasoning" and kids and kids[-1].kind == "reasoning":
                    kids[-1].text += payload            # 流式追加
                else:
                    kids.append(Message(kind, payload))
            elif payload or kind not in ("reasoning",):
                if kind == "result":
                    self.on_tool_result(payload)
                self.add(kind, payload)

    def on_chat_event(self, kind: str, payload):
        """把闲聊 Agent 的输出攒成一条独立的 chat 气泡；它的工具调用等杂项事件直接忽略。"""
        if kind == "assistant":
            self._chat_buf += payload
        elif kind == "done":
            text = self._chat_buf.strip()
            self._chat_buf = ""
            if text:
                self.messages.append(Message("chat", text))
                self.chat_view.stick = True
            if not self.busy and self.side is not None:      # 活已经干完了：这段旁聊直接并进记忆
                self.side.merge_into_main()
        elif kind in ("error", "chat_error"):
            self._chat_buf = ""
            self.add("info", f"闲聊出错：{payload}")

    def _route(self, kind, payload):
        """统一入口：零散提示（info / error 等）本轮已有工作流就挂进工作流，不单独占主聊天一行。"""
        # 流式场景直接在 drain_events 里处理的事件，原样返回
        stream_kinds = ("user", "model_info", "models", "member", "context", "memory", "image", "delete_confirm",
                        "api_key_checked", "workspace_opened", "front_report", "queue_kick", "restart_request", "done", "penalty", "choice",
                        "turn_failed",
                        "ui_command", "assistant", "reasoning", "tool", "result", "tool_args", "tool_call",
                        "escalate", "worker", "credentials")
        if kind in stream_kinds or kind.startswith("b_"):
            return kind, payload
        if not isinstance(payload, str):             # 带对象的事件（弹窗请求之类）原样交给 drain_events，不能当文字挂进工作流
            return kind, payload
        if payload and self.turn_flow is not None and kind in STYLE:
            self.turn_flow.children.append(Message(kind, payload))
            self.demote_answer()             # 说完这句还在继续干活，前面那段文字不是结论
            self.chat_view.stick = True
            return "__handled__", ""
        return kind, payload

    def demote_answer(self):
        """模型说完一段话后又去调用工具，说明那段话不是结论，收进工作流。"""
        ans = self.turn_answer
        if ans is None:
            return
        if ans in self.messages:
            self.messages.remove(ans)
        if self.turn_flow is not None:
            self.turn_flow.children.append(ans)
        self.turn_answer = None

    def on_worker_event(self, ev: dict):
        """执行成员的事件：每个成员一张卡片，把它的每一步追加进去；写文件照样进写入面板和文件树。"""
        w, kind, text = ev["w"], ev["kind"], ev["text"]
        if kind == "start":
            info = json.loads(text)
            card = Message("worker", f"{info['title']}\n负责：{', '.join(info['files']) or '只读'}")
            card.who = w if isinstance(w, str) else "#" + str(w)      # 不显示用的哪个模型
            self.worker_cards[w] = card
            self.active_workers.add(w)
            self.demote_answer()                 # 先说的那句话不是结论，收进工作流
            if self.turn_flow is not None:
                self.turn_flow.children.append(card)
            else:
                self.messages.append(card)
            return
        card = self.worker_cards.get(w)
        if card is None:
            return
        if kind == "tool":
            card.text += f"\n· {text[:160]}"
        elif kind == "result":
            card.text += f"\n   → {(text.splitlines() or [''])[0][:100]}"
            self.current_call = self.worker_calls.pop(w, None)
            self.on_tool_result(text)
        elif kind == "tool_args":
            a = json.loads(text)
            a["i"] = f"{w}:{a['i']}"                 # 不同成员的工具调用编号会重复
            self.on_tool_args(a)
        elif kind == "tool_call":
            c = json.loads(text)
            self.worker_calls[w] = c
            self.on_tool_call(c)
        elif kind in ("info", "error"):
            card.text += f"\n! {text}"
        elif kind == "end":
            res = json.loads(text)
            self.active_workers.discard(w)
            report = res.get("report", "").strip().replace("\n", " ")
            card.text += ("\n[完成] " if res.get("ok") else "\n[失败] ") + (report[:300] + ("…" if len(report) > 300 else ""))

    def on_b_event(self, kind: str, payload: str):
        """B库（改造层）的事件：过程放进右栏工作流，写文件照样显示在写入面板。"""
        if kind == "b_refresh":
            ev = json.loads(payload)
            return self.hot_reload(ev.get("files", []), ev.get("title", ""), ev.get("root"))
        if kind == "b_tool_args":
            return self.on_tool_args(json.loads(payload), reveal=False)
        if kind == "b_tool_call":
            return self.on_tool_call(json.loads(payload), reveal=False)
        if kind == "b_delivered":
            ev = json.loads(payload)
            self.restart_needed = self.restart_needed or ev.get("restart", False)
            if ev.get("restart"):
                self.restart_version = ev.get("version", "")
            auto = ev.get("restart") and self.settings.get("auto_restart", True)
            self.add("b_stage", f"B库已交工，改动：{', '.join(ev.get('files', []))}"
                     + ("\n本轮结束后自动重启到新版本" if auto else
                        "\n点顶栏的 \"重启生效\" 使用新版本" if ev.get("restart") else ""))
            self._windows_toast("任务完成，已交工" + (": " + ", ".join(ev.get("files", []) or []) if ev.get("files") else ""))
            return
        if kind in ("b_info", "b_error", "b_escalate", "b_memory"):
            kind = "b_stage"
        if kind not in STYLE:
            return
        if kind == "b_result":
            self.on_tool_result(payload, reveal=False)
        flow = self.turn_flow
        if flow is None:
            self.add(kind, payload)
        elif kind in ("b_reasoning", "b_assistant") and flow.children and flow.children[-1].kind == kind:
            flow.children[-1].text += payload           # 流式追加
        elif payload or kind not in ("b_reasoning", "b_assistant"):
            flow.children.append(Message(kind, payload))

    def on_tool_args(self, ev: dict, reveal: bool = True):
        i, name = ev["i"], ev["name"]
        if ev["new"]:
            self.stream_calls[i] = False          # 新一次工具调用，面板尚未切过去
        if name not in WRITE_TOOLS:
            return
        if not self.stream_calls.get(i):
            self.panel.start(name)
            self.stream_calls[i] = True
        self.panel.feed(ev["delta"])
        # 路径一传完就让左栏定位过去，不用等整个工具调用生成完
        path = partial_json_str(self.panel.raw, "path")
        if reveal and path and re.search(r'"path"\s*:\s*"(?:[^"\\]|\\.)*"', self.panel.raw):
            rel = self.tree.rel(path)
            if rel is not None and (rel != self.tree.focus or self.tree.focus_tool != name):
                self.tree.reveal(rel, name, False)

    def on_tool_call(self, ev: dict, reveal: bool = True):
        name, raw = ev["name"], ev["args"]
        self.current_call = ev
        args = parse_args(raw)
        path = args.get("path", "." if name in ("list_dir", "search", "run_command") else "")
        rel = self.tree.rel(str(path)) if reveal else None     # B库 改的是 Terminist 自己，不在工作区里
        if rel is not None:
            is_dir = name in ("list_dir", "run_command") or (name == "search" and (self.tree.root / rel).is_dir())
            self.tree.reveal(rel, name, is_dir)
        if name in WRITE_TOOLS:
            if self.panel.tool != name or self.panel.raw != raw:   # 同一次调用流式已收完就不重置
                self.panel.start(name, raw)
            self.panel.version += 1
            self.panel.status = "执行中…"

    def on_tool_result(self, result: str, reveal: bool = True):
        call = self.current_call
        if not call:
            return
        name = call["name"]
        rel = self.tree.rel(str(parse_args(call["args"]).get("path", ""))) if reveal else None
        ok = not result.startswith(("错误", "用户拒绝"))
        if rel:
            if name == "read_file" and ok:
                self.tree.status.setdefault(rel, "read")
            elif name == "write_file" and ok:
                self.tree.status[rel] = "new" if result.startswith("已新建") else "modified"
            elif name == "edit_file" and ok and self.tree.status.get(rel) != "new":
                self.tree.status[rel] = "modified"
            elif name == "delete_file" and ok:
                self.tree.status.pop(rel, None)
        if reveal and name in ("write_file", "edit_file", "delete_file", "move_file", "run_command"):
            self.tree.dirty = True
        if name in WRITE_TOOLS:
            self.panel.status = "已写入" if ok else ("已拒绝" if result.startswith("用户拒绝") else "失败")
        self.current_call = None

    # ---------------- 输入事件 ----------------

    def handle(self, e):
        if e.type == pygame.QUIT:
            return False
        if getattr(self, "screen_win_open", False):        # 独立小屏幕窗口的事件先交给小屏幕
            r = self.handle_screen_window(e)
            if r is not None:
                return r
        if getattr(self, "staff_win_open", False):         # 独立员工栏窗口的事件交给它（投影只转输入）
            r = self.handle_staff_window(e)
            if r is not None:
                return r
        if getattr(self, "panel_windows", None):           # 其它面板的独立窗口（多窗口按 key 各管各的）
            r = self.handle_panel_windows(e)
            if r is not None:
                return r
        if e.type == getattr(pygame, "DROPBEGIN", -2) and not self._is_screen_event(e) \
                and not self._is_staff_event(e):
            self._drop_hover = True                        # 文件拖进窗口：聊天栏亮起「拖拽到此处」
            self.mark_dirty()
            return True
        if e.type == getattr(pygame, "DROPCOMPLETE", -3) and not self._is_screen_event(e) \
                and not self._is_staff_event(e):
            self._drop_hover = False                       # 拖出窗口 / 松手结束：提示消失
            self.mark_dirty()
            return True
        if e.type == getattr(pygame, "DROPFILE", -1) and not self._is_screen_event(e)                 and not self._is_staff_event(e) and self._drop_on_module(getattr(e, "file", "")):
            self._drop_hover = False                       # 拖到外接模块上：交给它的 on_drop
            return True
        if e.type == getattr(pygame, "DROPFILE", -1) and not self._is_screen_event(e) \
                and not self._is_staff_event(e):
            self.on_drop_file(getattr(e, "file", ""))      # 从资源管理器拖图片进窗口
            self._drop_hover = False                       # 落图后提示立刻消失
            return True
        if e.type == pygame.VIDEORESIZE and not self._is_screen_event(e) \
                and not self._is_staff_event(e):
            self.screen = pygame.display.get_surface()     # pygame 2 会自动调整窗口表面，不要再 set_mode
            if not self.settings["fullscreen"]:
                self.settings["window_size"] = [e.w, e.h]
        if e.type == pygame.KEYDOWN and e.key == pygame.K_F11:
            self.toggle_fullscreen()
            return True
        if e.type == pygame.KEYDOWN and e.key == pygame.K_p and getattr(self, "takeover_active", False) \
                and not self.input_text and not getattr(self, "composing", "") \
                and self.pending_confirm is None and not self.pending_delete \
                and not getattr(self, "pending_credentials", None) and not getattr(self, "pending_need", None) \
                and getattr(self, "choice_typing", None) is None and not self.settings_open \
                and getattr(self, "key_edit", None) is None and modules_api.focused() is None \
                and not self._web_kbd():
            self.toggle_takeover_pause()         # 接管中按 P：暂停 / 继续（正在打字时 P 还是普通字母）
            return True

        if self.pending_delete:                  # 删除确认最优先
            return self.handle_delete(e)
        if getattr(self, "pending_credentials", None):   # 要账号密码的弹窗：比别的都优先
            return self.handle_credentials(e)
        if getattr(self, "pending_need", None):          # Agent 卡住要东西的弹窗
            return self.handle_need(e)
        if self.pending_confirm:
            return self.handle_modal(e)
        if self.settings_open:
            return self.handle_settings(e)
        if getattr(self, "live_layout", False):     # 实时拖动布局：只处理分隔条和退出键
            return self.handle_live_layout(e)

        if not self.screen_win_open and self._web_event(e, "dock"):   # 小浏览器优先：工具栏、点 / 拖 / 滚网页、打字
            self.mark_dirty()
            return True
        # 左栏小屏幕面板：兜底重开（独立窗口通常由程序自动开）
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and self.screen_win_open \
                and self.screen_panel_rect.w > 0 and self.screen_panel_rect.collidepoint(e.pos):
            self.open_screen_window()
            return True

        left, center, right = self.layout()
        if getattr(self, "staff_card", None) is not None and e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.click_staff_card(e.pos)             # 信息卡是模态：点哪儿都吃掉这次点击
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and getattr(self, "staff_menu", None) is not None:
            if not any(r.collidepoint(e.pos) for r, _a in getattr(self, "staff_menu_rects", [])):
                self.staff_menu, self.staff_menu_rects = None, []      # 点别处：批评菜单收起
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
                if surf is self.screen and body.collidepoint(e.pos) and modules_api.click(
                        self, k, self.screen, body, C, S, utext, e.pos):
                    self._plugin_down = k              # 记下按下的模块，松手时即使移出 rect 也把 up 发过来
                    self.mark_dirty()
                    return True
            hid = self._dock_hit_hide(e.pos)                  # 槽标题条上的 X：先把面板真拿掉，别当成拖拽
            if hid:
                self._dock_hide_panel(hid)
                self.mark_dirty()
                return True
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:
            if getattr(self, "input_rect", None) is not None and self.input_rect.collidepoint(e.pos):
                _p = self._save_clipboard_image()      # 输入框右键粘贴：剪贴板是图就进待发列表
                if _p:
                    self.add_pending_image(_p)
                else:
                    self.insert(get_clipboard())
                self.mark_dirty()
                return True
            for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
                if surf is self.screen and body.collidepoint(e.pos) and modules_api.event(
                        "down", self, k, body, C, S, utext, e.pos):
                    self._plugin_down = k
                    self.mark_dirty()
                    return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            mod = self._modules_hit(e.pos)                    # 模块管理里点一行：放回默认栏
            if mod == "__reload__":
                self.load_modules()
                self.mark_dirty()
                return True
            if mod and mod.startswith("__toggle__:"):         # 停用 / 启用一个外接模块：马上刷新生效
                label = mod[len("__toggle__:"):]
                on = label in modules_api.disabled()
                modules_api.set_enabled(label, on)
                self.notice("info", self.load_modules(quiet=True) if on else
                            f"已停用 {label}：{self.load_modules(quiet=True)}")
                self.mark_dirty()
                return True
            if mod:
                self._dock_restore_panel(mod)
                self.modules_open = False
                self.mark_dirty()
                return True
            mbr = getattr(self, "modules_btn_rect", None)
            if isinstance(mbr, pygame.Rect) and mbr.w > 0 and mbr.collidepoint(e.pos):
                self.modules_open = not self.modules_open            # 左下角「模块」：开 / 关模块管理
                self.mark_dirty()
                return True
            if self.modules_open:
                self.modules_open = False                       # 点模块管理面板外面：收起
                self.mark_dirty()
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            hit = self._panel_head_at(e.pos)                  # 面板标题条：按住拖出来就成独立窗口
            if hit:
                self._set_panel_drag(hit, e.pos)
                if hit == "staff":
                    return True                              # staff 命中标题条就吃掉这次点击（行为照旧）
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            ph = getattr(self, "staff_placeholder_rect", None)
            if isinstance(ph, pygame.Rect) and ph.w > 0 and ph.collidepoint(e.pos) \
                    and getattr(self, "staff_win_open", False):
                self.close_panel_window("staff", dock=True)   # 点虚影：员工栏归位
                return True
            if self.dropdown_open:      # 下拉框打开时，任意点击都先关闭它
                for rect, name in self.dropdown_rects:
                    if rect.collidepoint(e.pos):
                        if name != self.model:
                            self.set_model(name)
                        break
                self.dropdown_open = False
                return True
            for mode, r in zip(("left", "right", "input"), self.drag_handles()):   # 先看是不是点在分隔条上
                if r.w and r.collidepoint(e.pos):
                    self.drag_mode = mode
                    return True
            candy = getattr(self, "btn_candy", None)
            if candy is not None and candy.rect.w > 0 and candy.rect.collidepoint(e.pos) and self.candy_btn_on():
                self.on_candy()                        # 糖果按钮：label 是自绘图标，不走 Button.click
                return True
            for b in self.visible_top_buttons() + [self.btn_image, self.btn_voice, self.btn_send]:
                if b.click(e.pos):
                    return True
            for rect, idx in getattr(self, "pending_img_close_rects", []):   # 输入框缩略图上的小✕
                if rect.collidepoint(e.pos):
                    self.remove_pending_image(idx)
                    return True
            if self.input_rect is not None and self.input_rect.collidepoint(e.pos):
                modules_api.set_focus(None)            # 点主输入框：把被外接模块抢走的键盘焦点释放回来
                idx = self.input_index_at(e.pos)       # 点输入框：把光标放到点的位置，按住拖可以选择
                if not (pygame.key.get_mods() & pygame.KMOD_SHIFT):
                    self.sel_anchor = idx
                elif self.sel_anchor is None:
                    self.sel_anchor = self.cursor
                self.cursor = idx
                self.dragging_input = True
                return True
            for r, panel in getattr(self, "panel_icon_rects", []):
                if r.collidepoint(e.pos):          # 左栏底部的区块图标：在右栏打开它的设置
                    self.open_settings_panel(panel)
                    return True
            if left.collidepoint(e.pos):
                if self.click_staff(e.pos):      # 点员工行优先于下面的文件树预览
                    return True
                self.click_tree(e.pos)
            elif right.collidepoint(e.pos):
                if self.click_goal_queue(e.pos):   # 目标队列卡片上的 ↑ ↓ ✕ / ＋
                    return True
                for r, panel, _title in getattr(self, "spot_rects", []):
                    if r.collidepoint(e.pos):      # 每块标题上的设置图标
                        self.open_settings_panel(panel)
                        return True
                self.click_right(e.pos)
            else:
                for rect, act in self.chat_btns:   # 聊天栏右上角的清空 / 载入历史按钮
                    if rect.collidepoint(e.pos):
                        if act == "clear":
                            self.on_clear_view()       # 只清聊天栏显示，不动记忆 / 上下文
                        else:
                            self.on_load_history(5)
                        return True
                for r, m, i in getattr(self, "choice_rects", []):   # 聊天框里的选择卡片
                    if r.collidepoint(e.pos):
                        self.click_choice(m, i)
                        return True
                for rect, m in self.msg_rects:   # 点中间某一轮的对话，右栏切到那一轮的工作流
                    if rect.collidepoint(e.pos):
                        if m.kind == "image" and m.image and sys.platform == "win32":
                            try:
                                os.startfile(m.image)     # 用系统看图软件打开原图
                            except OSError:
                                pass
                        flow = self.flow_of(m)
                        if flow is not None:
                            self.selected_flow = flow
                        break
        elif e.type == pygame.MOUSEWHEEL:
            mouse = pygame.mouse.get_pos()
            for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
                if surf is self.screen and body.collidepoint(mouse) and modules_api.event(
                        "wheel", self, k, body, C, S, utext, (mouse, e.y)):
                    self.mark_dirty()
                    return True
            if getattr(self, "_goal_expanded", None) and right.collidepoint(mouse):
                self._goal_scroll = max(0, getattr(self, "_goal_scroll", 0) + (e.y if e.y > 0 else -1))
                self.mark_dirty()
                return True
            if (getattr(self, "staff_panel", True) and left.collidepoint(mouse)
                    and self.staff_last_rect.collidepoint(mouse)):
                top = max(0, getattr(self, "staff_content_h", 0) - self.staff_last_rect.h)
                self.staff_scroll -= e.y * self.small.get_linesize() * 3   # 员工列表能滚
                self.staff_scroll = max(0, min(top, self.staff_scroll))
            elif left.collidepoint(mouse):
                self.tree.scroll -= e.y * self.small.get_linesize() * 3
            elif self.write_rect.collidepoint(mouse):
                self.panel.scroll -= e.y * self.code_h * 3
                self.panel.stick = False
            elif getattr(self, "board_rect", pygame.Rect(0, 0, 0, 0)).collidepoint(mouse) \
                    and getattr(getattr(self, "board", None), "open", False):
                self.board.scroll = max(0, getattr(self.board, "scroll", 0) - e.y * self.code_h * 3)
            elif right.collidepoint(mouse):
                (self.log_view if self.flow_log else self.flow_view).wheel(e.y * self.code_h * 3)
            else:
                self.chat_view.wheel(e.y * self.line_h * 3)
        elif e.type == pygame.MOUSEMOTION and self.panel_drag:
            dk, start, moved = self.panel_drag
            if not moved and abs(e.pos[0] - start[0]) + abs(e.pos[1] - start[1]) < S(STAFF_DRAG_SLOP):
                return True                                # 还没拖够距离：当点击处理
            self._panel_ghost_to(dk, e.pos)
            self.panel_drag = (dk, start, True)
            self._dock_hover = self._dock_drop_zones(e.pos)   # 拖动中持续标出落点槽位
            self.mark_dirty()                              # 拖动虚影跟着鼠标走
        elif e.type == pygame.MOUSEBUTTONUP and e.button == 1 and self.panel_drag:
            dk, start, moved = self.panel_drag
            self._set_panel_drag(None, None)
            self._dock_hover = None
            self.mark_dirty()
            if moved:
                if self._dock_drop(dk, self._dock_drop_zones(e.pos)):
                    return True                            # 松手在槽位上：嵌入该槽，不弹独立窗口
                self.open_panel_window(dk, anchor=e.pos)    # 松手在栏外：这个面板弹出成独立窗口
        elif e.type == pygame.MOUSEMOTION and self.drag_mode:
            self.drag_sizes(e.pos)                 # 拖动分隔条：改尺寸，下一帧按新尺寸重画
        elif e.type == pygame.MOUSEMOTION and self.dragging_input:
            self.cursor = self.input_index_at(e.pos)
        elif e.type == pygame.MOUSEMOTION:
            hit, hbody = None, None                # 外接模块：进 / 出 / 移动
            for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
                if surf is self.screen and body.collidepoint(e.pos):
                    hit, hbody = k, body
                    break
            if hit != getattr(self, "_plugin_hover", None):
                old = getattr(self, "_plugin_hover", None)
                if old is not None:
                    _ob = self.plugin_rects.get(old, (self.screen, None))[1]
                    modules_api.event("leave", self, old, _ob if _ob is not None else pygame.Rect(0, 0, 0, 0),
                                      C, S, utext)
                if hit is not None:
                    modules_api.event("enter", self, hit, hbody, C, S, utext)
                self._plugin_hover = hit
                self.mark_dirty()
            if hit is not None:
                if modules_api.event("motion", self, hit, hbody, C, S, utext, e.pos):
                    self.mark_dirty()
                return True
        elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            _pdown = getattr(self, "_plugin_down", None)     # 外接模块：松手也要收到 up，否则滚轮一直跟鼠标
            for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
                if surf is self.screen and (body.collidepoint(e.pos) or k == _pdown) \
                        and modules_api.event("up", self, k, body, C, S, utext, e.pos):
                    self._plugin_down = None
                    self.mark_dirty()
                    return True
            self._plugin_down = None
            self.dragging_input = False
            self._dock_hover = None
            if self.drag_mode:                     # 拖完把尺寸存进设置，重启后还是这个宽度
                self.drag_mode = ""
                self.save_layout()
        elif e.type == pygame.TEXTEDITING:
            if e.text and self._sel():                 # 选中了文字再用输入法打字：先删掉选中的
                self._delete_sel()
            self.composing = e.text
        elif e.type == pygame.TEXTINPUT:
            self.composing = ""
            kf = modules_api.focused()             # 有模块持键盘焦点：文字先给模块，不打进主输入框
            if kf is not None:
                _b = getattr(self, "plugin_rects", {}).get(kf, (self.screen, pygame.Rect(0, 0, 0, 0)))[1]
                if modules_api.key_event(self, kf, _b, C, S, utext, None, e.text):
                    return True
            self.insert(e.text)
        elif e.type == pygame.KEYDOWN and not self.composing:
            kf = modules_api.focused()                 # 有模块持键盘焦点：按键先给模块，Esc 先释放焦点
            if kf is not None:
                if e.key == pygame.K_ESCAPE:
                    modules_api.set_focus(None)
                    self.mark_dirty()
                    return True
                _b = getattr(self, "plugin_rects", {}).get(kf, (self.screen, pygame.Rect(0, 0, 0, 0)))[1]
                if modules_api.key_event(self, kf, _b, C, S, utext, e.key, ""):
                    return True
            if e.key == pygame.K_ESCAPE and getattr(self, "staff_card", None) is not None:
                self.staff_card, self.staff_card_rects = None, []
                self.mark_dirty()
                return True
            if e.key == pygame.K_F2:                 # F2 = 语音输入：开始 / 停止录音
                self.on_voice()
                return True
            if e.key == pygame.K_ESCAPE and self.dropdown_open:
                self.dropdown_open = False
            else:
                self.handle_key(e)
        return True

    def on_board_event(self, payload):
        """A库 emit 的 board 事件（json 字符串）：打开 / 收起右栏画板区块。解析失败就忽略，不抛出去。"""
        try:
            ev = json.loads(payload) if payload else {}
        except (TypeError, ValueError):
            return
        if not isinstance(ev, dict):
            return
        self.board.set_open(bool(ev.get("open", True)))
        self.input_rect = None            # 让下一帧重排右栏
        self.mark_dirty()

    def click_right(self, pos):
        if getattr(self, "board_hide_rect", None) and self.board_hide_rect.w \
                and self.board_hide_rect.collidepoint(pos):     # 画板右上角「收起」：只关界面区块
            self.board.set_open(False)
            self.mark_dirty()
            return
        if self.panel_close_rect.collidepoint(pos):
            self.panel.reset()
            return
        for rect, act in self.log_rects:
            if rect.collidepoint(pos):
                if act == "toggle":
                    self.flow_log = not self.flow_log
                    self.log_view = ScrollView()
                elif sys.platform == "win32":
                    try:
                        os.startfile(str(lib_b.worklog.LOG_FILE))     # 用记事本之类的打开完整日志
                    except OSError:
                        pass
                return
        if self.flow_log:
            return
        for rect, m in self.flow_rects:
            if not rect.collidepoint(pos):
                continue
            if m is None:                   # "回到最新"
                self.selected_flow = None
            elif STYLE[m.kind][4]:
                m.collapsed = not m.collapsed
            return

    def flow_of(self, m: Message) -> Message | None:
        """找到某条对话所在那一轮的工作流。"""
        try:
            i = self.messages.index(m)
        except ValueError:
            return None
        start = i
        while start > 0 and self.messages[start].kind != "user":
            start -= 1
        for x in self.messages[start + 1:]:
            if x.kind == "user":
                break
            if x.kind == "workflow":
                return x
        return None

    def click_tree(self, pos):
        for rect, rel, is_dir in self.tree_rects:
            if not rect.collidepoint(pos):
                continue
            if is_dir:
                self.tree.toggle(rel)
            elif not (self.current_call and self.current_call["name"] in WRITE_TOOLS):
                try:
                    p = self.tree.root / rel
                    if p.stat().st_size > 2_000_000:
                        text = "(文件太大，不预览)"
                    else:
                        text = p.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    text = "(二进制文件，不预览)"
                except OSError as ex:
                    text = f"(无法读取: {ex})"
                self.panel.show_preview(rel, text)
            return

    # ---------------- A库 直接调界面设置（set_ui 工具）----------------

    def gui_workspace(self, root) -> "GuiWorkspace":
        """界面这边的工作区对象（文件树、写入面板用）；Agent 进程里另有一个真干活的。"""
        ws = GuiWorkspace(Path(root), self.events, True)
        ws.agent = self.agent
        ws.protected = [da.APP_ROOT]
        return ws

    def remote_confirm(self, msg: str, detail: str = "", items=None):
        """Agent 进程要用户确认：和 GuiWorkspace.confirm 一样弹窗，阻塞到用户选。"""
        req = ConfirmRequest(msg, detail, items=items)
        self.events.put(("confirm", req))
        while not req.event.wait(0.1):
            if self.agent and self.agent.stop_requested:
                return False
        return req.result_text() if req.items else req.result

    def remote_credentials(self, site: str, note: str = "") -> dict:
        req = CredentialsRequest(site, note)
        self.events.put(("credentials", req))
        while not req.event.wait(0.1):
            if self.agent and self.agent.stop_requested:
                return {"ok": False}
        return req.result or {"ok": False}

    def _open_folder_tool(self, args: dict) -> str:
        """在 Agent 线程里调用：打开桌面上的一个文件夹当工作区（桌面外的一律拒绝），界面在主线程里跟着换。"""
        try:
            path, created = desktop_folder(args.get("path", ""), bool(args.get("create")))
        except (ValueError, OSError) as e:
            return f"错误: {e}"
        agent = self.agent
        if agent.ws is not None and agent.ws.root == path:
            return f"{path} 已经是当前工作区了，不用再打开"
        ws = GuiWorkspace(path, self.events, True)   # 和用户手动打开一样：授权修改，删除仍要弹窗确认
        ws.agent = agent
        ws.protected = [da.APP_ROOT]                 # Terminist 自己的代码仍然只能走 B库
        agent.switch_workspace(ws)
        self.events.put(("workspace_opened", json.dumps({"path": str(path), "created": created}, ensure_ascii=False)))
        return open_folder_result(path, created)

    def click_choice(self, m, i):
        """选择卡片上的点击：i 是选项下标（多选切换勾选 / 单选直接提交），"ok" = 确定，"none" = 都不要。"""
        req = m.req
        if m.done or req is None or req.expired or req.event.is_set():
            self.notice("info", "这个选择已经结束了")
            return
        if i == "custom":                            # 自己写：借用下面的输入框（中文输入法、粘贴都现成）
            if getattr(self, "choice_typing", None) is m:
                self.stop_choice_typing()
            else:
                self.stop_choice_typing()
                self.choice_typing = m
                self._choice_draft = (self.input_text, self.cursor)   # 输入框里原来写了一半的先收起来
                self.input_text, self.cursor, self.sel_anchor = m.custom, len(m.custom), None
            self._dirty = True
            return
        self.stop_choice_typing(keep=True)
        req.custom = m.custom                         # 正在写的字跟着「确定」一起交
        if i in ("ok", "none") or not req.multi:
            if i == "none":                          # 都不要：自己写的也不算
                m.checked = set()
                m.custom = req.custom = ""
            elif i != "ok":                          # 单选点了一条：就是它，自己写的作废
                m.checked = {i}
                m.custom = req.custom = ""
            req.result = sorted(m.checked)
            m.done = True
            req.event.set()
        else:
            m.checked ^= {i}
        self._dirty = True

    def stop_choice_typing(self, keep: bool = False):
        """不在卡片上写了：输入框还原成原来写了一半的内容。keep=True 时把已经打的字留作这张卡片的回答。"""
        m = getattr(self, "choice_typing", None)
        if m is None:
            return
        if keep:
            m.custom = self.input_text.strip()
        self.choice_typing = None
        self.input_text, self.cursor = getattr(self, "_choice_draft", ("", 0))
        self.sel_anchor = None
        self._dirty = True

    def submit_choice_custom(self):
        """输入框里回车：把写的字交给正在写的那张卡片（多选时连同勾中的一起交）。"""
        m = self.choice_typing
        req = m.req
        text = self.input_text.strip()
        if req is None or req.expired or req.event.is_set():
            self.stop_choice_typing()
            self.notice("info", "这个选择已经结束了")
            return
        if not text:
            self.notice("info", "先写点什么，或者按 Esc 不写了")
            return
        m.custom = req.custom = text
        if not req.multi:
            m.checked = set()
        req.result = sorted(m.checked)
        m.done = True
        self.stop_choice_typing()
        req.event.set()
        self._dirty = True

    def expire_choices(self):
        """停止 / 打断：还在等的选择卡片作废，别让 Agent 一直卡在等主人选。"""
        for m in self.messages:
            req = getattr(m, "req", None)
            if m.kind == "choice" and req is not None and not m.done and not req.event.is_set():
                req.expired = True
                req.event.set()
        self.stop_choice_typing()

    def _choose_tool(self, args: dict) -> str:
        """A库 的 choose 工具：在聊天框里插一条带按钮的消息，等主人点选。不弹窗，不依赖 ws。"""
        items = [str(i).strip() for i in (args.get("items") or []) if str(i).strip()]
        if not items:
            return "没有可选项"
        msg = str(args.get("msg", "")).strip()
        detail = str(args.get("detail", "") or "").strip()
        single = bool(args.get("single"))
        req = ChoiceRequest(msg + ("\n" + detail if detail else ""), items, multi=not single)
        self.events.put(("choice", req))
        if not req.event.wait(CHOICE_WAIT) or req.result is None:
            req.expired = True                       # 卡片变灰、不能再点（点了也没人等结果了）
            self._dirty = True
            return "主人这次没有选（卡片已过期）。别替主人做决定，需要的话之后再问。"
        picked = [items[i] for i in req.result if 0 <= i < len(items)]
        own = req.custom.strip()
        if own and not picked:
            return "主人没用你给的选项，自己写了：\n" + own
        if own:
            picked.append(f"（主人自己写的）{own}")
        if not picked:
            return "主人一个都没选（都不要）：这些都别做。"
        if single:
            return "主人选了：" + picked[0]
        return "主人勾选了这些（照做，没勾的不要做）：\n" + "\n".join(f"- {t}" for t in picked)

    def _end_takeover_tool(self, args: dict) -> str:
        """A库 的 end_takeover：自己退出接管模式（不用确认），界面弹窗告诉主人已退出。"""
        summary = " ".join(str(args.get("summary") or "").split())[:300]
        if not getattr(self, "takeover_active", False):
            return "本来就不在接管模式，不用退出"
        box = {"ready": threading.Event()}
        self.events.put(("takeover_end", (summary, box)))
        if not box["ready"].wait(30):
            return "界面没有响应，没退出成功"
        return "已退出接管模式：眼睛停了，鼠标键盘交还给主人，界面弹窗告诉了主人。之后别再动鼠标键盘，用文字汇报结果。"

    LOCAL_STOP = {"停", "停下", "停掉", "停止", "别干了", "不干了", "不用干了", "停下来", "别做了", "不做了", "算了别做了",
                  "stop"}
    LOCAL_PAUSE = {"暂停", "等一下", "等等", "先停一停", "先暂停", "先等等", "pause"}
    LOCAL_RESUME = {"继续", "接着干", "继续干", "接着做", "继续做", "resume"}
    LOCAL_END_TAKEOVER = {"退出接管", "停止接管", "结束接管", "别接管了", "不用接管了"}

    def _local_intent(self, text: str) -> bool:
        """主人只说了一句「停 / 暂停 / 继续 / 退出接管」：本地当场办，不把 4 万 token 的上下文发给模型只为调一个工具。
        只认整句正好是这些（标点、空格不算）；「继续把按钮改红」这种带了别的内容的照常交给 Agent。办了返回 True。"""
        key = re.sub(r"[\s，,。.!！~～?？…、]+", "", text).lower()
        if not key or len(key) > 8:
            return False
        if key in self.LOCAL_END_TAKEOVER and getattr(self, "takeover_active", False):
            act = lambda: self.stop_takeover()
        elif not self.busy:
            return False                               # 没在干活：「继续」可能是叫它接着上次的事，交给 Agent
        elif key in self.LOCAL_STOP:
            act = self._stop_now
        elif key in self.LOCAL_PAUSE and not getattr(self, "paused", False):
            act = lambda: self._pause_set(True)
        elif key in self.LOCAL_RESUME and getattr(self, "paused", False):
            act = lambda: self._pause_set(False)
        else:
            return False
        self.input_text, self.cursor = "", 0
        self.add("user", text)
        self.add("info", "（这句在本地直接办了，没有调用模型）")
        act()
        self.mark_dirty()
        return True

    def _request_takeover_tool(self, args: dict) -> str:
        """A库 的 request_takeover：弹接管确认框，等主人点。点「确定」才进接管（answer_confirm 里调 start_takeover）。"""
        reason = " ".join(str(args.get("reason") or "").split())[:300]
        if not reason:
            return "错误: 要写清楚为什么要接管、打算做什么（reason），主人要看着理由决定"
        if getattr(self, "takeover_active", False):
            return ("已经在接管模式了" + ("（但主人按 P 暂停了，等主人按 P 继续）" if getattr(self, "takeover_paused", False)
                                    else "，直接干就行"))
        box = {"ready": threading.Event()}
        self.events.put(("takeover_request", (reason, box)))
        if not box["ready"].wait(30):
            return "界面没有响应，申请没弹出来"
        req = box.get("req")
        if req is None:
            return "已经在接管模式了，直接干就行"
        if not req.event.wait(300):                       # 5 分钟没理：撤掉这个申请
            self.events.put(("takeover_expire", req))
            return "主人 5 分钟没有回应，申请已撤回，没有进入接管模式。别反复申请，先用别的办法或者问主人。"
        if not req.result:
            return "主人拒绝了接管申请，没有进入接管模式。别再申请，换别的办法或者问主人想怎么做。"
        for _ in range(50):                                # 等接管状态传到 Agent（眼睛开起来）
            if getattr(self, "takeover_active", False):
                break
            time.sleep(0.1)
        front = getattr(self, "takeover_front", "") or ""
        return ("主人同意了，已进入接管模式：眼睛开始本地截图识别，之后你每做一步都会带上前 5 秒的眼睛日志；"
                "要等加载 / 等变化就用 skip(毫秒)，别干等着反复截图。主人按 P 会暂停，说 /接管停止 会退出。"
                + (f"\n开始接管时最上层的前台窗口：{front}（要操作别的窗口先用 screen_focus 切过去）" if front else ""))

    def _notify_tool(self, args: dict) -> str:
        """A库 的 notify 工具：弹 Windows 原生桌面通知（右下角），界面不在前台也能看到。
        用 PowerShell + Windows.UI.Notifications 实现，不依赖第三方库；失败就在主线程退回界面内 toast。"""
        text = str(args.get("text", "")).strip()
        if not text:
            return "没有通知文字"
        if not self._windows_toast(text):
            return f"原生通知启动失败（界面内兜底也没弹）：{text}"
        return f"已弹 Windows 桌面通知：{text}"

    def _windows_toast(self, text: str) -> bool:
        """用 PowerShell 调 surface/native_toast.ps1 弹系统通知（来源 Terminist + 图标 + 点击唤醒）。
        文字走 base64 参数，异步执行；失败回主线程 show_toast 兜底。"""
        import base64
        import subprocess
        try:
            script = da.APP_ROOT / "surface" / "native_toast.ps1"
            if not script.exists():
                return False
            b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
            cmd = ["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
                   "-ExecutionPolicy", "Bypass", "-File", str(script),
                   "-AppRoot", str(da.APP_ROOT),
                   "-B64", b64]
            def run():
                ok = False
                try:
                    r = subprocess.run(cmd, capture_output=True, timeout=25, check=False)
                    out = (r.stdout or b"").decode("utf-8", "ignore").strip()
                    err = (r.stderr or b"").decode("utf-8", "ignore").strip()
                    ok = r.returncode == 0 and "ok" in out and not err
                except Exception:
                    ok = False
                if not ok:
                    self.events.put(("toast", text))
            threading.Thread(target=run, daemon=True).start()
            return True
        except Exception:
            self.events.put(("toast", text))
            return False

    def _restart_tool(self, args: dict) -> str:
        """在 Agent 线程里调用：记下要重启，这一轮回复完由主线程去重启。
        selfcheck 不填=只重启；填 true/yes=重启后跑默认自检；填一段文本=重启后按这段内容验证。"""
        raw = str(args.get("selfcheck") or "").strip()
        if not raw:
            self.events.put(("restart_request", ""))
            return "好了，这一轮说完就重启（新窗口先起来、旧窗口再关，记忆和设置都保留）。用一句话告诉用户马上重启即可。"
        instruction = "" if raw.lower() in ("true", "1", "yes", "on", "selftest") else raw
        msg = request_self_test(True, instruction)
        if ("失败" in msg) or ("已取消" in msg):
            return f"没有重启：自检标记没写上（{msg}），这一轮不触发重启，别跟用户说已经重启。"
        self.events.put(("restart_request", ""))
        what = instruction or "默认自检项（find_files / read_lines / run_bg + bg_output / wait / 越界路径被拒绝）"
        return (f"自检已排上，本轮结束后自动重启；重启完会立刻用本地工具验证：{what}。"
                "用一句话告诉用户马上重启并会自检即可。")

    def _ui_tool(self, args: dict) -> str:
        """在 Agent 线程里调用：按注册表检查参数，交给主线程去改界面，马上返回。"""
        cmd, done = {}, []
        for key, raw in args.items():
            if raw is None or raw == "":
                continue
            if key not in UI_SETTINGS:
                return f"错误: 没有这个界面设置 {key}，可选：{', '.join(UI_SETTINGS)}"
            try:
                cmd[key] = parse_ui_value(self, key, raw)
            except ValueError as e:
                opts = "、".join(f"{v}（{t}）" for t, v in UI_SETTINGS[key]["options"](self))
                return f"错误: {e}。可选：{opts}"
            done.append(f"{UI_SETTINGS[key]['label']} → {ui_value_text(self, key, cmd[key])}")
        if not cmd:
            return f"错误: 没有给要改的设置，可选：{', '.join(UI_SETTINGS)}"
        self.events.put(("ui_command", json.dumps(cmd, ensure_ascii=False)))
        return "界面已经切换：" + "，".join(done) + "。直接告诉用户即可。"

    def apply_ui(self, cmd: dict):
        """主线程里执行：和设置弹窗里点选项的效果一样，设置会保存。"""
        done = []
        for key, value in cmd.items():
            if key in UI_SETTINGS and value != self.settings.get(key):
                UI_SETTINGS[key]["apply"](self, value)
                done.append(f"{UI_SETTINGS[key]['label']} → {ui_value_text(self, key, value)}")
        if done:
            self.add("info", lang("ui_applied") + lang("opt_sep").join(done))

    def set_command(self, text: str):
        """/set 列出所有界面设置；/set 设置名 值 直接改（设置名可以写英文 key 或中文名）。"""
        parts = text.split(maxsplit=2)
        if len(parts) < 3:
            self.add("info", lang("ui_settings_header") + "\n" + "\n".join(
                f"  {key}（{setting_label(key, e)}）= {ui_value_text(self, key, self.settings.get(key))}    "
                + "、".join(t for t, _ in e["options"](self)) for key, e in UI_SETTINGS.items()))
            return
        key = next((k for k, e in UI_SETTINGS.items() if parts[1] in (k, e["label"])), None)
        if key is None:
            self.add("error", lang("no_such_setting").format(k=parts[1]))
            return
        try:
            self.apply_ui({key: parse_ui_value(self, key, parts[2])})
        except ValueError as e:
            self.add("error", str(e))

    def handle_settings(self, e):
        if self.settings_value_edit is not None:       # 正在输入数值：键盘都给输入框
            if e.type == pygame.TEXTINPUT:
                self.settings_edit_text += e.text
                self.settings_edit_err = ""
            elif e.type == pygame.KEYDOWN:
                ctrl = e.mod & (pygame.KMOD_CTRL | pygame.KMOD_META)
                if e.key == pygame.K_ESCAPE:
                    self.settings_value_edit = None
                    self.settings_edit_text, self.settings_edit_err = "", ""
                elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self.settings_commit_value()
                elif e.key == pygame.K_BACKSPACE:
                    self.settings_edit_text = "" if ctrl else self.settings_edit_text[:-1]
                elif e.key == pygame.K_v and ctrl:
                    self.settings_edit_text += "".join(get_clipboard().split())
            return True
        if self.key_edit is not None:            # 正在输入新 key：键盘都给输入框
            if e.type == pygame.TEXTINPUT:
                self.key_edit += "".join(e.text.split())
            elif e.type == pygame.KEYDOWN:
                ctrl = e.mod & (pygame.KMOD_CTRL | pygame.KMOD_META)
                if e.key == pygame.K_ESCAPE:
                    self.on_api_key("cancel")
                elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self.on_api_key("save")
                elif e.key == pygame.K_BACKSPACE:
                    self.key_edit = "" if ctrl else self.key_edit[:-1]
                elif e.key == pygame.K_v and ctrl:
                    self.key_edit += "".join(get_clipboard().split())
            return True
        if e.type == pygame.MOUSEWHEEL:          # 设置面板内容滚动（不滚聊天栏）
            self.settings_scroll = max(0, min(self.settings_scroll_max,
                                              self.settings_scroll - e.y * S(48)))
            return True
        if e.type == pygame.MOUSEMOTION:
            if self.settings_slider_drag is not None:
                self.settings_slider_set(self.settings_slider_drag, e.pos[0])
            elif self.settings_sb_drag:
                self.settings_scroll_by_y(e.pos[1])
            return True
        if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            if self.settings_slider_drag is not None:   # 松手才存盘
                save_settings(self.settings)
                self.settings_slider_drag = None
            self.settings_sb_drag = False
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            candy = getattr(self, "btn_candy", None)
            if candy is not None and candy.rect.w > 0 and candy.rect.collidepoint(e.pos) and self.candy_btn_on():
                self.on_candy()                     # 糖果按钮画在所有面板之上：设置面板开着也能点
                return True
            for r, panel in getattr(self, "panel_icon_rects", []):
                if r.collidepoint(e.pos):          # 面板开着时从左栏图标直接换区块
                    self.open_settings_panel(panel)
                    return True
            if self.settings_sb_drag or (self.settings_sb_rect.w and self.settings_sb_rect.collidepoint(e.pos)):
                self.settings_sb_drag = True        # 点滚动条 / 拖滚动条
                self.settings_scroll_by_y(e.pos[1])
                return True
            for rect, kind, value in self.settings_rects:
                if not rect.collidepoint(e.pos):
                    continue
                self.settings_focus = None              # 点了这一项：高亮提示收起
                if kind == "close":
                    self.key_edit = None
                    self.settings_value_edit = None
                    self.settings_focus = None
                    self.settings_open = False
                elif kind == "back":
                    self.settings_open = False          # ‹ 返回：收起面板，右栏回到工作流
                    self.settings_focus = None
                elif kind == "apikey":
                    self.on_api_key(value)
                elif kind == "link":
                    act = value[0] if isinstance(value, tuple) else value
                    if act == "live_layout":
                        self.settings_open = False
                        self.settings_value_edit = None
                        self.save_layout()
                        self.live_layout = True
                    elif act == "apikey_edit":
                        self.on_api_key("edit")
                    else:
                        self.on_api_key("reset")
                elif kind == "slider":
                    self.settings_slider_drag = value
                    self.settings_slider_set(value, e.pos[0])
                elif kind == "minus":
                    self.settings_step(value, -1)
                elif kind == "plus":
                    self.settings_step(value, 1)
                elif kind == "num":
                    self.settings_open_edit(value)
                elif kind == "dd_open":
                    self.settings_open_dd = None if self.settings_open_dd == value else value
                elif kind == "topbtn":
                    self.toggle_top_button(value)
                elif kind == "set":
                    self.settings_open_dd = None
                    self.apply_ui({value[0]: value[1]})
                return True
            self.settings_open_dd = None            # 点别处：收起下拉
            return True
        if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_RETURN):
            self.settings_open = False              # Esc / 回车：收起面板（输入框里的键在上面已经吃掉）
            self.settings_focus = None
        return True

    def settings_open_edit(self, key: str):
        """点“数值”文字：在这一项上打开数值输入框（复用注册表的 parse / apply）。"""
        if key not in UI_SETTINGS:
            return
        self.settings_value_edit = key
        self.settings_edit_text = ui_value_text(self, key, self.settings.get(key))
        self.settings_edit_err = ""

    def settings_commit_value(self):
        """回车提交数值输入框：解析失败就在面板里红字提示，不崩。"""
        key = self.settings_value_edit
        if key not in UI_SETTINGS:
            self.settings_value_edit = None
            return
        try:
            self.apply_ui({key: parse_ui_value(self, key, self.settings_edit_text.strip())})
        except ValueError:
            self.settings_edit_err = lang("settings_edit_err")
            return
        self.settings_value_edit = None
        self.settings_edit_text, self.settings_edit_err = "", ""

    def settings_slider_set(self, key: str, pos_x: int):
        """按住滑杆拖动：按横坐标取最近的选项，实时生效（不每像素存盘）。"""
        info = getattr(self, "settings_slider_rect", {}).get(key)
        entry = UI_SETTINGS.get(key)
        if not info or entry is None:
            return
        track, opts = info
        if not opts:
            return
        ratio = (pos_x - track.x) / max(1, track.w)
        idx = max(0, min(len(opts) - 1, round(ratio * (len(opts) - 1))))
        value = opts[idx][1]
        if value != self.settings.get(key):
            entry["apply"](self, value)

    def settings_step(self, key: str, delta: int):
        """滑杆两边的 − / +：按选项列表动一档。"""
        entry = UI_SETTINGS.get(key)
        if entry is None:
            return
        info = getattr(self, "settings_slider_rect", {}).get(key)
        vals = [v for _, v in (info[1] if info else entry["options"](self))]
        if not vals:
            return
        cur = self.settings.get(key)
        idx = next((i for i, v in enumerate(vals) if v == cur), None)
        if idx is None:                        # 当前值不在选项里（例如手输的像素）：取最近的
            idx = 0
            for i, v in enumerate(vals):
                try:
                    if float(v) <= float(cur):
                        idx = i
                except (TypeError, ValueError):
                    pass
        idx = max(0, min(len(vals) - 1, idx + delta))
        if vals[idx] != cur:
            entry["apply"](self, vals[idx])

    def settings_scroll_by_y(self, pos_y: int):
        """按鼠标纵坐标换算设置面板的滚动量（拖滚动条用）。"""
        track = getattr(self, "settings_sb_rect", None)
        if not track or track.h <= 0 or self.settings_scroll_max <= 0:
            return
        ratio = (pos_y - track.y) / max(1, track.h)
        self.settings_scroll = max(0, min(self.settings_scroll_max, round(ratio * self.settings_scroll_max)))

    def toggle_top_button(self, name: str):
        """顶栏按钮的显示 / 隐藏（停止按钮始终保留）。"""
        if name == "stop":
            return
        hidden = list(self.settings.get("top_hidden", []) or [])
        if name in hidden:
            hidden.remove(name)
        else:
            hidden.append(name)
        self.settings["top_hidden"] = hidden
        self.save_layout()                       # 顶栏按钮显隐：改完立刻落盘
        self.mark_dirty()

    def on_api_key(self, act: str):
        """设置里的 API key：edit 开始输入 / cancel 取消 / save 试一下再加密保存。
        不放进界面设置注册表：A库 的 set_ui 碰不到 key。"""
        if self.key_checking:
            return
        if act == "edit":
            self.key_edit, self.key_msg = "", ("粘贴新的 key（Ctrl+V），回车保存，Esc 取消", "dim")
        elif act == "cancel":
            self.key_edit, self.key_msg = None, ("", "dim")
        elif act == "clear":                             # 点两次才清：第一次只是武装，4 秒内再点才真删
            if time.time() < getattr(self, "key_clear_armed", 0):
                self.key_clear_armed = 0
                self.key_msg = (clear_api_key(self.agent), "warn")
            else:
                self.key_clear_armed = time.time() + 4
                self.key_msg = ("再点一次「确认清空」：删掉这台电脑上保存的 key（4 秒内有效）", "warn")
        elif act == "save" and self.key_edit is not None:
            key = self.key_edit.strip()
            if not key:
                self.key_msg = ("还没填 key", "del")
                return
            self.key_checking, self.key_msg = True, ("正在试这个 key…", "dim")

            def check():
                ok, msg = check_api_key(key)
                self.events.put(("api_key_checked", (ok, msg, key)))   # 只在界面进程内部传，不进日志
            threading.Thread(target=check, daemon=True).start()

    def on_api_key_checked(self, ok, msg: str, key: str):
        self.key_checking = False
        if ok is False:
            self.key_msg = (msg + "，没有保存", "del")
            return
        save_api_key(self.agent, key)
        self.key_edit = None
        self.key_msg = ("新 key 能用，已保存并立刻换上" if ok else msg + "，先保存了，联网后试一下",
                        "add" if ok else "warn")
        if self.agent and not os.environ.get("TERMINIST_SMOKE"):
            agent = self.agent
            threading.Thread(target=lambda: self.events.put(("models", agent.list_models())), daemon=True).start()

    def handle_modal(self, e):
        req = self.pending_confirm
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            if req is not None and getattr(req, "items", None):     # 勾选式选择：点条目 / 全选按钮
                if getattr(req, "picked", None) is None:
                    req.picked = set(req.items)
                for r, item in getattr(self, "modal_item_rects", []) or []:
                    if r.collidepoint(e.pos):
                        if item in req.picked:
                            req.picked.discard(item)
                        else:
                            req.picked.add(item)
                        self._dirty = True
                        return True
                r = getattr(self, "modal_all_rect", None)
                if r is not None and r.w > 0 and r.collidepoint(e.pos):
                    req.picked = set() if len(req.picked) >= len(req.items) else set(req.items)
                    self._dirty = True
                    return True
            for b in self.modal_buttons_for(self.pending_confirm if self.pending_confirm else None):
                if b.click(e.pos):
                    break
        elif e.type == pygame.MOUSEWHEEL:
            self.modal_scroll = max(0, self.modal_scroll - e.y * 3)
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_y:
                self.answer_confirm(True)
            elif e.key in (pygame.K_n, pygame.K_ESCAPE):
                self.answer_confirm(False)
            elif e.key == pygame.K_a and getattr(self.pending_confirm, "kind", "") not in ("clear", "takeover", "notice"):
                self.answer_confirm(True, always=True)      # 清空对话 / 接管确认不吃“全部允许”这个快捷键
        return True

    # ---------------- 账号密码弹窗 ----------------

    def handle_credentials(self, e) -> bool:
        """账号密码弹窗的键盘 / 鼠标处理：Tab 切换，Enter 提供，Esc 拒绝。"""
        req = self.pending_credentials
        if req is None:
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, r in enumerate(getattr(self, "cred_rects", [])):
                if r.collidepoint(e.pos):
                    req.focus = self.cred_cursor = i
                    return True
            if self.cred_check_rect.collidepoint(e.pos):
                req.remember = not req.remember
                return True
            if self.cred_give_rect.collidepoint(e.pos):
                self.answer_credentials(True)
                return True
            if self.cred_deny_rect.collidepoint(e.pos):
                self.answer_credentials(False)
                return True
            return True
        if e.type == pygame.TEXTINPUT:
            if req.focus:
                req.pwd += e.text
            else:
                req.user += e.text
            return True
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_TAB:
                req.focus = self.cred_cursor = 1 - req.focus
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.answer_credentials(True)
            elif e.key == pygame.K_ESCAPE:
                self.answer_credentials(False)
            elif e.key == pygame.K_BACKSPACE:
                if req.focus:
                    req.pwd = req.pwd[:-1]
                else:
                    req.user = req.user[:-1]
        return True

    # ---------------- 输入框：光标、选择 ----------------

    def _input_lines(self, width: int) -> list[tuple[int, str]]:
        """输入框里的文字按宽度折行：[(这一行在 input_text 里的起点, 这一行的文字)]，折法和 wrap() 一致。"""
        out, start = [], 0
        for para in self.input_text.split("\n"):
            if self.font.size(para)[0] <= width:
                out.append((start, para))
            else:
                cur, cur_w, s0 = "", 0, start
                for i, ch in enumerate(para):
                    w = self.font.size(ch)[0]
                    if cur and cur_w + w > width:
                        out.append((s0, cur))
                        s0, cur, cur_w = start + i, ch, w
                    else:
                        cur += ch
                        cur_w += w
                out.append((s0, cur))
            start += len(para) + 1
        return out

    def draw_pending_thumbs(self, box: pygame.Rect, mouse) -> int:
        """在输入框左侧画待发图片缩略图，右上角小✕登记进 pending_img_close_rects；返回占用的宽度。"""
        self.pending_img_close_rects = []
        imgs = list(getattr(self, "pending_images", None) or [])
        if not imgs:
            return 0
        th_h = max(S(10), box.h - PAD)
        x = box.x + PAD
        y = box.y + PAD // 2
        gap = S(6)
        for idx, path in enumerate(imgs):
            try:
                src = pygame.image.load(path)
                w, h = src.get_size()
                th_w = int(w * th_h / float(h)) if h else th_h
                th_w = max(S(8), min(th_w, th_h * 3))
                thumb = pygame.transform.smoothscale(src, (th_w, th_h))
            except Exception:
                continue                       # 读不出来的图跳过，不画也不崩
            rect = pygame.Rect(x, y, th_w, th_h)
            self.screen.blit(thumb, rect)
            pygame.draw.rect(self.screen, C["border"], rect, 1, border_radius=S(3))
            # 右上角小✕
            cr = pygame.Rect(rect.right - S(14), rect.y, S(14), S(14))
            pygame.draw.rect(self.screen, C["del"], cr, border_radius=S(7))
            pygame.draw.line(self.screen, C["on_text"], (cr.x + S(4), cr.y + S(4)),
                             (cr.right - S(4), cr.bottom - S(4)), S(2))
            pygame.draw.line(self.screen, C["on_text"], (cr.right - S(4), cr.y + S(4)),
                             (cr.x + S(4), cr.bottom - S(4)), S(2))
            self.pending_img_close_rects.append((cr, idx))
            x = rect.right + gap
        if x <= box.x + PAD:
            return 0
        return x - (box.x + PAD)

    def _input_width(self) -> int:
        tw = (self.input_rect.w if self.input_rect else 400) - PAD * 2
        rect = self.input_rect
        if rect is not None:
            tw -= max(0, getattr(self, "input_text_x", rect.x + PAD) - (rect.x + PAD))
        return tw

    def _cursor_row(self, lines) -> int:
        """光标在第几行（行尾的光标算在这一行，不算下一行开头）。"""
        for row in range(len(lines) - 1, -1, -1):
            if lines[row][0] <= self.cursor:
                return row
        return 0

    def input_index_at(self, pos) -> int:
        """输入框里的一个像素位置 → 文字里的下标。"""
        r = self.input_rect
        if r is None:
            return self.cursor
        lines = self._input_lines(self._input_width())
        row = self.input_first + (pos[1] - (r.y + PAD // 2 + 2)) // self.line_h
        start, text = lines[max(0, min(len(lines) - 1, row))]
        x, acc = pos[0] - getattr(self, "input_text_x", r.x + PAD), 0
        for k, ch in enumerate(text):
            w = self.font.size(ch)[0]
            if acc + w / 2 > x:
                return start + k
            acc += w
        return start + len(text)

    def _sel(self):
        a = self.sel_anchor
        if a is None or a == self.cursor:
            return None
        return min(a, self.cursor), max(a, self.cursor)

    def _delete_sel(self) -> bool:
        s = self._sel()
        self.sel_anchor = None
        if not s:
            return False
        self.input_text = self.input_text[:s[0]] + self.input_text[s[1]:]
        self.cursor = s[0]
        return True

    def _move(self, idx: int, extend: bool):
        """移动光标；extend=True（按着 Shift）时扩大选择。"""
        if extend:
            if self.sel_anchor is None:
                self.sel_anchor = self.cursor
        else:
            self.sel_anchor = None
        self.cursor = max(0, min(len(self.input_text), idx))

    def insert(self, s: str):
        s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
        self._delete_sel()                       # 选中了文字再打字 = 替换
        self.input_text = self.input_text[:self.cursor] + s + self.input_text[self.cursor:]
        self.cursor += len(s)

    _IMG_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp")

    def add_pending_image(self, path):
        """把一张图加进待发列表（绝对路径，去重）。"""
        try:
            if not path:
                return
            p = os.path.abspath(str(path))
            if not p.lower().endswith(self._IMG_EXTS):
                self.add("error", "图片格式不支持：" + os.path.basename(p))
                return
            if not os.path.isfile(p):
                self.add("error", "图片不存在：" + p)
                return
            if p in self.pending_images:
                return
            self.pending_images.append(p)
            self.mark_dirty()
        except Exception:
            pass

    def remove_pending_image(self, index: int):
        """从待发列表里拿掉第 index 张。"""
        try:
            if 0 <= index < len(self.pending_images):
                self.pending_images.pop(index)
                self.mark_dirty()
        except Exception:
            pass

    def _save_clipboard_image(self):
        """剪贴板图片存成临时 png，返回绝对路径；拿不到返回 None。"""
        try:
            data = get_clipboard_image()
            if not data:
                return None
            import tempfile
            d = os.path.join(tempfile.gettempdir(), "terminist_pending", self._pending_session_id)
            os.makedirs(d, exist_ok=True)
            p = os.path.join(d, "img_%d.png" % int(time.time() * 1000))
            with open(p, "wb") as f:
                f.write(data)
            return os.path.abspath(p)
        except Exception:
            return None

    def _new_pending_session(self):
        """清掉上一会话的临时图片目录，再起一个新会话 id。"""
        try:
            import tempfile
            import shutil
            old = os.path.join(tempfile.gettempdir(), "terminist_pending", self._pending_session_id)
            if os.path.isdir(old):
                shutil.rmtree(old, ignore_errors=True)
        except OSError:
            pass
        self._pending_session_id = str(int(time.time() * 1000000))

    def handle_key(self, e):
        ctrl = e.mod & pygame.KMOD_CTRL
        shift = bool(e.mod & pygame.KMOD_SHIFT)
        if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if e.mod & pygame.KMOD_SHIFT:
                self.insert("\n")
            else:
                self.sel_anchor = None
                self.on_send()
        elif e.key == pygame.K_BACKSPACE:
            if not self._delete_sel() and self.cursor > 0:
                self.input_text = self.input_text[:self.cursor - 1] + self.input_text[self.cursor:]
                self.cursor -= 1
        elif e.key == pygame.K_DELETE:
            if not self._delete_sel():
                self.input_text = self.input_text[:self.cursor] + self.input_text[self.cursor + 1:]
        elif e.key in (pygame.K_LEFT, pygame.K_RIGHT):
            s = self._sel()
            if s and not shift:                  # 有选择时按左右：光标跳到选择的那一头
                self._move(s[0] if e.key == pygame.K_LEFT else s[1], False)
            else:
                self._move(self.cursor + (-1 if e.key == pygame.K_LEFT else 1), shift)
        elif e.key in (pygame.K_UP, pygame.K_DOWN):
            lines = self._input_lines(self._input_width())
            row = self._cursor_row(lines)
            target = row + (-1 if e.key == pygame.K_UP else 1)
            if 0 <= target < len(lines):         # 上下一行：保持大致相同的横向位置
                start, text = lines[row]
                x = self.font.size(text[:self.cursor - start])[0]
                t_start, t_text = lines[target]
                idx, acc = t_start + len(t_text), 0
                for k, ch in enumerate(t_text):
                    w = self.font.size(ch)[0]
                    if acc + w / 2 > x:
                        idx = t_start + k
                        break
                    acc += w
                self._move(idx, shift)
            else:
                self._move(0 if e.key == pygame.K_UP else len(self.input_text), shift)
        elif e.key in (pygame.K_HOME, pygame.K_END):
            if ctrl:
                self._move(0 if e.key == pygame.K_HOME else len(self.input_text), shift)
            else:                                # 当前这一行的行首 / 行尾
                lines = self._input_lines(self._input_width())
                start, text = lines[self._cursor_row(lines)]
                self._move(start if e.key == pygame.K_HOME else start + len(text), shift)
        elif e.key == pygame.K_a and ctrl:
            self.sel_anchor, self.cursor = 0, len(self.input_text)
        elif e.key in (pygame.K_c, pygame.K_x) and ctrl:
            s = self._sel()
            if s:
                set_clipboard(self.input_text[s[0]:s[1]])
                if e.key == pygame.K_x:
                    self._delete_sel()
        elif e.key == pygame.K_v and ctrl:
            _p = self._save_clipboard_image()     # 剪贴板里是图片就进待发列表，否则按文字粘
            if _p:
                self.add_pending_image(_p)
            else:
                self.insert(get_clipboard())
        elif e.key == pygame.K_PAGEUP:
            self.chat_view.wheel(S(300))
        elif e.key == pygame.K_PAGEDOWN:
            self.chat_view.wheel(-S(300))
        elif e.key == pygame.K_ESCAPE:
            if getattr(self, "choice_typing", None) is not None:   # 不给卡片写了：输入框还原
                self.stop_choice_typing()
                return
            self._screen_esc_press()          # 连按两次 Esc 关独立小屏幕窗口（单击只提示）

    # ---------------- 绘制 ----------------

    def draw(self):
        W, H = self.screen.get_size()
        self.plugin_rects = {}                    # 外接模块的可点区域每帧重新登记（收起了的不能再被点到）
        self.tick_panels()                        # 先推进两侧栏的显隐动画，再算布局
        self.tick_economy()                       # 空闲时也定时向 A库 要经济栏序列（随时间重切桶）
        mouse = pygame.mouse.get_pos()
        self._dock_hide_rects = []                # 本帧停靠槽标题条上的 X：整帧只清一次，左右两栏只往里 append
        left, center, right = self.layout()
        self.screen.fill(C["bg"])
        self.draw_messages(center)
        self.draw_progress(center)
        hud_h = self.live_hud_height()            # 同一帧里浮条和输入框用同一个高度，避免错位
        self.draw_live_hud(center, hud_h)
        self.draw_input(center, mouse, hud_h)
        self.draw_drag_handles(mouse)
        if getattr(self, "live_layout", False):
            self.draw_live_layout_hint(W)
        if left.w:
            fade = 1.0
            if self.anim_on():
                if self._left_w_last in (0, None):      # 左栏从 0 宽变宽：入场淡入 + 轻微位移
                    self._left_fade = _Tween(0.0, self.anim_frames(14)).to(1.0)
                self._left_fade.tick()
                fade = self._left_fade.value
            tmp = None
            if fade < 1.0:                              # 只在这一小段里走临时 Surface
                real = self.screen
                tmp = pygame.Surface(real.get_size(), pygame.SRCALPHA)
                self.screen = tmp
            self.draw_left_docked(left)               # 按 dock_state["left"] 动态画各槽（最多 3 槽）
            if tmp is not None:                         # 画完整体带 alpha 贴回，并往左让 8px
                self.screen = real
                tmp.fill((255, 255, 255, int(255 * fade)), special_flags=pygame.BLEND_RGBA_MULT)
                real.blit(tmp, (-int(round(S(8) * (1.0 - fade))), 0))
        if right.w:
            # 先铺满整个右栏区域再画内容：滑出时右侧才不会留下上一帧的残影
            pygame.draw.rect(self.screen, C["panel"], (right.x, 0, W - right.x, H + 2))
            if self.settings_open:
                self.draw_settings(right, mouse)
            else:
                self._drop_settings_fade()       # 面板没开：缓存丢掉，下次打开重新淡入
                self.draw_right(right)
        else:
            if not self._auto_hide_on():
                self.settings_open = False    # 窗口太窄右栏收起：面板也跟着收起来
            self._drop_settings_fade()
            self.flow_rects, self.write_rect = [], pygame.Rect(0, 0, 0, 0)
            self.spot_rects = []
            self._dock_right_rects = []       # 右栏收起：没有可落点的槽
        self.draw_detached_windows()          # 拖出去的独立窗口：每帧投影（它们不在任何一栏里了）
        if not left.w:
            self._dock_left_rects = []        # 左栏收起：没有可落点的槽
        self.draw_top(W, mouse)
        self.draw_modules_panel()             # 顶栏「模块」展开的模块管理（画在最上层，左栏收起也看得到）
        if self.candy_btn_on():
            self.draw_candy_btn(W, H, mouse)
        else:
            btn = getattr(self, "btn_candy", None)
            if btn is not None:
                btn.rect = pygame.Rect(0, 0, 0, 0)   # 关掉：不画也不响应点击
        if self.dropdown_open:
            self.draw_dropdown(mouse)
        if self.pending_confirm:
            self.draw_modal(W, H, mouse)
        if getattr(self, "pending_need", None):
            self.draw_need(W, H, mouse)
        if getattr(self, "pending_credentials", None):
            self.draw_credentials(W, H, mouse)
        if self.pending_delete:
            self.draw_delete(W, H, mouse)
        if getattr(self, "staff_card", None) is not None:   # 员工信息卡：模态，盖在其它东西上面
            self.draw_staff_card(W, H, mouse)
        if getattr(self, "_candy_bursts", None):          # 糖果爱心特效画在最上层
            alive = []
            for burst in self._candy_bursts:
                if burst.tick():
                    burst.draw(self.screen)
                    alive.append(burst)
            self._candy_bursts = alive
        self._right_w_last = right.w                 # 记下这一帧的实宽：下一帧的滑出从它出发
        self._left_w_last = left.w
        if getattr(self, "panel_ghost", None) is not None:   # 拖面板出来的虚影：松手就成独立窗口
            self.draw_staff_ghost()
        self._draw_dock_overlay()                    # 槽位高亮 + 拖动标签（只画不改状态）
        self._draw_win_drag_hint()                   # 拖着小窗口压在哪一栏：那一栏高亮，写「松手放到这里」
        self.draw_toast(W, H)
        pygame.display.flip()
        self.pump_projection()                       # 把这一帧送给屏幕上的投影壳（没开投影就什么都不做）

    def draw_panel_icons(self, x: int) -> int:
        """顶栏左边一排管理按钮：每个 UI 区块一个（点了在右栏打开它的设置），最后是「模块」（展开模块管理）。
        以前画在左栏底部，左栏一收起就看不到了。返回画完后的 x。"""
        h = TOP_H - S(18)
        y = S(9)
        self.panel_icon_rects = []
        for panel in PANEL_ORDER:
            w = min(self.small.size(panel_label(panel))[0] + S(16), S(80))
            ir = pygame.Rect(x, y, w, h)
            on = panel == self.settings_panel and self.settings_open
            if on or ir.collidepoint(pygame.mouse.get_pos()):
                pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.18), ir, border_radius=S(6))
            label = ellipsize(self.small, panel_label(panel), w - S(8))
            t = utext(self.small, label, C["text"])
            self.screen.blit(t, t.get_rect(center=ir.center))
            self.panel_icon_rects.append((ir, panel))
            x += w + S(4)
        mw = self.small.size("模块")[0] + S(20)                 # 「模块」：开 / 关模块管理
        br = pygame.Rect(x, y, mw, h)
        self.modules_btn_rect = br
        if self.modules_open or br.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.screen, mix(C["top"], C["hdr"], 0.22 if self.modules_open else 0.14),
                             br, border_radius=S(6))
        t = utext(self.small, "模块", C["hdr"] if self.modules_open else C["text"])
        self.screen.blit(t, t.get_rect(center=br.center))
        return br.right + S(8)

    def draw_top(self, W, mouse):
        pygame.draw.rect(self.screen, C["top"], (0, 0, W, TOP_H))
        if self.model == da.TEAM_MODE:
            n = len(self.active_workers)
            self.btn_model.label = (lang("team_running").format(n=n, m=da.WORKER_MODEL) if n else
                                    lang("team_lead").format(m=da.LEAD_MODEL))
        else:
            self.btn_model.label = lang("model_line").format(m=self.model)
        self.btn_stop.enabled = True                    # 没活干时点也会提示「现在没有正在跑的工作流」
        self.btn_clear.enabled = self.btn_model.enabled = not self.busy
        self.btn_clearview.enabled = not self.busy
        x = PAD
        self.btn_restart.enabled = not self.busy
        shown = self.visible_top_buttons()
        for b in shown:
            if isinstance(b.label, Glyph):          # 自绘图标按钮：按图标宽度算
                bw = glyph_width(self.small, b.label)
            else:
                bw = self.small.size(b.label)[0]
            w = bw + S(24)
            b.rect = pygame.Rect(x, S(9), w, TOP_H - S(18))
            base = b.color or C["btn"]
            sig = (b.label, b.enabled, b.color, b.rect.size, base, b.rect.collidepoint(mouse),
                   C["hdr"], C["btn"], C["on_text"], C["text"])
            self.draw_faded(("topbtn", id(b)), sig, b.rect,
                            lambda surf, off, b=b: self._paint_top_button(surf, b, mouse, off))
            x += w + S(8)
        x = self.draw_panel_icons(x)                    # 管理按钮（界面主题 / 对话 / 团队 / 干活 / 模块）
        live = {("topbtn", id(b)) for b in shown}
        for k in [k for k in getattr(self, "_fade_cache", {})
                  if isinstance(k, tuple) and k and k[0] == "topbtn" and k not in live]:
            self._fade_cache.pop(k, None)      # 按钮隐藏了：缓存和淡入进度一起丢掉，别让主循环永久刷帧
        # 放不下时从左边截断，所以路径放最前，状态和记忆用量放最后
        parts = [str(self.ws.root) if self.ws else lang("no_folder")]
        if self.actual_model:
            parts.append(lang("server_model").format(m=self.actual_model))
        if self.agent:
            used, limit = self.context
            parts.append(lang("memory_usage").format(used=da.fmt_tokens(used), limit=da.fmt_tokens(limit)))
        pen = getattr(self, "penalty", {})
        if any(pen.get(k) for k in ("A", "B", "R", "RA")):
            parts.append(lang("score_line").format(a=pen.get("A", 0), b=pen.get("B", 0),
                                                   ra=pen.get("RA", 0), r=pen.get("R", 0)))
        parts.append(lang("running") if self.busy else lang("ready"))
        label = ellipsize(self.small, "   |   ".join(parts), W - x - PAD * 2)
        t = utext(self.small, label, C["add"] if self.busy else C["dim"])
        self.screen.blit(t, (W - t.get_width() - PAD, (TOP_H - t.get_height()) // 2))
        pygame.draw.line(self.screen, C["border"], (0, TOP_H - 1), (W, TOP_H - 1))

    def draw_dropdown(self, mouse):
        b = self.btn_model.rect
        item_h = self.small.get_linesize() + S(12)
        options = [da.TEAM_MODE] + self.models
        w = max(b.w, max(self.small.size(self.model_label(m))[0] for m in options) + S(48))
        full_h = item_h * len(options) + S(8)
        if self.anim_on():                       # 高度按缓动进度展开（smoothed 无副作用，每帧直接查）
            self._dropdown_tween.tick()
            prog = self._dropdown_tween.smoothed()
            h = max(S(4), int(full_h * max(0.0, min(1.0, prog))))
        else:
            h = full_h
        box = pygame.Rect(b.x, b.bottom + S(4), w, h)
        soft_shadow(self.screen, box, S(10))
        pygame.draw.rect(self.screen, C["modal"], box, border_radius=S(10))
        pygame.draw.rect(self.screen, C["input_border"], box, 1, border_radius=S(10))
        self.dropdown_rects = []
        self.screen.set_clip(box.inflate(-1, -1))     # 没展开完的选项裁在框里，别溢出
        for i, name in enumerate(options):
            r = pygame.Rect(box.x + S(4), box.y + S(4) + i * item_h, box.w - S(8), item_h)
            if r.y + r.h > box.bottom:
                break                             # 超出框高度的下拉项不画
            if r.collidepoint(mouse):
                pygame.draw.rect(self.screen, mix(C["btn"], C["panel"], 0.5), r, border_radius=S(6))
            current = name == self.model
            if current:
                pygame.draw.circle(self.screen, C["add"], (r.x + S(12), r.centery), S(4))
            t = utext(self.small, self.model_label(name), C["add"] if current else C["text"])
            self.screen.blit(t, (r.x + S(24), r.y + (item_h - t.get_height()) // 2))
            self.dropdown_rects.append((r, name))
            if name == da.TEAM_MODE:        # 工作组和单个模型之间画条分隔线
                pygame.draw.line(self.screen, C["border"], (r.x, r.bottom - 1), (r.right, r.bottom - 1))
        self.screen.set_clip(None)

    def _panel_head_set(self, key: str, rect: pygame.Rect):
        """把某个面板的标题条矩形登记进 panel_heads（自绘标题不走 panel_header 的面板用）。"""
        heads = getattr(self, "panel_heads", None)
        if not isinstance(heads, dict):
            heads = self.panel_heads = {}
        heads[key] = pygame.Rect(rect)

    # ---------------- 停靠槽位（第三批：按 dock_state 动态渲染 + 拖拽嵌入） ----------------

    DOCK_TITLES = {
        "staff": "员工栏", "screen": "小屏幕", "economy": "经济栏", "flow": "工作流",
        "write": "写入预览", "board": "小画板", "tree": "文件树视图",
    }

    def _dock_side_keys(self, side) -> list[str]:
        """某一栏当前的槽位 key 列表（左栏截到 LEFT_MAX，容错成列表）。"""
        st = getattr(self, "dock_state", None) or {}
        keys = st.get(side)
        if not isinstance(keys, list):
            return []
        keys = [k for k in keys if k in self.PANEL_WINDOW_KEYS
                and not self.panel_window_open(k)                       # 拖出去成了独立窗口：栏里不再留它
                and not (k == "screen" and getattr(self, "screen_win_open", False))]   # 小屏幕自己的窗口开着：不占格子
        return keys[:panels.LEFT_MAX] if side == "left" else keys

    def _dock_title(self, key) -> str:
        """面板标题（panels.PANELS 里取不到就用内置标题兜底）。"""
        try:
            return str(panels.PANELS[key]["title"])
        except Exception:
            return self.DOCK_TITLES.get(key, key)

    def _dock_title_h(self) -> int:
        """拖出去了只留标题条时的高度。"""
        return self.small.get_linesize() * 2 + S(16)

    def _dock_left_geom(self, left: pygame.Rect) -> list[tuple[str, pygame.Rect]]:
        """左栏各槽的视觉矩形：economy 固定 168px 贴底，staff 吃掉其余高度的 40%，剩下的均分。"""
        keys = self._dock_side_keys("left")
        if not keys or left.w <= 0:
            return []
        bottom = left.bottom                     # 底下那排管理按钮挪到顶栏了：左栏不用再留位置
        top_y = left.y
        if len(keys) == 1:                               # 只有一块：占满整栏，不留空白
            return [(keys[0], pygame.Rect(left.x, top_y, left.w, max(0, bottom - top_y)))]
        econ_h = S(168) if "economy" in keys else 0
        avail = max(0, bottom - top_y - econ_h)
        rest = [k for k in keys if k not in ("economy", "staff")]
        sh = 0
        if "staff" in keys:
            sh = max(S(120), avail * 40 // 100) if rest else avail      # 没有别的格子：员工栏占满，别留空白
            others = len(rest)
            sh = min(sh, max(0, avail - others * S(80)))
        out, y = [], top_y
        for k in keys:
            if k == "economy":
                r = pygame.Rect(left.x, bottom - econ_h, left.w, econ_h)
            elif k == "staff":
                r = pygame.Rect(left.x, y, left.w, sh)
                y += sh
            else:
                r = pygame.Rect(left.x, y, left.w, max(0, avail - sh) // max(1, len(rest)))
                y += r.h
            out.append((k, r))
        return out

    def draw_left_docked(self, left: pygame.Rect):
        """左栏按 dock_state["left"] 动态画各槽；拖出去的槽只留标题条并每帧投影到独立窗口。"""
        if not isinstance(getattr(self, "_dock_left_rects", None), list):
            self._dock_left_rects = []
        self._dock_left_rects = []
        for key, r in self._dock_left_geom(left):
            if r.w <= 0 or r.h <= 0:
                continue
            self._dock_left_rects.append((key, r))
            self._draw_slot(key, r)
            self.draw_dock_hide(r, key)              # 标题条右上角的 X：点了把这个槽真拿掉

    def _draw_slot(self, key, rr: pygame.Rect, title: str | None = None):
        """在栏里的一格画某个模块（左栏右栏同一套：员工栏、小屏幕、经济栏放到右栏也能画）。"""
        if key == "staff":
            self.draw_staff_area(rr)
        elif key == "screen":
            self.draw_screen(rr, title)
        elif key == "economy":
            self.draw_economy(rr)
        elif key == "tree":
            self.draw_tree(rr, title)
        elif key == "flow":
            self.flow_rect = rr
            self.draw_flow(rr, title)
        elif key == "board":
            self.draw_board(rr, title)
        elif key == "write":
            self.write_rect = rr
            self.draw_panel(rr)
        elif key == "task_queue":
            self.draw_goal_queue(rr)
        elif modules_api.get(key):
            p = modules_api.get(key)
            top = self.panel_header(rr, title or p["title"], p["sub"], C["dim"], key=key)
            self._draw_plugin_body(key, pygame.Rect(rr.x, top, rr.w, max(0, rr.bottom - top)))

    def _draw_plugin_body(self, key, body: pygame.Rect):
        """外接模块的内容区：交给模块自己画；模块出错只在这块写原因，不影响别的。"""
        pygame.draw.rect(self.screen, C["panel"], body)
        if body.w < 20 or body.h < 20:
            return
        clip = self.screen.get_clip()
        self.screen.set_clip(body)                      # 模块只能画在自己那块里
        err = modules_api.draw(self, key, self.screen, body, C, S, utext)
        self.screen.set_clip(clip)
        if err:
            err = f"{err}（完整报错：modules/.logs/{key}.log）"
            for i, line in enumerate(wrap(self.small, f"模块出错：{err}", body.w - PAD * 2)[:5]):
                self.screen.blit(utext(self.small, line, STYLE["error"][1]),
                                 (body.x + PAD, body.y + S(6) + i * self.small.get_linesize()))
        modules_api.mark_drawn(key)
        self.plugin_rects[key] = (self.screen, body)

    def load_modules(self, quiet: bool = False) -> str:
        """扫 modules/ 文件夹：新模块登记成面板（先放进「模块管理」等你放回），改过的重新读，删掉的拿掉。返回一句结果。"""
        modules_api.set_host(self, C, S, utext)
        added, removed, errs = modules_api.load_all()
        fresh = modules_api.take_new_installs()
        if fresh:                                       # 第一次装上的模块：提醒它的代码以 Terminist 的权限跑
            self.notice("info", f"新装了外接模块：{'、'.join(fresh)}。模块的代码会以 Terminist 的权限运行"
                                "（能读写文件、联网），只装信得过的；不想要了在「模块」里停用。")
        for k in modules_api.keys():
            p = modules_api.get(k)
            panels.PANELS[k] = {"side": p["side"], "hidden": True, "title": p["title"]}
            if k not in self.PANEL_WINDOW_KEYS:
                self.PANEL_WINDOW_KEYS.append(k)
        for k in removed:
            panels.PANELS.pop(k, None)
            if k in self.PANEL_WINDOW_KEYS:
                self.PANEL_WINDOW_KEYS.remove(k)
            if self.panel_window_open(k):
                self.close_panel_window(k)
        st = getattr(self, "dock_state", None)
        if isinstance(st, dict):                        # 运行中刷新：新模块进「模块管理」，删掉的从各栏拿掉
            for name in ("left", "right", "hidden"):
                st[name] = [k for k in (st.get(name) or []) if k not in removed]
            placed = set(st["left"]) | set(st["right"]) | set(st["hidden"])
            st["hidden"] += [k for k in added if k not in placed]
            panels.save_dock(self.settings, st)
            self._dock_changed()
        msg = (f"外接模块：{len(modules_api.keys())} 个"
               + (f"，新加 {'、'.join(modules_api.get(k)['title'] for k in added)}（在「模块」里放回）" if added else "")
               + (f"，去掉 {'、'.join(removed)}" if removed else "")
               + (f"；读不了：{'；'.join(f'{f}（{e}）' for f, e in errs.items())}" if errs else ""))
        if not quiet or added or errs:
            self.notice("info", msg)
        return msg

    # ---------------- 接管模式（黄色开始按钮 / /接管 / 按 P 暂停） ----------------

    def start_takeover(self):
        # 进入接管模式：自己频繁截图 + 控制键鼠干，任务队列抽成独立窗钉在屏幕右上角。
        try:                                              # 先看前台是谁（任务队列小窗弹出来之前）
            from base import winfo
            front = winfo.describe()
        except Exception:
            front = ""
        self.takeover_active = True
        self.takeover_paused = False
        self.takeover_front = front
        self.ensure_agent()
        self._sync_takeover()                             # 眼睛开始看；Agent 进入接管模式
        w, h = S(300), S(420)                             # 队列独立窗尺寸（宽, 高）
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
            dw, dh = int(dw), int(dh)
        except Exception:
            dw, dh = 1920, 1080
        ok = False
        try:
            ok = bool(self.open_panel_window('task_queue', anchor=(max(0, dw - w), 0), size=(w, h)))
        except Exception as ex:                           # 抽窗失败也不能把界面搞崩
            self.add('warn', '任务队列独立窗没弹出来：' + str(ex))
        self.add('assistant', '已进入接管模式：我会频繁截图+控制键鼠自己干。按 P 暂停/继续，再点红按钮或说 /接管停止 退出。'
                 + (f'\n当前最上层的前台窗口：{front}' if front else ''))
        if not ok:
            self.add('warn', '接管已开，但任务队列独立窗没弹出来')
        self.mark_dirty()

    def stop_takeover(self, summary: str = '', by_agent: bool = False):
        # 退出接管模式：队列独立窗归位回右栏，弹窗告诉主人已退出（主人自己退、Agent 自己退都弹）。
        if not getattr(self, 'takeover_active', False):
            if not by_agent:
                self.add('info', '现在不在接管模式。')
            return
        self.takeover_active = False
        self.takeover_paused = False
        self._sync_takeover()
        if self.panel_window_open('task_queue'):
            try:
                self.close_panel_window('task_queue', dock=True)
            except Exception:
                pass
        who = 'Agent 干完了，自己退出了接管模式' if by_agent else '已退出接管模式'
        msg = who + '：眼睛停止截图，鼠标键盘交还给你。' + (f'\n\n这次接管：{summary}' if summary else '')
        self.add('assistant', msg)
        self.show_notice('已退出接管', msg)
        if by_agent:
            self.bring_to_front()                         # 主人可能正看着别的窗口：把弹窗亮出来
        self.mark_dirty()

    def show_notice(self, title: str, msg: str):
        """只有一个「知道了」按钮的提示弹窗（复用确认框）；已经有框在显示就排到后面。"""
        req = ConfirmRequest(msg, '', kind='notice', title=title, ok_text='知道了')
        if self.pending_confirm is not None:
            self.confirm_queue.append(req)
        else:
            self.pending_confirm = req
            self.modal_scroll = 0
        self._dirty = True
        return req

    def toggle_takeover_pause(self):
        # 接管中按 P：暂停 / 继续。眼睛跟着停 / 开；Agent 正在干活的话这一步做完就停住（继续时接着干）。
        self.takeover_paused = not getattr(self, 'takeover_paused', False)
        self._sync_takeover()
        try:
            if self.agent and self.busy:
                (self.agent.pause if self.takeover_paused else self.agent.resume)()
        except Exception:
            pass
        self.add('assistant', '接管已暂停' if self.takeover_paused else '接管继续')
        self.mark_dirty()

    def _sync_takeover(self):
        """把接管状态告诉 Agent（眼睛在 Agent 那边截图识别；Agent 每做一件事带上前 5 秒眼睛日志、能用 skip）。"""
        on = bool(getattr(self, 'takeover_active', False))
        paused = bool(getattr(self, 'takeover_paused', False))
        agent = getattr(self, 'agent', None)
        if agent is None:
            return

        def run():
            try:
                if isinstance(agent, AgentProxy):
                    agent.set_takeover(on, paused)
                else:                                     # Agent 在界面进程里：眼睛也在这边跑
                    from base import eye
                    agent.takeover = on
                    eye.set_takeover(on, paused)
            except Exception as ex:
                self.events.put(('error', f'接管模式没告诉到 Agent：{type(ex).__name__}: {ex}'))
        threading.Thread(target=run, daemon=True).start()     # Agent 进程可能刚起来：别卡界面

    def _takeover_knowledge_file(self):
        # 接管模式学习缓存的 json 路径。
        return os.path.join(str(da.APP_ROOT), 'modules', '.state', 'takeover_learn.json')

    def save_interface_knowledge(self, app_name, steps):
        # 把某个软件的界面学习结果（步骤 + 坐标）写进本地 json；写失败静默返回 False。
        try:
            path = self._takeover_knowledge_file()
            data = {}
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    got = json.load(f)
                if isinstance(got, dict):
                    data = got
            except Exception:
                data = {}                                # 还没有缓存 / 文件坏了：重开一份
            old = data.get(str(app_name))
            old_coords = old.get('coords') if isinstance(old, dict) else None
            coords = old_coords if isinstance(old_coords, dict) else {}
            if isinstance(steps, dict):                  # 传 {'steps': [...], 'coords': {...}} 也认
                coords = steps.get('coords') or coords
                steps = steps.get('steps') or []
            data[str(app_name)] = {'steps': list(steps or []),
                                   'coords': coords,
                                   'updated': time.ctime()}
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False

    def load_interface_knowledge(self, app_name):
        # 读某个软件的界面学习缓存；没有 / 读不了返回 None。
        try:
            with open(self._takeover_knowledge_file(), 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            return None
        if not isinstance(data, dict):
            return None
        got = data.get(str(app_name))
        return got if isinstance(got, dict) else None

    def draw_detached_windows(self):
        """拖出去的独立窗口每帧投影一次（它们已经不在任何一栏里了，栏里不会顺手画它们）。"""
        for key in list((getattr(self, "panel_windows", None) or {}).keys()):
            if self.panel_window_open(key):
                self.draw_panel_window(key)

    def _dock_slot_at(self, pos, side: str):
        """这一栏哪个槽压着 pos：返回 slot 序号，没有返回 None。rects 是本帧渲染时填的视觉顺序，跟 index 对齐。"""
        if pos is None:
            return None
        rects = (getattr(self, "_dock_left_rects", None) if side == "left" else None) \
            or (getattr(self, "_dock_right_rects", None) if side == "right" else None) or []
        for i, item in enumerate(rects):
            r = item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else item
            if isinstance(r, pygame.Rect) and r.w > 0 and r.h > 0 and r.collidepoint(pos):
                return i
        return None

    def _dock_drop_zones(self, pos):
        """落点判定：pos 在左栏/右栏内就返回 (side, slot_idx)，否则 (None, None)。"""
        if pos is None:
            return (None, None)
        try:
            left, _center, right = self.layout()
        except Exception:
            return (None, None)
        if left.w and left.collidepoint(pos):
            idx = self._dock_slot_at(pos, "left")
            return ("left", idx if idx is not None else len(self._dock_side_keys("left")))
        if right.w and right.collidepoint(pos):
            idx = self._dock_slot_at(pos, "right")
            return ("right", idx if idx is not None else len(self._dock_side_keys("right")))
        W = self.screen.get_width()
        if not left.w and TOP_H <= pos[1] and 0 <= pos[0] < self.sizes["left"]:
            return ("left", len(self._dock_side_keys("left")))      # 左栏收着：拖到最左边那条就放进左栏
        if not right.w and TOP_H <= pos[1] and W - max(S(360), self.sizes["right"]) < pos[0] <= W:
            return ("right", len(self._dock_side_keys("right")))    # 右栏收着：拖到最右边那条就放进右栏
        return (None, None)

    def _dock_visual_to_list(self, side: str, slot_idx: int) -> int:
        """视觉槽位号换成列表插入位置：左栏 economy 固定画在底部但留在列表末尾。"""
        keys = self._dock_side_keys(side)
        n = len(keys)
        if slot_idx is None:
            return n
        slot_idx = max(0, min(int(slot_idx), max(0, n - (1 if side == "left" and "economy" in keys else 0))))
        if side == "left" and "economy" in keys and slot_idx >= len(keys) - 1:
            return len(keys) - 1
        return slot_idx

    def _dock_drop(self, key, zone) -> bool:
        """松手嵌入：把 key 插进命中栏的命中槽，落盘 dock_state 并收掉它的独立窗口。栏外返回 False。"""
        if not key or not zone:
            return False
        side, slot_idx = zone
        if side not in ("left", "right"):
            return False
        st = getattr(self, "dock_state", None)
        if not isinstance(st, dict):
            return False
        for name in ("left", "right", "hidden"):
            st[name] = [k for k in (st.get(name) or []) if k != key]
        idx = self._dock_visual_to_list(side, slot_idx)
        st[side].insert(max(0, min(idx, len(st[side]))), key)
        if side == "left":
            while len(st["left"]) > panels.LEFT_MAX:     # 左栏最多 3 槽：多的溢到 hidden
                over = st["left"].pop()
                if over != key and over not in st["hidden"]:
                    st["hidden"].append(over)
        panels.save_dock(self.settings, st)
        _save_setting(self, "panel_dock", self.settings.get("panel_dock"))
        self.close_panel_window(key, dock=True)
        self._dock_changed()
        return True

    def _dock_changed(self):
        """dock_state 刚变过：清掉这一帧的槽位矩形，下一帧重排并重绘。"""
        self._dock_left_rects = []
        self._dock_right_rects = []
        self.mark_dirty()

    def _dock_hide_panel(self, key):
        """点 X：把面板从停靠槽里真拿掉（left/right/hidden 三列先全剔除再进 hidden）+ 落盘。
        只动 dock 槽位，不碰这个面板的独立窗口（两套状态独立）。"""
        if not key or key not in self.PANEL_WINDOW_KEYS:
            return
        st = getattr(self, "dock_state", None)
        if not isinstance(st, dict):
            return
        for name in ("left", "right", "hidden"):
            st[name] = [k for k in (st.get(name) or []) if k != key]
            if not isinstance(st[name], list):
                st[name] = []
        st["hidden"].append(key)
        panels.save_dock(self.settings, st)
        _save_setting(self, "panel_dock", self.settings.get("panel_dock"))
        self._dock_changed()

    def _dock_restore_panel(self, key):
        """模块管理里点一个：把 key 从 hidden 移回它默认那一栏（左栏满 LEFT_MAX 就顺延右栏）+ 落盘。"""
        if not key or key not in self.PANEL_WINDOW_KEYS:
            return
        st = getattr(self, "dock_state", None)
        if not isinstance(st, dict):
            return
        for name in ("left", "right", "hidden"):         # 一个 key 同一时刻只在一个列表里
            st[name] = [k for k in (st.get(name) or []) if k != key]
            if not isinstance(st[name], list):
                st[name] = []
        try:
            side = str(panels.PANELS[key]["side"])
        except Exception:
            side = "left"
        if side == "left" and len(st["left"]) >= panels.LEFT_MAX:
            side = "right"                               # 左栏满了：顺延到右栏
        st[side if side in ("left", "right") else "left"].append(key)
        panels.save_dock(self.settings, st)
        _save_setting(self, "panel_dock", self.settings.get("panel_dock"))
        self._dock_changed()

    def draw_dock_hide(self, box: pygame.Rect, key, right_edge: int | None = None) -> None:
        """在停靠槽标题条右上角自绘一个 X，并把 (rect, key) 登记进 _dock_hide_rects（draw() 每帧只清一次）。"""
        if not key or box is None or box.w <= 0 or box.h <= 0:
            return
        if not isinstance(getattr(self, "_dock_hide_rects", None), list):
            self._dock_hide_rects = []
        s = max(S(16), self.small.get_linesize())
        r = pygame.Rect(0, 0, s + S(6), s + S(4))
        r.topright = ((right_edge if right_edge is not None else box.right) - S(2), box.y + S(2))
        r.clamp_ip(box)                                  # 别画到隔壁槽上
        hot = r.collidepoint(pygame.mouse.get_pos())
        if hot:
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.18), r, border_radius=S(5))
        color = C["hdr"] if hot else C["dim"]
        c = s // 2
        d = max(S(3), c // 2)
        cx, cy = r.centerx, r.centery
        pygame.draw.line(self.screen, color, (cx - d, cy - d), (cx + d, cy + d), max(1, S(2)))
        pygame.draw.line(self.screen, color, (cx - d, cy + d), (cx + d, cy - d), max(1, S(2)))
        self._dock_hide_rects.append((r, key))

    def _dock_hit_hide(self, pos):
        """pos 点中了哪个槽标题条的 X：返回 key，否则 None。"""
        if pos is None:
            return None
        for item in getattr(self, "_dock_hide_rects", []) or []:
            try:
                r, key = item[0], item[1]
            except (TypeError, IndexError):
                continue
            if isinstance(r, pygame.Rect) and r.w > 0 and r.collidepoint(pos):
                return key
        return None

    def draw_modules_panel(self):
        """顶栏「模块」展开后的模块管理面板（列 dock_state["hidden"] 里的面板，点一行放回）。"""
        self.modules_rects = []
        br = getattr(self, "modules_btn_rect", None)
        if not self.modules_open or not isinstance(br, pygame.Rect) or br.w <= 0:
            return
        hidden = [k for k in (self.dock_state.get("hidden") or []) if k in self.PANEL_WINDOW_KEYS]
        row_h = self.small.get_linesize() + S(10)
        errs = modules_api.errors()
        cat = modules_api.catalog()
        box = pygame.Rect(br.x, br.bottom + S(6), S(380),
                          row_h * (max(1, len(hidden)) + 1 + len(errs) + len(cat) + (1 if cat else 0)) + S(56))
        soft_shadow(self.screen, box, S(8))
        pygame.draw.rect(self.screen, C["modal"], box, border_radius=S(8))
        pygame.draw.rect(self.screen, C["input_border"], box, 1, border_radius=S(8))
        self.screen.blit(utext(self.small, "模块管理", C["hdr"]), (box.x + S(10), box.y + S(8)))
        y = box.y + self.small.get_linesize() + S(14)
        rr = pygame.Rect(box.x + S(4), y, box.w - S(8), row_h)         # 刷新模块：重新扫 modules/ 文件夹
        if rr.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.screen, mix(C["modal"], C["hdr"], 0.16), rr, border_radius=S(5))
        t = utext(self.small, f"刷新模块（读 modules/ 文件夹，现有外接 {len(modules_api.keys())} 个）", C["hdr"])
        self.screen.blit(t, (rr.x + S(8), rr.centery - t.get_height() // 2))
        self.modules_rects.append((rr, "__reload__"))
        y += row_h
        for f, e in errs.items():                       # 读不了的模块：写出原因
            t = utext(self.small, ellipsize(self.small, f"读不了 {f}：{e}", box.w - S(20)), STYLE["error"][1])
            self.screen.blit(t, (box.x + S(12), y + S(4)))
            y += row_h
        if cat:                                         # 装了哪些外接模块：版本、作者、给 Agent 的工具数；可以停用 / 启用
            self.screen.blit(utext(self.small, "已装的外接模块", C["dim"]), (box.x + S(10), y + S(4)))
            y += row_h
            mouse = pygame.mouse.get_pos()
            for row in cat:
                ir = pygame.Rect(box.x + S(4), y, box.w - S(8), row_h)
                act = utext(self.small, "停用" if row["enabled"] else "启用", C["hdr"])
                ar = act.get_rect(midright=(ir.right - S(8), ir.centery)).inflate(S(10), S(4))
                if ar.collidepoint(mouse):
                    pygame.draw.rect(self.screen, mix(C["modal"], C["hdr"], 0.16), ar, border_radius=S(5))
                self.screen.blit(act, act.get_rect(center=ar.center))
                self.modules_rects.append((ar, "__toggle__:" + row["label"]))
                info = [x for x in (f"v{row['version']}" if row["version"] else "", row["author"],
                                    f"{row['tools']} 个工具给 Agent" if row["tools"] else "") if x]
                name = row["title"] + ("" if row["enabled"] else "（已停用）")
                col = C["text"] if row["enabled"] else C["dim"]
                if row["error"] or row["last_error"]:
                    col = STYLE["error"][1]
                    info = ["出错了，看 modules/.logs"] + info
                t = utext(self.small, ellipsize(self.small, name + ("  · " + " · ".join(info) if info else ""),
                                                ar.x - ir.x - S(14)), col)
                self.screen.blit(t, (ir.x + S(8), ir.centery - t.get_height() // 2))
                y += row_h
        if not hidden:
            self.screen.blit(utext(self.small, "没有隐藏的模块", C["dim"]), (box.x + S(10), y + S(4)))
            return
        for key in hidden:
            ir = pygame.Rect(box.x + S(4), y, box.w - S(8), row_h)
            if ir.collidepoint(pygame.mouse.get_pos()):
                pygame.draw.rect(self.screen, mix(C["modal"], C["hdr"], 0.16), ir, border_radius=S(5))
            t = utext(self.small, ellipsize(self.small, self._dock_title(key), ir.w - S(14)), C["text"])
            self.screen.blit(t, (ir.x + S(8), ir.centery - t.get_height() // 2))
            put = utext(self.small, "放回", C["dim"])
            self.screen.blit(put, (ir.right - put.get_width() - S(8), ir.centery - put.get_height() // 2))
            self.modules_rects.append((ir, key))
            y += row_h

    def _drop_on_module(self, path) -> bool:
        """文件拖到外接模块的面板上：交给模块的 on_drop；模块没写 on_drop 就照原来的方式处理。"""
        if not path:
            return False
        mouse = pygame.mouse.get_pos()
        for k, (surf, body) in list(getattr(self, "plugin_rects", {}).items()):
            if surf is self.screen and body.collidepoint(mouse) and modules_api.drop(k, path, body):
                self.mark_dirty()
                return True
        return False

    def _modules_hit(self, pos):
        """pos 点中模块管理面板的哪一行：返回 key，否则 None。"""
        if pos is None:
            return None
        for r, key in getattr(self, "modules_rects", []) or []:
            if isinstance(r, pygame.Rect) and r.w > 0 and r.collidepoint(pos):
                return key
        return None

    def _draw_dock_overlay(self):
        """槽位高亮 + 拖动标签：只画，不改任何状态。"""
        drag = getattr(self, "panel_drag", None)
        hover = getattr(self, "_dock_hover", None)
        if hover and drag:
            side, idx = hover
            rects = self._dock_left_rects if side == "left" else self._dock_right_rects
            r = None
            for i, item in enumerate(rects or []):
                if i == idx:
                    rr = item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else item
                    if isinstance(rr, pygame.Rect) and rr.w > 0 and rr.h > 0:
                        r = rr
                    break
            if r is not None:
                lay = pygame.Surface(r.size, pygame.SRCALPHA)
                lay.fill((70, 140, 255, 60))
                self.screen.blit(lay, r.topleft)
                pygame.draw.rect(self.screen, (120, 180, 255), r, max(1, S(2)))
        if not drag:
            return
        key = drag[0]
        pos = pygame.mouse.get_pos()
        text = self._dock_title(key)
        if hover:
            text = f"{text} · {lang('dock_drop_here', '松手嵌入')}"
        try:
            t = utext(self.small, text, C["text"])
            box = t.get_rect()
            box.inflate_ip(S(16), S(8))
            box.topleft = (pos[0] + S(14), pos[1] + S(14))
            lay = pygame.Surface(box.size, pygame.SRCALPHA)
            lay.fill((0, 0, 0, 150))
            self.screen.blit(lay, box.topleft)
            pygame.draw.rect(self.screen, C["hdr"], box, 1)
            self.screen.blit(t, (box.x + S(8), box.y + S(4)))
        except Exception:
            pass

    def panel_header(self, rect: pygame.Rect, title: str, sub: str, sub_color, key: str | None = None) -> int:
        """画侧栏标题，返回内容区起始 y。key 非空时把标题条矩形登记进 self.panel_heads[key]（每帧刷新）。"""
        hdr_h = self.small.get_linesize() * 2 + S(14)
        pygame.draw.rect(self.screen, C["panel"], (rect.x, rect.y, rect.w, hdr_h))
        pygame.draw.rect(self.screen, C["hdr"],
                         (rect.x + S(4), rect.y + S(5), S(3), self.small.get_linesize()),
                         border_radius=S(2))
        title_w = rect.w - PAD * 2 - S(14)          # 左边竖条 + 内缩，标题也要截断，不然拖窄会冲出去
        self.screen.blit(utext(self.small, ellipsize(self.small, title, title_w), C["hdr"]),
                         (rect.x + PAD + S(8), rect.y + S(5)))
        sub = ellipsize(self.small, sub, rect.w - PAD * 2 - S(8))
        self.screen.blit(utext(self.small, sub, sub_color),
                         (rect.x + PAD + S(8), rect.y + S(7) + self.small.get_linesize()))
        pygame.draw.line(self.screen, C["border"], (rect.x, rect.y + hdr_h - 1),
                         (rect.right, rect.y + hdr_h - 1))
        if key:
            self._panel_head_set(key, pygame.Rect(rect.x, rect.y, rect.w, hdr_h))
        return rect.y + hdr_h

    def staff_avatar(self, name: str, size: int):
        """员工的圆形头像（缩小好的 Surface）；没头像或读不出来返回 None。带缓存，每帧不重读盘。"""
        cache = getattr(self, "_avatar_cache", None)
        try:
            stamp = STAFF_FILE.stat().st_mtime_ns          # 编辑器改过花名册 / 换过头像：缓存作废
        except OSError:
            stamp = None
        if not isinstance(cache, dict) or getattr(self, "_avatar_stamp", None) != stamp:
            cache = self._avatar_cache = {}
            self._avatar_stamp = stamp
        key = (name, int(size))
        if key in cache:
            return cache[key] or None
        try:
            p = avatar_path(name)
            if not p:
                cache[key] = self.default_avatar(name, size)
                return cache[key]
            img = pygame.image.load(io.BytesIO(Path(p).read_bytes()), str(p))
            img = img.convert_alpha()
            w, h = img.get_size()
            side = min(w, h)
            if side <= 0:
                cache[key] = False
                return None
            square = pygame.Rect((w - side) // 2, (h - side) // 2, side, side)
            face = pygame.transform.smoothscale(img.subsurface(square), (size, size)).copy()
            mask = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(mask, (255, 255, 255, 255), (size // 2, size // 2), size // 2)
            face.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            cache[key] = face
            return face
        except Exception:
            cache[key] = False
            return None

    def default_avatar(self, name: str, size: int):
        """没传图片的员工：圆形底色（按员工固定）+ 显示名第一个字。"""
        face = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.circle(face, avatar_color(name), (size // 2, size // 2), size // 2)
        try:
            ch = avatar_initial(name, staff_label(canon(name)))
        except Exception:
            ch = "?"
        font = getattr(self, "_avatar_fonts", {}).get(size)
        if font is None:
            font = load_font(max(8, int(size * 0.5)))
            font.set_bold(True)
            self.__dict__.setdefault("_avatar_fonts", {})[size] = font
        t = font.render(ch, True, (255, 255, 255))
        face.blit(t, t.get_rect(center=(size // 2, size // 2)))
        return face

    def open_staff_editor(self, name: str | None):
        """新建前台角色（name=None）/ 改已有员工的设定：单独的小窗口进程，改完主界面自动刷新。"""
        proc = getattr(self, "staff_editor_proc", None)
        if proc is not None and proc.poll() is None:
            self.notice("info", "员工编辑窗口已经开着了")
            return
        import subprocess
        import run as launcher
        try:
            self.staff_editor_proc = subprocess.Popen(
                [launcher._python_for_gui(), "-m", "surface.staff_editor", name or "--new"], cwd=str(launcher.ROOT),
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=0x08000000 if sys.platform == "win32" else 0)
        except OSError as e:
            self.add("error", f"打不开员工编辑窗口：{e}")

    def poll_staff_editor(self):
        """编辑窗口关了：读它的结果，刷新头像；改的是正在上岗的前台就立刻换上新人设。"""
        proc = getattr(self, "staff_editor_proc", None)
        if proc is None or proc.poll() is None:
            return
        self.staff_editor_proc = None
        try:
            out = (proc.stdout.read() or b"").decode("utf-8", "replace").strip().splitlines()
            res = json.loads(out[-1]) if out else {}
        except (OSError, ValueError):
            res = {}
        self._avatar_cache = {}
        self.mark_dirty()
        if res.get("error"):
            self.add("error", res["error"])
        elif res.get("deleted"):
            self.notice("info", f"已删除员工 {res['deleted']}")
        elif res.get("saved"):
            name = res["saved"]
            self.notice("info", ("已新建前台「{}」：在员工栏点它、再点「上岗」就能换它来聊" if res.get("new")
                         else "已保存「{}」的设定").format(res.get("label") or name))
            try:
                if canon(name) == canon(active_staff()) and self.agent:   # 正在上岗：新人设立刻生效
                    self.agent.set_persona(active_persona())
            except Exception as e:
                self.add("error", f"新人设没能换上：{type(e).__name__}: {e}")

    def staff_runtime_rows(self, staff: dict) -> list:
        """运行时正在干活的角色（B库 / 执行成员）：花名册里没有的，按岗位补进员工栏。"""
        rows = []
        try:
            seen = set(str(k) for k in (staff or {}))
        except Exception:
            seen = set()
        try:
            agent = getattr(self, "agent", None)
            if agent is not None and getattr(agent, "child", None) is not None and "b库" not in seen:
                rows.append(("b库", {"label": "B库", "role": "builder", "duty": ""}))
                seen.add("b库")
        except Exception:
            pass
        try:
            for w in sorted(getattr(self, "active_workers", None) or set(), key=str):
                nm = w if isinstance(w, str) else f"#{w}"
                if nm in seen:
                    continue
                rows.append((nm, {"label": nm, "role": "worker", "duty": ""}))
                seen.add(nm)
        except Exception:
            pass
        try:
            cur = str(getattr(self, "current_member", "") or "")
            low = cur.lower()
            if cur and cur not in seen:
                role = "builder" if ("b库" in low or "lib_b" in low or "builder" in low) else "worker"
                rows.append((cur, {"label": cur, "role": role, "duty": ""}))
        except Exception:
            pass
        return rows

    def tick_economy(self):
        """每 3 秒向 Agent 拉一次经济栏最新序列（空闲不烧 token 也要随时间重切桶）。"""
        now = pygame.time.get_ticks()
        last = getattr(self, "_economy_tick", 0) or 0
        if now - last < 3000:
            return
        self._economy_tick = now
        try:
            agent = getattr(self, "agent", None)
            if agent is not None and not getattr(self, "busy", False):
                agent.request_economy()
        except Exception:
            pass

    def draw_economy(self, rect: pygame.Rect):
        """左栏底部经济栏：利用率 + 带标尺的输入/输出分色柱状图 + 分色折线图。"""
        if rect.w <= 0 or rect.h <= 0:
            return
        pygame.draw.rect(self.screen, mix(C["panel"], C["bg"], 0.35), rect)
        top = self.panel_header(rect, lang("economy", "经济栏"), "", C["dim"], key="economy")
        e = getattr(self, "economy", None) or {}
        s5i = list(e.get("series_5s_in", []) or [])
        s5o = list(e.get("series_5s_out", []) or [])
        m1i = list(e.get("series_1min_in", []) or [])
        m1o = list(e.get("series_1min_out", []) or [])
        h1i = list(e.get("series_1h_in", []) or [])
        h1o = list(e.get("series_1h_out", []) or [])
        util = e.get("utilization", 0.0) or 0.0
        formula = e.get("util_formula", "利用率 = 输出 ÷ (输入+输出)")
        lh = self.small.get_linesize() + S(3)
        inner_w = rect.w - PAD * 2
        x0 = rect.x + PAD
        y = top + S(2)
        c_in = C["hdr"]       # 输入色（蓝）
        c_out = C["add"]      # 输出色（绿）

        # 利用率 + 公式
        self.screen.blit(utext(self.small, f"利用率 {util:g}%", c_out), (x0, y))
        y += lh
        self.screen.blit(utext(self.small, ellipsize(self.small, formula, inner_w), C["dim"]), (x0, y))
        y += lh + S(2)

        # 成本：本会话 / 历史累计（拿不到 cost 模块就不显示）
        try:
            from lib_a import cost as _cost
            fmt_usd, fmt_cny = _cost.fmt_cost, _cost.fmt_cost_cny
        except Exception:
            fmt_usd = fmt_cny = None
        if fmt_usd is not None:
            for label, key in (("最近1分钟成本", "cost_last_min"), ("最近1小时成本", "cost_last_hour"), ("历史累计成本", "cost_lifetime")):
                usd = float(e.get(key, 0.0) or 0.0)
                self.screen.blit(utext(self.small, ellipsize(
                    self.small, f"{label} {fmt_usd(usd)} / {fmt_cny(usd)}", inner_w), C["text"]), (x0, y))
                y += lh
            y += S(2)

        # 图例
        t_in = utext(self.small, "■输入", c_in)
        self.screen.blit(t_in, (x0, y))
        self.screen.blit(utext(self.small, "■输出", c_out), (x0 + t_in.get_width() + S(10), y))
        y += lh + S(2)

        # 5 秒吞吐：分色柱状图 + 垂直标尺（刻度数字）
        bar_h = S(44)
        if s5i or s5o:
            self.screen.blit(utext(self.small, "5秒吞吐", C["dim"]), (x0, y))
            y += lh
            bar_top = y
            allv = s5i + s5o
            maxv = (max(allv) if allv else 0) or 1
            n = max(len(s5i), len(s5o), 1)
            gg = S(2)
            # 垂直标尺：右侧标出 0 和 maxv
            scale_w = S(26)
            plot_w = max(S(10), inner_w - scale_w - S(4))
            self.screen.blit(utext(self.small, self._fmt_tok(maxv), C["dim"]),
                             (x0 + plot_w + S(2), bar_top))
            self.screen.blit(utext(self.small, "0", C["dim"]),
                             (x0 + plot_w + S(2), bar_top + bar_h - self.small.get_linesize()))
            pair_w = max(S(2), (plot_w - gg * (n - 1)) // n)
            for i in range(n):
                bx = x0 + i * (pair_w + gg)
                # 输入柱（偏左）
                vi = s5i[i] if i < len(s5i) else 0
                bih = int((vi / maxv) * (bar_h - S(2)))
                pygame.draw.rect(self.screen, c_in,
                                 (bx, bar_top + bar_h - bih, max(S(1), pair_w // 2), max(1, bih)))
                # 输出柱（偏右）
                vo = s5o[i] if i < len(s5o) else 0
                boh = int((vo / maxv) * (bar_h - S(2)))
                pygame.draw.rect(self.screen, c_out,
                                 (bx + pair_w // 2, bar_top + bar_h - boh,
                                  max(S(1), pair_w - pair_w // 2), max(1, boh)))
            y = bar_top + bar_h + S(2)

        # 1 分钟 / 1 小时：输入/输出分开的两组折线（1分与1小时同区叠画）
        line_h = S(36)
        if m1i or m1o or h1i or h1o:
            self.screen.blit(utext(self.small, "1分/1小时", C["dim"]), (x0, y))
            y += lh
            line_top = y
            self._draw_series_line(x0, line_top, inner_w, line_h, m1i, c_in)
            self._draw_series_line(x0, line_top, inner_w, line_h, m1o, c_out)
            self._draw_series_line(x0, line_top, inner_w, line_h, h1i, c_in)
            self._draw_series_line(x0, line_top, inner_w, line_h, h1o, c_out)
            y = line_top + line_h + S(2)

    def _fmt_tok(self, n):
        """token 数字缩成易读格式（4 位有效数字）：>=1e6 用 M，>=1e3 用 K。"""
        n = int(n or 0)
        if n >= 1000000:
            return f"{n / 1000000:.4g}M"
        if n >= 1000:
            return f"{n / 1000:.4g}K"
        return str(n)

    def _draw_series_line(self, x, top, w, h, values, color):
        """在 (x, top, w, h) 区域画一条折线，values 横向均布、纵向按最大值归一化。"""
        if not values:
            return
        mx = max(values) or 1
        n = len(values)
        pts = []
        for i, v in enumerate(values):
            px = x + int(w * i / max(1, n - 1))
            py = top + h - int((v / mx) * h)
            pts.append((px, py))
        if len(pts) == 1:
            pygame.draw.circle(self.screen, color, pts[0], S(2))
        else:
            pygame.draw.lines(self.screen, color, False, pts, S(1))

    def draw_staff_area(self, rect: pygame.Rect):
        """左栏员工区块：没拖出去就正常画，拖出去成独立窗口了就只留一块虚影占位。"""
        if getattr(self, "staff_win_open", False):
            return self.draw_staff_placeholder(rect)
        return self.draw_staff(rect)

    def draw_staff_placeholder(self, rect: pygame.Rect):
        """占位虚影：员工栏在独立窗口里时，原位置只画一块淡色虚线框，不接任何点击。"""
        self.staff_rects = []                       # 主窗口这里不再有可点的员工行
        self.staff_menu_rects = []
        self.staff_head_rect = pygame.Rect(0, 0, 0, 0)
        self.staff_last_rect = pygame.Rect(0, 0, 0, 0)
        self.staff_panel_rect = pygame.Rect(rect)
        pygame.draw.rect(self.screen, mix(C["panel"], C["bg"], 0.5), rect)
        pygame.draw.line(self.screen, C["border"], (rect.right - 1, rect.y), (rect.right - 1, rect.bottom))
        top = self.panel_header(rect, lang("staff"), lang("staff_placeholder"), C["dim"], key="staff")
        box = pygame.Rect(rect.x + PAD, top + S(10), max(0, rect.w - PAD * 2), S(92))
        self.staff_placeholder_rect = pygame.Rect(box)
        if box.w <= 0 or box.h <= 0:
            return
        lay = pygame.Surface(box.size, pygame.SRCALPHA)
        lay.fill((0, 0, 0, 16))
        self.screen.blit(lay, box.topleft)
        self._dash_rect(box, C["border"])
        for i, key in enumerate(("staff_placeholder", "staff_placeholder_hint")):
            t = utext(self.small, ellipsize(self.small, lang(key), max(0, box.w - S(16))), C["dim"])
            self.screen.blit(t, (box.x + S(8), box.y + S(9) + i * (self.small.get_linesize() + S(4))))

    def _dash_rect(self, box: pygame.Rect, color, dash: int = 6, gap: int = 5, width: int = 1):
        """画一圈虚线框（占位虚影 / 拖动虚影用）。"""
        dash, step = max(2, S(dash)), max(4, S(dash + gap))
        x, y, w, h = box
        for i in range(x, x + w, step):
            pygame.draw.line(self.screen, color, (i, y), (min(i + dash, x + w), y), width)
            pygame.draw.line(self.screen, color, (i, y + h - 1), (min(i + dash, x + w), y + h - 1), width)
        for j in range(y, y + h, step):
            pygame.draw.line(self.screen, color, (x, j), (x, min(j + dash, y + h)), width)
            pygame.draw.line(self.screen, color, (x + w - 1, j), (x + w - 1, min(j + dash, y + h)), width)

    def draw_staff_ghost(self):
        """拖动面板时的虚影：只是提示松手会成独立窗口，不改任何状态。"""
        box = getattr(self, "panel_ghost", None)
        if not isinstance(box, pygame.Rect) or box.w <= 0 or box.h <= 0:
            return
        try:
            lay = pygame.Surface(box.size, pygame.SRCALPHA)
            lay.fill((0, 0, 0, 28))
            self.screen.blit(lay, box.topleft)
            self._dash_rect(box, C["add"])
            k = getattr(self, "panel_ghost_key", None)
            title = ""
            if k:
                try:
                    title = str(panels.PANELS[k]["title"])
                except Exception:
                    title = k
            text = f"{title} · {lang('staff_drag_out')}" if title else lang("staff_drag_out")
            t = utext(self.small, ellipsize(self.small, text, max(0, box.w - S(14))), C["dim"])
            self.screen.blit(t, (box.x + S(7), box.y + S(6)))
        except Exception:
            pass

    def draw_staff(self, rect: pygame.Rect, title: str | None = None):
        """员工面板：花名册 + 运行时角色按岗位分组，正在干活的用亮色加圆点标出来。"""
        pygame.draw.rect(self.screen, C["panel"], rect)
        pygame.draw.line(self.screen, C["border"], (rect.right - 1, rect.y), (rect.right - 1, rect.bottom))
        try:
            staff = load_staff()
        except Exception:
            staff = {}
        if not isinstance(staff, dict):
            staff = {}
        busy = getattr(self, "active_workers", None) or set()
        current = getattr(self, "current_member", "")
        try:
            act = active_staff()
        except Exception:
            act = "fish"
        rows = [(n, s if isinstance(s, dict) else {}) for n, s in staff.items() if not str(n).startswith("_")]
        try:
            rows += self.staff_runtime_rows(staff)
        except Exception:
            pass
        self.staff_info = {n: s for n, s in rows}
        top = self.panel_header(rect, title or lang("staff"),
                                lang("staff_count").format(n=len(rows), who=staff_label(act)), C["dim"],
                                key="staff")
        self.staff_head_rect = pygame.Rect(rect.x, rect.y, rect.w, max(0, top - rect.y))   # 拖这块能拖出独立窗口
        self.staff_panel_rect = pygame.Rect(rect)
        self.staff_rects = []
        self.staff_menu_rects = []
        area = pygame.Rect(rect.x, top, rect.w, max(0, rect.bottom - top))
        self.staff_last_rect = pygame.Rect(area)     # 滚轮判断用
        line_h = self.small.get_linesize()
        self.screen.set_clip(area)
        if not rows:
            self.screen.blit(utext(self.small, lang("no_staff"), C["dim"]), (rect.x + PAD, area.y + S(4)))
        # 按岗位分组：分组顺序固定，同组内保持花名册原顺序
        groups = {}
        try:
            for name, s in rows:
                order = staff_group(name, s)[0]
                groups.setdefault(order, []).append((name, s))
        except Exception:
            groups = {4: rows}
        y = area.y + S(4) - int(getattr(self, "staff_scroll", 0))
        av = S(26)                                   # 头像直径
        hover = pygame.mouse.get_pos()
        for order in sorted(groups):
            items = groups[order]
            if not items:                            # 空分组不画标题
                continue
            if y + line_h > area.bottom:
                break
            gtitle = ellipsize(self.small, lang(STAFF_GROUP_KEYS.get(order, "staff_group_other")),
                               max(0, rect.w - PAD * 2))
            self.screen.blit(utext(self.small, gtitle, C["dim"]), (rect.x + PAD, y))   # 分组小标题，不可点
            y += line_h + S(2)
            for name, s in items:
                if y + line_h > area.bottom:
                    break
                on = name in busy or name == current or name == act
                color = C["add"] if on else C["text"]
                row_h = av + S(6)                    # 每条固定一行高，只留头像 + 名字
                img = self.staff_avatar(name, av)    # 没头像就是 None，退回纯文字
                shift = av + S(6) if img is not None else 0
                ty = y + (row_h - self.small.get_linesize()) // 2      # 名字竖直居中
                row = pygame.Rect(rect.x, y, max(0, rect.w - 1), row_h)   # 整行（头像也算进宽度）
                if row.collidepoint(hover):          # 鼠标移上来：浅色底提示可以点
                    pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.18), row)
                if img is not None:
                    self.screen.blit(img, (rect.x + PAD, y + (row_h - av) // 2))
                    if on:                           # 在岗圆点画在头像右下角
                        pygame.draw.circle(self.screen, C["add"],
                                           (rect.x + PAD + av - S(4), y + (row_h - av) // 2 + av - S(4)), S(3))
                elif on:
                    pygame.draw.circle(self.screen, C["add"], (rect.x + S(8), y + row_h // 2), S(3))
                mark = ""                            # 在岗已经有绿点和绿字标出来；▶ 字体里没有，会画成方框
                avail = rect.w - PAD * 2 - S(8) - shift
                text = ellipsize(self.small, f"{mark}{s.get('label') or name}（{name}）", avail)
                self.screen.blit(utext(self.small, text, color), (rect.x + PAD + S(4) + shift, ty))
                self.staff_rects.append((row, name))
                y += row_h
            if order == 0 and y + line_h <= area.bottom:   # 前台分组末尾：新建角色
                row_h = av + S(6)
                row = pygame.Rect(rect.x, y, max(0, rect.w - 1), row_h)
                if row.collidepoint(hover):
                    pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.18), row)
                ring = pygame.Rect(rect.x + PAD, y + (row_h - av) // 2, av, av)
                pygame.draw.circle(self.screen, C["border"], ring.center, av // 2, max(1, S(1)))
                plus = utext(self.small, "+", C["dim"])
                self.screen.blit(plus, plus.get_rect(center=ring.center))
                self.screen.blit(utext(self.small, ellipsize(self.small, lang("staff_new").lstrip("＋+ "),
                                                             rect.w - PAD * 2 - av - S(14)), C["dim"]),
                                 (ring.right + S(10), y + (row_h - self.small.get_linesize()) // 2))
                self.staff_rects.append((row, "__new__"))
                y += row_h
        self.staff_content_h = max(0, y - (area.y + S(4)) + int(getattr(self, "staff_scroll", 0)))
        self.screen.set_clip(None)
        try:
            if getattr(self, "staff_menu", None) is not None:
                self.draw_staff_menu(rect, area, line_h)
        except Exception:
            self.staff_menu_rects = []

    def draw_staff_menu(self, rect: pygame.Rect, area: pygame.Rect, line_h: int):
        """批评菜单：画在点开的那一行下方，两项「批评」「取消」，样式和下拉框一致。"""
        self.staff_menu_rects = []
        men = getattr(self, "staff_menu", None)
        if not men:
            return
        anchor = getattr(self, "staff_menu_at", None)
        w = min(max(0, rect.w - PAD * 2), S(180))
        item_h = line_h + S(6)
        h = item_h * 2 + S(2)
        y = anchor.bottom if isinstance(anchor, pygame.Rect) else area.y
        if y + h > area.bottom:                      # 放不下就往上收，别画出面板
            y = max(area.y, area.bottom - h)
        box = pygame.Rect(rect.x + PAD, y, w, h)
        pygame.draw.rect(self.screen, C["panel"], box, border_radius=S(6))
        pygame.draw.rect(self.screen, C["border"], box, 1, border_radius=S(6))
        hover = pygame.mouse.get_pos()
        for i, (action, key) in enumerate((("criticize", "staff_menu_criticize"), ("cancel", "staff_menu_cancel"))):
            r = pygame.Rect(box.x + S(2), box.y + S(1) + i * item_h, max(0, box.w - S(4)), item_h)
            if r.collidepoint(hover):
                pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.3), r, border_radius=S(4))
            text = ellipsize(self.small, lang(key), max(0, r.w - S(12)))
            self.screen.blit(utext(self.small, text, C["text"]), (r.x + S(6), r.y + S(3)))
            self.staff_menu_rects.append((r, action))

    def draw_staff_card(self, W, H, mouse):
        """员工信息卡：模态弹窗，画头像 / 名字 / 分组 / 职责 / 状态和底部「关闭」「上岗」两个按钮。只画不改状态。"""
        name = getattr(self, "staff_card", None)
        if not name:
            self.staff_card_rects = []
            self.staff_card_modal = pygame.Rect(0, 0, 0, 0)
            return
        key = canon(name)
        try:
            info = (getattr(self, "staff_info", None) or {}).get(key) or load_staff().get(key) or {}
        except Exception:
            info = {}
        if not isinstance(info, dict):
            info = {}
        try:
            label = staff_label(name)
        except Exception:
            label = str(name)
        try:
            group = staff_group(name, info)[1]
        except Exception:
            group = ""
        duty = str(info.get("duty") or "")
        try:
            act = active_staff()
        except Exception:
            act = "fish"
        on = canon(name) == canon(act)
        modal = self.draw_modal_frame(W, H, S(420), S(300))
        self.staff_card_modal = pygame.Rect(modal)
        x = modal.x + PAD * 2
        inner_w = max(0, modal.w - PAD * 4)
        y = modal.y + PAD
        self.screen.blit(utext(self.font, ellipsize(self.font, lang("staff_card_title"), inner_w),
                               C["hdr"]), (x, y))
        y += self.line_h + S(8)
        av = S(56)
        img = self.staff_avatar(key, av)
        if img is not None:
            self.screen.blit(img, (x, y))
        else:                                        # 没头像：画个占位方块
            box = pygame.Rect(x, y, av, av)
            pygame.draw.rect(self.screen, C["panel"], box, border_radius=S(8))
            pygame.draw.rect(self.screen, C["border"], box, 1, border_radius=S(8))
        tx = x + av + S(12)
        tw = max(0, modal.right - PAD * 2 - tx)
        self.screen.blit(utext(self.font, ellipsize(self.font, f"{label}（{name}）", tw), C["hdr"]),
                         (tx, y + S(4)))
        sy = y + self.line_h + S(10)
        sx = tx
        if group:
            gtext = ellipsize(self.small, group + " · ", tw)
            self.screen.blit(utext(self.small, gtext, C["dim"]), (sx, sy))
            sx += self.small.size(gtext)[0]
        stext = ellipsize(self.small, lang("staff_card_state_on") if on else lang("staff_card_state_off"),
                          max(0, modal.right - PAD * 2 - sx))
        self.screen.blit(utext(self.small, stext, C["add"] if on else C["dim"]), (sx, sy))
        y += av + S(12)
        self.screen.blit(utext(self.small, lang("staff_card_duty"), C["dim"]), (x, y))
        y += self.small.get_linesize() + S(2)
        try:
            lines = wrap(self.small, duty, inner_w) if duty else []
        except Exception:
            lines = [duty]
        if not lines:
            lines = ["—"]
        if len(lines) > 5:                           # 最多画 5 行，多的用省略号收尾
            lines = lines[:5]
            lines[-1] = ellipsize(self.small, lines[-1] + "…", inner_w)
        for line in lines:
            self.screen.blit(utext(self.small, ellipsize(self.small, line, inner_w), C["text"]), (x, y))
            y += self.small.get_linesize()
        bh, bw = S(38), S(110)
        by = modal.bottom - S(54)
        close_r = pygame.Rect(modal.right - PAD * 2 - bw, by, bw, bh)
        take_r = pygame.Rect(close_r.x - S(10) - bw, by, bw, bh)
        try:
            editable = key in load_staff()
        except Exception:
            editable = False
        edit_r = pygame.Rect(modal.x + PAD * 2, by, S(90), bh) if editable else None
        if edit_r is not None:
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.55 if edit_r.collidepoint(mouse) else 0.4),
                             edit_r, border_radius=S(8))
            t = utext(self.font, lang("staff_card_edit"), C["text"])
            self.screen.blit(t, t.get_rect(center=edit_r.center))
        pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.4), close_r, border_radius=S(8))
        t = utext(self.font, lang("staff_card_close"), C["text"])
        self.screen.blit(t, (close_r.centerx - t.get_width() // 2, close_r.centery - t.get_height() // 2))
        if on:                                       # 已在岗：按钮变灰不可点
            bg, fg, tkey = mix(C["panel"], C["hdr"], 0.35), C["dim"], "staff_card_on"
        else:
            bg = mix(C["add"], C["hdr"], 0.15) if take_r.collidepoint(mouse) else C["add"]
            fg, tkey = C["bg"], "staff_card_take"
        pygame.draw.rect(self.screen, bg, take_r, border_radius=S(8))
        t = utext(self.font, lang(tkey), fg)
        self.screen.blit(t, (take_r.centerx - t.get_width() // 2, take_r.centery - t.get_height() // 2))
        self.staff_card_rects = ([(close_r, "close")] + ([] if on else [(take_r, "take")])
                                 + ([(edit_r, "edit")] if edit_r is not None else []))

    def click_goal_queue(self, pos) -> bool:
        """右栏任务队列卡片上的 ↑ ↓ ✕ 和「＋ 新增」。按任务编号改，不按位置（不会改错条）。命中就返回 True。"""
        from lib_a import taskq
        for action, tid, r in getattr(self, "goal_q_rects", []):
            if not r.collidepoint(pos):
                continue
            try:
                if action == "add":                  # 预填到输入框，写完回车走 /queue add
                    self.input_text = "/queue add "
                    self.cursor = len(self.input_text)
                    self.add("info", "在输入框里写上新的任务，回车就加进队列。")
                elif action in ("up", "down"):
                    self.add_result(taskq.move(tid, action, by="user"))
                elif action == "drop":
                    self.add_result(taskq.drop(tid, "主人在界面上删掉的", by="user"))
                elif action == "resume":
                    self.add_result(taskq.resume(tid, by="user"))
                    self.kick_queue()                    # Agent 闲着就马上开工
            except Exception as e:
                self.add("error", f"改目标队列失败：{type(e).__name__}: {e}")
            self.mark_dirty()
            return True
        for tid, row in getattr(self, "_goal_rows", []):
            if row.collidepoint(pos):
                self._goal_expanded = None if getattr(self, "_goal_expanded", None) == tid else tid
                self._goal_scroll = 0
                self.mark_dirty()
                return True
        return False

    def add_result(self, res):
        """goals 返回的字符串直接分类显示：错误进 error，其它进 info。"""
        text = str(res or "").strip()
        self.add("error" if text.startswith("错误") else "info", text)

    def module_help_text(self) -> str:
        """外接模块注册的命令清单（/help 用）；一个模块命令都没有就返回空串。"""
        prefixes = modules_api.list_module_commands()
        if not prefixes:
            return ""
        lines = ["模块命令："]
        for pfx in prefixes:
            hit = modules_api.get_module_command(pfx)
            p = (modules_api.get(hit[0]) if hit else None) or {}
            lines.append(f"  /{pfx} —— {p.get('title') or (hit[0] if hit else '')}")
        return "\n".join(lines) + "\n"

    def queue_command(self, text: str):
        """斜杠命令 /queue：list | add <标题> | top / up / down / drop / done <编号或序号> |
        move <编号或序号> <位置> | edit <编号或序号> <新标题> | show <编号或序号>。编号是 t3 这种，序号是列表里的第几项。"""
        from lib_a import taskq
        usage = ("用法：/queue list | add <标题> | top / up / down / drop / done <t3 或 3> | "
                 "move <t3 或 3> <top / bottom / before:t5 / 第几位> | edit <t3 或 3> <新标题> | show <t3 或 3>")
        parts = str(text or "").split(None, 1)
        rest = parts[1].strip() if len(parts) > 1 else ""
        act, _, tail = rest.partition(" ")
        act, tail = act.strip().lower(), tail.strip()
        ref, _, body = tail.partition(" ")
        if ref.isdigit():
            ref = "#" + ref                          # 纯数字 = 列表里的第几项；t3 = 编号
        try:
            if act in ("", "list", "列表"):
                res = taskq.list_text()
            elif act in ("add", "加"):
                res = taskq.add(tail, by="user") if tail else usage
                if tail:
                    self.kick_queue()
            elif act in ("top", "置顶", "up", "上移", "down", "下移"):
                pos = {"置顶": "top", "上移": "up", "下移": "down"}.get(act, act)
                res = taskq.move(ref, pos, by="user")
            elif act == "move":
                res = taskq.move(ref, body or "bottom", by="user")
            elif act in ("drop", "del", "删除"):
                res = taskq.drop(ref, "主人用 /queue 删掉的", by="user")
            elif act in ("done", "完成"):
                res = taskq.done(ref, "主人标的完成", by="user")
            elif act in ("edit", "改"):
                res = taskq.edit(ref, title=body, by="user") if body else usage
            elif act == "show":
                res = taskq.show(ref)
            else:
                res = usage
            self.add_result(res)
        except Exception as e:
            self.add("error", f"改任务队列失败：{type(e).__name__}: {e}")

    def click_staff(self, pos) -> bool:
        """左栏员工面板里点了某一行：弹出该员工的信息卡（上岗在卡里点）。命中就返回 True。"""
        for r, action in getattr(self, "staff_menu_rects", []):     # 先判批评菜单
            if not r.collidepoint(pos):
                continue
            men = getattr(self, "staff_menu", None) or ("", "")
            label = men[1] if len(men) > 1 else ""
            try:
                if action == "criticize":
                    self.input_text = f"/criticize {label} "
                    self.cursor = len(self.input_text)
                    self.add("info", lang("criticize_prefill").format(who=label))
            except Exception as e:
                self.add("error", f"打开批评输入框失败：{type(e).__name__}: {e}")
            self.staff_menu, self.staff_menu_rects = None, []
            return True
        if getattr(self, "staff_menu", None) is not None:           # 点别处：收起菜单
            self.staff_menu, self.staff_menu_rects = None, []
        for r, name in getattr(self, "staff_rects", []):
            if not r.collidepoint(pos):
                continue
            if name == "__new__":                    # 「＋ 新角色」
                self.open_staff_editor(None)
                return True
            self.staff_card = canon(name)            # 点任何一行都只弹信息卡
            self.staff_card_rects = []
            self.mark_dirty()
            return True
        return False

    def click_staff_card(self, pos) -> bool:
        """员工信息卡上的点击：点「上岗」关卡并切换前台，点「关闭」或卡片外任意处就关卡。"""
        name = getattr(self, "staff_card", None)
        if not name:
            return False
        for r, action in getattr(self, "staff_card_rects", []):
            if r.collidepoint(pos) and action == "edit":
                self.staff_card, self.staff_card_rects = None, []
                self.open_staff_editor(name)
                self.mark_dirty()
                return True
            if not r.collidepoint(pos) or action != "take":
                continue
            self.staff_card, self.staff_card_rects = None, []
            self.mark_dirty()
            try:
                set_active(name)
                if self.settings.get("front_desk") and self.agent:   # 前台在岗：语气立刻切过去
                    self.agent.set_persona(active_persona())
                handover = getattr(self.agent, "handover_memory", None) if self.agent else None
                summary = handover() if callable(handover) else ""
                if summary:
                    self.add("memory", "已交接：上一个前台的对话压成了摘要，新前台接着往下聊")
                self.add("info", f"已切换到 {staff_label(name)} 上岗，正在重启…")
                self.restart_at = pygame.time.get_ticks() + 1500   # 让新前台语气落地
            except Exception as e:
                self.add("error", f"切换上岗失败：{type(e).__name__}: {e}")
            return True
        self.staff_card, self.staff_card_rects = None, []           # 点别处 = 点遮罩：关掉
        self.mark_dirty()
        return True

    # ---------------- 左栏小屏幕（实时网页截图） ----------------

    def update_screen_view(self, rect: pygame.Rect):
        """到点了就发一条截图请求，让后台线程去截，主循环不阻塞。"""
        self.screen_rect = pygame.Rect(rect)
        now = pygame.time.get_ticks()
        if now < getattr(self, 'screen_next', 0):
            return
        req = getattr(self, 'screen_req', None)
        if req is not None and now - getattr(req, 'at', now) < 20000:
            return                                         # 上一张还没回来：别叠着发（卡住超过 20 秒才放弃它）
        st = self._web_state()
        active = (now - st["last_input"] < 4000 or st["loading"] or st["focus"] == "page"
                  or st.get("down") is not None)
        self.screen_next = now + (200 if active else 1000)  # 正在用 / 在加载：一秒五张；闲着一秒一张
        req = ScreenShotRequest()
        req.at = now
        self.screen_req = req
        self.handle_screen_shot(req)                       # 马上在后台线程截，主循环不等

    def web_screenshot(self) -> bytes:
        """内置浏览器当前网页的截图。Agent 在独立进程时浏览器也在那边，得请它截（这边调 base.web 会另起一个空白 Edge）。"""
        if isinstance(self.agent, AgentProxy):
            return self.agent.web_screenshot(False)
        return webpage.screenshot(False)

    def _grab_shot(self):
        """后台线程：取 Playwright 当前网页的 jpeg 字节。失败就保留上一帧。"""
        try:
            data = self.web_screenshot()
        except Exception:
            return
        if data:
            self._load_shot(data)

    def _load_shot(self, data):
        """收下一帧：data 是 {"jpeg", "url", "title", "loading"}（新）或 jpeg 字节（旧）。存原图，画的时候再按地方缩放。"""
        if isinstance(data, dict):
            st = self._web_state()
            new_url = str(data.get("url") or "")
            if st["focus"] != "addr" and new_url and not new_url.startswith("chrome-error://") \
                    and not st.get("url_hold"):
                st["url"] = new_url                        # 打不开的页面：地址栏留着想去的那个网址，不显示 chrome-error
            st["title"] = str(data.get("title") or "")
            st["loading"] = bool(data.get("loading"))
            data = data.get("jpeg") or b""
        if not data:
            return
        try:
            img = pygame.image.load(io.BytesIO(data))
            img = img.convert()
        except Exception:
            return                                         # 解码失败也保留上一帧
        iw, ih = img.get_size()
        if iw <= 0 or ih <= 0:
            return
        self._shot_wh = (iw, ih)                           # 截图原图尺寸：坐标换算用
        self.screen_shot = img
        self.screen_last = img

    def _screen_to_page(self, pos):
        """窗口坐标换算成网页坐标；不在上一帧画面上就返回 None。"""
        rect = getattr(self, 'screen_img_rect', None)
        shot = getattr(self, 'screen_shot', None)
        if rect is None or shot is None or rect.w <= 0 or rect.h <= 0:
            return None
        if not rect.collidepoint(pos):
            return None
        kx = (pos[0] - rect.x) / max(1, rect.w)
        ky = (pos[1] - rect.y) / max(1, rect.h)
        wh = getattr(self, '_shot_wh', None)
        if not wh:
            try:
                wh = shot.get_size()
            except Exception:
                return None
        if not wh or wh[0] <= 0 or wh[1] <= 0:
            return None
        vw, vh = _web_viewport()
        x = max(0, min(vw - 1, int(kx * vw)))
        y = max(0, min(vh - 1, int(ky * vh)))
        return (x, y)

    def _screen_pending(self) -> int:
        """小屏幕上还有多少条待执行（排队模式已废弃，恒为 0）。"""
        return len(getattr(self, 'screen_pending', None) or [])

    def _screen_set_result(self, text, ok=True):
        """把一行结果记到小屏幕底部提示条上（界面自己的操作走这里，不刷屏对话）。"""
        self.screen_status = (str(text or ''), bool(ok), pygame.time.get_ticks())
        self.screen_result = self.screen_status
        self.mark_dirty()

    def set_screen_result(self, text, ok=True):
        """A库 执行完小屏幕动作后回写结果：存下来让 _draw_screen_hint 显示几秒。"""
        try:
            self.screen_result = (str(text or ''), bool(ok), pygame.time.get_ticks())
            self.screen_status = self.screen_result
        except Exception:
            pass
        try:
            self.mark_dirty()
        except Exception:
            pass

    def _screen_point(self, pos):
        """在画面上标一个点（存网页坐标）；换算不了就返回提示文字。"""
        xy = self._screen_to_page(pos)
        if not xy:
            self._screen_set_result('小屏幕里还没有网页画面，先让 A库 打开网页再点', False)
            return '错误: 小屏幕里还没有网页画面，先让 A库 用 web_open / web_search 打开网页再点。'
        self.screen_mark = xy
        self._screen_set_result(f'已标点（网页 {xy[0]},{xy[1]}）：左键＝确认点击，右键＝右击', True)
        self.mark_dirty()
        return None

    def _screen_to_win(self, xy, img_rect=None):
        """网页坐标换算回窗口（截图）坐标；换算不了返回 None。"""
        rect = img_rect or getattr(self, 'screen_img_rect', None)
        if rect is None or rect.w <= 0 or rect.h <= 0 or not xy:
            return None
        vw, vh = getattr(self, '_screen_vp', None) or _web_viewport()
        if vw <= 0 or vh <= 0:
            return None
        return (rect.x + int(xy[0] / vw * rect.w), rect.y + int(xy[1] / vh * rect.h))

    def _screen_commit(self, button: str, pos=None):
        """标好的点立刻点下去（界面自己打进内置浏览器，不等 A库）。"""
        if getattr(self, 'screen_mark', None) is None:
            return
        px, py = self.screen_mark
        self.screen_mark = None
        if pos is not None:                  # 防误触：只有点进红圈里才算数，圈外一律当误触
            cur = self._screen_to_page(pos)
            a = self._screen_to_win((px, py))
            b = self._screen_to_win(cur) if cur else None
            limit = S(SCREEN_MARK_R + SCREEN_HIT_SLOP)
            if a and b:
                dist = ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5
                ok = dist <= limit
            else:                            # 换算不出来就别乱点
                dist, ok = 0.0, False
            if not ok:
                self.mark_dirty()
                self._screen_set_result(f'没点进红圈内（偏差 {int(round(dist))}px > 圈半径 {limit}px），本次点击已取消，请重新右键标点。', False)
                self.add('info', f'没点进红圈内（偏差 {int(round(dist))}px > 圈半径 {limit}px），本次点击已取消，请重新右键标点。')
                return
        self._screen_run({'kind': 'click', 'x': int(px), 'y': int(py), 'button': button})

    def _screen_run(self, action):
        """小屏幕上的手动操作：立刻打进内置浏览器，不等 A库。"""
        import threading
        from base import web as _web
        kind = str(action.get('kind') or '')
        x, y = int(action.get('x') or 0), int(action.get('y') or 0)
        amount = int(action.get('amount') or 0)
        right = str(action.get('button')) == 'right'
        label = (f"{'右' if right else '左'}键点击({x},{y})" if kind == 'click'
                 else f"滚轮 {amount} 格({x},{y})")

        def _job():
            try:
                if isinstance(self.agent, AgentProxy):    # 浏览器在 Agent 进程里：请它点
                    self.agent.web_mouse(kind, x, y, amount, right)
                    self._screen_set_result(f'已执行：{label}', True)
                    self._screen_refresh()
                    return
                b = _web.browser()
                if kind == 'click':
                    # page.mouse.click() 没有 timeout 参数，传了会抛 TypeError；超时由 b.call 兜
                    b.call(lambda bb: bb.page.mouse.click(x, y, button='right' if right else 'left'),
                           timeout=20)
                else:
                    def _roll(bb):
                        bb.page.mouse.move(x, y)
                        bb.page.mouse.wheel(0, amount * 100)
                    b.call(_roll, timeout=20)
                self._screen_set_result(f'已执行：{label}', True)
            except Exception as e:
                msg = f'执行失败：{type(e).__name__}: {e}'
                self._screen_set_result(msg[:120], False)
            try:
                self._screen_refresh()               # 执行完让小屏幕尽快重截一张
            except Exception:
                pass

        threading.Thread(target=_job, daemon=True).start()

    def _screen_refresh(self):
        """让小屏幕下一帧就去重截一张（不在这里等浏览器）。"""
        try:
            self.screen_next = 0
            self.mark_dirty()
        except Exception:
            pass

    def take_screen_actions(self) -> list:
        """排队模式已废弃：小屏幕操作现在点一下立刻执行，这里恒返回空列表。"""
        return []

    # ---------------- 小浏览器：工具栏（后退 / 前进 / 刷新 / 地址栏 / 系统浏览器打开）+ 直接操作网页 ----------------
    # 小屏幕两处画：栏里（slot="dock"，主窗口坐标）和拖出去的独立窗口（slot="win"，窗口自己的坐标），
    # 每处各记一份命中矩形。手动操作排进一个队列按顺序发给浏览器（在 Agent 进程里就走 RPC），连打的字合成一次发。

    _WEB_KEYS = {"K_RETURN": "Enter", "K_KP_ENTER": "Enter", "K_BACKSPACE": "Backspace", "K_DELETE": "Delete",
                 "K_TAB": "Tab", "K_LEFT": "ArrowLeft", "K_RIGHT": "ArrowRight", "K_UP": "ArrowUp",
                 "K_DOWN": "ArrowDown", "K_HOME": "Home", "K_END": "End", "K_PAGEUP": "PageUp",
                 "K_PAGEDOWN": "PageDown", "K_INSERT": "Insert"}
    _WEB_OP_LABEL = {"goto": "打开", "back": "后退", "forward": "前进", "reload": "刷新", "stop": "停止",
                     "down": "点击", "up": "点击", "move": "移动", "wheel": "滚动", "text": "输入", "key": "按键",
                     "copy": "复制"}

    def _web_state(self) -> dict:
        st = getattr(self, "web", None)
        if not isinstance(st, dict):
            st = self.web = {"url": "", "title": "", "loading": False, "focus": None, "focus_slot": None,
                             "addr": "", "cur": 0, "anchor": 0, "slots": {}, "down": None,
                             "last_input": -100000, "last_move": 0, "click_fx": None, "last_click": None,
                             "scaled": None}
        return st

    def _web_kbd(self, slot=None) -> bool:
        """小浏览器（地址栏或网页）现在拿着键盘。"""
        st = getattr(self, "web", None)
        return bool(isinstance(st, dict) and st.get("focus") and (slot is None or st.get("focus_slot") == slot))

    def _web_blur(self):
        st = self._web_state()
        if st["focus"]:
            st["focus"] = st["focus_slot"] = None
            self.composing = ""
            self.mark_dirty()

    def _web_send(self, op, **args):
        """排一个浏览器操作（后台线程按顺序发；界面不等）。"""
        st = self._web_state()
        st["last_input"] = pygame.time.get_ticks()
        if op not in ("move", "wheel", "copy"):
            st.pop("url_hold", None)                       # 有新动作了：地址栏重新跟着网页走
        if op in ("goto", "back", "forward", "reload"):
            st["loading"] = True
        if op == "goto" and args.get("text"):
            st["url"] = str(args["text"]).strip()          # 先显示要去的地方；打不开时地址栏也留着它
        q = getattr(self, "_web_q", None)
        if q is None:
            q = self._web_q = queue.Queue()
            threading.Thread(target=self._web_worker, args=(q,), daemon=True, name="web-ui").start()
        q.put((op, args))
        self._screen_refresh()

    def _web_call(self, op, args):
        if isinstance(self.agent, AgentProxy):        # 浏览器在 Agent 进程里
            return self.agent.web_ui(op, args)
        from base import web as _web
        return _web.ui(op, **args)

    def _web_worker(self, q):
        later = []
        while True:
            op, args = later.pop(0) if later else q.get()
            while op in ("text", "move", "wheel"):    # 连着的同类操作合成一次：打字连起来、移动只要最后一下、滚动累加
                try:
                    nop, nargs = q.get_nowait()
                except queue.Empty:
                    break
                if nop != op:
                    later.append((nop, nargs))
                    break
                if op == "text":
                    args = {"text": args["text"] + nargs["text"]}
                elif op == "wheel":
                    args = {**nargs, "dx": args.get("dx", 0) + nargs.get("dx", 0),
                            "dy": args.get("dy", 0) + nargs.get("dy", 0)}
                else:
                    args = nargs
            try:
                res = self._web_call(op, args)
                if op == "copy":
                    text = str(res or "")
                    if text:
                        set_clipboard(text)
                        self._screen_set_result(f"已复制 {len(text)} 个字", True)
                    else:
                        self._screen_set_result("网页里没有选中的文字", False)
            except Exception as e:
                if op == "goto" and args.get("text"):      # 没打开：Playwright 还报旧网址，地址栏留着想去的那个
                    st = self._web_state()
                    st["url"] = st["url_hold"] = str(args["text"]).strip()
                if op != "move":                           # 鼠标移动失败不值得提示
                    why = (str(e).strip().splitlines() or [type(e).__name__])[0]    # Playwright 后面那段 Call log 不要
                    for junk in ("RuntimeError: ", "WebError: ", "Error: ", "Page.goto: ", "Page.go_back: ",
                                 "Page.go_forward: ", "Page.reload: "):
                        why = why.replace(junk, "")
                    self._screen_set_result(f"{self._WEB_OP_LABEL.get(op, op)}失败：{why}"[:120], False)
            self._screen_refresh()

    def _web_frame(self):
        """取一帧（后台线程里调）：新接口拿不到就退回只要截图的旧接口。"""
        try:
            if isinstance(self.agent, AgentProxy):
                data = self.agent.web_frame()
            else:
                from base import web as _web
                data = _web.frame()
            if isinstance(data, dict) and data.get("jpeg"):
                return data
        except Exception:
            pass
        return self.web_screenshot()

    def _web_xy(self, img: pygame.Rect, pos, clamp=False):
        """画面上的点 → 网页视口坐标。"""
        vw, vh = _web_viewport()
        kx = (pos[0] - img.x) / max(1, img.w)
        ky = (pos[1] - img.y) / max(1, img.h)
        if clamp:
            kx, ky = max(0.0, min(1.0, kx)), max(0.0, min(1.0, ky))
        return int(max(0, min(vw - 1, kx * vw))), int(max(0, min(vh - 1, ky * vh)))

    def _web_button(self, name):
        st = self._web_state()
        if name == "external":
            url = st.get("url") or ""
            if url.startswith(("http://", "https://")):
                import webbrowser
                webbrowser.open(url)                      # 主人自己点的：用系统浏览器打开当前页
                self._screen_set_result("已在系统浏览器里打开", True)
            else:
                self._screen_set_result("现在没有可以打开的网页", False)
            return
        self._web_send(name)

    def _web_focus_addr(self, slot, select_all=True):
        st = self._web_state()
        if st["focus"] != "addr":
            st["addr"] = st.get("url") or ""
            if st["addr"] == "about:blank":
                st["addr"] = ""
        st["focus"], st["focus_slot"] = "addr", slot
        if select_all:
            st["anchor"], st["cur"] = 0, len(st["addr"])
        modules_api.set_focus(None)
        self.mark_dirty()

    # ---- 画 ----
    def _web_icon(self, surf, name, r: pygame.Rect, col):
        cx, cy, k = r.centerx, r.centery, max(1, S(1))
        w = max(1, S(2))
        if name in ("back", "forward"):
            d = -1 if name == "back" else 1
            pygame.draw.line(surf, col, (cx - d * S(6), cy), (cx + d * S(6), cy), w)
            pygame.draw.lines(surf, col, False, [(cx + d * S(1), cy - S(5)), (cx + d * S(6), cy),
                                                 (cx + d * S(1), cy + S(5))], w)
        elif name == "reload":
            rr = pygame.Rect(0, 0, S(13), S(13))
            rr.center = (cx, cy)
            pygame.draw.arc(surf, col, rr, math.radians(-40), math.radians(250), w)
            tip = (rr.right - S(1), cy - S(2))
            pygame.draw.polygon(surf, col, [(tip[0] - S(4), tip[1] - S(1)), (tip[0] + S(3), tip[1] - S(1)),
                                            (tip[0], tip[1] + S(4))])
        elif name == "stop":
            pygame.draw.line(surf, col, (cx - S(5), cy - S(5)), (cx + S(5), cy + S(5)), w)
            pygame.draw.line(surf, col, (cx - S(5), cy + S(5)), (cx + S(5), cy - S(5)), w)
        elif name == "external":
            pygame.draw.lines(surf, col, False, [(cx - S(1), cy - S(6)), (cx - S(6), cy - S(6)),
                                                 (cx - S(6), cy + S(6)), (cx + S(6), cy + S(6)),
                                                 (cx + S(6), cy + S(1))], max(1, k))
            pygame.draw.line(surf, col, (cx - S(1), cy + S(1)), (cx + S(6), cy - S(6)), w)
            pygame.draw.lines(surf, col, False, [(cx + S(1), cy - S(6)), (cx + S(6), cy - S(6)),
                                                 (cx + S(6), cy - S(1))], w)

    def _draw_web(self, surf, area: pygame.Rect, slot: str, mouse=None):
        """小浏览器：工具栏 + 加载条 + 网页画面 + 提示。命中矩形记进 web["slots"][slot]。"""
        st = self._web_state()
        area = pygame.Rect(area)
        lay = {"area": area}
        st["slots"][slot] = lay
        if area.w < S(60) or area.h < S(60):
            return None
        if mouse is None:
            mouse = pygame.mouse.get_pos()
        now = pygame.time.get_ticks()
        old_clip = surf.get_clip()
        surf.set_clip(area.clip(old_clip) if old_clip else area)
        try:
            bar = pygame.Rect(area.x, area.y, area.w, S(34))
            pygame.draw.rect(surf, C["top"], bar)
            pygame.draw.line(surf, C["border"], (bar.x, bar.bottom - 1), (bar.right, bar.bottom - 1))
            bh = S(26)
            by = bar.y + (bar.h - bh) // 2
            x = bar.x + S(6)
            for name in ("back", "forward", "stop" if st["loading"] else "reload"):
                r = pygame.Rect(x, by, bh, bh)
                if r.collidepoint(mouse):
                    pygame.draw.rect(surf, mix(C["top"], C["hdr"], 0.18), r, border_radius=S(6))
                self._web_icon(surf, name, r, C["text"])
                lay[name] = r
                x += bh + S(2)
            ext = pygame.Rect(bar.right - S(6) - bh, by, bh, bh)
            if ext.collidepoint(mouse):
                pygame.draw.rect(surf, mix(C["top"], C["hdr"], 0.18), ext, border_radius=S(6))
            self._web_icon(surf, "external", ext, C["dim"] if not st["url"].startswith("http") else C["text"])
            lay["external"] = ext
            addr = pygame.Rect(x + S(4), by, max(S(40), ext.x - S(6) - (x + S(4))), bh)
            lay["addr"] = addr
            self._draw_web_addr(surf, addr, slot, now)
            if st["loading"]:                          # 加载中：工具栏底下一条来回跑的细条
                seg = max(S(30), bar.w // 4)
                t = (now % 1400) / 1400.0
                sx = bar.x - seg + int((bar.w + seg) * t)
                pygame.draw.rect(surf, C["hdr"], pygame.Rect(sx, bar.bottom - S(2), seg, S(2)).clip(bar))

            page = pygame.Rect(area.x, bar.bottom, area.w, max(0, area.bottom - bar.bottom))
            lay["page"] = page
            shot = getattr(self, "screen_shot", None)
            img_rect = None
            if shot is not None and page.w > 4 and page.h > 4:
                sw, sh = shot.get_size()
                k = min(page.w / max(1, sw), page.h / max(1, sh))
                dw, dh = max(1, int(sw * k)), max(1, int(sh * k))
                cache = st.get("scaled")
                if cache and cache[0] is shot and cache[1] == (dw, dh):
                    img = cache[2]
                else:
                    img = pygame.transform.smoothscale(shot, (dw, dh)) if (dw, dh) != (sw, sh) else shot
                    st["scaled"] = (shot, (dw, dh), img)
                img_rect = pygame.Rect(page.x + (page.w - dw) // 2, page.y, dw, dh)
                surf.blit(img, img_rect)
                if st["focus"] == "page" and st["focus_slot"] == slot:
                    pygame.draw.rect(surf, C["input_focus"], img_rect, max(1, S(1)))
                fx = st.get("click_fx")
                if fx and fx[2] == slot and now - fx[1] < 350:     # 点下去的位置：一圈扩散的波纹
                    p = (now - fx[1]) / 350.0
                    ring = pygame.Surface((S(40), S(40)), pygame.SRCALPHA)
                    pygame.draw.circle(ring, (*C["hdr"][:3], int(180 * (1 - p))), (S(20), S(20)),
                                       max(2, int(S(6) + S(12) * p)), max(1, S(2)))
                    surf.blit(ring, (fx[0][0] - S(20), fx[0][1] - S(20)))
            elif page.h > 4:
                msg = lang("screen_wait") if not st["url"] else "正在取画面…"
                surf.blit(utext(self.small, msg, C["dim"]), (page.x + PAD, page.y + S(8)))
                hint = "在上面的地址栏输入网址或搜索词，回车打开"
                surf.blit(utext(self.small, hint, C["dim"]), (page.x + PAD, page.y + S(8) + self.small.get_linesize()))
            lay["img"] = img_rect
            self._draw_web_hint(surf, page, slot)
        finally:
            surf.set_clip(old_clip)
        return img_rect

    def _draw_web_addr(self, surf, r: pygame.Rect, slot, now):
        st = self._web_state()
        editing = st["focus"] == "addr" and st["focus_slot"] == slot
        pygame.draw.rect(surf, C["input_bg"], r, border_radius=S(13))
        pygame.draw.rect(surf, C["input_focus"] if editing else C["border"], r, 1, border_radius=S(13))
        inner = pygame.Rect(r.x + S(12), r.y, max(1, r.w - S(24)), r.h)
        ty = r.y + (r.h - self.small.get_linesize()) // 2
        old = surf.get_clip()
        surf.set_clip(inner.clip(old) if old else inner)
        try:
            if editing:
                text, cur = st["addr"], max(0, min(len(st["addr"]), st["cur"]))
                comp = getattr(self, "composing", "") or ""
                shown = text[:cur] + comp + text[cur:]
                cur_px = self.small.size(text[:cur] + comp)[0]
                scroll = max(0, cur_px - inner.w + S(4))
                ox = inner.x - scroll
                a, b = sorted((max(0, min(len(text), st["anchor"])), cur))
                if a != b and not comp:
                    x1, x2 = self.small.size(text[:a])[0], self.small.size(text[:b])[0]
                    shade = mix(C["input_bg"], C["input_focus"], 0.3)
                    pygame.draw.rect(surf, shade, (ox + x1, ty, max(1, x2 - x1), self.small.get_linesize()))
                if shown:
                    surf.blit(utext(self.small, shown, C["text"]), (ox, ty))
                elif not comp:
                    surf.blit(utext(self.small, "输入网址或搜索词", C["dim"]), (inner.x, ty))
                cx = ox + cur_px
                if comp:
                    cw = self.small.size(comp)[0]
                    pygame.draw.line(surf, C["input_focus"], (cx - cw, ty + self.small.get_linesize() - 1),
                                     (cx, ty + self.small.get_linesize() - 1), max(1, S(1)))
                if now // 530 % 2 == 0:
                    pygame.draw.line(surf, C["text"], (cx, ty + S(1)), (cx, ty + self.small.get_linesize() - S(1)),
                                     max(1, S(1)))
                ime = (cx - (self.small.size(comp)[0] if comp else 0), ty, S(10), self.small.get_linesize())
                if ime != st.get("ime"):
                    st["ime"] = ime
                    try:
                        pygame.key.set_text_input_rect(pygame.Rect(*ime))
                    except Exception:
                        pass
            else:
                url = st.get("url") or ""
                if url and url != "about:blank":
                    shown = url.split("://", 1)[-1] if url.startswith("https://") else url
                    title = st.get("title") or ""
                    t = utext(self.small, ellipsize(self.small, shown, inner.w), C["text"])
                    surf.blit(t, (inner.x, ty))
                    if title and t.get_width() + S(20) < inner.w:          # 地址后面空着就淡淡写上标题
                        tt = utext(self.small, ellipsize(self.small, "— " + title, inner.w - t.get_width() - S(10)),
                                   C["dim"])
                        surf.blit(tt, (inner.x + t.get_width() + S(8), ty))
                else:
                    surf.blit(utext(self.small, "输入网址或搜索词", C["dim"]), (inner.x, ty))
        finally:
            surf.set_clip(old)

    def _draw_web_hint(self, surf, page: pygame.Rect, slot):
        st = self._web_state()
        msg, col = None, C["text"]
        res = getattr(self, "screen_result", None)
        if res and pygame.time.get_ticks() - res[2] < 6000:
            msg, col = res[0], (C["add"] if res[1] else C["warn"])
        elif st["focus"] == "page" and st["focus_slot"] == slot:
            comp = getattr(self, "composing", "") or ""
            msg = f"正在拼写：{comp}" if comp else "键盘正在给网页打字 · Esc 退出 · Ctrl+L 地址栏 · F5 刷新"
        if not msg:
            return
        t = utext(self.small, ellipsize(self.small, msg, max(S(20), page.w - S(24))), col)
        box = pygame.Rect(page.x + S(6), page.bottom - t.get_height() - S(12), t.get_width() + S(12),
                          t.get_height() + S(6))
        back = pygame.Surface(box.size, pygame.SRCALPHA)
        pygame.draw.rect(back, (20, 20, 20, 170), back.get_rect(), border_radius=S(6))
        surf.blit(back, box.topleft)
        if col == C["text"]:
            t = utext(self.small, ellipsize(self.small, msg, max(S(20), page.w - S(24))), (240, 240, 240))
        surf.blit(t, (box.x + S(6), box.y + S(3)))

    # ---- 鼠标 / 键盘 ----
    def _web_event(self, e, slot, mouse=None) -> bool:
        """小浏览器的事件。处理掉返回 True。mouse：这个 slot 坐标系里的鼠标位置（滚轮事件没带 pos 时用）。"""
        st = self._web_state()
        t = e.type
        if t in (pygame.TEXTINPUT, pygame.TEXTEDITING, pygame.KEYDOWN, pygame.KEYUP):
            if self._web_kbd(slot):
                return self._web_key(e)
            return False
        lay = st["slots"].get(slot)
        if not lay:
            return False
        area = lay.get("area")
        img = lay.get("img")
        now = pygame.time.get_ticks()
        if t == pygame.MOUSEBUTTONDOWN:
            pos = e.pos
            if not area or not area.collidepoint(pos):
                if st["focus_slot"] == slot:
                    self._web_blur()                         # 点到小浏览器外面：键盘还给别处
                return False
            if e.button in (4, 5):
                return True
            if e.button == 1:
                for name in ("back", "forward", "reload", "stop", "external"):
                    r = lay.get(name)
                    if r is not None and r.collidepoint(pos):
                        self._web_button(name)
                        return True
                if lay.get("addr") is not None and lay["addr"].collidepoint(pos):
                    if st["focus"] == "addr" and st["focus_slot"] == slot:     # 已经在编辑：把光标放到点的位置
                        inner_x = lay["addr"].x + S(12)
                        cur_px = self.small.size(st["addr"][:st["cur"]])[0]
                        rel = pos[0] - inner_x + max(0, cur_px - (lay["addr"].w - S(24)) + S(4))
                        best = min(range(len(st["addr"]) + 1),
                                   key=lambda i: abs(self.small.size(st["addr"][:i])[0] - rel))
                        st["cur"] = best
                        if not (pygame.key.get_mods() & pygame.KMOD_SHIFT):
                            st["anchor"] = best
                    else:
                        self._web_focus_addr(slot)
                    self.mark_dirty()
                    return True
            if img is not None and img.collidepoint(pos):
                button = {1: "left", 2: "middle", 3: "right"}.get(e.button, "left")
                x, y = self._web_xy(img, pos)
                last = st.get("last_click")
                count = 1
                if last and last[0] == button and now - last[1] < 450 and abs(last[2][0] - pos[0]) < S(6) \
                        and abs(last[2][1] - pos[1]) < S(6):
                    count = min(3, last[3] + 1)                     # 双击 / 三击
                st["last_click"] = (button, now, pos, count)
                st["down"] = (button, count, slot)
                st["focus"], st["focus_slot"] = "page", slot        # 点进网页：之后打字就打进网页
                modules_api.set_focus(None)
                st["click_fx"] = (pos, now, slot)
                self._web_send("down", x=x, y=y, button=button, count=count)
                self.mark_dirty()
                return True
            if st["focus_slot"] == slot:
                self._web_blur()
            return True                                             # 工具栏空白处：吃掉
        if t == pygame.MOUSEBUTTONUP:
            d = st.get("down")
            if d and d[2] == slot:
                st["down"] = None
                if img is not None:
                    x, y = self._web_xy(img, e.pos, clamp=True)
                    self._web_send("up", x=x, y=y, button=d[0], count=d[1])
                return True
            return False
        if t == pygame.MOUSEMOTION:
            dragging = bool(st.get("down") and st["down"][2] == slot)
            if img is not None and (dragging or img.collidepoint(e.pos)):
                gap = 30 if dragging else 120                       # 拖着选字 / 拖滑块要跟手；悬停只为了菜单弹出
                if now - st["last_move"] >= gap:
                    st["last_move"] = now
                    x, y = self._web_xy(img, e.pos, clamp=True)
                    self._web_send("move", x=x, y=y)
            if lay.get("addr") is not None:
                over = lay["addr"].collidepoint(e.pos)
                if over != st.get("ibeam"):
                    st["ibeam"] = over
                    try:
                        pygame.mouse.set_system_cursor(pygame.SYSTEM_CURSOR_IBEAM if over
                                                       else pygame.SYSTEM_CURSOR_ARROW)
                    except pygame.error:
                        pass
            return dragging
        if t == pygame.MOUSEWHEEL:
            pos = mouse if mouse is not None else pygame.mouse.get_pos()
            if img is not None and pos and img.collidepoint(pos):
                x, y = self._web_xy(img, pos)
                dy = -float(getattr(e, "precise_y", e.y)) * 120
                dx = float(getattr(e, "precise_x", e.x)) * 120
                if pygame.key.get_mods() & pygame.KMOD_SHIFT:        # Shift + 滚轮：横着滚
                    dx, dy = dy, 0.0
                self._web_send("wheel", x=x, y=y, dx=dx, dy=dy)
                return True
            return bool(area and pos and area.collidepoint(pos))
        return False

    def _web_key(self, e) -> bool:
        st = self._web_state()
        t = e.type
        if t == pygame.TEXTEDITING:
            self.composing = e.text
            self.mark_dirty()
            return True
        if t == pygame.KEYUP:
            return True
        mods = pygame.key.get_mods()
        ctrl, shift, alt = bool(mods & pygame.KMOD_CTRL), bool(mods & pygame.KMOD_SHIFT), bool(mods & pygame.KMOD_ALT)
        if st["focus"] == "addr":
            return self._web_addr_key(e, ctrl, shift)
        # ---- 键盘打进网页 ----
        if t == pygame.TEXTINPUT:
            self.composing = ""
            if e.text:
                self._web_send("text", text=e.text)
            return True
        if self.composing:                               # 输入法在拼：按键归输入法
            return True
        k = e.key
        if k == pygame.K_ESCAPE:
            self._web_blur()
            return True
        if k == pygame.K_F5:
            self._web_send("reload")
            return True
        if ctrl and k == pygame.K_l:
            self._web_focus_addr(st["focus_slot"])
            return True
        if ctrl and k == pygame.K_v:                     # 粘贴：网页那边拿不到系统剪贴板，这边读了当字打进去
            text = get_clipboard()
            if text:
                self._web_send("text", text=text)
            return True
        if ctrl and k in (pygame.K_c, pygame.K_x):
            self._web_send("copy")
            if k == pygame.K_x:
                self._web_send("key", key="Delete")
            return True
        if alt and k == pygame.K_LEFT:
            self._web_send("back")
            return True
        if alt and k == pygame.K_RIGHT:
            self._web_send("forward")
            return True
        name = next((v for n, v in self._WEB_KEYS.items() if getattr(pygame, n, None) == k), None)
        if name is None and (ctrl or alt) and 32 < k < 127:
            name = chr(k)                                # Ctrl+A / Ctrl+Z 这类组合键
        if name:
            prefix = ("Control+" if ctrl else "") + ("Alt+" if alt else "") + ("Shift+" if shift else "")
            self._web_send("key", key=prefix + name)
        return True

    def _web_addr_key(self, e, ctrl, shift) -> bool:
        st = self._web_state()
        text = st["addr"]
        cur = max(0, min(len(text), st["cur"]))
        a, b = sorted((max(0, min(len(text), st["anchor"])), cur))

        def put(new, at):
            st["addr"], st["cur"], st["anchor"] = new, at, at
        if e.type == pygame.TEXTINPUT:
            self.composing = ""
            s = e.text.replace("\r", "").replace("\n", " ")
            put(text[:a] + s + text[b:], a + len(s))
            self.mark_dirty()
            return True
        if self.composing:
            return True
        k = e.key
        if k == pygame.K_ESCAPE:
            self._web_blur()
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            q = text.strip()
            self._web_blur()
            if q:
                st["url"] = q                            # 先显示要去的地方，真网址等下一帧拿回来
                self._web_send("goto", text=q)
        elif ctrl and k == pygame.K_a:
            st["anchor"], st["cur"] = 0, len(text)
        elif ctrl and k in (pygame.K_c, pygame.K_x):
            if a != b:
                set_clipboard(text[a:b])
                if k == pygame.K_x:
                    put(text[:a] + text[b:], a)
        elif ctrl and k == pygame.K_v:
            s = get_clipboard().replace("\r", "").replace("\n", " ").strip()
            put(text[:a] + s + text[b:], a + len(s))
        elif k == pygame.K_BACKSPACE:
            if a != b:
                put(text[:a] + text[b:], a)
            elif cur:
                put(text[:cur - 1] + text[cur:], cur - 1)
        elif k == pygame.K_DELETE:
            if a != b:
                put(text[:a] + text[b:], a)
            elif cur < len(text):
                put(text[:cur] + text[cur + 1:], cur)
        elif k in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_HOME, pygame.K_END):
            if not shift and a != b and k in (pygame.K_LEFT, pygame.K_RIGHT):
                to = a if k == pygame.K_LEFT else b
            else:
                to = {pygame.K_LEFT: cur - 1, pygame.K_RIGHT: cur + 1, pygame.K_HOME: 0,
                      pygame.K_END: len(text)}[k]
                to = max(0, min(len(text), to))
            st["cur"] = to
            if not shift:
                st["anchor"] = to
        self.mark_dirty()
        return True

    def _draw_screen_mark(self, img_rect: pygame.Rect):
        """把标好的网页坐标画回画面：红圈 + 中心十字。"""
        mark = getattr(self, 'screen_mark', None)
        if mark is None or img_rect.w <= 0 or img_rect.h <= 0:
            return
        vw, vh = getattr(self, '_screen_vp', None) or _web_viewport()
        x = img_rect.x + int(mark[0] / max(1, vw) * img_rect.w)
        y = img_rect.y + int(mark[1] / max(1, vh) * img_rect.h)
        col = (220, 60, 60)
        pygame.draw.circle(self.screen, col, (x, y), S(SCREEN_MARK_R), S(2))
        pygame.draw.line(self.screen, col, (x - S(SCREEN_MARK_R + 4), y), (x + S(SCREEN_MARK_R + 4), y), S(1))
        pygame.draw.line(self.screen, col, (x, y - S(SCREEN_MARK_R + 4)), (x, y + S(SCREEN_MARK_R + 4)), S(1))

    def _draw_screen_hint(self, area: pygame.Rect):
        """小屏幕左下角的操作提示（有没有画面都画）。"""
        mark = getattr(self, 'screen_mark', None)
        res = getattr(self, 'screen_result', None)
        col = C['text']
        msg = None
        if res:
            text, ok, at = res
            if pygame.time.get_ticks() - at < 8000:        # 8 秒内显示最近一次操作的结果
                msg = text
                col = C['add'] if ok else C['warn']
            else:
                self.screen_result = None
        if msg is None:
            if mark is None:
                msg = '右键标点 · 左键确认 · 再次右键＝右击 · 滚轮=滚动网页'
            else:
                msg = f'已标点（网页 {mark[0]},{mark[1]}）：左键＝确认点击，右键＝右击 · 只有点进红圈内才算'
        avail = max(S(20), area.w - S(8))
        msg = ellipsize(self.small, msg, avail)
        t = utext(self.small, msg, col)
        tw, th = t.get_size()
        box = pygame.Rect(area.x + S(4), area.bottom - th - S(10), min(avail, tw + S(10)), th + S(6))
        if box.w <= 0 or box.h <= 0:
            return
        old = self.screen.get_clip()
        back = pygame.Surface(box.size, pygame.SRCALPHA)
        back.fill((0, 0, 0, 150))
        self.screen.blit(back, box.topleft)
        self.screen.blit(t, (box.x + S(5), box.y + S(3)))
        self.screen.set_clip(old)

    # ---------------- 独立小屏幕窗口（第二个窗口） ----------------

    def screen_mode(self) -> str:
        """小屏幕现在就是一个模块（放在栏里，要独立窗口就拖出去）：旧的「自动开独立窗口」设置删了，固定 off。"""
        return "off"

    def screen_window_on(self) -> bool:
        """设置里小屏幕是不是独立窗口（off = 仍嵌在左栏）。"""
        return self.screen_mode() != "off"

    def _screen_aspect(self):
        """网页视口的宽高（窗口比例按它对齐，缩放不变形）。"""
        try:
            vw, vh = _web_viewport()
            vw, vh = int(vw), int(vh)
        except Exception:
            return (1280, 900)
        if vw <= 0 or vh <= 0:
            return (1280, 900)
        return (vw, vh)

    def _screen_web_size(self):
        """按网页视口算独立窗口尺寸：放得下就用视口本身，放不下就等比缩进桌面。"""
        try:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            desk_w, desk_h = int(desk_w), int(desk_h)
        except Exception:
            desk_w, desk_h = 1920, 1080
        if desk_w <= 0 or desk_h <= 0:
            desk_w, desk_h = 1920, 1080
        vw, vh = _web_viewport()
        vw, vh = max(1, int(vw)), max(1, int(vh))
        k = min(1.0, desk_h * 0.92 / vh, desk_w * 0.90 / vw)
        return (max(160, int(round(vw * k))), max(120, int(round(vh * k))))

    def _screen_fit(self):
        """按网页视口尺寸对齐独立窗口（只在比例偏差 > 2% 时动，用户自己拉的尺寸不碰）。"""
        try:
            win = getattr(self, 'screen_win', None)
            if win is None:
                return
            w, h = win.size
            if int(w) <= 0 or int(h) < 120:
                return
            tw, th = self._screen_web_size()
            dev = abs((w / max(1, h)) - (tw / max(1, th))) / max(0.001, tw / max(1, th))
            if dev <= 0.02:
                return                     # 比例本来就对，用户拖的尺寸不碰
            win.size = (tw, th)
            try:                           # 位置跟着尺寸差往回收一半，窗口不至于跳走
                px, py = win.position
                win.position = (int(px) + (int(w) - tw) // 2, int(py) + (int(h) - th) // 2)
            except Exception:
                pass
        except Exception:
            pass

    def screen_win_id(self):
        """独立小屏幕窗口的窗口 id（没有就返回 None）。"""
        try:
            return self.screen_win.id if self.screen_win is not None else None
        except Exception:
            return None

    def _screen_event_mine(self, e) -> bool:
        """这个事件是不是独立小屏幕窗口来的（按窗口对象或 id 认）。"""
        try:
            w = getattr(e, 'window', None)
            win = getattr(self, 'screen_win', None)
            return w is not None and win is not None and (
                w is win or getattr(w, 'id', None) == getattr(win, 'id', None))
        except Exception:
            return False

    def _is_screen_event(self, e) -> bool:
        """这个事件是不是独立小屏幕窗口发来的。"""
        try:
            return bool(self.screen_win_open) and self._screen_event_mine(e)
        except Exception:
            return False

    def _screen_auto(self):
        """该开独立窗口时开：模式 on 才自动开，noauto 不自动开；已经开着就每次上网对齐一次尺寸。"""
        if not self.screen_window_on():
            return
        if self.screen_win_open:       # 已经开着：直接对齐一次（偏差 ≤2% 不动）
            self._screen_fit()
            return
        if self.screen_mode() != "on":
            return
        self.open_screen_window()

    def open_screen_window(self, force=False):
        """额外开一个无边框、可缩放、默认置顶的小屏幕窗口。失败只提示，不抛异常。"""
        if not self.screen_window_on() or self.screen_win_open:
            return
        if self.screen_win is not None and not self.screen_win_open:   # 清掉已销毁的旧窗口对象
            try:
                self.screen_win.destroy()
            except Exception:
                pass
            self.screen_win = None
        title = f"{lang('small_screen')} · Terminist"
        try:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
        except Exception:
            desk_w, desk_h = 1920, 1080
        size = self._screen_web_size()
        w, h = size
        pos = (max(0, (int(desk_w) - size[0]) // 2 + S(220)), max(0, (int(desk_h) - size[1]) // 3))
        win = None
        # 绝不能用「从 display 模块取窗口」那种做法：拿到的就是主窗口本身，
        # 再对它赋 size / borderless 等于把主窗口改小、去掉边框，主窗口就废了。
        try:
            win = pygame.Window(title, size)
        except Exception as ex:
            self.add("info", f"小屏幕独立窗口建不了：{ex}")
            win = None
        if win is not None:            # 尺寸、位置、可缩放、无边框、置顶都单独设，哪一个不行就算了
            for act in (lambda: setattr(win, 'title', title),
                        lambda: setattr(win, 'size', (w, h)),
                        lambda: setattr(win, 'position', pos),
                        lambda: setattr(win, 'resizable', True),
                        lambda: setattr(win, 'borderless', True),
                        lambda: setattr(win, 'always_on_top', True)):
                try:
                    act()
                except Exception:
                    pass
        if win is not None:            # win32 自己摘掉标题栏和系统缩放边框，失败就退回 pygame 的 borderless
            if not self._screen_win32(self._screen_hwnd_of(win)):
                try:
                    setattr(win, 'borderless', True)
                except Exception:
                    pass
        if win is None:
            self.screen_win_ready = True
            self.add("info", "小屏幕独立窗口开不了，继续用左栏显示")
            return
        self.screen_win = win
        self.screen_win_open = True
        self.screen_win_ready = True
        self.screen_resizing = False
        self._screen_topmost()
        self.screen_next = 0           # 首次开窗也强制立刻按新视口重截一张
        self._screen_set_result(lang("screen_detached_on"), True)
        self.mark_dirty()

    def _screen_hwnd_of(self, win) -> int:
        """取某个 pygame 窗口的 win32 句柄（拿不到返回 0）。"""
        try:
            return int(getattr(win, "handle", 0) or 0)
        except Exception:
            return 0

    def _screen_hwnd(self) -> int:
        """独立小屏幕窗口的 win32 句柄（没开或拿不到返回 0）。"""
        if getattr(self, "screen_win", None) is None:
            return 0
        return self._screen_hwnd_of(self.screen_win)

    def _screen_win32(self, hwnd) -> bool:
        """win32 去掉标题栏、系统缩放边框和系统按钮，只留 WS_POPUP | WS_VISIBLE；成功返回 True。"""
        if sys.platform != "win32" or not hwnd:
            return False
        try:
            import ctypes
            u = ctypes.windll.user32
            GWL_STYLE = -16
            WS_CAPTION, WS_THICKFRAME, WS_SYSMENU = 0x00C00000, 0x00040000, 0x00080000
            WS_MINIMIZEBOX, WS_MAXIMIZEBOX = 0x00020000, 0x00010000
            WS_POPUP, WS_VISIBLE = 0x80000000, 0x10000000
            style = int(u.GetWindowLongW(hwnd, GWL_STYLE)) & 0xFFFFFFFF
            style &= ~(WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
            style = (style | WS_POPUP | WS_VISIBLE) & 0xFFFFFFFF
            u.SetWindowLongW(hwnd, GWL_STYLE, style)
            SWP_FRAMECHANGED, SWP_NOSIZE, SWP_NOMOVE, SWP_NOZORDER = 0x0020, 0x0001, 0x0002, 0x0004
            u.SetWindowPos(hwnd, 0, 0, 0, 0, 0,
                           SWP_FRAMECHANGED | SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER)
            return True
        except Exception as ex:
            self.add("info", f"去边框失败（继续用普通窗口）：{ex}")
            return False

    def _screen_drag(self, hwnd) -> bool:
        """无边框后自己实现拖动：ReleaseCapture 再发 WM_NCLBUTTONDOWN(HTCAPTION)。"""
        if sys.platform != "win32" or not hwnd:
            return False
        try:
            import ctypes
            u = ctypes.windll.user32
            u.ReleaseCapture()
            u.SendMessageW(hwnd, 0x00A1, 0x2, 0)      # WM_NCLBUTTONDOWN / HTCAPTION
            return True
        except Exception as ex:
            self.add("info", f"拖动窗口失败：{ex}")
            return False

    def _screen_resize_to(self, w, h) -> bool:
        """按像素改独立窗口尺寸（最小 320x240，位置不动）。"""
        try:
            w = max(SCREEN_MIN_W, int(w))
            h = max(SCREEN_MIN_H, int(h))
        except Exception:
            return False
        hwnd = self._screen_hwnd()
        if sys.platform == "win32" and hwnd:
            try:
                import ctypes
                SWP_NOMOVE, SWP_NOZORDER = 0x0002, 0x0004
                ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, w, h, SWP_NOMOVE | SWP_NOZORDER)
                return True
            except Exception as ex:
                self.add("info", f"改窗口大小失败：{ex}")
                return False
        try:                                          # 非 win32：退回 pygame 自己的尺寸
            self.screen_win.size = (w, h)
            return True
        except Exception as ex:
            self.add("info", f"改窗口大小失败：{ex}")
            return False

    def _screen_topmost(self):
        """独立窗口置顶：优先 win32 SetWindowPos，不行就 pygame 的 always_on_top，都不行就算了。"""
        self.screen_topmost = False
        if self.screen_win is None:
            return False
        try:
            if sys.platform == "win32":
                import ctypes
                hwnd = int(getattr(self.screen_win, "handle", 0) or 0)
                if hwnd:
                    HWND_TOPMOST, SWP_NOSIZE, SWP_NOMOVE, SWP_SHOWWINDOW = -1, 0x0001, 0x0002, 0x0040
                    ok = ctypes.windll.user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                                                           SWP_NOSIZE | SWP_NOMOVE | SWP_SHOWWINDOW)
                    self.screen_topmost = bool(ok)
        except Exception:
            self.screen_topmost = False
        if not self.screen_topmost:                  # 退回 pygame 自己的置顶标志
            try:
                self.screen_win.always_on_top = True
                self.screen_topmost = bool(self.screen_win.always_on_top)
            except Exception:
                self.screen_topmost = False
        return bool(self.screen_topmost)

    def close_screen_window(self):
        """关掉独立小屏幕窗口（Esc 连按两次 / 点到窗口关闭）。"""
        try:
            if self.screen_win is not None:
                self.screen_win.destroy()
        except Exception:
            pass
        self.screen_win = None
        self.screen_win_open = False
        self.screen_topmost = False
        self.screen_resizing = False
        self.screen_mark = None
        self.screen_esc_at = 0
        self.screen_mouse_pos = None
        self._screen_set_result(lang("screen_detached_off"), True)
        self.mark_dirty()

    def _screen_esc_press(self) -> bool:
        """独立窗口里按 Esc：连按两次（≤ 0.6 秒）才关，单击只提示。"""
        if not self.screen_win_open:
            return False
        now = pygame.time.get_ticks()
        if now - self.screen_esc_at <= SCREEN_ESC_GAP:
            self.close_screen_window()
        else:
            self.screen_esc_at = now
            self.screen_esc_hint_at = now
            self._screen_set_result(lang("screen_esc_hint"), True)
        return True

    def handle_screen_window(self, e):
        """独立小屏幕窗口的事件：缩放、关闭、标点、滚轮。不是它的就返回 None 交回主流程。"""
        if not self.screen_win_open:
            return None
        if e.type == pygame.WINDOWCLOSE and self._screen_event_mine(e):      # 系统把独立窗口关了
            self.close_screen_window()
            return True
        if not self._screen_event_mine(e):                                   # 不是独立窗口的事件
            return None
        if e.type in (pygame.WINDOWRESIZED, pygame.WINDOWSIZECHANGED):
            self._screen_refresh()                           # 拉大拉小：马上按新尺寸重截重画
            self.draw_screen_window()
            self.mark_dirty()                                # 拖拽中不改用户自己拉的尺寸
            return True
        if e.type == pygame.MOUSEMOTION:
            self.screen_mouse_pos = getattr(e, "pos", None)
            if getattr(self, "screen_resizing", False):       # 拖右下角手柄：实时改尺寸
                self._screen_drag_resize(getattr(e, "pos", None))
            return True
        if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            self.screen_mouse_pos = getattr(e, "pos", None)
            self.draw_screen_window()                         # 先按最新一帧换算出 screen_img_rect
            if self._screen_chrome_click(e):                  # 置顶按钮 / 缩放手柄 / 拖动顶栏
                return True
            self._screen_mouse(e)
            return True
        if e.type == pygame.MOUSEWHEEL:
            self.draw_screen_window()
            self._screen_mouse(e, getattr(self, "screen_mouse_pos", None))
            return True
        if e.type in (pygame.KEYDOWN, pygame.KEYUP):
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self._screen_esc_press()
                return True
            return True                                       # 独立窗口里别的按键不往主窗口输入框里塞字
        if e.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return True
        return None

    def _screen_panel_rect(self) -> pygame.Rect:
        """独立窗口自绘面板的矩形（外圈留 SCREEN_FRAME 的留白）。拿不到尺寸就给空 Rect。"""
        try:
            w, h = self.screen_win.size
            f = SCREEN_FRAME
            return pygame.Rect(f, f, max(0, int(w) - 2 * f), max(0, int(h) - 2 * f))
        except Exception:
            return pygame.Rect(0, 0, 0, 0)

    def _screen_title_rect(self) -> pygame.Rect:
        """标题条矩形（面板顶部 SCREEN_TITLE_H 高，窗口极矮时按一半截）。"""
        panel = self._screen_panel_rect()
        if panel.w <= 0 or panel.h <= 0:
            return pygame.Rect(0, 0, 0, 0)
        return pygame.Rect(panel.x, panel.y, panel.w, min(SCREEN_TITLE_H, panel.h // 2))

    def _screen_topmost_btn_hit(self, pos) -> bool:
        """点没点在标题条右侧的置顶按钮上（矩形由 _screen_draw_chrome 存下来）。"""
        try:
            r = getattr(self, "screen_topmost_rect", None)
            return bool(r is not None and r.w > 0 and r.collidepoint(int(pos[0]), int(pos[1])))
        except Exception:
            return False

    def _screen_close_btn_hit(self, pos) -> bool:
        """点没点在标题条右侧的关闭按钮上（矩形由 _screen_draw_chrome 存下来）。"""
        try:
            r = getattr(self, "screen_close_rect", None)
            return bool(r is not None and r.w > 0 and r.collidepoint(int(pos[0]), int(pos[1])))
        except Exception:
            return False

    def _screen_handle_hit(self, pos) -> bool:
        """点没点在面板内右下角的缩放手柄里。"""
        try:
            x, y = int(pos[0]), int(pos[1])
            panel = self._screen_panel_rect()
            if panel.w <= 0 or panel.h <= 0:
                return False
            n = min(max(8, S(SCREEN_RESIZE)), panel.w, panel.h)
            m = S(4)                                          # 放宽几个像素，手抖也能抓住
            return (panel.right - n - m <= x <= panel.right + m
                    and panel.bottom - n - m <= y <= panel.bottom + m)
        except Exception:
            return False

    def _screen_hot_hit(self, pos) -> bool:
        """点没点在标题条空白处（避开两颗按钮、缩放手柄和标点红圈）。"""
        try:
            x, y = int(pos[0]), int(pos[1])
        except Exception:
            return False
        try:
            bar = self._screen_title_rect()
            if bar.w <= 0 or bar.h <= 0 or not bar.collidepoint(x, y):
                return False
            if self._screen_topmost_btn_hit((x, y)) or self._screen_close_btn_hit((x, y)):
                return False
            if self._screen_handle_hit((x, y)):
                return False
            mark = getattr(self, 'screen_mark', None)
            shr = getattr(self, 'screen_img_rect', None)
            if mark is not None and shr is not None and shr.w > 0:
                vw, vh = getattr(self, '_screen_vp', None) or _web_viewport()
                cx = shr.x + int(mark[0] / max(1, vw) * shr.w)
                cy = shr.y + int(mark[1] / max(1, vh) * shr.h)
                r = S(SCREEN_MARK_R + SCREEN_HIT_SLOP)
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    return False                              # 红圈区域留给标点/确认逻辑
            return True
        except Exception:
            return False

    def _screen_chrome_click(self, e) -> bool:
        """独立窗口自己的交互：关闭按钮、置顶按钮、右下角缩放手柄、标题条拖动。处理过返回 True。"""
        pos = getattr(e, "pos", None)
        if pos is None:
            return False
        if e.type == pygame.MOUSEBUTTONUP:
            if getattr(e, "button", 0) == 1 and getattr(self, "screen_resizing", False):
                self.screen_resizing = False
                return True
            return False
        if getattr(e, "button", 0) != 1:
            return False
        if self._screen_close_btn_hit(pos):                   # 关闭按钮：关掉独立小屏幕
            self.close_screen_window()
            return True
        if self._screen_topmost_btn_hit(pos):                 # 置顶按钮：重新置顶
            ok = self._screen_topmost()
            self._screen_set_result(lang("screen_topmost_ok") if ok else lang("screen_topmost_bad"), ok)
            return True
        if self._screen_handle_hit(pos):                      # 右下角手柄：开始拖拽缩放
            try:
                w, h = self.screen_win.size
            except Exception:
                w, h = SCREEN_MIN_W, SCREEN_MIN_H
            self.screen_resizing = True
            self.screen_resize_from = (int(w), int(h), int(pos[0]), int(pos[1]))
            return True
        if self._screen_hot_hit(pos):                         # 标题条空白处：拖动窗口（只在按下那一刻发一次）
            return self._screen_drag(self._screen_hwnd())
        return False

    def _screen_drag_resize(self, pos):
        """在拖右下角手柄：按起点算新尺寸实时改窗口大小，失败只提示不抛异常。"""
        if pos is None:
            return
        try:
            w0, h0, x0, y0 = getattr(self, "screen_resize_from", (0, 0, 0, 0))
            if not w0 or not h0:
                return
            self._screen_resize_to(w0 + int(pos[0]) - x0, h0 + int(pos[1]) - y0)
            self.draw_screen_window()
            self.mark_dirty()
        except Exception as ex:
            self.add("info", f"缩放窗口失败：{ex}")

    def _screen_draw_chrome(self, surf, win_size):
        """无边框窗口自己画的装饰：圆角描边 + 标题条 + 置顶/关闭按钮 + 右下角缩放手柄。"""
        try:
            w, h = int(win_size[0]), int(win_size[1])
        except Exception:
            return
        if w <= 0 or h <= 0:
            return
        try:
            frame = SCREEN_FRAME
            rad = SCREEN_RADIUS
            panel = pygame.Rect(frame, frame, max(0, w - 2 * frame), max(0, h - 2 * frame))
            if panel.w <= 0 or panel.h <= 0:
                return
            title_h = min(SCREEN_TITLE_H, panel.h // 2)
            bar = pygame.Rect(panel.x, panel.y, panel.w, title_h)
            try:                                  # 标题条底色（只圆上面两个角）+ 底部 1px 分隔线
                head = C.get("panel_hdr", C["panel"])
                pygame.draw.rect(surf, head, bar, border_top_left_radius=rad,
                                 border_top_right_radius=rad)
                pygame.draw.line(surf, C["border"], (bar.x + rad, bar.bottom - 1),
                                 (bar.right - rad, bar.bottom - 1))
            except Exception:
                pass
            b = max(14, min(title_h - S(10), S(20)))            # 按钮边长
            close_rect = pygame.Rect(bar.right - PAD - b, bar.centery - b // 2, b, b)
            top_rect = pygame.Rect(close_rect.x - b - PAD, close_rect.y, b, b)
            if top_rect.x < bar.x + S(4):                        # 窗口极窄时别越界
                top_rect.x = bar.x + S(4)
            self.screen_close_rect = close_rect
            self.screen_topmost_rect = top_rect
            try:                                  # 标题文字：两颗按钮左边，超宽就截断
                title = lang("small_screen")
                avail = max(S(20), top_rect.x - bar.x - PAD * 2)
                t = utext(self.small, ellipsize(self.small, title, avail), C["dim"])
                surf.blit(t, (bar.x + PAD, bar.centery - t.get_height() // 2))
            except Exception:
                pass
            pos = getattr(self, "screen_mouse_pos", None)
            try:                                  # 置顶按钮：已置顶绿色、未置顶灰色，悬停亮一档
                on = bool(getattr(self, "screen_topmost", False))
                col = (80, 200, 120) if on else (140, 140, 140)
                if pos and top_rect.collidepoint(pos):
                    col = tuple(min(255, c + 34) for c in col)
                pygame.draw.rect(surf, col, top_rect, border_radius=max(3, b // 3))
                lay = pygame.Surface((b, b), pygame.SRCALPHA)
                ic = C.get("on_text", (255, 255, 255))
                k, m, sg = max(3, b // 4), max(1, b // 6), max(1, S(2))
                for a1, b1 in (((m, m), (m + k, m)), ((m, m), (m, m + k)),
                               ((b - 1 - m, m), (b - 1 - m - k, m)), ((b - 1 - m, m), (b - 1 - m, m + k)),
                               ((m, b - 1 - m), (m + k, b - 1 - m)), ((m, b - 1 - m), (m, b - 1 - m - k)),
                               ((b - 1 - m, b - 1 - m), (b - 1 - m - k, b - 1 - m)),
                               ((b - 1 - m, b - 1 - m), (b - 1 - m, b - 1 - m - k))):
                    pygame.draw.line(lay, ic, a1, b1, sg)
                surf.blit(lay, top_rect.topleft)
            except Exception:
                pass
            try:                                  # 关闭按钮：悬停红底 + 白叉，平时只有灰叉
                hot = bool(pos and close_rect.collidepoint(pos))
                if hot:
                    pygame.draw.rect(surf, (200, 80, 80), close_rect,
                                     border_radius=max(3, b // 3))
                lay = pygame.Surface((b, b), pygame.SRCALPHA)
                cc = C.get("on_text", (255, 255, 255)) if hot else (170, 170, 170)
                e, sg = max(4, b // 4), max(1, S(2))
                pygame.draw.line(lay, cc, (e, e), (b - 1 - e, b - 1 - e), sg)
                pygame.draw.line(lay, cc, (b - 1 - e, e), (e, b - 1 - e), sg)
                surf.blit(lay, close_rect.topleft)
            except Exception:
                pass
            try:                                  # 右下角缩放手柄：画在面板内，三条对角线
                n = min(max(8, S(SCREEN_RESIZE)), panel.w, panel.h)
                lay = pygame.Surface((n, n), pygame.SRCALPHA)
                for i in (1, 2, 3):
                    off = max(2, int(n * i / 4))
                    pygame.draw.line(lay, (150, 200, 240, 190), (n - off, n - 1), (n - 1, n - off), 1)
                surf.blit(lay, (max(panel.x, panel.right - n - S(3)),
                                max(panel.y, panel.bottom - n - S(3))))
            except Exception:
                pass
            try:                                  # 描边（border）+ 内侧 1px 高光，圆角跟着面板走
                pygame.draw.rect(surf, C["border"], panel, 1, border_radius=rad)
                hi = tuple(min(255, c + 40) for c in C["border"])
                pygame.draw.rect(surf, hi, panel.inflate(-2, -2), 1,
                                 border_radius=max(0, rad - 1))
            except Exception:
                pass
        except Exception:
            return

    def _screen_mouse(self, e, pos=None) -> bool:
        """小屏幕上的鼠标操作：右键标点 / 左键确认 / 滚轮滚网页。处理过返回 True。"""
        shr = getattr(self, "screen_img_rect", None)
        if not shr or shr.w <= 0:
            return False
        pos = pos or getattr(e, "pos", None) or shr.center
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 3 and shr.collidepoint(pos):
            if getattr(self, "screen_mark", None) is not None:
                self._screen_commit("right", pos)             # 再次右键 = 右击
            else:
                msg = self._screen_point(pos)                 # 第一次右键 = 标点
                if msg:
                    self.add("info", msg)
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and shr.collidepoint(pos):
            if getattr(self, "screen_mark", None) is not None:
                self._screen_commit("left", pos)              # 有标记时左键 = 确认点击
            return True                                       # 没标记时点画面不做任何事
        if e.type == pygame.MOUSEWHEEL and shr.collidepoint(pos):
            direction = -1 if e.y > 0 else 1
            try:
                xy = self._screen_to_page(shr.center)         # 画面中心换算成网页坐标
            except Exception:
                xy = None
            if not xy:
                vw, vh = _web_viewport()                      # 换算失败就滚视口中心
                xy = (vw // 2, vh // 2)
            self._screen_run({"kind": "scroll", "x": xy[0], "y": xy[1], "amount": direction * 3})
            return True
        return False

    def _draw_screen_mark_on(self, surf, img_rect: pygame.Rect):
        """把标好的网页坐标画回画面：红圈 + 中心十字（画到指定 surface 上）。"""
        mark = getattr(self, 'screen_mark', None)
        if mark is None or img_rect.w <= 0 or img_rect.h <= 0:
            return
        vw, vh = getattr(self, '_screen_vp', None) or _web_viewport()
        x = img_rect.x + int(mark[0] / max(1, vw) * img_rect.w)
        y = img_rect.y + int(mark[1] / max(1, vh) * img_rect.h)
        col = (220, 60, 60)
        pygame.draw.circle(surf, col, (x, y), S(SCREEN_MARK_R), S(2))
        pygame.draw.line(surf, col, (x - S(SCREEN_MARK_R + 4), y), (x + S(SCREEN_MARK_R + 4), y), S(1))
        pygame.draw.line(surf, col, (x, y - S(SCREEN_MARK_R + 4)), (x, y + S(SCREEN_MARK_R + 4)), S(1))

    def _draw_screen_hint_on(self, surf, area: pygame.Rect):
        """小屏幕左下角的操作提示（有没有画面都画，画到指定 surface 上）。"""
        mark = getattr(self, 'screen_mark', None)
        res = getattr(self, 'screen_result', None)
        col = C['text']
        msg = None
        if res:
            text, ok, at = res
            if pygame.time.get_ticks() - at < 8000:            # 8 秒内显示最近一次操作的结果
                msg = text
                col = C['add'] if ok else C['warn']
            else:
                self.screen_result = None
        if msg is None:
            if mark is None:
                msg = '右键标点 · 左键确认 · 再次右键＝右击 · 滚轮=滚动网页'
            else:
                msg = f'已标点（网页 {mark[0]},{mark[1]}）：左键＝确认点击，右键＝右击 · 只有点进红圈内才算'
        avail = max(S(20), area.w - S(8))
        msg = ellipsize(self.small, msg, avail)
        t = utext(self.small, msg, col)
        tw, th = t.get_size()
        box = pygame.Rect(area.x + S(4), area.bottom - th - S(10), min(avail, tw + S(10)), th + S(6))
        if box.w <= 0 or box.h <= 0:
            return
        old = surf.get_clip()
        back = pygame.Surface(box.size, pygame.SRCALPHA)
        back.fill((0, 0, 0, 150))
        surf.blit(back, box.topleft)
        surf.blit(t, (box.x + S(5), box.y + S(3)))
        surf.set_clip(old)

    def _screen_round_corners(self, lay, radius):
        """把一张 SRCALPHA 图层的四个角按 radius 挖成圆角（圆角以外的部分变透明）。"""
        try:
            radius = int(radius)
            if radius <= 0 or lay.get_width() <= 0 or lay.get_height() <= 0:
                return
            mask = pygame.Surface(lay.get_size(), pygame.SRCALPHA)
            pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
            lay.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        except Exception:
            pass

    def draw_screen_window(self):
        """画独立小屏幕窗口（无边框）：自绘圆角面板 + 标题条 + 网页画面 + 提示条，全按窗口自己的尺寸算。"""
        win = getattr(self, "screen_win", None)
        if win is None:
            return
        try:
            w, h = win.size
            w, h = int(w), int(h)
        except Exception:
            return
        if w <= 0 or h <= 0:
            return
        try:
            frame = SCREEN_FRAME
            rad = SCREEN_RADIUS
            surf = pygame.Surface((w, h))
            surf.fill(C["panel"])                                  # 圆角外先铺面板色，避免露出异色
            panel = pygame.Rect(frame, frame, max(0, w - 2 * frame), max(0, h - 2 * frame))
            if panel.w <= 0 or panel.h <= 0:
                return
            title_h = min(SCREEN_TITLE_H, panel.h // 2)
            # 内容区：四周留 PAD，上方让出标题条，整体在面板里面
            area = pygame.Rect(panel.x + PAD, panel.y + title_h,
                               panel.w - 2 * PAD, panel.h - title_h - PAD)
            if area.w <= 0 or area.h <= 0:
                return
            try:                                                  # 外投影：两层半透明黑，越靠外越淡
                lay = pygame.Surface((w, h), pygame.SRCALPHA)
                pygame.draw.rect(lay, (0, 0, 0, 46), panel.inflate(S(8), S(8)),
                                 border_radius=rad + 4)
                pygame.draw.rect(lay, (0, 0, 0, 70), panel.inflate(S(2), S(2)),
                                 border_radius=rad + 1)
                surf.blit(lay, (0, 0))
            except Exception:
                pass
            pygame.draw.rect(surf, C["panel"], panel, border_radius=rad)   # 圆角面板底板
            self.update_screen_view(area)
            self.screen_img_rect = pygame.Rect(0, 0, 0, 0)
            shot = getattr(self, "screen_shot", None)
            if shot is not None:
                sw, sh = shot.get_size()
                k = max(area.w / max(1, sw), area.h / max(1, sh))     # 铺满整块 area，超出的裁掉
                dw, dh = max(1, int(sw * k)), max(1, int(sh * k))
                img = pygame.transform.smoothscale(shot, (dw, dh)) if (dw, dh) != (sw, sh) else shot
                img_rect = pygame.Rect(area.x, area.y, dw, dh)        # 左上对齐铺满，不留边
                try:                                                  # 先进中间层，再把四角裁成圆角
                    lay = pygame.Surface(area.size, pygame.SRCALPHA)
                    lay.blit(img, (0, 0))
                    self._screen_round_corners(lay, rad)
                    surf.blit(lay, area.topleft)
                except Exception:                                     # 中间层不行就退回硬边裁切
                    try:
                        surf.set_clip(area)
                        surf.blit(img, img_rect)
                    finally:
                        surf.set_clip(None)
                self.screen_img_rect = img_rect
                self._screen_vp = _web_viewport()
                self._draw_screen_mark_on(surf, img_rect)
            else:
                t = utext(self.small, lang("screen_wait"), C["dim"])
                surf.blit(t, (area.x + PAD, area.y + S(6)))
            self._draw_screen_hint_on(surf, area)
            self._screen_draw_chrome(surf, (w, h))                # 标题条、两颗按钮、手柄、描边都在这里画
            try:
                win.get_surface().blit(surf, (0, 0))
                win.flip()
            except Exception:
                pass
        except Exception:
            pass

    def _draw_screen_hint_panel(self, rect, title=None):
        """独立窗口模式下左栏不再显示小屏幕区块（只保留员工栏）。"""
        self.tree_rects = []                # 文件树不再显示，避免点击落在旧的树条目上
        self.screen_img_rect = pygame.Rect(0, 0, 0, 0)
        self.screen_open_btn_rect = pygame.Rect(0, 0, 0, 0)   # 不再有按钮，杜绝残留可点区域
        self.screen_panel_rect = pygame.Rect(0, 0, 0, 0)
        self._panel_head_set("screen", pygame.Rect(rect.x, rect.y, rect.w,
                                                   self.small.get_linesize() * 2 + S(14)))
        return

    def draw_screen(self, rect: pygame.Rect, title: str | None = None):
        """小屏幕：实时显示 Playwright 当前网页，也能直接在上面标点、点击、滚动。"""
        if getattr(self, "screen_win_open", False):   # 小屏幕自己的窗口开着：栏里不重复画
            return self._draw_screen_hint_panel(rect, title)
        self.tree_rects = []                # 文件树不再显示，避免点击落在旧的树条目上
        pygame.draw.rect(self.screen, C['panel'], rect)
        pygame.draw.rect(self.screen, C['border'], rect, 1)
        st = self._web_state()
        sub = st.get("title") or lang('screen_sub')
        top = self.panel_header(rect, title or lang('small_screen'), sub, C['dim'], key="screen")
        area = pygame.Rect(rect.x + 1, top, max(0, rect.w - 2), max(0, rect.bottom - top - 1))
        if area.w <= 0 or area.h <= 0:
            return
        self.update_screen_view(area)
        img = self._draw_web(self.screen, area, "dock")
        self.screen_img_rect = img if img is not None else pygame.Rect(0, 0, 0, 0)
        self._screen_vp = _web_viewport()

    def draw_tree(self, rect: pygame.Rect, title: str | None = None):
        tree = self.tree
        pygame.draw.rect(self.screen, C["panel"], rect)
        pygame.draw.line(self.screen, C["border"], (rect.right - 1, rect.y), (rect.right - 1, rect.bottom))
        if tree.focus is not None:
            act = ACTIONS.get(tree.focus_tool, (lang("view"), None))[0]
            sub, color = f"{act}: {tree.focus or '/'}", C["warn"] if tree.focus_tool in WRITE_TOOLS else C["text"]
        else:
            sub, color = lang("tree_none"), C["dim"]
        top = self.panel_header(rect, title or lang("tree_title"), sub, color, key="tree")
        if tree.dirty:
            tree.rebuild()

        area = pygame.Rect(rect.x, top, rect.w, rect.bottom - top)
        row_h = self.small.get_linesize() + S(4)
        rows = [("", -1, True)] + tree.rows        # 第 0 行是工作区根目录
        total = len(rows) * row_h + PAD
        if tree.scroll_to_focus:
            idx = next((i for i, r in enumerate(rows) if r[0] == tree.focus), None)
            if idx is not None:
                y = idx * row_h
                if y < tree.scroll or y > tree.scroll + area.h - row_h * 3:
                    tree.scroll = y - area.h // 3
            tree.scroll_to_focus = False
        tree.scroll = max(0, min(tree.scroll, total - area.h))

        self.screen.set_clip(area)
        self.tree_rects = []
        first = tree.scroll // row_h
        for i in range(first, min(len(rows), first + area.h // row_h + 2)):
            rel, depth, is_dir = rows[i]
            y = area.y + i * row_h - tree.scroll + S(4)
            r = pygame.Rect(rect.x + S(4), y, rect.w - S(12), row_h)
            if rel == tree.focus:
                pygame.draw.rect(self.screen, ACTIONS.get(tree.focus_tool, ("", (230, 238, 250)))[1],
                                 r, border_radius=S(4))
            x = rect.x + PAD + (depth + 1) * S(14)
            if is_dir:      # 用多边形画展开/折叠三角，部分字体没有 ▶ 字形
                cx, cy = x + S(5), y + row_h // 2
                pts = [(cx - S(4), cy - S(2)), (cx + S(4), cy - S(2)), (cx, cy + S(3))] \
                    if depth < 0 or rel in tree.expanded \
                    else [(cx - S(2), cy - S(4)), (cx + S(3), cy), (cx - S(2), cy + S(4))]
                pygame.draw.polygon(self.screen, C["dir"], pts)
            name = (tree.root.name if tree.root else "") if depth < 0 else rel.rsplit("/", 1)[-1]
            color = C["dir"] if is_dir else C["text"]
            x += S(14)
            mark = MARKS.get(tree.status.get(rel))
            mark_w = S(18) if mark else 0
            name = ellipsize(self.small, name, r.right - x - mark_w - S(4))
            self.screen.blit(utext(self.small, name, color), (x, y + S(2)))
            if mark:
                t = utext(self.small, mark[0], mark[1])
                self.screen.blit(t, (r.right - t.get_width() - S(6), y + S(2)))
            if depth >= 0:
                self.tree_rects.append((r, rel, is_dir))
        self.screen.set_clip(None)
        draw_scrollbar(self.screen, area, total, tree.scroll)

    def draw_panel(self, rect: pygame.Rect):
        p = self.panel
        pygame.draw.rect(self.screen, C["panel"], rect)
        pygame.draw.line(self.screen, C["border"], (rect.x, rect.y), (rect.x, rect.bottom))
        gutter = S(44)      # 行号栏宽度
        lines = p.lines(self.code, rect.w - PAD * 2 - gutter) if p.tool else []
        if p.tool:
            act = lang("preview") if p.tool == "preview" else ACTIONS[p.tool][0]
            status_color = {"已写入": C["add"], "已拒绝": C["del"], "失败": C["del"],
                            "等待确认": C["warn"], "预览": C["dim"]}.get(p.status, C["hdr"])
            sub = f"{act} {p.path or '…'}   [{p.status}]"
        else:
            sub, status_color = lang("panel_none"), C["dim"]
        title = lang("panel_write") if p.tool != "preview" else lang("panel_preview")
        top = self.panel_header(rect, title, sub, status_color, key="write")
        t = utext(self.small, lang("collapse"), C["dim"])
        tx = rect.right - PAD - S(76)          # 右上角留出设置齿轮图标的位置
        self.panel_close_rect = t.get_rect(topright=(tx, rect.y + S(5))).inflate(S(10), S(4))
        self.screen.blit(t, t.get_rect(topright=(tx, rect.y + S(5))))

        area = pygame.Rect(rect.x, top, rect.w, rect.bottom - top)
        total = len(lines) * self.code_h + PAD * 2
        max_scroll = max(0, total - area.h)
        if p.stick:
            p.scroll = max_scroll
        p.scroll = max(0, min(p.scroll, max_scroll))
        if p.scroll >= max_scroll and p.status == "生成中…":
            p.stick = True

        bg = {"old": DIFF["old_bg"], "new": DIFF["new_bg"]}
        fg = {"old": DIFF["old_fg"], "new": DIFF["new_fg"], "plain": C["text"]}
        if p.tool == "write_file":
            bg = {}
        self.screen.set_clip(area)
        first = max(0, (p.scroll - PAD) // self.code_h)
        for i in range(first, min(len(lines), first + area.h // self.code_h + 2)):
            num, kind, text = lines[i]
            y = area.y + PAD + i * self.code_h - p.scroll
            if kind in bg:
                pygame.draw.rect(self.screen, bg[kind], (rect.x + 1, y, rect.w - 2, self.code_h))
            if num:
                t, nw = _code_line(self.code, num, "num", C["lineno"])
                self.screen.blit(t, (rect.x + PAD + gutter - S(8) - nw, y))
            if text:
                t, _ = _code_line(self.code, text, kind, fg[kind])
                self.screen.blit(t, (rect.x + PAD + gutter, y))
        # 生成中时在末尾画闪烁光标
        if p.status == "生成中…" and lines and pygame.time.get_ticks() // 400 % 2 == 0:
            num, kind, text = lines[-1]
            y = area.y + PAD + (len(lines) - 1) * self.code_h - p.scroll
            x = rect.x + PAD + gutter + self.code.size(text)[0] + S(2)
            pygame.draw.rect(self.screen, C["add"], (x, y + S(3), S(8), self.code_h - S(6)))
        self.screen.set_clip(None)
        draw_scrollbar(self.screen, area, total, p.scroll)

    def message_body(self, m: Message, width, font=None):
        lines = m.lines(font or self.font, width)
        if m.collapsed and len(lines) > COLLAPSED_LINES:
            return lines[:COLLAPSED_LINES] + [f"…（共 {len(lines)} 行，点击展开）"]
        if not m.collapsed and STYLE[m.kind][4] and len(lines) > COLLAPSED_LINES:
            return lines + ["（点击折叠）"]
        return lines

    def clear_card_h_cache(self):
        """清空卡片高度缓存（换会话、清空对话、改缩放后调用）。"""
        try:
            self._card_h_cache.clear()
        except AttributeError:
            self._card_h_cache = {}

    def _card_alpha(self, m) -> tuple[int, int]:
        """卡片入场动画：返回 (alpha 0~255, 额外向上偏移的像素)。关掉动画就是 (255, 0)。"""
        if not self.anim_on():
            return 255, 0
        t0 = self._card_t0.get(id(m))
        if not t0:
            self._card_t0[id(m)] = pygame.time.get_ticks()
            t0 = self._card_t0[id(m)]
        dur = 180.0 / max(0.25, min(4.0, float(self.settings.get("anim_speed") or 1.0)))
        k = _ease_out(min(1.0, (pygame.time.get_ticks() - t0) / dur if dur > 0 else 1.0))
        return int(255 * k), int(round(S(8) * (1.0 - k)))

    def _card_anim_done(self) -> bool:
        """还有卡片在入场动画中就让主循环继续刷帧；顺便清掉早就不在列表里的 id，防内存涨。"""
        if not self._card_t0:
            return True
        live = {id(m) for m in self.messages}
        for k in list(self._card_t0):
            if k not in live:
                self._card_t0.pop(k, None)
        if not self._card_t0:
            return True
        dur = 200.0 / max(0.25, min(4.0, float(self.settings.get("anim_speed") or 1.0)))
        now = pygame.time.get_ticks()
        return all(now - t > dur for t in self._card_t0.values())

    def draw_cards(self, area: pygame.Rect, items: list[Message], view: ScrollView, font,
                   highlight: set | None = None) -> list[tuple[pygame.Rect, Message]]:
        """在 area 里画一列可滚动的消息卡片，返回各卡片的位置（用于点击）。
        高度缓存：每帧只对可见区附近的消息真折行，其余用缓存的高度顶替，
        历史很长时每帧开销从 O(全部消息) 降到 O(可见消息)。"""
        line_h = font.get_linesize()
        time_h = self.small.get_linesize()             # 卡片左下角那行时间占的高度
        inner_w = area.w - PAD * 4 - S(10)
        inner_w = min(inner_w, S(520))                 # 图片卡片最大宽度，超大图不横向撑爆
        label_h = self.small.get_linesize() + S(2)
        av = S(28)                                     # 前台卡片的头像
        av_label_h = max(label_h, av + S(6))           # 有头像的卡片标题行高一点
        img_max_h = min(S(160), area.h * 7 // 10)      # 图片卡片的最大高度
        cache = getattr(self, "_card_h_cache", None)
        if cache is None:
            cache = self._card_h_cache = {}
        if len(cache) > 4000:                          # 换过很多次会话：别让缓存无限长
            cache.clear()

        # 第一阶段：顺序累加高度，有缓存就直接用，没有才折行算一次
        layout, y = [], PAD
        for m in items:
            if m.kind == "image":                  # 图片卡片：高度跟着缩放后的图片走
                key = (id(m), "image", inner_w, img_max_h, label_h, time_h)
                hit = cache.get(key)
                if hit is not None and hit[0] is m:
                    body, h = hit[1], hit[2]
                else:
                    img = m.image_surface(inner_w, img_max_h)
                    body = [] if img else ["(图片读不出来：" + m.image + ")"]
                    h = label_h + (img.get_height() + S(6) if img else line_h) + PAD + time_h
                    cache[key] = (m, body, h)
                layout.append((m, body, y, h))
                y += h + S(8)
                continue
            lh = av_label_h if m.kind in AVATAR_KINDS else label_h
            key = (id(m), m.kind, inner_w, len(m.text), m.collapsed, font, lh, time_h)
            hit = cache.get(key)
            if hit is not None and hit[0] is m:    # 命中缓存：不再折行（body 留到画的时候现算）
                body_ = None
                h = hit[2]
            else:
                body = self.message_body(m, inner_w, font)
                body_ = body
                h = lh + len(body) * line_h + PAD + time_h
                if m.kind == "choice" and m.options:
                    h += (len(m.options) + 1) * S(30) + S(36)
                cache[key] = (m, body, h)
            layout.append((m, body_, y, h))
            y += h + S(8)
        total = y + PAD

        max_scroll = max(0, total - area.h)
        if view.stick:
            view.scroll = max_scroll
        view.scroll = max(0, min(view.scroll, max_scroll))
        if view.scroll >= max_scroll:
            view.stick = True

        # 第二阶段：只对落在可见区上下各一个 area.h 窗口里的卡片真折行并绘制
        win_top = area.y - area.h
        win_bot = area.bottom + area.h
        self.screen.set_clip(area)
        rects = []
        def _fade_begin(alpha: int, card: pygame.Rect):
            """开始画一张正在淡入的卡片：换到临时 Surface 上画，只动这张卡片（含阴影）那一块，返回贴回需要的现场。"""
            if alpha >= 255:
                return None
            real = self.screen
            surf = getattr(self, "_fade_surf", None)    # 整个程序只分配一次（窗口大小变了才重来）
            if surf is None or surf.get_size() != real.get_size():
                surf = self._fade_surf = pygame.Surface(real.get_size(), pygame.SRCALPHA)
            region = card.inflate(S(32), S(32)).clip(area)
            surf.fill((0, 0, 0, 0), region)
            self.screen = surf
            surf.set_clip(region)
            return real, surf, region

        def _fade_end(ctx, alpha: int):
            """把卡片那一块按 alpha 混色后贴回真屏幕。"""
            if not ctx:
                return
            real, surf, region = ctx
            self.screen = real
            real.set_clip(area)
            surf.fill((255, 255, 255, max(0, min(255, alpha))), region, special_flags=pygame.BLEND_RGBA_MULT)
            real.blit(surf, region.topleft, region)

        if view is self.chat_view:                     # 只有聊天栏重画时才清：右栏工作流也调这个函数，别把聊天里选项的点击区清掉
            self.choice_rects = []
        for m, body, my, h in layout:
            top = area.y + my - view.scroll
            if top > win_bot or top + h < win_top:
                continue
            lh = av_label_h if m.kind in AVATAR_KINDS else label_h
            if m.kind == "image":
                pass
            elif body is None:                     # 缓存命中的卡片才在这里折行
                body = self.message_body(m, inner_w, font)
                h2 = lh + len(body) * line_h + PAD + time_h
                if m.kind == "choice" and m.options:
                    h2 += (len(m.options) + 1) * S(30) + S(36)
                if h2 != h:                        # 缓存高度不准（过期了）：以实际为准并回写
                    h = h2
                    key = (id(m), m.kind, inner_w, len(m.text), m.collapsed, font, lh, time_h)
                    cache[key] = (m, body, h)
            label, lc, bg, tc, collapsible = STYLE[m.kind]
            face = None
            if m.kind in AVATAR_KINDS:                # 前台说的话：头像 + 这个前台的名字（不显示用的哪个模型）
                who = getattr(m, "staff", "") or "fish"
                try:
                    label = staff_label(who)
                except Exception:
                    label = "肥鱼"
                face = self.staff_avatar(who, av)
            elif m.kind == "choice":
                label = "选一个" if (m.req is not None and not m.req.multi) else "选几项"
            elif m.who:
                label = f"{label} · {m.who}"
            rect = pygame.Rect(area.x + PAD, top, area.w - PAD * 2 - S(10), h)
            alpha, lift = self._card_alpha(m)
            if lift:
                rect.y -= lift
                top -= lift
            if alpha < 255:                        # 上浮时露出来的底色也补一层，别露白条
                pygame.draw.rect(self.screen, mix(C["bg"], bg, 0.5), rect.inflate(0, S(2)),
                                 border_radius=S(12))
            ctx = _fade_begin(alpha, rect)
            soft_shadow(self.screen, rect, S(12))
            pygame.draw.rect(self.screen, bg, rect, border_radius=S(12))
            pygame.draw.rect(self.screen, mix(C["border"], C["panel"], 0.3), rect, S(1), border_radius=S(12))
            if highlight and m in highlight:      # 右栏正在显示这一轮的工作流
                pygame.draw.rect(self.screen, STYLE["workflow"][1],
                                 (rect.x, rect.y + S(6), S(3), rect.h - S(12)), border_radius=S(3))
            rects.append((rect, m))
            if face is not None:
                self.screen.blit(face, (rect.x + PAD, top + S(5)))
                lab = utext(self.small, label, lc)
                self.screen.blit(lab, (rect.x + PAD + av + S(8), top + S(5) + (av - lab.get_height()) // 2))
            else:
                self.screen.blit(utext(self.small, label, lc), (rect.x + PAD, top + S(5)))
            ly = top + lh
            if m.kind == "image" and not body:
                img = m.image_surface(inner_w, img_max_h)
                if img:
                    self.screen.blit(img, (rect.x + PAD, ly + S(2)))
                    hint = utext(self.small, lang("click_original"), C["dim"])
                    self.screen.blit(hint, (rect.right - hint.get_width() - PAD, top + S(5)))
                stamp = fmt_msg_time(getattr(m, "ts", None))      # 左下角：这条消息的时间
                if stamp:
                    t = utext(self.small, stamp, C["dim"])
                    self.screen.blit(t, (rect.x + PAD, rect.bottom - PAD - t.get_height()))
                _fade_end(ctx, alpha)
                continue
            for line in body:
                if area.y - line_h < ly < area.bottom and line:
                    hint = collapsible and (line.startswith("…（共") or line.startswith("（点击"))
                    self.screen.blit(utext(font, line, C["dim"] if hint else tc), (rect.x + PAD, ly))
                ly += line_h
            if m.kind == "choice" and m.options:
                self.draw_choice(m, rect.x + PAD, ly + S(4), inner_w)
            stamp = fmt_msg_time(getattr(m, "ts", None))          # 左下角：这条消息的时间
            if stamp:
                t = utext(self.small, stamp, C["dim"])
                self.screen.blit(t, (rect.x + PAD, rect.bottom - PAD - t.get_height()))
            _fade_end(ctx, alpha)
        self.screen.set_clip(None)
        draw_scrollbar(self.screen, area, total, view.scroll)
        return rects

    def draw_choice(self, m, x: int, y: int, w: int):
        """选择卡片的选项和按钮。多选：勾选框 + 「确定（n 项）」「都不要」；单选：点一条就交。"""
        req = m.req
        closed = m.done or req is None or req.expired
        multi = req is None or req.multi
        mouse = pygame.mouse.get_pos()
        for i, opt in enumerate(m.options):
            r = pygame.Rect(x, y, w, S(26))
            on = i in m.checked
            hov = not closed and r.collidepoint(mouse)
            pygame.draw.rect(self.screen, mix(C["btn_on"], C["panel"], 0.55) if on else
                             mix(C["panel"], C["hdr"], 0.2 if hov else 0.1), r, border_radius=S(6))
            pygame.draw.rect(self.screen, C["btn_on"] if on else C["border"], r, S(1), border_radius=S(6))
            box = pygame.Rect(r.x + S(8), r.centery - S(7), S(14), S(14))
            if multi:                                  # 方框；勾中画一个对勾（字体里不一定有 ✓，自己画线）
                pygame.draw.rect(self.screen, C["btn_on"] if on else C["panel"], box, border_radius=S(3))
                pygame.draw.rect(self.screen, C["btn_on"] if on else C["dim"], box, S(1), border_radius=S(3))
                if on:
                    pts = [(box.x + S(3), box.centery), (box.x + S(6), box.bottom - S(4)), (box.right - S(3), box.y + S(4))]
                    pygame.draw.lines(self.screen, C["on_text"], False, pts, max(2, S(2)))
            else:                                      # 单选：圆圈
                pygame.draw.circle(self.screen, C["dim"] if not on else C["btn_on"], box.center, S(7), S(1))
                if on:
                    pygame.draw.circle(self.screen, C["btn_on"], box.center, S(4))
            color = C["text"] if (on or not closed) else C["dim"]
            t = utext(self.small, ellipsize(self.small, opt, w - S(40)), color)
            self.screen.blit(t, (box.right + S(8), r.centery - t.get_height() // 2))
            if not closed:
                self.choice_rects.append((r, m, i))
            y += S(30)
        r = pygame.Rect(x, y, w, S(26))                # 最后一行：自己写一个
        typing = getattr(self, "choice_typing", None) is m
        own = m.custom.strip()
        hov = not closed and r.collidepoint(mouse)
        if typing or own:
            pygame.draw.rect(self.screen, mix(C["btn_on"], C["panel"], 0.55), r, border_radius=S(6))
            pygame.draw.rect(self.screen, C["btn_on"], r, S(1), border_radius=S(6))
        else:
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.2 if hov else 0.06), r, border_radius=S(6))
            dash = mix(C["border"], C["dim"], 0.4)       # 虚线框：和正常选项区分开
            for dx in range(r.x + S(6), r.right - S(6), S(10)):
                pygame.draw.line(self.screen, dash, (dx, r.y), (min(dx + S(5), r.right - S(6)), r.y))
                pygame.draw.line(self.screen, dash, (dx, r.bottom - 1), (min(dx + S(5), r.right - S(6)), r.bottom - 1))
        pen = pygame.Rect(r.x + S(8), r.centery - S(7), S(14), S(14))      # 一支小笔：自己画，不靠字体
        pygame.draw.line(self.screen, C["dim"] if closed else C["hdr"], (pen.x + S(2), pen.bottom - S(2)),
                         (pen.right - S(2), pen.y + S(2)), max(2, S(2)))
        pygame.draw.line(self.screen, C["dim"] if closed else C["hdr"], (pen.x + S(1), pen.bottom - S(1)),
                         (pen.x + S(5), pen.bottom - S(1)), max(1, S(1)))
        if typing:
            text, color = "正在下面的输入框里写…（Enter 提交，Esc 不写了）", C["text"]
        elif own:
            text, color = own, C["text"]
        else:
            text, color = "自己写一个…", C["dim"] if closed else C["hdr"]
        t = utext(self.small, ellipsize(self.small, text, w - S(40)), color)
        self.screen.blit(t, (pen.right + S(8), r.centery - t.get_height() // 2))
        if not closed:
            self.choice_rects.append((r, m, "custom"))
        y += S(30)
        y += S(2)
        if closed:                                     # 结束了：一行结果
            if m.done:
                names = [m.options[i] for i in sorted(m.checked) if i < len(m.options)]
                if own:
                    names.append(f"自己写的「{own}」")
                text = "已提交：" + ("、".join(names) if names else "都不要")
            else:
                text = "已过期：没等到你选（或者被停止了），这张卡片不再生效"
            self.screen.blit(utext(self.small, ellipsize(self.small, text, w), C["dim"]), (x, y + S(6)))
            return
        if not multi:
            self.screen.blit(utext(self.small, "点一项就提交", C["dim"]), (x, y + S(6)))
            return
        bx = x
        for act, text, primary in (("ok", f"确定（{len(m.checked)} 项）", True), ("none", "都不要", False)):
            bw = self.small.size(text)[0] + S(28)
            r = pygame.Rect(bx, y, bw, S(30))
            hov = r.collidepoint(mouse)
            base = C["btn_on"] if primary else C["btn"]
            pygame.draw.rect(self.screen, mix(base, C["hdr"], 0.15) if hov else base, r, border_radius=S(8))
            t = utext(self.small, text, C["on_text"] if primary else C["text"])
            self.screen.blit(t, t.get_rect(center=r.center))
            self.choice_rects.append((r, m, act))
            bx += bw + S(10)

    def progress_text(self) -> str:
        who = ""                                       # 以前这里带当前成员用的模型名：不显示模型了
        try:
            name = staff_label(active_staff())
        except Exception:
            name = "肥鱼"
        if self.current_call:
            args = parse_args(self.current_call["args"])
            act = ACTIONS.get(self.current_call["name"], ("处理",))[0]
            target = args.get("path") or args.get("command") or ""
            return f"{name}{who} 正在{act} {target}"
        if self.panel.status == "生成中…":
            return f"{name}{who} 正在写 {self.panel.path or '文件'}"
        flow = self.turn_flow
        if self.active_workers:
            return f"{len(self.active_workers)} 个执行成员正在干活"
        if flow is not None and flow.children and flow.children[-1].kind.startswith("b_"):
            return "B库 正在改造 Terminist"
        return f"{name}{who} 思考中"

    def progress_h(self) -> int:
        """工作流进度条占用的高度；没有进度时返回 0（输入框、聊天区位置跟原来一模一样）。"""
        p = getattr(self, "progress", None) or {}
        if int(p.get("total") or 0) <= 0:
            return 0
        return self.small.get_linesize() + S(6)

    def draw_progress(self, center: pygame.Rect) -> int:
        """输入框正上方的工作流进度条：已完成格子填满打勾，当前格高亮，右侧「第 k/total · label」。返回占用的高度。"""
        h = self.progress_h()
        if not h:
            return 0
        p = self.progress
        total = max(0, int(p.get("total") or 0))
        done = max(0, min(int(p.get("done") or 0), total))
        if not self.anim_on():                         # 关掉动画：直接用真实值，和改造之前一样
            self._prog_done_tween.value = self._prog_done_tween.target = float(done)
            self._prog_total_last = total
            shown_done = done
        else:
            if total != getattr(self, "_prog_total_last", total):   # 换了一轮：直接对齐，不从满格倒着掉回来
                self._prog_done_tween.value = self._prog_done_tween.target = float(done)
            self._prog_total_last = total
            if self._prog_done_tween.target != float(done):
                self._prog_done_tween.to(float(done), self.anim_frames(10))
            self._prog_done_tween.tick()
            shown_done = int(round(self._prog_done_tween.value))
        y = center.bottom - self.sizes["input_h"] - h
        x0 = center.x + PAD
        w = center.w - PAD * 3 - S(80)
        bh = S(8)
        gap = S(3)
        k = total if done >= total else done + 1
        head = f"第 {k}/{total}" + (f" · {p.get('label', '')}" if (p.get("label") or "").strip() else "")
        txt = ellipsize(self.small, head, max(S(120), w // 2))
        tw = self.small.size(txt)[0]
        bar_w = max(S(60), w - tw - S(10))
        seg = max(S(6), (bar_w - gap * (total - 1)) // max(1, total))
        by = y + max(0, (self.small.get_linesize() - bh) // 2)
        if self.anim_on():                             # 当前这一格的呼吸色（1.6Hz）
            sp = max(0.25, min(4.0, float(self.settings.get("anim_speed") or 1.0)))
            pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 1000.0 * 1.6 * 2 * math.pi * sp)
            cur_col = mix(C["input_focus"], C["add"], 0.45 + 0.35 * pulse)
        else:
            cur_col = C["input_focus"]
        for i in range(total):
            r = pygame.Rect(x0 + i * (seg + gap), by, seg, bh)
            if i < shown_done:                             # 已完成的格子：填满 + 打勾
                pygame.draw.rect(self.screen, C["add"], r, border_radius=S(3))
                if r.w >= S(8) and r.h >= S(6):
                    pygame.draw.lines(self.screen, C["bg"], False,
                                      [(r.x + r.w * 0.24, r.centery),
                                       (r.x + r.w * 0.44, r.y + r.h * 0.72),
                                       (r.x + r.w * 0.78, r.y + r.h * 0.28)], max(1, S(2)))
            elif i == shown_done and self.busy:            # 正在做的那格：高亮（呼吸）
                pygame.draw.rect(self.screen, cur_col, r, border_radius=S(3))
            else:
                pygame.draw.rect(self.screen, C["border"], r, border_radius=S(3))
        self.screen.blit(utext(self.small, txt, C["add"] if done >= total else C["dim"]),
                         (x0 + w - tw, y))
        return h

    def draw_messages(self, center: pygame.Rect):
        """中间栏：只显示用户需求、结论和提示，过程都在右栏。"""
        reserve = self.sizes["input_h"] + self.progress_h() + max(0, self.live_hud_height())
        area = pygame.Rect(center.x, center.y, center.w, max(S(40), center.h - reserve))
        # 聊天栏右上角的工具按钮：清空聊天栏 / 载入历史
        self.chat_btns = []
        bh = S(24)
        bx = area.right - PAD * 2
        mouse = pygame.mouse.get_pos()
        for act, txt in (("history", "载入历史"), ("clear", "清空聊天栏")):
            r = pygame.Rect(0, area.y, utext(self.small, txt, C["text"]).get_width() + PAD * 2, bh)
            r.right = bx
            bx = r.x - S(8)
            base = mix(C["panel"], C["hdr"], 0.15) if r.collidepoint(mouse) else C["panel"]
            pygame.draw.rect(self.screen, base, r, border_radius=S(8))
            pygame.draw.rect(self.screen, C["border"], r, S(1), border_radius=S(8))
            t = utext(self.small, txt, C["text"])
            self.screen.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
            self.chat_btns.append((r, act))
        area = pygame.Rect(area.x, area.y + bh + S(6), area.w, max(S(40), area.h - bh - S(6)))
        items = [m for m in self.messages if m.kind != "workflow"]
        shown = self.shown_flow()
        turn = set()
        if shown is not None and self.selected_flow is not None:   # 手动选了某一轮时，标出那一轮的对话
            turn = {m for m in items if self.flow_of(m) is shown}
        self.msg_rects = self.draw_cards(area, items, self.chat_view, self.font, turn)
        if self._drop_hover:   # 有文件拖进窗口还没松手：聊天栏画一个「拖拽到此处」的虚线高亮框
            r = pygame.Rect(area.x + S(6), area.y + S(6), max(1, area.w - S(12)), max(1, area.h - S(12)))
            _dash_dotted_rect(self.screen, C["accent"], r, S(2), S(8))
            tip = utext(self.small, lang("drop_here", "拖拽到此处，松开即插入图片"), C["accent"])
            tw = tip.get_width() + PAD * 2
            ty = r.y + S(8)
            bg = pygame.Rect(r.centerx - tw // 2, ty - S(2), tw, tip.get_height() + S(4))
            pygame.draw.rect(self.screen, mix(C["panel"], C["accent"], 0.18), bg, border_radius=S(8))
            pygame.draw.rect(self.screen, C["accent"], bg, S(1), border_radius=S(8))
            self.screen.blit(tip, (r.centerx - tip.get_width() // 2, ty))
            self.mark_dirty()
        if self.busy and self.turn_answer is None:
            if self.anim_on():                     # 点点在 400ms 内从 1 个平滑长到 3 个
                sp = max(0.25, min(4.0, float(self.settings.get("anim_speed") or 1.0)))
                dur = max(1.0, 400.0 / sp)
                n = 1 + int(3 * _ease_out((pygame.time.get_ticks() % dur) / dur))
                dots = "." * max(1, min(3, n))
            else:
                dots = "." * (pygame.time.get_ticks() // 400 % 4)
            r = max(5, self.small.get_linesize() // 3)       # 文字前面的旋转加载圈
            label = ellipsize(self.small, self.progress_text() + dots, area.w - PAD * 4 - 2 * r - S(6))
            t = utext(self.small, label, C["dim"])
            ty = area.bottom - t.get_height() - S(6)
            draw_spinner(self.screen, (area.x + PAD * 2 + r, ty + t.get_height() // 2), r,
                         C["dim"], pygame.time.get_ticks())
            self.screen.blit(t, (area.x + PAD * 2 + 2 * r + S(6), ty))

    # ---------------- 右栏：工作流 + 写入面板 ----------------

    def shown_flow(self) -> Message | None:
        if self.selected_flow is not None and self.selected_flow in self.messages:
            return self.selected_flow
        flows = [m for m in self.messages if m.kind == "workflow"]
        return flows[-1] if flows else None

    def flow_summary(self, flow: Message) -> str:
        counts: dict[str, int] = {}
        for c in flow.children:
            if c.kind in ("tool", "b_tool"):
                name = c.text.split("(", 1)[0]
                act = ("B库" if c.kind == "b_tool" else "看源码" if name.startswith("terminist_")
                       else "桌面文件" if name.startswith("desktop_") else "屏幕操作" if name.startswith("screen_")
                       else "上网" if name.startswith("web_") else "看图" if name == "image_describe"
                       else "画图" if name in ("draw_diagram", "show_image", "web_snapshot")
                       else "听音视频" if name == "media_transcribe"
                       else ACTIONS.get(name, (name,))[0])
                counts[act] = counts.get(act, 0) + 1
        parts = []
        workers = sum(1 for c in flow.children if c.kind == "worker")
        if self.model == da.TEAM_MODE:
            parts.append(f"{da.LEAD_MODEL} + {workers} 个 {da.WORKER_MODEL}" if workers else da.LEAD_MODEL)
        parts += [f"{k} {v}" for k, v in counts.items()]
        return " · ".join(parts) or "还没有工具调用"

    def draw_goal_queue(self, rect: pygame.Rect, mouse=None) -> int:
        """右栏顶部「目标队列」卡片：每条未完成目标一行，行上 ↑ ↓ ✕，底部「＋ 新增目标」。"""
        self.goal_q_rects = []
        self._goal_rows = []
        self._goal_expanded = getattr(self, "_goal_expanded", None)
        self._goal_scroll = getattr(self, "_goal_scroll", 0)
        line_h = self.small.get_linesize()
        row_h = line_h + S(6)
        btn_w = max(S(18), line_h + S(4))
        items, done, total = [], 0, 0
        try:
            from lib_a import taskq
            data = taskq.load()                      # 文件没变就是缓存，每帧读不费事
            items = list(data["tasks"])
            done = sum(1 for t in data["history"] if t.get("status") == "done")
            total = len(items) + done
        except Exception:
            items, done, total = [], 0, 0
        self._report_blocked(items)
        red = STYLE["error"][1]
        if mouse is None:
            mouse = pygame.mouse.get_pos()
        n_blocked = sum(1 for t in items if t.get("status") == "blocked")
        h = line_h + S(10) + max(1, len(items)) * row_h + n_blocked * line_h + row_h + S(6)
        if getattr(self, "_goal_expanded", None):
            for it in items:
                if it["id"] == self._goal_expanded:
                    det = it.get("detail") or "（无详细方案）"
                    h += len(wrap(self.small, det, max(0, rect.w - PAD * 2 - S(12)))) * line_h + S(4)
                    break
        h = min(h, max(0, rect.h))                   # 别把下面的工作流挤出面板
        card = pygame.Rect(rect.x, rect.y, rect.w, h)
        if card.h <= 0:
            return 0
        pygame.draw.rect(self.screen, C["panel"], card)
        pygame.draw.line(self.screen, C["border"], (card.right - 1, card.y), (card.right - 1, card.bottom))
        pygame.draw.line(self.screen, C["border"], (card.x, card.bottom), (card.right, card.bottom))
        y = card.y + S(4)
        left = len(items)                            # 未完成项数
        waiting = sum(1 for t in items if t.get("status") == "blocked")
        text = "任务队列  全部完成" if (total and not items) else f"任务队列  还差 {left} 项"
        if waiting:
            text += f"（{waiting} 项卡住等你：点三角按钮接着做）"
        head = ellipsize(self.small, text, max(0, card.w - PAD * 2))
        self.screen.blit(utext(self.small, head, red if waiting else C["dim"]), (card.x + PAD, y))
        y += line_h + S(4)
        if not items:
            if y + row_h <= card.bottom:
                t = ellipsize(self.small, "队列空，点 ＋ 新增", max(0, card.w - PAD * 2))
                self.screen.blit(utext(self.small, t, C["dim"]), (card.x + PAD + S(2), y + S(3)))
        for idx, it in enumerate(items):
            if y + row_h > card.bottom:
                break
            tid = it["id"]
            active = it.get("status") == "active"
            row = pygame.Rect(card.x + PAD, y, max(0, card.w - PAD * 2), row_h)
            if it.get("status") == "blocked":            # 卡住的整行标红（底色 + 下面一行写为什么卡住）
                pygame.draw.rect(self.screen, mix(C["panel"], red, 0.14),
                                 row.inflate(0, line_h).move(0, line_h // 2), border_radius=S(4))
            elif row.collidepoint(mouse):
                pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.16), row, border_radius=S(4))
            bx = row.right - btn_w
            blocked = it.get("status") == "blocked"
            acts = () if active else (("drop", "down", "resume") if blocked else ("drop", "down", "up"))
            for act in acts:   # 从右往左排：✕ ↓ ↑（卡住的是 ✕ ↓ ▶）；正在做的那项固定在最前，不给按钮
                r = pygame.Rect(bx, y + S(1), btn_w, max(0, row_h - S(2)))
                bx -= btn_w + S(2)
                on = r.collidepoint(mouse)
                pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.34 if on else 0.14), r,
                                 border_radius=S(4))
                col = C["text"] if on else C["dim"]
                if act == "resume":                  # ▶：放回队列接着做
                    col = C["add"] if on else col
                    pygame.draw.polygon(self.screen, col, [(r.centerx - S(4), r.centery - S(5)),
                                                           (r.centerx - S(4), r.centery + S(5)),
                                                           (r.centerx + S(5), r.centery)])
                elif act == "up":
                    pygame.draw.polygon(self.screen, col, [(r.centerx, r.centery - S(5)),
                                                           (r.centerx - S(5), r.centery + S(3)),
                                                           (r.centerx + S(5), r.centery + S(3))])
                elif act == "down":
                    pygame.draw.polygon(self.screen, col, [(r.centerx, r.centery + S(5)),
                                                           (r.centerx - S(5), r.centery - S(3)),
                                                           (r.centerx + S(5), r.centery - S(3))])
                else:
                    d = S(4)
                    pygame.draw.line(self.screen, col, (r.centerx - d, r.centery - d),
                                     (r.centerx + d, r.centery + d), 2)
                    pygame.draw.line(self.screen, col, (r.centerx + d, r.centery - d),
                                     (r.centerx - d, r.centery + d), 2)
                self.goal_q_rects.append((act, tid, r))
            avail = max(0, row.w - btn_w * 3 - S(20))
            num = utext(self.small, f"{idx + 1}. ", C["add"] if active else C["text"])
            tx = row.x + S(4)
            self.screen.blit(num, (tx, y + S(3)))
            tx += num.get_width()
            st = it.get("status")
            if st in ("active", "blocked"):          # ▶ / ⏸ 自己画：字体里没有这两个符号，会显示成方框
                cy, k = y + row_h // 2, S(4)
                col = C["add"] if active else red
                if active:
                    pygame.draw.polygon(self.screen, col, [(tx, cy - k), (tx, cy + k), (tx + k + S(2), cy)])
                else:
                    pygame.draw.rect(self.screen, col, (tx, cy - k, S(2), k * 2))
                    pygame.draw.rect(self.screen, col, (tx + S(4), cy - k, S(2), k * 2))
                tx += k + S(6)
            t = ellipsize(self.small, it.get("title", ""), max(0, avail - (tx - row.x - S(4))))
            self.screen.blit(utext(self.small, t, C["add"] if active else (red if st == "blocked" else C["text"])),
                             (tx, y + S(3)))
            y += row_h
            if st == "blocked":                      # 第二行：为什么卡住
                why = "卡住：" + (it.get("blocked_on") or "没写原因")
                t = ellipsize(self.small, why, max(0, row.w - S(12)))
                self.screen.blit(utext(self.small, t, red), (row.x + S(8), y))
                y += line_h
            if self._goal_expanded == tid:           # 展开：显示 detail（设计方案）
                det = it.get("detail") or "（无详细方案）"
                if active:
                    det = "▶ 正在做\n" + det
                lines = wrap(self.small, det, max(0, row.w - S(12)))
                for k, ln in enumerate(lines):
                    yy = y + (k - self._goal_scroll) * line_h
                    if yy + line_h < row.bottom:
                        continue
                    if yy >= card.bottom:
                        break
                    self.screen.blit(utext(self.small, ln, C["dim"]), (row.x + S(8), yy))
                y += len(lines) * line_h + S(4)
            self._goal_rows.append((tid, row))
        if y + row_h <= card.bottom:                 # 底部「＋ 新增目标」
            r = pygame.Rect(card.x + PAD, y, max(0, card.w - PAD * 2), row_h)
            on = r.collidepoint(mouse)
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.34 if on else 0.16), r, border_radius=S(4))
            t = ellipsize(self.small, "＋ 新增目标", max(0, r.w - S(12)))
            self.screen.blit(utext(self.small, t, C["hdr"]), (r.x + S(6), y + S(3)))
            self.goal_q_rects.append(("add", -1, r))
            y += row_h
        return max(0, min(card.h, y + S(4) - card.y))

    def _report_blocked(self, items):
        """任务一卡住就在聊天里报一次异常（写清为什么卡住、怎么继续）；启动时已经卡着的也报一次。"""
        seen = getattr(self, "_blocked_seen", None)
        now = {t["id"]: t.get("blocked_on") or "没写原因" for t in items if t.get("status") == "blocked"}
        if seen is None:
            seen = {}
        for tid, why in now.items():
            if seen.get(tid) != why:
                title = next((t.get("title", "") for t in items if t["id"] == tid), "")
                self.add("error", f"任务 [{tid}] 卡住了：{title[:60]}\n原因：{why}\n"
                                  f"能继续就点任务队列里那行右边的三角按钮（或跟我说「继续」），不要了点叉。")
                if not why.startswith("主人停掉了"):        # Agent 说要主人给东西：弹窗直接要
                    self.ask_need(NeedRequest(tid, title, why))
        self._blocked_seen = now

    def ask_need(self, req):
        if getattr(self, "pending_need", None) is None:
            self.pending_need = req
            self.need_cursor = 0
        elif all(r.tid != req.tid for r in [self.pending_need] + self.need_queue):
            self.need_queue.append(req)
        self._dirty = True

    def answer_need(self, action: str):
        """要东西弹窗的答案：give 填了的内容补进任务说明、放回队列接着做；later 先放着；drop 不要了。"""
        req = getattr(self, "pending_need", None)
        if req is None:
            return
        from lib_a import taskq
        try:
            if action == "give" and req.text.strip():
                got = req.text.strip()
                old = next((t.get("detail", "") for t in taskq.open_tasks() if t["id"] == req.tid), "")
                taskq.edit(req.tid, detail=(old + "\n主人给的：" + got).strip(), by="user")
                self.add_result(taskq.resume(req.tid, by="user"))
                if self.busy and self.agent:
                    self.agent.add_instruction(f"主人给了任务 [{req.tid}] 要的东西：{got}（已放回队列，做完手上的就接着做它）")
                else:
                    self.kick_queue()
            elif action == "drop":
                self.add_result(taskq.drop(req.tid, "卡住时主人说不要了", by="user"))
            else:
                self.add("info", f"任务 [{req.tid}] 先放着：想好了点任务队列里那行右边的三角按钮，或者直接跟我说。")
        except Exception as e:
            self.add("error", f"处理任务 [{req.tid}] 失败：{type(e).__name__}: {e}")
        self.pending_need = self.need_queue.pop(0) if self.need_queue else None
        self._dirty = True

    def handle_need(self, e) -> bool:
        """要东西弹窗：打字 / 粘贴，Enter 提交，Esc 先放着。"""
        req = self.pending_need
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for action, r in getattr(self, "need_btn_rects", []):
                if r.collidepoint(e.pos):
                    self.answer_need(action)
                    return True
            return True
        if e.type == pygame.TEXTINPUT:
            req.text += e.text
            return True
        if e.type == pygame.KEYDOWN:
            ctrl = e.mod & (pygame.KMOD_CTRL | pygame.KMOD_META)
            if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                if e.mod & pygame.KMOD_SHIFT:
                    req.text += "\n"
                else:
                    self.answer_need("give")
            elif e.key == pygame.K_ESCAPE:
                self.answer_need("later")
            elif e.key == pygame.K_BACKSPACE:
                req.text = req.text[:-1]
            elif e.key == pygame.K_v and ctrl:
                req.text += get_clipboard()
        return True

    def draw_need(self, W, H, mouse):
        """Agent 卡住要东西：居中弹窗（哪个任务 / 要什么 / 输入框 / 提交 · 先放着 · 不要了）。"""
        req = self.pending_need
        modal = self.draw_modal_frame(W, H, S(760), S(440))
        x, y, iw = modal.x + PAD * 2, modal.y + PAD, modal.w - PAD * 4
        red = STYLE["error"][1]
        self.screen.blit(utext(self.font, f"任务卡住了，需要你给点东西  [{req.tid}]", red), (x, y))
        y += self.line_h + S(6)
        self.screen.blit(utext(self.font, ellipsize(self.font, req.title, iw), C["hdr"]), (x, y))
        y += self.line_h + S(6)
        for line in wrap(self.font, "要的是：" + req.reason, iw)[:4]:
            self.screen.blit(utext(self.font, line, C["text"]), (x, y))
            y += self.line_h
        y += S(8)
        box = pygame.Rect(x, y, iw, max(S(60), modal.bottom - S(70) - y))
        pygame.draw.rect(self.screen, C["bg"], box, border_radius=S(6))
        pygame.draw.rect(self.screen, C["input_border"], box, 2, border_radius=S(6))
        lines = []
        for para in (req.text or "").split("\n"):
            lines += wrap(self.font, para, box.w - PAD) or [""]
        if not req.text:
            self.screen.blit(utext(self.font, "在这里填（Enter 提交，Shift+Enter 换行，Ctrl+V 粘贴）", C["dim"]),
                             (box.x + PAD // 2, box.y + S(8)))
        visible = max(1, (box.h - S(8)) // self.line_h)
        ly = box.y + S(6)
        for line in lines[-visible:]:
            self.screen.blit(utext(self.font, line, C["text"]), (box.x + PAD // 2, ly))
            ly += self.line_h
        if (pygame.time.get_ticks() // 500) % 2 == 0:          # 光标
            cx = box.x + PAD // 2 + (self.font.size(lines[-1])[0] if lines else 0)
            cy = box.y + S(6) + (min(len(lines), visible) - 1) * self.line_h if lines else box.y + S(6)
            pygame.draw.line(self.screen, C["text"], (cx + 1, cy + S(2)), (cx + 1, cy + self.line_h - S(2)), 2)
        self._ime_rect = (box.x + PAD // 2, ly, S(10), self.line_h)       # 输入法候选框跟着输入框
        bw, bh = S(96), S(38)
        self.need_btn_rects = []
        bx = modal.right - PAD * 2
        for action, label, color in (("drop", "不要了", C["btn_danger"]), ("later", "先放着", C["btn"]),
                                     ("give", "提交", C["btn_on"])):
            r = pygame.Rect(bx - bw, modal.bottom - S(54), bw, bh)
            bx -= bw + S(10)
            base = mix(color, C["hdr"], 0.15) if r.collidepoint(mouse) else color
            pygame.draw.rect(self.screen, base, r, border_radius=S(8))
            t = utext(self.font, label, C["on_text"] if is_dark(base) else C["text"])
            self.screen.blit(t, t.get_rect(center=r.center))
            self.need_btn_rects.append((action, r))

    def draw_right(self, rect: pygame.Rect):
        """右栏从上到下：目标队列（常驻）、工作流（有写入内容时再加一块写入预览）。"""


        spots = self.right_spots(rect)
        self.spot_rects = []
        self._dock_right_rects = []                     # 本帧右栏槽位（下面每画一块登记一次）
        self.flow_rects, self.log_rects = [], []
        self.tree_rects = []
        for panel, title, r in spots:
            if r.h <= 0:
                continue
            rr = r
            self._draw_slot(panel, rr, title)
            if panel in SPOT_PANELS:                     # 有对应设置面板的才画齿轮
                self.draw_spot_bar(rr, SPOT_PANELS[panel], title)
            self.draw_dock_hide(rr, panel, right_edge=rr.right - self._spot_gear_w())   # X 让开设置齿轮
            self._dock_right_rects.append((panel, r))   # 本帧右栏各槽（落点 / 高亮用，key 跟槽位一一对应）
        if not any(p == "write" for p, _, _ in spots):
            self.write_rect = pygame.Rect(0, 0, 0, 0)
            self.panel_close_rect = pygame.Rect(0, 0, 0, 0)
        if not any(p == "board" for p, _, _ in spots):
            self.board_hide_rect = pygame.Rect(0, 0, 0, 0)
            self.board_img_rect = pygame.Rect(0, 0, 0, 0)
        if not any(p == "tree" for p, _, _ in spots):
            self.tree_rects = []                        # 文件树视图不在右栏：别留着上一帧的可点条目

    def right_spots(self, rect: pygame.Rect) -> list[tuple[str, str, pygame.Rect]]:
        """右栏各块的区域：按 dock_state["right"] 的顺序排，装不下就先丢最后一块。"""
        parts = [(k, self._dock_title(k)) for k in self._dock_side_keys("right")]
        hmin = S(90)
        while len(parts) > 1 and rect.h - (len(parts) - 1) < hmin * len(parts):
            parts = parts[:-1]                     # 装不下：先丢最后一个
        weights = {"flow": 46, "write": 40, "board": 34, "tree": 40, "staff": 40, "screen": 40, "economy": 34}
        avail = max(hmin, rect.h - (len(parts) - 1))
        total_w = sum(weights.get(p, 38) for p, _ in parts) or 1
        out, y = [], rect.y
        gap = 1
        for i, (panel, title) in enumerate(parts):
            h = max(S(60), min(avail * weights.get(panel, 38) // total_w, rect.bottom - y))
            if i == len(parts) - 1:
                h = max(0, rect.bottom - y)
            out.append((panel, title, pygame.Rect(rect.x, y, rect.w, h)))
            y += h
            if i < len(parts) - 1:
                pygame.draw.line(self.screen, C["border"], (rect.x, y), (rect.right, y))
                y += gap
        return out

    def _spot_gear_w(self) -> int:
        """标题条上「设置」齿轮那块的宽度（X 要往左让开它；flow 没有齿轮返回 0）。"""
        t = utext(self.small, lang("settings_icon"), C["dim"])
        gs = max(10, self.small.get_linesize() - S(2))
        return gs + S(5) + t.get_width() + S(10) + PAD + S(4)

    def draw_spot_bar(self, rect: pygame.Rect, panel: str, title: str) -> None:
        """每块标题条右上角的「设置」图标（自绘齿轮 + 文字，画在标题条上，不占内容高度）。"""
        if panel in ("flow", "Workflow"):
            return
        on = self.settings_open and self.settings_panel == panel
        color = C["hdr"] if on else C["dim"]
        t = utext(self.small, lang("settings_icon"), color)
        gs = max(10, self.small.get_linesize() - S(2))           # 齿轮大小跟着小字号走
        w = gs + S(5) + t.get_width() + S(10)
        h = max(t.get_height(), gs) + S(6)
        r = pygame.Rect(0, 0, w, h)
        r.topright = (rect.right - PAD, rect.y + S(2))
        if r.collidepoint(pygame.mouse.get_pos()) or on:
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.14), r, border_radius=S(6))
        gx = r.x + S(5)
        draw_gear(self.screen, pygame.Rect(gx, r.centery - gs // 2, gs, gs), color)
        self.screen.blit(t, (gx + gs + S(5), r.centery - t.get_height() // 2))
        self.spot_rects.append((r, panel, title))

    def draw_board(self, rect: pygame.Rect, title: str | None = None):
        """右栏画板区块：顶部信息条（工具/颜色/画布尺寸/笔数）+ 右上「收起」，下面按比例显示 board.png。"""
        pygame.draw.rect(self.screen, C["panel"], rect)
        pygame.draw.line(self.screen, C["border"], (rect.x, rect.y), (rect.x, rect.bottom))
        pygame.draw.line(self.screen, C["border"], (rect.x, rect.bottom - 1), (rect.right, rect.bottom - 1))
        self.board_rect = rect
        line_h = self.small.get_linesize()
        head = lang("board", "画板")
        t = utext(self.small, ellipsize(self.small, title or head, rect.w - PAD * 2 - S(80)), C["hdr"])
        self.screen.blit(t, (rect.x + PAD - S(2), rect.y + S(5)))
        label = utext(self.small, lang("collapse"), C["dim"])
        hb = label.get_rect(topright=(rect.right - PAD - S(66), rect.y + S(4)))   # 右边让开设置齿轮
        self.board_hide_rect = hb.inflate(S(12), S(6))
        if self.board_hide_rect.collidepoint(pygame.mouse.get_pos()):
            pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.16), self.board_hide_rect,
                             border_radius=S(5))
        self.screen.blit(label, hb)
        # 信息条：当前工具名 · 颜色色块 · 画布尺寸 · 笔数
        tool, color, size, n = self.board.info()
        y, x = rect.y + S(4) + line_h, rect.x + PAD
        box = pygame.Rect(x, y + S(2), S(12), S(12))
        pygame.draw.rect(self.screen, _hex_rgb(color), box, border_radius=S(2))
        pygame.draw.rect(self.screen, C["border"], box, 1, border_radius=S(2))
        x += S(18)
        info = ellipsize(self.small, f"{tool} · {size} · {n} 笔", max(0, rect.w - (x - rect.x) - PAD))
        self.screen.blit(utext(self.small, info, C["dim"]), (x, y))
        top = rect.y + line_h * 2 + S(10)
        pygame.draw.line(self.screen, C["border"], (rect.x, top - 1), (rect.right, top - 1))
        self._panel_head_set("board", pygame.Rect(rect.x, rect.y, rect.w, max(0, top - rect.y)))
        area = pygame.Rect(rect.x + S(2), top, max(0, rect.w - S(4)), max(0, rect.bottom - top - S(2)))
        if area.h <= 0:
            return
        img = self.board.surface(area.w - PAD, max(area.h - PAD, S(96)))     # mtime 变了才重新读盘
        if img is None:
            self.board_img_rect = pygame.Rect(0, 0, 0, 0)
            t = utext(self.small, lang("board_empty", "画板还空着，等 A库 落第一笔"), C["dim"])
            self.screen.blit(t, (area.x + PAD, area.y + PAD))
            return
        max_scroll = max(0, img.get_height() - (area.h - PAD * 2))
        self.board.scroll = max(0, min(getattr(self.board, "scroll", 0), max_scroll))
        x = area.x + max(0, (area.w - img.get_width()) // 2)                  # 居中，不拉伸
        y = area.y - self.board.scroll + max(0, (area.h - PAD * 2 - img.get_height()) // 2)
        self.screen.set_clip(area)
        self.screen.blit(img, (x, y))
        self.screen.set_clip(None)
        self.board_img_rect = pygame.Rect(x, y, img.get_width(), img.get_height())
        if max_scroll:
            draw_scrollbar(self.screen, area, img.get_height(), self.board.scroll)

    def draw_flow(self, rect: pygame.Rect, title: str | None = None):
        pygame.draw.rect(self.screen, C["panel"], rect)
        pygame.draw.line(self.screen, C["border"], (rect.x, rect.y), (rect.x, rect.bottom))
        flow = self.shown_flow()
        if flow is not self.shown_flow_last:         # 换了一轮，滚动回到最新位置
            self.flow_view = ScrollView()
            self.shown_flow_last = flow
        live = flow is not None and flow is self.turn_flow and self.busy
        if self.flow_log:
            rows = self.log_rows(rect.w - PAD * 3 - S(10))
            head, sub, color = lang("workflow_log"), lang("log_lines").format(
                f=lib_b.worklog.LOG_FILE, n=len(rows)), C["dim"]
        elif flow is None:
            head, sub, color = lang("workflow"), lang("workflow_none"), C["dim"]
        else:
            n = [m for m in self.messages if m.kind == "workflow"].index(flow) + 1
            head = lang("workflow_round").format(n=n) + (lang("in_progress") if live else "")
            sub, color = self.flow_summary(flow), (C["add"] if live else C["text"])
        top = self.panel_header(rect, title or head, sub, color, key="flow")
        # 标题右边的按钮，从右往左排："日志"/"返回工作流"、"打开文件"（日志模式）或 "回到最新"
        # 右上角留出设置图标的位置
        right_x, self.log_rects, self.flow_rects = rect.right - PAD - S(76) - S(34), [], []   # 再让出标题条上的 X
        buttons = [(lang("back_flow") if self.flow_log else lang("log_btn"), "toggle")]
        if self.flow_log:
            buttons.append((lang("open_file"), "open"))
        elif self.selected_flow is not None and self.selected_flow is not self.turn_flow and flow is not None:
            buttons.append((lang("to_latest"), None))
        for label, act in buttons:
            t = utext(self.small, label, C["hdr"])
            r = t.get_rect(topright=(right_x, rect.y + S(5)))
            self.screen.blit(t, r)
            if act is None:
                self.flow_rects.append((r.inflate(S(10), S(4)), None))
            else:
                self.log_rects.append((r.inflate(S(10), S(4)), act))
            right_x = r.x - S(14)

        area = pygame.Rect(rect.x, top, rect.w, rect.bottom - top)
        if self.flow_log:
            return self.draw_log(area, rows)
        if flow is not None and flow.children:
            self.flow_rects += self.draw_cards(area, flow.children, self.flow_view, self.code)
        elif live:
            t = utext(self.small, lang("waiting_model"), C["dim"])
            self.screen.blit(t, (area.x + PAD * 2, area.y + PAD))

    def log_rows(self, width: int) -> list[tuple[str, str]]:
        """日志视图的行：[(文字, 角色标记)]。日志文件变了（最多每 0.5 秒查一次）或宽度变了才重新折行。"""
        now = pygame.time.get_ticks()
        cache = self.log_cache
        if cache is not None and cache[1] == width and now - self.log_checked < 500:
            return cache[2]
        self.log_checked = now
        stamp = lib_b.worklog.stamp()
        if cache is not None and cache[:2] == (stamp, width):
            return cache[2]
        rows, tag = [], "plain"
        for raw in lib_b.worklog.tail(400):
            if not raw.startswith("    "):              # 新的一条：按角色上色，续行跟着上一条
                head = raw.split("]", 1)[0]
                tag = ("error" if "] 错误:" in raw[:60] else "mark" if "====" in raw[:60] else
                       "b" if "[B库" in head else "user" if "[用户" in head else
                       "a" if "[A库" in head else "worker")
            for line in wrap(self.code, raw, width) or [""]:
                rows.append((line, tag if not raw.startswith("    ") else tag + "_more"))
        self.log_cache = (stamp, width, rows)
        return rows

    def draw_log(self, area: pygame.Rect, rows: list[tuple[str, str]]):
        colors = {"a": STYLE["assistant"][1], "b": STYLE["b_stage"][1], "worker": STYLE["worker"][1],
                  "user": STYLE["user"][1], "error": STYLE["error"][1], "mark": C["hdr"], "plain": C["text"]}
        if not rows:
            t = utext(self.small, lang("no_logs"), C["dim"])
            self.screen.blit(t, (area.x + PAD * 2, area.y + PAD))
            return
        v = self.log_view
        total = len(rows) * self.code_h + PAD * 2
        max_scroll = max(0, total - area.h)
        if v.stick:
            v.scroll = max_scroll
        v.scroll = max(0, min(v.scroll, max_scroll))
        if v.scroll >= max_scroll:
            v.stick = True
        self.screen.set_clip(area)
        first = max(0, (v.scroll - PAD) // self.code_h)
        for i in range(first, min(len(rows), first + area.h // self.code_h + 2)):
            text, tag = rows[i]
            more = tag.endswith("_more")
            color = C["dim"] if more else colors.get(tag, C["text"])
            if text:
                self.screen.blit(utext(self.code, text, color),
                                 (area.x + PAD, area.y + PAD + i * self.code_h - v.scroll))
        self.screen.set_clip(None)
        draw_scrollbar(self.screen, area, total, v.scroll)

    # ---------------- 工作流现场浮条 ----------------
    LIVE_HUD_LINES = 2          # 浮条最多显示几行最近动作

    def live_hud_lines(self) -> list[str]:
        """浮条要显示的内容：第一行是进度/当前子任务，后面几行是最近的动作。没在干活就返回空。"""
        if not self.settings.get("hud", True):
            return []
        rep = self._deal_agent_live()
        selftest = bool(getattr(self, "_selftest_turn", False))
        if not rep and not selftest:
            return []
        lines = [x.strip() for x in rep.splitlines() if x.strip()]
        out = []
        head = self.progress or {}
        if head.get("total"):
            tag = f"工作流 {head.get('done', 0)}/{head.get('total', 0)}"
            if head.get("label"):
                tag += f"：{head['label']}"
            out.append(tag)
        if selftest:                                          # 自检这一轮：浮条上能看到它在跑
            out.append("重启后自检进行中…")
        acts = [x[2:] if x.startswith("- ") else x.lstrip("- ") for x in lines
                if not x.startswith("[") and not x.startswith("正在干活")
                and not x.startswith("上一轮") and not x.startswith("这一轮的用户要求")
                and not x.startswith("最近几步")]
        if acts:
            out.extend(acts[-self.LIVE_HUD_LINES:])
        return out or ["工作流在跑…"]

    def live_hud_height(self) -> int:
        n = len(self.live_hud_lines())
        return n * self.small.get_linesize() + S(10) + S(4) if n else 0

    def draw_live_hud(self, center: pygame.Rect, hud_h: int = None):
        """输入框上方的一条小浮条：滚动显示干活那一轮最近在做什么。"""
        if hud_h is None:
            hud_h = self.live_hud_height()
        if hud_h <= 0:
            return
        lines = self.live_hud_lines()
        if not lines:
            return
        h = hud_h - S(4)
        box = pygame.Rect(center.x + PAD, center.bottom - self.sizes["input_h"] - h - S(2),
                          center.w - PAD * 2, h)
        soft_shadow(self.screen, box, S(8))
        pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.06), box, border_radius=S(8))
        pygame.draw.rect(self.screen, mix(C["border"], C["hdr"], 0.18), box, 1, border_radius=S(8))
        pygame.draw.rect(self.screen, STYLE["workflow"][1],
                         (box.x + S(4), box.y + S(4), S(3), box.h - S(8)), border_radius=S(2))
        y = box.y + S(5)
        lh = self.small.get_linesize()
        for i, line in enumerate(lines):
            color = C["text"] if i == 0 else C["dim"]
            self.screen.blit(utext(self.small, ellipsize(self.small, line, box.w - PAD * 2 - S(8)), color),
                             (box.x + PAD + S(6), y))
            y += lh

    def on_candy(self):
        """点糖果按钮：给 A库 加 1 分（顶栏的奖励分跟着变），再从按钮那儿放一团糖果爱心。"""
        try:
            self.penalty = dict(getattr(self, "penalty", None) or {})
            self.penalty["RA"] = int(self.penalty.get("RA", 0)) + 1
        except Exception:
            pass
        btn = getattr(self, "btn_candy", None)
        rect = getattr(btn, "rect", None)
        if rect is not None and rect.w > 0:
            cx, cy = rect.center
        else:
            cx, cy = self.screen.get_width() - S(40), self.screen.get_height() - S(40)
        bursts = getattr(self, "_candy_bursts", None)
        if not isinstance(bursts, list):
            bursts = self._candy_bursts = []
        bursts.clear()                       # 连点也只飘最后一团，不叠图层
        bursts.append(CandyBurst(cx, cy))
        self.mark_dirty()

    def on_pick_image(self):
        """点「+」：弹文件选择框选一张图，加进待发列表。"""
        try:
            import tkinter
            from tkinter import filedialog
            r = tkinter.Tk()
            r.withdraw()
            r.attributes("-topmost", True)
            path = filedialog.askopenfilename(
                title="选择图片",
                filetypes=[("图片", "*.png *.jpg *.jpeg *.bmp *.gif *.webp"), ("所有文件", "*.*")])
            r.destroy()
            if path:
                self.add_pending_image(path)
        except Exception as e:
            self.add("error", f"选图失败：{e}")
        self.mark_dirty()

    def on_voice(self):
        """点麦克风 / 按 F2：没在录就开始录，正在录就停下来转文字（转写在后台线程，界面不卡）。"""
        if getattr(self, "_voice_busy", False):
            self.add("info", lang("voice_wait"))
            return
        rec = getattr(self, "_voice_rec", None)
        if rec is not None and rec.is_recording:
            try:
                path = rec.stop()
            except Exception as e:
                self._voice_rec = None
                self.add("error", lang("voice_fail") + f"{type(e).__name__}: {e}")
                self.mark_dirty()
                return
            self._voice_rec = None
            if not path:
                self.add("info", lang("voice_empty"))
                self.mark_dirty()
                return
            self._voice_busy = True
            self.mark_dirty()

            def work(p=path):
                try:
                    text = voice_input.transcribe_wav(p)
                    self.events.put(("voice_done", json.dumps({"ok": True, "text": text, "err": ""},
                                                              ensure_ascii=False)))
                except Exception as e:
                    self.events.put(("voice_done", json.dumps({"ok": False, "text": "",
                                                               "err": f"{type(e).__name__}: {e}"},
                                                              ensure_ascii=False)))

            threading.Thread(target=work, daemon=True).start()
            return
        try:
            if rec is not None:
                rec.cancel()                     # 有旧的没停干净：先取消掉
            self._voice_rec = voice_input.VoiceRecorder()
            self._voice_rec.start()
            self.add("info", lang("voice_recording"))
        except Exception as e:
            self._voice_rec = None
            self.add("error", lang("voice_fail") + f"{e}")
        self.mark_dirty()

    def on_voice_done(self, payload):
        """后台转写完成：把文字追加到输入框末尾（不自动发送）。"""
        self._voice_busy = False
        try:
            data = json.loads(payload) if isinstance(payload, str) else dict(payload or {})
        except Exception:
            data = {}
        if not data.get("ok"):
            self.add("error", lang("voice_fail") + str(data.get("err") or "未知错误"))
            self.mark_dirty()
            return
        text = (data.get("text") or "").strip()
        if not text:
            self.add("info", lang("voice_empty"))
            self.mark_dirty()
            return
        self.input_text = (self.input_text + " " + text) if self.input_text else text
        self.cursor = len(self.input_text)
        self.add("info", lang("voice_ok"))
        self.mark_dirty()

    def candy_btn_on(self) -> bool:
        """糖果按钮开着没有（设置里关掉就不画也不响应点击）。"""
        return bool(self.settings.get("candy_btn", True))

    def draw_candy_btn(self, W, H, mouse):
        """发糖果按钮：窗口绝对右下角的圆形按钮（鼠标在任何地方都能点到）。"""
        sw, sh = self.screen.get_width(), self.screen.get_height()
        sy = sh / float(H) if H else 1.0
        size = max(8, int(round(S(CANDY_SLOT_D) * sy)))
        margin = max(2, int(round(S(CANDY_SCREEN_PAD) * sy)))
        used = []
        for name in ("btn_send", "btn_voice"):          # 输入框按钮占着的位置要让开
            r = getattr(getattr(self, name, None), "rect", None)
            if isinstance(r, pygame.Rect) and r.w > 0 and r.h > 0:
                used.append((r.x - margin, r.y - margin, r.w + margin * 2, r.h + margin * 2))
        slot = getattr(self, "_candy_slot", None)
        if not (isinstance(slot, tuple) and len(slot) == 4
                and slot[2] == size and slot[3] == size
                and slot[0] + size <= sw and slot[1] + size <= sh
                and not any(pygame.Rect(*slot).colliderect(pygame.Rect(*u)) for u in used)):
            slot = sweep_candy_slot(sw, sh, margin, used=used, size=size)   # 尺寸变了或没空位就重算
            self._candy_slot = slot
        if not slot:                                     # 整屏都放不下：不画（也不响应点击）
            self.btn_candy.rect = pygame.Rect(0, 0, 0, 0)
            return
        rect = pygame.Rect(*slot)
        self.btn_candy.rect = rect
        over = rect.collidepoint(mouse)
        radius = max(4, rect.w // 2)
        if over:                                         # 悬停：圆外一圈淡光
            glow = pygame.Surface((rect.w + S(14), rect.h + S(14)), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*C["hdr"], 40), glow.get_rect().center,
                               glow.get_rect().w // 2, S(2))
            self.screen.blit(glow, (rect.x - S(7), rect.y - S(7)))
        pygame.draw.circle(self.screen, mix(C["btn"], C["hdr"], 0.15) if over else C["btn"],
                           rect.center, radius)
        pygame.draw.circle(self.screen, C["border"], rect.center, radius, S(1))
        draw_candy(self.screen, rect.centerx, rect.centery, max(4, rect.w // 4))

    def draw_input(self, center: pygame.Rect, mouse, hud_h: int = None):
        if hud_h is None:
            hud_h = self.live_hud_height()            # 有工作流现场时输入框往上让一点
        btn_w = S(44) + PAD + S(44) + PAD + S(80)     # 选图按钮 + 语音按钮 + 发送按钮一起占的宽度
        box = pygame.Rect(center.x + PAD, center.bottom - hud_h - self.sizes["input_h"] + PAD // 2,
                          center.w - PAD * 3 - btn_w, self.sizes["input_h"] - PAD)
        pygame.draw.rect(self.screen, C["input_bg"], box, border_radius=S(8))
        if box.collidepoint(mouse) or pygame.key.get_focused():      # 有焦点：亮边框 + 外发光
            glow = pygame.Surface((box.w + S(8), box.h + S(8)), pygame.SRCALPHA)
            pygame.draw.rect(glow, (*C["input_focus"], 60), glow.get_rect(), 1, border_radius=S(10))
            self.screen.blit(glow, (box.x - S(4), box.y - S(4)))
            pygame.draw.rect(self.screen, C["input_focus"], box, 1, border_radius=S(8))
        else:
            pygame.draw.rect(self.screen, C["border"], box, 1, border_radius=S(8))
        # 语音输入按钮：在发送按钮左边，录音时红色实心 + 「录音中…」，识别中显示「识别中…」
        rec = bool(getattr(self, "_voice_rec", None) and self._voice_rec.is_recording)
        vbusy = bool(getattr(self, "_voice_busy", False))
        # 选图按钮：语音按钮左边，点开文件框选图进待发列表
        self.btn_image.rect = pygame.Rect(box.right + PAD, box.y, S(44), box.h)
        self.btn_image.draw(self.screen, self.font, mouse)
        self.btn_voice.rect = pygame.Rect(self.btn_image.rect.right + PAD, box.y, S(44), box.h)
        self.btn_voice.enabled = not vbusy
        self.btn_voice.color = C["del"] if rec else None
        self.btn_voice.draw(self.screen, self.font, mouse)
        if rec:
            pygame.draw.circle(self.screen, C["on_text"], self.btn_voice.rect.center, S(4))
        self.btn_send.rect = pygame.Rect(self.btn_voice.rect.right + PAD, box.y, S(80), box.h)
        self.btn_send.enabled = True                     # 干活时也能点：点了就是和独立对话说
        self.btn_send.label = lang("stop_workflow") if self.busy else lang("send")
        self.btn_send.draw(self.screen, self.font, mouse)
        hint = lang("voice_wait") if vbusy else (lang("voice_recording") if rec else "")
        if hint:                                          # 提示挂在按钮上方，不遮输入框
            ht = utext(self.small, ellipsize(self.small, hint, S(260)), C["warn"] if rec else C["dim"])
            self.screen.blit(ht, (self.btn_send.rect.right - ht.get_width(),
                                  max(0, box.y - ht.get_height() - S(2))))

        self.pending_img_close_rects = []         # 每帧重建缩略图小✕的命中矩形
        thumb_w = self.draw_pending_thumbs(box, mouse)
        tw = box.w - PAD * 2 - thumb_w
        self.input_text_x = box.x + PAD + thumb_w
        visible = (box.h - PAD) // self.line_h
        self.input_rect = box
        over = box.collidepoint(mouse)
        if over != self.ibeam:                   # 鼠标在输入框上时显示 I 形光标
            self.ibeam = over
            try:
                pygame.mouse.set_system_cursor(pygame.SYSTEM_CURSOR_IBEAM if over else pygame.SYSTEM_CURSOR_ARROW)
            except pygame.error:
                pass
        mod_focus = modules_api.focused_field() is not None or self._web_kbd()   # 模块输入框 / 小浏览器拿着键盘：输入法和光标归它
        composing = "" if mod_focus else self.composing
        if mod_focus:
            self._ime_rect = None                 # 焦点回到主输入框时重新告诉系统候选框位置
        if not self.input_text and not composing:
            hint = (lang("placeholder_busy") if self.busy else lang("placeholder"))
            if getattr(self, "choice_typing", None) is not None:
                hint = "写你自己的回答，Enter 交给上面的选择卡片（Esc 不写了）"
            self.screen.blit(utext(self.font, hint, C["dim"]), (box.x + PAD + thumb_w, box.y + PAD // 2 + 2))

        # 光标位置 = 光标前文本折行后的最后一行末尾（逐字折行时与整体折行结果一致）
        before = self.input_text[:self.cursor] + composing
        all_lines = wrap(self.font, before + self.input_text[self.cursor:], tw)
        pre_lines = wrap(self.font, before, tw)
        cur_row = len(pre_lines) - 1
        cur_x = self.font.size(pre_lines[-1])[0]
        first = max(0, cur_row - visible + 1)
        self.input_first = first

        self.screen.set_clip(box)
        sel = self._sel()
        if sel and not composing:           # 选中的文字画上底色
            fc, bc = C["input_focus"], C["input_bg"]
            shade = tuple(int(f * 0.35 + b * 0.65) for f, b in zip(fc[:3], bc[:3]))
            for i, (start, text) in enumerate(self._input_lines(tw)[first:first + visible]):
                a, b = max(sel[0], start), min(sel[1], start + len(text))
                ends_inside = sel[1] > start + len(text)        # 选择跨到下一行：行尾补一点，看得出选中了换行
                if a < b or (a == b and ends_inside and start <= sel[0] <= start + len(text)):
                    x1 = self.font.size(text[:a - start])[0]
                    x2 = self.font.size(text[:b - start])[0] + (S(6) if ends_inside else 0)
                    pygame.draw.rect(self.screen, shade, (self.input_text_x + x1,
                                                          box.y + PAD // 2 + 2 + i * self.line_h,
                                                          max(S(2), x2 - x1), self.line_h))
        for i, line in enumerate(all_lines[first:first + visible]):
            self.screen.blit(utext(self.font, line, C["text"]),
                             (self.input_text_x, box.y + PAD // 2 + 2 + i * self.line_h))
        cx = self.input_text_x + cur_x
        cy = box.y + PAD // 2 + 2 + (cur_row - first) * self.line_h
        if composing:
            cw = self.font.size(composing)[0]
            pygame.draw.line(self.screen, C["input_focus"], (cx - cw, cy + self.line_h - S(2)),
                             (cx, cy + self.line_h - S(2)), S(2))
        if not mod_focus and pygame.time.get_ticks() // 530 % 2 == 0:
            pygame.draw.line(self.screen, C["text"], (cx, cy + S(2)), (cx, cy + self.line_h - S(2)), S(2))
        self.screen.set_clip(None)
        # 输入法候选框跟随光标：对齐到正在拼写的文字开头，放在这一行下面
        comp_x = cx - (self.font.size(composing)[0] if composing else 0)
        ime_rect = (comp_x, cy, S(10), self.line_h)
        if not mod_focus and ime_rect != getattr(self, "_ime_rect", None):     # 位置变了才告诉系统，免得候选框闪烁
            self._ime_rect = ime_rect
            pygame.key.set_text_input_rect(pygame.Rect(*ime_rect))
            if getattr(self, "proj_writer", None) is not None:   # 投影开着：输入法是壳的，候选框位置也要告诉壳
                self.proj_writer.set_ime_rect(ime_rect)

    def modal_buttons_for(self, req) -> list:
        """当前这条确认请求该画哪几个按钮：清空对话只给「清空」和「取消」，其余还是允许 / 拒绝 / 全部允许。"""
        if getattr(req, "kind", "") == "clear":
            return self.modal_clear_buttons
        if getattr(req, "kind", "") == "takeover":
            return getattr(self, "modal_takeover_buttons", self.modal_buttons)
        if getattr(req, "kind", "") == "notice":
            return getattr(self, "modal_notice_buttons", self.modal_buttons)
        return self.modal_buttons

    def draw_modal(self, W, H, mouse):
        req = self.pending_confirm
        modal = self.draw_modal_frame(W, H, S(900),
                                      S(600) if (req.detail or getattr(req, "items", None)) else S(220))
        mw = modal.w

        y = modal.y + PAD
        head = getattr(req, "title", "") or lang("confirm_needed")     # 标题：缺省还是「需要你的确认」
        self.screen.blit(utext(self.font, head, C["hdr"]), (modal.x + PAD * 2, y))
        y += self.line_h + S(6)
        body = getattr(req, "msg", "") or lang("confirm_needed")
        for line in wrap(self.font, body, mw - PAD * 4):
            self.screen.blit(utext(self.font, line, C["text"]), (modal.x + PAD * 2, y))
            y += self.line_h
        y += S(6)

        if getattr(req, "items", None):                 # 勾选式选择：画条目列表，不走详情文本框
            self.draw_modal_items(req, modal, y, mouse)
        else:
            detail_rect = pygame.Rect(modal.x + PAD * 2, y, mw - PAD * 4, modal.bottom - y - S(70))
            if req.detail:
                pygame.draw.rect(self.screen, C["bg"], detail_rect, border_radius=S(6))
                pygame.draw.rect(self.screen, C["input_border"], detail_rect, 1, border_radius=S(6))
                lines = wrap(self.font, req.detail, detail_rect.w - PAD * 2)
                visible = (detail_rect.h - PAD) // self.line_h
                self.modal_scroll = min(self.modal_scroll, max(0, len(lines) - visible))
                self.screen.set_clip(detail_rect)
                ly = detail_rect.y + PAD // 2
                for line in lines[self.modal_scroll:self.modal_scroll + visible]:
                    color = C["del"] if line.startswith("- ") else C["add"] if line.startswith("+ ") \
                        else C["hdr"] if line.startswith("---") else C["text"]
                    self.screen.blit(utext(self.font, line, color), (detail_rect.x + PAD, ly))
                    ly += self.line_h
                self.screen.set_clip(None)
                if len(lines) > visible:
                    t = utext(self.small, lang("scroll_more") + f" ({self.modal_scroll + 1}-"
                                                                 f"{min(len(lines), self.modal_scroll + visible)}/{len(lines)})",
                              C["dim"])
                    self.screen.blit(t, (detail_rect.x, detail_rect.bottom + S(4)))

        bx = modal.right - PAD * 2
        for b in reversed(self.modal_buttons_for(req)):
            w = self.font.size(b.label)[0] + S(30)
            bx -= w
            b.rect = pygame.Rect(bx, modal.bottom - S(50), w, S(38))
            b.draw(self.screen, self.font, mouse)
            bx -= S(10)

    def draw_modal_items(self, req, modal, y, mouse):
        """勾选式选择弹窗的条目列表：勾选框 + 条目文字，可滚动，右上角「全选 / 全不选」。"""
        self.modal_item_rects = []
        self.modal_all_rect = pygame.Rect(0, 0, 0, 0)
        items = list(getattr(req, "items", None) or [])
        if getattr(req, "picked", None) is None:
            req.picked = set(items)
        picked = req.picked
        x0 = modal.x + PAD * 2
        iw = modal.w - PAD * 4
        sh = self.small.get_linesize()
        self.screen.blit(utext(self.small, f"已勾选 {len(picked)}/{len(items)} · 点条目切换勾选", C["dim"]),
                         (x0, y))
        label = "全不选" if len(picked) >= len(items) else "全选"
        tw = self.small.size(label)[0] + PAD * 2
        r = pygame.Rect(x0 + iw - tw, y - S(2), tw, sh + S(4))
        self.modal_all_rect = r
        pygame.draw.rect(self.screen, C["bg"], r, border_radius=S(6))
        pygame.draw.rect(self.screen, C["input_border"], r, 1, border_radius=S(6))
        t = utext(self.small, label, C["hdr"] if r.collidepoint(mouse) else C["text"])
        self.screen.blit(t, t.get_rect(center=r.center))
        y += sh + S(10)

        area = pygame.Rect(x0, y, iw, max(self.line_h + S(6), modal.bottom - S(66) - y))
        row_h = self.line_h + S(6)
        visible = max(1, area.h // row_h)
        self.modal_scroll = max(0, min(self.modal_scroll, max(0, len(items) - visible)))
        self.screen.set_clip(area)
        ly = area.y
        for i in range(self.modal_scroll, min(len(items), self.modal_scroll + visible)):
            item = items[i]
            row = pygame.Rect(area.x, ly, area.w, row_h - S(2))
            on = item in picked
            box = pygame.Rect(row.x + S(2), row.y + (row.h - S(16)) // 2, S(16), S(16))
            if on:
                pygame.draw.rect(self.screen, C["btn_on"], box, border_radius=S(4))
                draw_check(self.screen, box, (255, 255, 255))
            else:
                pygame.draw.rect(self.screen, C["bg"], box, border_radius=S(4))
                pygame.draw.rect(self.screen, C["input_border"], box, 1, border_radius=S(4))
            txt = ellipsize(self.font, f"{i + 1}. {item}", max(S(20), row.right - box.right - PAD * 2))
            self.screen.blit(utext(self.font, txt, C["text"] if on else C["dim"]),
                             (box.right + PAD, row.y + (row.h - self.line_h) // 2))
            self.modal_item_rects.append((row, item))
            ly += row_h
        self.screen.set_clip(None)
        if len(items) > visible:
            t = utext(self.small, lang("scroll_more") + f" ({self.modal_scroll + 1}-"
                                                        f"{min(len(items), self.modal_scroll + visible)}/{len(items)})",
                      C["dim"])
            self.screen.blit(t, (area.x, area.bottom + S(4)))

    def draw_modal_frame(self, W, H, want_w, want_h) -> pygame.Rect:
        """画半透明遮罩和居中的弹窗底板，返回弹窗区域。"""
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill(C["overlay"])
        self.screen.blit(overlay, (0, 0))
        mw, mh = min(want_w, W - S(60)), min(want_h, H - S(60))
        modal = pygame.Rect((W - mw) // 2, (H - mh) // 2, mw, mh)
        soft_shadow(self.screen, modal, S(16))
        pygame.draw.rect(self.screen, C["modal"], modal, border_radius=S(16))
        pygame.draw.rect(self.screen, C["input_border"], modal, 1, border_radius=S(16))
        return modal

    def draw_credentials(self, W, H, mouse):
        """网页要账号密码：居中的弹窗（网站名 / 说明 / 账号 / 密码 / 记住密码 / 提供 / 拒绝）。"""
        req = self.pending_credentials
        modal = self.draw_modal_frame(W, H, S(700), S(380))
        x = modal.x + PAD * 2
        y = modal.y + PAD
        iw = modal.w - PAD * 4
        self.screen.blit(utext(self.font, lang("cred_title"), C["hdr"]), (x, y))
        y += self.line_h + S(8)
        self.screen.blit(utext(self.font, ellipsize(self.font, req.site, iw), C["hdr"]), (x, y))
        y += self.line_h + S(4)
        if req.note:
            for line in wrap(self.small, req.note, iw)[:3]:
                self.screen.blit(utext(self.small, line, C["dim"]), (x, y))
                y += self.small.get_linesize()
        y += S(10)

        # 两个输入行：点哪一行焦点就移到哪一行
        self.cred_rects = []
        for i, (label, text, hidden) in enumerate(((lang("cred_user"), req.user, False),
                                                   (lang("cred_pass"), req.pwd, True))):
            self.screen.blit(utext(self.font, label, C["text"]), (x, y + S(8)))
            r = pygame.Rect(x + S(76), y, iw - S(76), S(36))
            pygame.draw.rect(self.screen, C["bg"], r, border_radius=S(6))
            pygame.draw.rect(self.screen, C["input_border"], r, 2 if req.focus == i else 1,
                             border_radius=S(6))
            shown = ("●" * len(text)) if hidden else text
            t = utext(self.font, ellipsize(self.font, shown, r.w - PAD), C["text"])
            self.screen.blit(t, (r.x + PAD // 2, r.y + S(8)))
            self.cred_rects.append(r)
            y += S(44)

        # 记住密码
        box = pygame.Rect(x, y + S(2), S(16), S(16))
        pygame.draw.rect(self.screen, C["bg"], box, border_radius=S(3))
        pygame.draw.rect(self.screen, C["input_border"], box, 1, border_radius=S(3))
        if req.remember:
            pygame.draw.line(self.screen, C["hdr"], (box.x + S(3), box.centery),
                             (box.centerx, box.bottom - S(4)), 2)
            pygame.draw.line(self.screen, C["hdr"], (box.centerx, box.bottom - S(4)),
                             (box.right - S(3), box.y + S(4)), 2)
        self.cred_check_rect = pygame.Rect(x, y - S(4), S(200), S(26))
        self.screen.blit(utext(self.font, lang("cred_remember"), C["text"]),
                         (box.right + S(8), y))
        y += S(30)

        # 底部按钮：提供 / 拒绝
        bw, bh = S(96), S(38)
        deny = pygame.Rect(modal.right - PAD * 2 - bw, modal.bottom - S(54), bw, bh)
        give = pygame.Rect(deny.x - S(10) - bw, deny.y, bw, bh)
        self.cred_give_rect, self.cred_deny_rect = give, deny
        for r, label, color in ((give, lang("cred_give"), C["btn_on"]),
                                (deny, lang("cred_deny"), C["btn_danger"])):
            base = mix(color, C["hdr"], 0.15) if r.collidepoint(mouse) else color
            pygame.draw.rect(self.screen, base, r, border_radius=S(8))
            t = utext(self.font, label, C["on_text"] if is_dark(base) else C["text"])
            self.screen.blit(t, t.get_rect(center=r.center))

    def settings_plan(self) -> list[tuple[str, list[tuple[int, str, object]]]]:
        """设置面板的内容：[(分组名, [(行高, 行类型, 数据), ...]), ...]，只放当前区块归属的设置。
        行类型：hint 小字 / secret 换 key / topbtns 顶栏按钮 / slider 滑杆 / opts 选项 / link 跳转。"""
        panel = self.settings_panel
        rows = settings_of(panel)
        order = list(dict.fromkeys(e["group"] for _, e in rows))     # 同一个分组的项挨在一起
        out: list[tuple[str, list[tuple[int, str, object]]]] = []
        for g in order:
            items = [(S(46), "slider" if k in SLIDER_KEYS else "opts", (k, e))
                     for k, e in rows if e["group"] == g]
            out.append((group_label(g), items))
        if panel == "show":                    # 注册表里新加的项忘了写 panel：兜底显示在这里
            stray = [(S(46), "slider" if k in SLIDER_KEYS else "opts", (k, e)) for k, _, e in stray_settings()]
            if stray:
                out.append((lang("group_other"), stray))
        if panel == "privacy":                 # 隐私：换 API key（不放进注册表，A库 碰不到）
            out.append((lang("api_key"), [(S(46), "secret", None)]))
        if not any(items for _, items in out):
            out.append(("", [(self.small.get_linesize() + S(6), "hint", lang("no_settings_here"))]))
        return out

    def _drop_settings_fade(self) -> None:
        """右栏设置面板收起时丢掉它的淡入缓存（alpha 归零，下次打开重新淡入；也不会让主循环一直刷帧）。"""
        for k in [k for k in getattr(self, "_fade_cache", {})
                  if isinstance(k, tuple) and k and k[0] == "settings"]:
            self._fade_cache.pop(k, None)

    def draw_faded(self, key, sig, rect: pygame.Rect, painter, size=None) -> None:
        """带淡入的绘制：同一个 key 的内容签名没变就复用上一帧的 surface，只把 alpha 往 255 推。
        painter(surf, off)：把这一块画到 surf 上（surf 左上角对应 off；面板用整屏坐标就传 (0, 0)）。
        size 给了就按它建画布（整屏坐标的面板传窗口大小），否则按 rect.size。
        关掉动画时直接画到真屏幕上，和改造之前一模一样。"""
        if not self.anim_on():
            painter(self.screen, (0, 0))
            return
        cache = getattr(self, "_fade_cache", None)
        if not isinstance(cache, dict):
            cache = self._fade_cache = {}
        surf_size = size or rect.size
        hit = cache.get(key)
        if not isinstance(hit, list) or hit[0] != sig or hit[1].get_size() != surf_size:
            alpha = hit[2] if isinstance(hit, list) else 0.0      # 内容变了重画，但淡入进度接着走（不闪）
            tmp = pygame.Surface(surf_size, pygame.SRCALPHA)
            painter(tmp, (0, 0) if size else rect.topleft)
            hit = cache[key] = [sig, tmp, alpha]
        a = hit[2]
        if a < 1.0:                                    # 只有还没淡完才继续往 255 推进
            a = min(1.0, a + 1.0 / max(1, self.anim_frames(10)))
            hit[2] = a
        surf = hit[1]
        pos = (0, 0) if size else rect.topleft
        k = int(255 * _ease_out(a))
        if k >= 255:                                   # 淡完了：直接贴缓存，不再多拷一份
            self.screen.blit(surf, pos)
        else:
            faded = surf.copy()
            faded.fill((255, 255, 255, max(0, k)), special_flags=pygame.BLEND_RGBA_MULT)
            self.screen.blit(faded, pos)

    def _paint_top_button(self, surf, b, mouse, off=(0, 0)) -> None:
        """把顶栏按钮画到 surf 上（坐标减掉 off：淡入缓存时 off 是按钮左上角，直接画屏幕时是 (0,0)）。"""
        real, r = self.screen, b.rect
        self.screen = surf
        b.rect = pygame.Rect(r.x - off[0], r.y - off[1], r.w, r.h)
        try:
            b.draw(surf, self.small, (mouse[0] - r.x, mouse[1] - r.y))
        finally:
            b.rect = r
            self.screen = real

    def draw_settings(self, rect: pygame.Rect, mouse):
        """右栏里的设置面板：整块淡入（内容没变就直接用缓存，只把 alpha 往 255 推）。"""
        key = ("settings", self.settings_panel)
        for k in [k for k in getattr(self, "_fade_cache", {})
                  if isinstance(k, tuple) and k and k[0] == "settings" and k != key]:
            self._fade_cache.pop(k, None)               # 换面板了：丢掉旧面板的缓存和淡入进度
        if not self.anim_on():
            self._draw_settings_body(rect, mouse)
            return
        sig = (self.settings_panel, self.settings_scroll, self.settings_open, SCALE,
               self.settings.get("theme"), self.settings_focus, self._settings_sig(), mouse,
               tuple(self.screen.get_size()))

        def _paint(surf, off):
            real = self.screen
            self.screen = surf
            try:
                self._draw_settings_body(rect, mouse)   # 面板本来就用整屏坐标画，off 可忽略
            finally:
                self.screen = real

        self.draw_faded(key, sig, rect, _paint, size=self.screen.get_size())

    def _settings_sig(self):
        """设置面板内容签名：注册表里这些项的值（面板按钮的文字和选中态都跟着变）。"""
        out = []
        for k, e in UI_SETTINGS.items():
            try:
                out.append((k, str(self.settings.get(k))))
            except Exception:
                out.append((k, ""))
        return tuple(out)

    def _draw_settings_body(self, rect: pygame.Rect, mouse):
        """右栏里的设置面板：顶部 ‹ 返回 / 标题 / ✕，内容按区块分组、可滚动。"""
        pygame.draw.rect(self.screen, C["panel"], rect)
        self.settings_rects = []
        self.settings_slider_rect = {}
        self.settings_dd_pending = None
        self.spot_rects = []
        x0 = rect.x + PAD
        y = rect.y + S(4)

        back = utext(self.small, lang("back"), C["hdr"])
        br = back.get_rect(topleft=(x0, y + S(3))).inflate(S(12), S(6))
        self.screen.blit(back, back.get_rect(center=br.center))
        self.settings_rects.append((br, "back", None))
        close = utext(self.font, "✕", C["hdr"])
        cr = close.get_rect(topright=(rect.right - PAD, y)).inflate(S(14), S(6))
        self.screen.blit(close, close.get_rect(center=cr.center))
        self.settings_rects.append((cr, "close", None))
        head = f"{lang('settings_panel')} · {panel_label(self.settings_panel)}"
        t = utext(self.font, ellipsize(self.font, head, max(S(40), rect.w - br.w - cr.w - PAD * 4)), C["hdr"])
        self.screen.blit(t, t.get_rect(midtop=(rect.centerx, y)))
        y += max(self.font.get_linesize(), br.h) + S(2)
        self.screen.blit(utext(self.small, ellipsize(self.small, lang("panel_note"), rect.w - PAD * 2), C["dim"]),
                         (x0, y))
        y += self.small.get_linesize() + S(6)
        pygame.draw.line(self.screen, C["border"], (rect.x, y - S(2)), (rect.right, y - S(2)))

        plan = self.settings_plan()
        labels = [setting_label(key, e) for _, items in plan for _, kind, data in items
                  if kind in ("slider", "opts") for key, e in [data]]
        label_w = max([self.font.size(t2)[0] for t2 in labels + ["API key"]] or [S(80)]) + S(20)
        label_w = min(label_w, max(S(80), (rect.w - PAD * 4) * 2 // 5))   # 右栏窄时别把整行挤出去

        sb_w = S(8)
        body = pygame.Rect(rect.x + S(2), y, max(S(60), rect.w - S(4) - sb_w),
                           max(S(20), rect.bottom - S(6) - y))
        self.settings_body_rect = body
        clip = body.clip(rect)                     # 内容一律裁在右栏里，窗口很小时也不画出去
        clip.h = max(1, clip.h)
        title_h = self.small.get_linesize() + S(8)
        total = sum(title_h + sum(h for h, _, _ in items) + S(10) for _, items in plan)
        self.settings_scroll_max = max(0, total - clip.h)
        self.settings_scroll = max(0, min(self.settings_scroll, self.settings_scroll_max))

        self.screen.set_clip(clip)
        cy = clip.y - self.settings_scroll             # 推式滚动：所有 y 都减去滚动量
        for name, items in plan:
            if name:
                self.screen.blit(utext(self.small, ellipsize(self.small, name, body.w - PAD), C["hdr"]), (x0, cy))
                line_y = cy + self.small.get_linesize() + S(2)
                pygame.draw.line(self.screen, mix(C["border"], C["panel"], 0.45),
                                 (x0, line_y), (body.right, line_y))
            cy += title_h
            for h, kind, data in items:
                if self.settings_focus and kind in ("slider", "opts") and data[0] == self.settings_focus:
                    pygame.draw.rect(self.screen, mix(C["panel"], C["hdr"], 0.13),   # 就是这一项：淡色高亮
                                     pygame.Rect(x0 - S(4), cy - S(2), body.w, h), border_radius=S(6))
                if kind == "hint":
                    self.screen.blit(utext(self.small, ellipsize(self.small, data, body.w - PAD), C["dim"]),
                                     (x0, cy))
                elif kind == "secret":
                    self.draw_key_row(body, x0, cy, label_w, mouse)
                elif kind == "topbtns":
                    self.draw_top_button_row(data, x0, cy, mouse, body)
                elif kind == "slider":
                    self.draw_slider_row(data, x0, cy, label_w, mouse, body)
                elif kind == "link":
                    self.draw_link_row(data, x0, cy, mouse, body)
                else:
                    self.draw_option_row(data, x0, cy, label_w, mouse, body)
                cy += h
            cy += S(10)
        self.screen.set_clip(None)

        self.settings_sb_rect = pygame.Rect(0, 0, 0, 0)
        if self.settings_scroll_max > 0:               # 右侧滚动条（可拖）
            track = pygame.Rect(rect.right - sb_w - S(1), clip.y, sb_w, clip.h)
            pygame.draw.rect(self.screen, mix(C["border"], C["panel"], 0.4), track, border_radius=S(4))
            vis = max(S(30), clip.h * clip.h // max(1, total))
            top = clip.y + (clip.h - min(clip.h, vis)) * self.settings_scroll // max(1, self.settings_scroll_max)
            knob = pygame.Rect(track.x, top, sb_w, min(clip.h, vis))
            pygame.draw.rect(self.screen, C["scroll"], knob, border_radius=S(4))
            self.settings_sb_rect = pygame.Rect(track.x - S(4), track.y, sb_w + S(4), track.h)

        if self.settings_open_dd and self.settings_dd_pending:      # 展开的下拉选项（画在最上面）
            self.draw_settings_dropdown(mouse, body)

        if self.settings_value_edit is not None:       # 数值输入框：贴在面板底部，不随滚动
            box = pygame.Rect(rect.x + PAD, rect.bottom - S(42), max(S(120), rect.w - PAD * 2), S(34))
            pygame.draw.rect(self.screen, C["input_bg"], box, border_radius=S(6))
            pygame.draw.rect(self.screen, C["input_focus"], box, S(2), border_radius=S(6))
            text = self.settings_edit_text or lang("settings_edit_hint")
            t = utext(self.small, ellipsize(self.small, text, box.w - S(16)),
                      C["text"] if self.settings_edit_text else C["dim"])
            self.screen.set_clip(box.inflate(-S(4), 0))
            self.screen.blit(t, (box.x + S(8), box.y + (box.h - t.get_height()) // 2))
            self.screen.set_clip(None)
            if self.settings_edit_err:
                e = utext(self.small, self.settings_edit_err, C["del"])
                self.screen.blit(e, (box.x, box.y - self.small.get_linesize() - S(2)))

    def small_button(self, r, text, on: bool, mouse, kind: str, value) -> None:
        """设置面板里的小按钮（分段按钮 / − + / ✎ / 顶栏开关共用）。"""
        color = C["input_focus"] if on else \
            (mix(C["btn"], C["hdr"], 0.12) if r.collidepoint(mouse) else C["btn"])
        pygame.draw.rect(self.screen, color, r, border_radius=S(8))
        t = utext(self.small, text, C["on_text"] if on else C["text"])
        self.screen.blit(t, t.get_rect(center=r.center))
        self.settings_rects.append((r, kind, value))

    def draw_setting_label(self, key, entry, x0, y, label_w) -> None:
        shift = S(20)                                   # 左边留出自绘图标的位置（所有行一样宽，对齐）
        kind = glyph_kind(entry.get("icon", ""))
        if kind:
            gs = max(10, self.small.get_linesize())
            Glyph(kind, gs).render(self.screen, pygame.Rect(x0, y + S(3), gs, gs), C["dim"])
        label = ellipsize(self.font, setting_label(key, entry), label_w - S(16) - shift)
        self.screen.blit(utext(self.font, label, C["text"]), (x0 + shift, y + S(6)))

    def draw_slider_row(self, data, x0, y, label_w, mouse, body) -> None:
        """滑杆一行：− 滑轨 + 当前值 ✎（按住滑轨拖动实时预览）。"""
        key, entry = data
        self.draw_setting_label(key, entry, x0, y, label_w)
        opts = entry["options"](self)
        cur = self.settings.get(key)
        bw, bh = S(26), S(26)
        right = body.right - S(12)
        edit_r = pygame.Rect(right - bw, y + S(9), bw, bh)
        num_r = pygame.Rect(edit_r.x - S(8) - S(84), y + S(9), S(84), bh)
        minus_r = pygame.Rect(x0 + label_w, y + S(9), bw, bh)
        plus_r = pygame.Rect(num_r.x - S(8) - bw, y + S(9), bw, bh)
        track = pygame.Rect(minus_r.right + S(8), y + S(9) + bh // 2 - S(4),
                            max(S(30), plus_r.x - S(8) - (minus_r.right + S(8))), S(9))
        vals = [v for _, v in opts]
        idx = next((i for i, v in enumerate(vals) if v == cur), 0)
        pygame.draw.rect(self.screen, mix(C["border"], C["dim"], 0.4), track, border_radius=S(4))
        pos = 0.0 if len(vals) < 2 else idx / (len(vals) - 1)
        kx = track.x + int(track.w * pos)
        pygame.draw.circle(self.screen, C["input_focus"], (kx, track.centery), S(7))
        self.settings_slider_rect[key] = (track, opts)
        self.settings_rects.append((track.inflate(S(10), S(22)), "slider", key))
        for r, text, kind in ((minus_r, "−", "minus"), (plus_r, "+", "plus")):
            pygame.draw.rect(self.screen, mix(C["btn"], C["hdr"], 0.12) if r.collidepoint(mouse) else C["btn"],
                             r, border_radius=S(8))
            t = utext(self.font, text, C["text"])
            self.screen.blit(t, t.get_rect(center=r.center))
            self.settings_rects.append((r, kind, key))
        t = utext(self.small, ellipsize(self.small, ui_value_text(self, key, cur), num_r.w), C["dim"])
        self.screen.blit(t, t.get_rect(center=num_r.center))
        self.settings_rects.append((num_r, "num", key))
        self.small_button(edit_r, "✎", False, mouse, "num", key)

    def draw_option_row(self, data, x0, y, label_w, mouse, body) -> None:
        """普通一行：选项不超过 6 个就用分段按钮，超过就变成下拉点选；最右边统一一个 ✎。"""
        key, entry = data
        self.draw_setting_label(key, entry, x0, y, label_w)
        opts = entry["options"](self)
        cur = self.settings.get(key)
        edit_r = pygame.Rect(body.right - S(12) - S(26), y + S(7), S(26), S(32))
        avail = edit_r.x - S(8)
        x = x0 + label_w
        if len(opts) <= 6:
            for text, value in opts:
                w = min(self.small.size(text)[0] + S(22), max(S(40), avail - x))
                if w < S(30):
                    break
                r = pygame.Rect(x, y + S(7), w, S(32))
                self.small_button(r, ellipsize(self.small, text, w - S(12)), value == cur, mouse,
                                  "set", (key, value))
                x += w + S(8)
                if x >= avail:
                    break
        else:
            w = min(S(220), max(S(60), avail - x))
            r = pygame.Rect(x, y + S(7), w, S(32))
            text = ui_value_text(self, key, cur) + "  ▼"
            self.small_button(r, ellipsize(self.small, text, w - S(12)), self.settings_open_dd == key,
                              mouse, "dd_open", key)
            if self.settings_open_dd == key:
                self.settings_dd_pending = (key, r, opts, body)
        self.small_button(edit_r, "✎", False, mouse, "num", key)

    def draw_top_button_row(self, choices, x0, y, mouse, body) -> None:
        """顶栏分组：每个顶栏按钮一个开关（停止按钮不允许隐藏）。没按钮就什么都不画。"""
        if not choices:
            return
        hidden = self.settings.get("top_hidden", []) or []
        avail = body.right - S(12)
        x = x0
        for name, text in choices:
            w = self.small.size(text)[0] + S(22)
            if x + w > avail:
                break
            r = pygame.Rect(x, y + S(4), w, S(30))
            self.small_button(r, text, name not in hidden or name == "stop", mouse, "topbtn", name)
            x += w + S(8)

    def draw_link_row(self, data, x0, y, mouse, body) -> None:
        """整行一个按钮：跳到实时拖动布局 / 换 API key。"""
        act, text = data
        r = pygame.Rect(x0, y + S(2), max(S(60), body.w - PAD * 2), S(32))
        base = C["btn_on"] if act == "live_layout" else C["btn"]
        pygame.draw.rect(self.screen, mix(base, C["hdr"], 0.15) if r.collidepoint(mouse) else base,
                         r, border_radius=S(8))
        t = utext(self.small, ellipsize(self.small, text, r.w - S(12)), C["on_text"] if act == "live_layout"
                  else C["text"])
        self.screen.blit(t, t.get_rect(center=r.center))
        self.settings_rects.append((r, "link", (act, text)))

    def draw_settings_dropdown(self, mouse, bounds) -> None:
        """选项超过 6 个时的下拉列表（画在内容上面，点一项就生效并收起）；超过内容区就贴边。"""
        key, r, opts, _body = self.settings_dd_pending
        h = S(30)
        box = pygame.Rect(r.x, r.bottom + S(2), r.w, h * len(opts))
        if box.bottom > bounds.bottom:      # 下面放不下就翻到上面，贴着内容区
            box.y = max(bounds.y, min(r.y - box.h - S(2), bounds.bottom - box.h))
        self.screen.set_clip(bounds)
        pygame.draw.rect(self.screen, C["modal"], box, border_radius=S(6))
        pygame.draw.rect(self.screen, C["input_border"], box, 1, border_radius=S(6))
        cur = self.settings.get(key)
        dd_rects = []
        for i, (text, value) in enumerate(opts):
            ir = pygame.Rect(box.x + S(2), box.y + i * h, box.w - S(4), h)
            if value == cur:
                pygame.draw.rect(self.screen, C["input_focus"], ir, border_radius=S(6))
            elif ir.collidepoint(mouse):
                pygame.draw.rect(self.screen, mix(C["btn"], C["hdr"], 0.12), ir, border_radius=S(6))
            t = utext(self.small, ellipsize(self.small, text, ir.w - S(12)),
                      C["on_text"] if value == cur else C["text"])
            self.screen.blit(t, t.get_rect(center=ir.center))
            dd_rects.append((ir, "set", (key, value)))
        self.settings_rects = dd_rects + self.settings_rects   # 下拉画在最上面：点击也优先给它
        self.screen.set_clip(None)

    def draw_key_row(self, body, x0, y, label_w, mouse) -> int:
        """设置里的 API key 一行：平时显示打码后的 key 和来源，点 "更换" 变成输入框。返回下一行的 y。"""
        self.screen.blit(utext(self.font, lang("api_key"), C["text"]), (x0, y + S(6)))
        x = x0 + label_w

        def button(text, act, primary=False):
            nonlocal x
            w = self.small.size(text)[0] + S(22)
            r = pygame.Rect(x, y, w, S(32))
            base = C["btn_on"] if primary else C["btn"]
            pygame.draw.rect(self.screen, mix(base, C["hdr"], 0.12) if r.collidepoint(mouse) else base,
                             r, border_radius=S(8))
            t = utext(self.small, text, C["on_text"] if primary else C["text"])
            self.screen.blit(t, t.get_rect(center=r.center))
            self.settings_rects.append((r, "apikey", act))
            x += w + S(8)

        if self.key_edit is None:
            t = utext(self.small, ellipsize(self.small, api_key_text(), max(S(40), body.w - label_w - S(220))),
                      C["text"])
            self.screen.blit(t, (x, y + S(7)))
            x += t.get_width() + S(14)
            button(lang("change"), "edit")
            from lib_a.config import key_source
            if key_source() == "custom":                # 有加密保存的 key 才能清空
                armed = time.time() < getattr(self, "key_clear_armed", 0)
                button(lang("clear_key_confirm") if armed else lang("clear_key"), "clear", primary=armed)
        else:
            box = pygame.Rect(x, y, max(S(120), body.right - S(12) - x - S(140)), S(32))
            pygame.draw.rect(self.screen, C["input_bg"], box, border_radius=S(6))
            pygame.draw.rect(self.screen, C["input_focus"], box, S(2), border_radius=S(6))
            k = self.key_edit                          # 只露出最后 4 位，截图也不会把 key 带出去
            shown = ("•" * min(len(k) - 4, 40) + k[-4:]) if len(k) > 4 else "•" * len(k)
            t = utext(self.small, shown, C["text"])
            self.screen.set_clip(box.inflate(-S(12), 0))
            self.screen.blit(t, (box.x + S(8), box.y + (box.h - t.get_height()) // 2))
            self.screen.set_clip(None)
            if pygame.time.get_ticks() // 500 % 2 == 0:
                cx = min(box.right - S(8), box.x + S(10) + t.get_width())
                pygame.draw.line(self.screen, C["text"], (cx, box.y + S(7)), (cx, box.bottom - S(7)), S(2))
            x = box.right + S(8)
            button(lang("try_saving") if self.key_checking else lang("save"), "save", primary=True)
            button(lang("cancel"), "cancel")
        y += S(38)
        text, color = self.key_msg
        if text:
            avail = max(S(40), body.right - x0 - label_w)
            self.screen.blit(utext(self.small, ellipsize(self.small, text, avail),
                                   C.get(color, C["dim"])), (x0 + label_w, y))
        return y + self.small.get_linesize() + S(14)

    # ---------------- 独立员工栏窗口（投影技术） ----------------

    # 通用面板窗口框架：按 key 分发（state 在 self.panel_windows[key] 里），7 个面板都接了。

    PANEL_WINDOW_KEYS = ["staff", "screen", "economy", "task_queue", "flow", "write", "board", "tree"]   # 外接模块读进来会追加在后面

    def _panel_win_state_on(self, key):
        """取这个 key 的面板窗口状态；没开着返回 None。"""
        return (getattr(self, "panel_windows", None) or {}).get(key) or None

    def panel_window_open(self, key) -> bool:
        """这个 key 的面板独立窗口现在开着没（通用入口）。"""
        return self._panel_win_state_on(key) is not None

    def open_panel_window(self, key, anchor=None, size=None) -> bool:
        """按 key 把面板拖出成独立窗口：staff 走原来的员工栏开窗，其余走通用开窗。"""
        if key == "staff":
            return self._open_panel_window_staff(anchor=anchor)
        if key in self.PANEL_WINDOW_KEYS:
            return self._open_panel_window_generic(key, anchor=anchor, size=size)
        return False

    def close_panel_window(self, key, dock: bool = False) -> bool:
        """按 key 收起面板独立窗口（dock=True 是归位到栏里）：staff 走原来的员工栏收窗。"""
        if key == "staff":
            return self._close_panel_window_staff(dock=dock)
        if key in self.PANEL_WINDOW_KEYS:
            return self._close_panel_window_generic(key, dock=dock)
        return False

    def draw_panel_window(self, key) -> bool:
        """按 key 把面板投影到独立窗口：staff 走原来的员工栏投影，其余走通用投影。"""
        if key == "staff":
            return self._draw_panel_window_staff()
        if key in self.PANEL_WINDOW_KEYS:
            return self._draw_panel_window_generic(key)
        return False

    def open_staff_window(self, anchor=None) -> bool:
        """把员工栏拖出成独立窗口（key='staff' 的特例）。"""
        return self.open_panel_window("staff", anchor=anchor)

    def close_staff_window(self, dock: bool = False):
        """收起独立员工栏窗口（key='staff' 的特例）。"""
        self.close_panel_window("staff", dock=dock)

    def draw_staff_window(self):
        """投影独立员工栏窗口（key='staff' 的特例）。"""
        self.draw_panel_window("staff")

    def _open_panel_window_staff(self, anchor=None) -> bool:
        """staff 的实际开窗：窗口只做渲染投影，滚动 / 点击仍归主窗口的状态处理。"""
        if getattr(self, "staff_win_open", False):
            return True
        old = getattr(self, "staff_win", None)
        if old is not None:
            try:
                old.destroy()
            except Exception:
                pass
            self.staff_win = None
        try:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            desk_w, desk_h = int(desk_w), int(desk_h)
        except Exception:
            desk_w, desk_h = 1920, 1080
        w = S(STAFF_WIN_SIZE[0])
        h = max(S(200), min(S(STAFF_WIN_SIZE[1]), desk_h - S(80)))
        main_pos = self._main_window_pos()
        if anchor is not None:                     # 拖出来的：窗口跟着松手的位置
            pos = (int(anchor[0]), int(anchor[1]))
        elif main_pos is not None:                 # 默认放在主窗口左边
            pos = (int(main_pos[0]) - w - S(12), int(main_pos[1]) + S(48))
        else:
            pos = None
        if pos is not None:
            pos = (max(0, min(pos[0], max(0, desk_w - w))), max(0, min(pos[1], max(0, desk_h - h))))
        try:
            self.staff_win = PanelWindow(f"{lang('staff')} · Terminist", (w, h), pos)
        except Exception as ex:
            self.staff_win = None
            self.add("info", f"员工栏独立窗口建不了：{ex}")
            return False
        self.staff_win_open = True
        self.panel_windows["staff"] = {"win": self.staff_win, "open": True, "key": "staff"}
        self.staff_drag, self.staff_ghost = None, None
        self.staff_win_mouse = None
        self.staff_win_rects, self.staff_win_menu_rects = [], []
        hwnd = self.staff_win.hwnd()
        if hwnd:
            self._screen_win32(hwnd)               # 去掉系统标题栏 / 边框，自己画标题条
        self._staff_win_on_top()
        self.add("info", lang("staff_detached_on"))
        self.mark_dirty()
        self.draw_panel_window("staff")
        return True

    def _close_panel_window_staff(self, dock: bool = False):
        """staff 的实际收窗：员工栏回到左栏原位（dock=True 是拖回来 / 点虚影归位）。"""
        pw = getattr(self, "staff_win", None)
        if pw is not None:
            try:
                pw.destroy()
            except Exception:
                pass
        self.staff_win = None
        self.staff_win_open = False
        self.panel_windows.pop("staff", None)      # 状态清干净，别留脏数据
        self.staff_win_rects, self.staff_win_menu_rects = [], []
        self.staff_win_mouse = None
        self.staff_win_area = pygame.Rect(0, 0, 0, 0)
        self.staff_drag, self.staff_ghost = None, None
        if dock:
            self.add("info", lang("staff_detached_off"))
        self.mark_dirty()

    def _staff_win_on_top(self) -> bool:
        """独立员工栏窗口置顶（失败就算了，不影响功能）。"""
        pw = getattr(self, "staff_win", None)
        hwnd = pw.hwnd() if pw is not None else 0
        if not hwnd or sys.platform != "win32":
            return False
        try:
            import ctypes
            HWND_TOPMOST, SWP_NOSIZE, SWP_NOMOVE, SWP_SHOWWINDOW = -1, 0x0001, 0x0002, 0x0040
            return bool(ctypes.windll.user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                                                          SWP_NOSIZE | SWP_NOMOVE | SWP_SHOWWINDOW))
        except Exception:
            return False

    # ------------- 通用面板独立窗口（staff 之外 6 个面板，多窗口 chrome 按 key 存矩形） -------------

    def _set_panel_drag(self, key, start):
        """开始 / 结束一次标题条拖拽；staff_drag、staff_ghost 跟着同步（老代码还读它们）。"""
        if key is None:
            self.panel_drag = None
            self.panel_ghost = None
            self.panel_ghost_key = None
        else:
            self.panel_drag = (key, tuple(start), False)
            self.panel_ghost = None
            self.panel_ghost_key = None
        self._staff_compat_sync()

    def _staff_compat_sync(self):
        """把 panel_drag / panel_ghost 的 staff 部分同步到老的 staff_drag / staff_ghost（兼容别名）。"""
        pd = getattr(self, "panel_drag", None)
        if isinstance(pd, (tuple, list)) and len(pd) == 3 and pd[0] == "staff":
            d = self.__dict__
            d["staff_drag"] = (pd[1], bool(pd[2]))
            d["staff_ghost"] = getattr(self, "panel_ghost", None) if pd[2] else None
        else:
            d = self.__dict__
            d["staff_drag"] = None
            d["staff_ghost"] = None

    def __setattr__(self, name, value):
        """staff_drag / staff_ghost 是 panel_drag / panel_ghost 的兼容别名，别真存成两个字段。"""
        d = self.__dict__
        if name == "staff_drag":
            pd = d.get("panel_drag")
            if value is None:
                d["panel_drag"] = None
                d["_staff_drag_synced"] = False
            elif isinstance(pd, (tuple, list)) and len(pd) == 3 and pd[0] == "staff":
                d["panel_drag"] = ("staff", value[0], bool(value[1]))
            else:
                d["panel_drag"] = ("staff", value[0], bool(value[1]))
                d["_staff_drag_synced"] = False
            return
        if name == "staff_ghost":
            if value is not None:
                d["panel_ghost"] = value
                d["panel_ghost_key"] = "staff"
            elif d.get("panel_ghost_key") in (None, "staff"):
                d["panel_ghost"] = None
                d["panel_ghost_key"] = None
            return
        object.__setattr__(self, name, value)

    def __getattr__(self, name):
        """staff_drag / staff_ghost 惰性从 panel_drag / panel_ghost 读（第二批次后只有一个真字段）。"""
        d = self.__dict__
        if name == "staff_drag":
            pd = d.get("panel_drag")
            if isinstance(pd, (tuple, list)) and len(pd) == 3 and pd[0] == "staff":
                return (pd[1], bool(pd[2]))
            return None
        if name == "staff_ghost":
            return d.get("panel_ghost") if d.get("panel_ghost_key") in (None, "staff") else None
        if name in ("on_open_settings", "open_settings"):   # 类里前面那个 __getattr__ 被这个盖掉了：兼容旧名字合到这里
            return lambda *_a, **_k: self.open_settings_panel("show")
        raise AttributeError(name)

    def __getattribute__(self, name):
        """读 staff_drag / staff_ghost 直接映射到 panel_drag / panel_ghost（兼容别名，真字段只有一个）。"""
        if name == "staff_drag" or name == "staff_ghost":
            d = object.__getattribute__(self, "__dict__")
            if name == "staff_drag":
                pd = d.get("panel_drag")
                if isinstance(pd, (tuple, list)) and len(pd) == 3 and pd[0] == "staff":
                    return (pd[1], bool(pd[2]))
                return None
            return d.get("panel_ghost") if d.get("panel_ghost_key") in (None, "staff") else None
        return object.__getattribute__(self, name)

    def _panel_head_at(self, pos):
        """这个位置压在哪个面板的标题条上（先看开着的独立窗口，再看主窗口那一栏）。返回 key 或 None。"""
        if pos is None:
            return None
        for key, st in (getattr(self, "panel_windows", None) or {}).items():
            if key == "staff" or not isinstance(st, dict):
                continue
            for name in ("close_rect", "title_rect"):       # 每块窗口各按自己的 key 取矩形
                r = st.get(name)
                if isinstance(r, pygame.Rect) and r.w > 0 and r.collidepoint(pos):
                    return key
        heads = getattr(self, "panel_heads", None) or {}
        for key in self.PANEL_WINDOW_KEYS:
            if key != "staff" and self.panel_window_open(key):
                continue                                    # 已经拖出去了：主窗口这边不再是拖拽来源
            r = heads.get(key)
            if isinstance(r, pygame.Rect) and r.w > 0 and r.h > 0 and r.collidepoint(pos):
                return key
        return None

    def _panel_ghost_to(self, key, pos):
        """拖动时的虚影跟着鼠标走：大小取被拖块在这一帧的矩形，拿不到给个默认。"""
        r = (getattr(self, "panel_heads", None) or {}).get(key)
        if not isinstance(r, pygame.Rect) or r.w <= 0 or r.h <= 0:
            r = pygame.Rect(0, 0, S(200), S(64))
        box = pygame.Rect(0, 0, max(S(120), r.w), max(S(48), r.h))
        box.center = pos
        self.panel_ghost_key = key
        self.panel_ghost = box

    def _panel_body_spec(self, key, area: pygame.Rect):
        """这个面板投影时该画哪一块：返回 (画法, rect, 标题) ；没接的不投影（返回 None）。"""
        if key not in ("screen", "flow", "write", "board", "tree", "economy"):
            return None
        return ("content", pygame.Rect(area), str(panels.PANELS[key]["title"]))

    def _panel_win_close_hit(self, key, pos) -> bool:
        """点没点在这个 key 的独立窗口的关闭按钮上（按 key 取各自的 close_rect）。"""
        st = self._panel_win_state_on(key)
        if not isinstance(st, dict) or not pos:
            return False
        r = st.get("close_rect")
        return bool(isinstance(r, pygame.Rect) and r.w > 0 and r.collidepoint(pos))

    def _open_panel_window_generic(self, key, anchor=None, size=None) -> bool:
        """非 staff 面板的实际开窗：建 PanelWindow，state 全存在 self.panel_windows[key] 里。"""
        st = self._panel_win_state_on(key)
        if isinstance(st, dict) and st.get("open"):
            return True
        if isinstance(st, dict):                        # 有残留状态先清掉，别留脏窗口
            self._close_panel_window_generic(key, dock=False)
        old = (self.panel_windows or {}).get(key) or {}
        pw_old = old.get("win") if isinstance(old, dict) else None
        if pw_old is not None:
            try:
                pw_old.destroy()
            except Exception:
                pass
        try:
            desk_w, desk_h = pygame.display.get_desktop_sizes()[0]
            desk_w, desk_h = int(desk_w), int(desk_h)
        except Exception:
            desk_w, desk_h = 1920, 1080
        head = (getattr(self, "panel_heads", None) or {}).get(key)
        if isinstance(head, pygame.Rect) and head.w > 0:
            w = max(S(260), min(S(440), head.w))
        else:
            w = S(360)
        h = max(S(240), min(S(460), desk_h - S(80)))
        if isinstance(size, (tuple, list)) and len(size) == 2:   # 调用方指定了尺寸（接管模式要 300x420）
            w, h = max(S(120), int(size[0])), max(S(120), int(size[1]))
        main_pos = self._main_window_pos()
        if anchor is not None:                          # 拖出来的：窗口跟着松手的位置
            pos = (int(anchor[0]), int(anchor[1]))
        elif main_pos is not None:
            pos = (int(main_pos[0]) + S(48), int(main_pos[1]) + S(96))
        else:
            pos = None
        if pos is not None:
            pos = (max(0, min(pos[0], max(0, desk_w - w))), max(0, min(pos[1], max(0, desk_h - h))))
        title = f"{panels.PANELS[key]['title']} · Terminist"
        try:
            win = PanelWindow(title, (w, h), pos)
        except Exception as ex:
            self.add("info", f"{panels.PANELS[key]['title']}独立窗口建不了：{ex}")
            return False
        if not isinstance(getattr(self, "panel_windows", None), dict):
            self.panel_windows = {}
        self.panel_windows[key] = {"win": win, "open": True, "key": key,
                                   "close_rect": pygame.Rect(0, 0, 0, 0),     # 每个 key 各存一份，别用全局单值
                                   "title_rect": pygame.Rect(0, 0, 0, 0),
                                   "mouse": None}
        hwnd = win.hwnd()
        if hwnd:
            self._screen_win32(hwnd)                    # 去掉系统标题栏 / 边框，自己画标题条
        self._set_panel_drag(None, None)
        self.add("info", f"{panels.PANELS[key]['title']}已拖出成独立窗口")
        self.mark_dirty()
        self.draw_panel_window(key)
        return True

    def _close_panel_window_generic(self, key, dock: bool = False) -> bool:
        """非 staff 面板的实际收窗：销毁窗口、把这一份 state 清干净。"""
        st = self._panel_win_state_on(key)
        if not isinstance(st, dict):
            return False
        pw = st.get("win")
        if pw is not None:
            try:
                pw.destroy()
            except Exception:
                pass
        (self.panel_windows or {}).pop(key, None)
        self.mark_dirty()
        return True

    def _panel_win_event_mine(self, key, e):
        """这个事件是不是 key 的独立窗口发来的；不是返回 None，是就返回 key。"""
        st = self._panel_win_state_on(key)
        if not isinstance(st, dict):
            return None
        pw = st.get("win")
        if pw is None:
            return None
        w = getattr(e, "window", None)
        if w is None:
            return None                                 # 认不出来就不抢，交给主窗口
        try:
            if int(w) == int(pw.id()):
                return key
        except Exception:
            pass
        try:
            if w is pw or w is getattr(pw, "win", None):
                return key
        except Exception:
            pass
        return None

    def handle_panel_windows(self, e):
        """非 staff 面板独立窗口的事件：关闭 / Esc 都走 close_panel_window(key)。"""
        states = getattr(self, "panel_windows", None) or {}
        if not states:
            return None
        key = None
        for k in self.PANEL_WINDOW_KEYS:
            if k == "staff":
                continue
            key = self._panel_win_event_mine(k, e)
            if key:
                break
        if not key:
            return None
        if e.type == pygame.WINDOWCLOSE:
            self.close_panel_window(key)                # 系统把这个窗口关了
            return True
        if e.type in (pygame.WINDOWRESIZED, pygame.WINDOWSIZECHANGED):
            self.draw_panel_window(key)
            return True
        if key == "screen":                             # 拖出去的小浏览器：照样能点、滚、打字（Esc 先退出打字）
            st = self._panel_win_state_on(key)
            bar = st.get("title_rect") if isinstance(st, dict) else None
            on_bar = isinstance(bar, pygame.Rect) and getattr(e, "pos", None) is not None and bar.collidepoint(e.pos)
            if not on_bar and self._web_event(e, "win", mouse=st.get("mouse") if isinstance(st, dict) else None):
                if e.type == pygame.MOUSEMOTION and isinstance(st, dict):
                    st["mouse"] = e.pos
                self.draw_panel_window(key)
                return True
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.close_panel_window(key)                # 窗口里按 Esc：关掉
            return True
        if e.type in (pygame.KEYDOWN, pygame.KEYUP, pygame.TEXTINPUT, pygame.TEXTEDITING):
            return True                                 # 窗口里别的按键不往主窗口输入框里塞字
        pos = getattr(e, "pos", None)
        if e.type == pygame.MOUSEMOTION:
            st = self._panel_win_state_on(key)
            if isinstance(st, dict):
                st["mouse"] = pos
            self.draw_panel_window(key)
            return True
        if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            if e.type == pygame.MOUSEBUTTONDOWN and getattr(e, "button", 0) == 1:
                if self._panel_win_close_hit(key, pos):  # 只比这个 key 自己的 close_rect
                    self.close_panel_window(key)
                    return True
                st = self._panel_win_state_on(key)
                bar = st.get("title_rect") if isinstance(st, dict) else None
                if isinstance(bar, pygame.Rect) and bar.w > 0 and bar.collidepoint(pos):
                    pw = st.get("win")
                    if pw is not None:
                        self._begin_win_drag(key, pw)  # 自己拖：每帧跟鼠标走，拖到哪一侧那一侧的栏滑出来
            return True
        if e.type == pygame.MOUSEWHEEL:
            return True
        return None

    def _draw_panel_window_generic(self, key) -> bool:
        """非 staff 面板的投影：切 self.screen 到窗口 surf 画标题条 + 内容，画完还原命中矩形再 flip。"""
        st = self._panel_win_state_on(key)
        if not isinstance(st, dict) or not st.get("open"):
            return False
        pw = st.get("win")
        if pw is None:
            return False
        w, h = pw.size()
        if w <= 0 or h <= 0:
            return False
        real = self.screen
        saved = (dict(getattr(self, "panel_heads", None) or {}),
                 getattr(self, "log_rects", None), getattr(self, "flow_rects", None),
                 getattr(self, "spot_rects", None), getattr(self, "tree_rects", None),
                 getattr(self, "write_rect", None), getattr(self, "flow_rect", None),
                 getattr(self, "panel_close_rect", None), getattr(self, "board_rect", None),
                 getattr(self, "board_img_rect", None), getattr(self, "board_hide_rect", None))
        try:
            surf = pygame.Surface((w, h))
            surf.fill(C["panel"])
            rad = STAFF_WIN_RADIUS
            panel = pygame.Rect(1, 1, max(0, w - 2), max(0, h - 2))
            pygame.draw.rect(surf, C["panel"], panel, border_radius=rad)
            title_h = min(S(STAFF_WIN_TITLE_H), max(0, h // 4))
            area = pygame.Rect(panel.x, panel.y + title_h,
                               max(0, panel.w), max(0, panel.h - title_h))
            self.screen = surf
            if area.w > 8 and area.h > 8:
                self._panel_body_of(key, area)
            self.screen = real
            pygame.draw.rect(surf, C["border"], panel, S(1), border_radius=rad)
            self._panel_win_chrome(key, surf, (w, h), title_h)
            pw.blit(surf, (0, 0))
            pw.flip()                                    # SDL 窗口表面要自己 flip 才上屏
            return True
        except Exception:
            self.screen = real
            return False
        finally:
            (self.panel_heads or {}).clear()
            self.panel_heads.update(saved[0])
            if saved[1] is not None:
                self.log_rects = saved[1]
            if saved[2] is not None:
                self.flow_rects = saved[2]
            if saved[3] is not None:
                self.spot_rects = saved[3]
            if saved[4] is not None:
                self.tree_rects = saved[4]
            if saved[5] is not None:
                self.write_rect = saved[5]
            if saved[6] is not None:
                self.flow_rect = saved[6]
            if saved[7] is not None:
                self.panel_close_rect = saved[7]
            if saved[8] is not None:
                self.board_rect = saved[8]
            if saved[9] is not None:
                self.board_img_rect = saved[9]
            if saved[10] is not None:
                self.board_hide_rect = saved[10]

    def _panel_body_of(self, key, area: pygame.Rect):
        """在投影窗口的 surface 上画这个面板对应的一块（各面板按自己那块内容的画法投影）。"""
        try:
            sub = pygame.Rect(area.x, area.y + S(STAFF_WIN_TITLE_H), max(0, area.w),
                              max(0, area.h - S(STAFF_WIN_TITLE_H)))
            if sub.w < 40 or sub.h < 40:
                return
            if key == "screen":
                self.draw_screen_window_to(self.screen, sub)
            elif key == "flow":
                self.draw_flow(sub, panels.PANELS[key]["title"])
            elif key == "write":
                self.draw_panel(sub)
            elif key == "board":
                self.draw_board(sub, panels.PANELS[key]["title"])
            elif key == "tree":
                self.draw_tree(sub, panels.PANELS[key]["title"])
            elif key == "economy":
                self.draw_economy(sub)
            elif key == "task_queue":
                self.draw_goal_queue(sub)
            elif modules_api.get(key):                 # 外接模块拖成了独立窗口
                self._draw_plugin_body(key, sub)
        except Exception:
            pass

    def draw_screen_window_to(self, surf, area: pygame.Rect):
        """把网页画面投影到指定 surface 的指定区域（独立窗口内容用，不碰主窗口命中区）。"""
        area = pygame.Rect(area)
        if area.w <= 0 or area.h <= 0:
            return
        pygame.draw.rect(surf, C["panel"], area)
        self.update_screen_view(area)                  # 拖出去的窗口也要自己取新画面（以前这里只画旧图）
        st = self._panel_win_state_on("screen")
        mouse = st.get("mouse") if isinstance(st, dict) else None
        self._draw_web(surf, area, "win", mouse=mouse or (-1, -1))

    def _panel_win_chrome(self, key, surf, size, title_h: int):
        """通用面板窗口的自绘标题条：标题 + 右下角「关闭」按钮，矩形按 key 存进 self.panel_windows[key]。"""
        st = self._panel_win_state_on(key)
        if not isinstance(st, dict):
            return
        w, h = size
        st["title_rect"] = pygame.Rect(1, 1, max(0, w - 2), title_h)
        label = utext(self.small, "关闭", C["dim"])
        btn = label.get_rect()
        btn.inflate_ip(S(12), S(4))
        btn.topright = (w - S(6), 1 + max(0, (title_h - btn.h) // 2))
        st["close_rect"] = pygame.Rect(btn)
        pygame.draw.rect(surf, mix(C["panel"], C["hdr"], 0.45), st["title_rect"],
                         border_top_left_radius=STAFF_WIN_RADIUS, border_top_right_radius=STAFF_WIN_RADIUS)
        hover = st.get("mouse")
        if hover and btn.collidepoint(hover):
            pygame.draw.rect(surf, mix(C["panel"], C["hdr"], 0.95), btn, border_radius=S(4))
        surf.blit(utext(self.small, "关闭", C["text"] if hover and btn.collidepoint(hover) else C["dim"]),
                  label.get_rect(center=btn.center))
        try:
            title = str(panels.PANELS[key]["title"])
        except Exception:
            title = str(key)
        text = ellipsize(self.small, title, max(0, btn.x - S(12)))
        t = utext(self.small, text, C["dim"])
        surf.blit(t, (S(8), max(0, (title_h - t.get_height()) // 2)))


    def _hwnd_rect(self, hwnd):
        """取某个窗口在桌面上的矩形（win32 才拿得到，拿不到返回 None）。"""
        if sys.platform != "win32" or not hwnd:
            return None
        try:
            import ctypes

            class _R(ctypes.Structure):
                _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long),
                            ("r", ctypes.c_long), ("b", ctypes.c_long)]
            r = _R()
            if not ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r)):
                return None
            return pygame.Rect(int(r.l), int(r.t), int(r.r - r.l), int(r.b - r.t))
        except Exception:
            return None

    def _main_window_pos(self):
        """主窗口在桌面上的左上角（拿不到返回 None）。"""
        try:
            hwnd = int(pygame.display.get_wm_info().get("window", 0) or 0)
            r = self._hwnd_rect(hwnd)
            if r is not None:
                return (r.x, r.y)
        except Exception:
            pass
        try:
            return tuple(self.window_pos())
        except Exception:
            return None

    def _staff_event_mine(self, e) -> bool:
        """这个事件是不是独立员工窗口来的：按窗口对象 / 窗口 id 认，认不出来再按前台窗口兜底。"""
        pw = getattr(self, "staff_win", None)
        if pw is None:
            return False
        try:
            w = getattr(e, "window", None)
        except Exception:
            w = None
        if w is not None:
            try:
                if w is pw or w is getattr(pw, "win", None):
                    return True
                wid, pid = getattr(w, "id", None), pw.id()
                return wid is not None and pid is not None and int(wid) == int(pid)
            except Exception:
                return False
        return self._staff_foreground()             # 事件不带 window 字段：按前台窗口兜底

    def _staff_foreground(self) -> bool:
        """兜底：独立员工窗口现在是前台窗口就当事件是它的。"""
        pw = getattr(self, "staff_win", None)
        hwnd = pw.hwnd() if pw is not None else 0
        if not hwnd or sys.platform != "win32":
            return False
        try:
            import ctypes
            return int(ctypes.windll.user32.GetForegroundWindow()) == hwnd
        except Exception:
            return False

    def _is_staff_event(self, e) -> bool:
        """这个事件是不是独立员工栏窗口发来的。"""
        try:
            return bool(getattr(self, "staff_win_open", False)) and self._staff_event_mine(e)
        except Exception:
            return False

    def _staff_dock_needed(self) -> bool:
        """独立员工窗口是不是被拖回主窗口的左栏 / 右栏上了。"""
        return self._win_dock_zone(getattr(self, "staff_win", None)) is not None

    # ---------------- 自己拖小窗口（拖到哪一侧，那一侧的栏滑出来） ----------------
    @staticmethod
    def _cursor_screen():
        import ctypes
        import ctypes.wintypes as wt
        pt = wt.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y

    @staticmethod
    def _left_button_down() -> bool:
        import ctypes
        return bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)

    def _main_client_origin(self):
        import ctypes
        import ctypes.wintypes as wt
        hwnd = int(pygame.display.get_wm_info().get("window", 0) or 0)
        o = wt.POINT(0, 0)
        ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(o))
        return o.x, o.y

    def _begin_win_drag(self, key, pw):
        """按下小窗口标题条：记下鼠标在窗口里的偏移，之后每帧跟着鼠标挪（_tick_win_drag）。
        不用系统的模态拖动：那样拖动期间整个程序停住，主窗口没法实时把栏滑出来。"""
        if sys.platform != "win32" or pw is None:
            return
        try:
            r = self._hwnd_rect(pw.hwnd())
            cx, cy = self._cursor_screen()
            self.win_drag = {"key": key, "pw": pw, "dx": cx - r.x, "dy": cy - r.y}
        except Exception:
            self.win_drag = None

    def _drag_zone(self):
        """鼠标现在压在主窗口的哪一栏上（栏收着时压在最左 / 最右那条也算）：返回 (side, slot) 或 None。"""
        try:
            cx, cy = self._cursor_screen()
            ox, oy = self._main_client_origin()
        except Exception:
            return None
        side, slot = self._dock_drop_zones((cx - ox, cy - oy))
        return (side, slot) if side else None

    def _tick_win_drag(self):
        """主循环每帧调：拖着的小窗口跟鼠标走；压到哪一侧，那一侧的栏先滑出来（预览）；松手就放进去或者留在原地。"""
        d = getattr(self, "win_drag", None)
        if not d:
            return
        import ctypes
        u = ctypes.windll.user32
        zone = self._drag_zone()
        if not self._left_button_down():                    # 左键松开了：落定
            self.win_drag = None
            self.dock_preview = None
            if zone and self._dock_drop(d["key"], zone):
                self.notice("info", f"{self._dock_title(d['key'])}已放回主窗口")
            self.mark_dirty()
            return
        cx, cy = self._cursor_screen()
        try:
            u.SetWindowPos(d["pw"].hwnd(), 0, cx - d["dx"], cy - d["dy"], 0, 0, 0x0001 | 0x0004 | 0x0010)
        except Exception:
            pass
        side = zone[0] if zone else None
        if side != getattr(self, "dock_preview", None):
            self.dock_preview = side                         # 压到哪一侧：那一侧的栏滑出来（layout 里看这个）
        self._dock_hover = zone
        self.mark_dirty()

    def _tick_modules(self):
        """主循环每帧调：节流到 1 秒一次，给每个带 on_tick 的外接模块一次后台机会（面板没打开也照跑）。

        用来做到点提醒（闹钟、备忘录）：draw 只在面板可见时才跑，这里跟可见性无关。
        单个模块抛异常只吞掉，不影响其他模块和主循环。
        另外每帧（不节流）给带 on_frame(ctx, dt) 的模块一次机会，用来推动惯性和缓动动画。
        """
        try:                                             # 后台回调、on_load、模块请 Agent 做的事、主题变化
            if modules_api.pump(self):                   # modules/ 里的文件改了：自动刷新（边改边看效果）
                self.load_modules(quiet=True)
        except Exception:
            pass
        # 每帧回调 on_frame：不节流，给惯性 / 动画用
        _fnow = pygame.time.get_ticks()
        _fprev = getattr(self, "_modules_frame_at", None)
        _fdt = ((_fnow - _fprev) / 1000.0) if _fprev is not None else 0.016
        _fdt = max(0.0, min(_fdt, 0.25))                 # 卡顿 / 切后台回来别一下跳太多
        self._modules_frame_at = _fnow
        for _fkey in modules_api.keys():
            _fp = modules_api.get(_fkey)
            if _fp and callable(_fp.get("on_frame")):
                # 出错记进 modules/.logs（以前直接吞掉，模块坏了谁也不知道）；要动画的模块自己调 ctx.redraw()，
                # 以前这里每帧都把整个界面标脏重画，有 on_frame 的模块一装上界面就一直满帧空转
                modules_api.call_hook(_fp, "on_frame", _fdt)
        now = pygame.time.get_ticks()
        if now - getattr(self, "_modules_tick_at", 0) < 1000:
            return
        self._modules_tick_at = now
        for key in modules_api.keys():
            p = modules_api.get(key)
            if p and callable(p.get("on_tick")):
                modules_api.call_hook(p, "on_tick")

    def _draw_win_drag_hint(self):
        """拖着小窗口压在左栏 / 右栏上：整栏高亮，中间写「松手放到这里：xx」，看得出松手会放到哪。"""
        d, side = getattr(self, "win_drag", None), getattr(self, "dock_preview", None)
        if not d or side not in ("left", "right"):
            return
        left, _c, right = self.layout()
        col = left if side == "left" else right
        if col.w <= 0:
            return
        box = col.inflate(-S(12), -S(12))
        hl = pygame.Surface(box.size, pygame.SRCALPHA)
        hl.fill((*C["hdr"][:3], 40))
        self.screen.blit(hl, box.topleft)
        pygame.draw.rect(self.screen, C["hdr"], box, S(2), border_radius=S(10))
        t = utext(self.font, f"松手放到这里：{self._dock_title(d['key'])}", C["hdr"])
        self.screen.blit(t, t.get_rect(center=box.center))

    def _win_dock_zone(self, pw):
        """独立小窗口松手时中心落在主窗口哪一栏的哪一格：返回 (side, slot)，不在左右栏上返回 None。
        主窗口常常是最大化的（整个屏幕都是它），所以不能按「落在主窗口上」判断——那样拖到哪都会被收回去；
        只认左栏 / 右栏：拖到聊天区或者主窗口外面就照常浮着。"""
        if pw is None or sys.platform != "win32":
            return None
        try:
            import ctypes
            import ctypes.wintypes as wt
            hwnd = int(pygame.display.get_wm_info().get("window", 0) or 0)
            sub = self._hwnd_rect(pw.hwnd())
            if sub is None:
                x, y = pw.position()
                w, h = pw.size()
                sub = pygame.Rect(x, y, w, h)
            origin = wt.POINT(0, 0)
            ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(origin))   # 主窗口客户区左上角的屏幕坐标
        except Exception:
            return None
        side, slot = self._dock_drop_zones((sub.centerx - origin.x, sub.centery - origin.y))
        return (side, slot) if side else None

    def _win_over_main(self, pw) -> bool:
        """（旧判定，保留给别处用）某个独立小窗口是不是落在主窗口上了（中心点在主窗口里，或重叠超过一半）。"""
        if pw is None:
            return False
        try:
            hwnd = int(pygame.display.get_wm_info().get("window", 0) or 0)
            main = self._hwnd_rect(hwnd)
            sub = self._hwnd_rect(pw.hwnd())
            if sub is None:                        # 拿不到窗口矩形：按 pygame 的位置和尺寸算
                x, y = pw.position()
                w, h = pw.size()
                sub = pygame.Rect(x, y, w, h)
        except Exception:
            return False
        if main is None or not main.w or not main.h or sub.w <= 0 or sub.h <= 0:
            return False
        if main.collidepoint(sub.center):
            return True
        clip = main.clip(sub)
        return bool(clip) and clip.w * clip.h >= sub.w * sub.h // 2

    def _staff_win_wheel(self, e):
        """独立窗口里滚轮：滚的还是主窗口那一份员工列表状态。"""
        area = getattr(self, "staff_win_area", None)
        if not isinstance(area, pygame.Rect) or area.h <= 0:
            return
        top = max(0, int(getattr(self, "staff_win_content_h", 0) or 0) - area.h)
        self.staff_scroll -= int(getattr(e, "y", 0) or 0) * self.small.get_linesize() * 3
        self.staff_scroll = max(0, min(top, self.staff_scroll))
        self.mark_dirty()

    def _staff_win_row_click(self, pos) -> bool:
        """独立窗口里点了员工行 / 批评菜单：临时换成窗口坐标的矩形，走主窗口同一套 click_staff。"""
        rows = getattr(self, "staff_win_rects", [])
        menus = getattr(self, "staff_win_menu_rects", [])
        if not pos or not (rows or menus):
            return False
        saved = (getattr(self, "staff_rects", []), getattr(self, "staff_menu_rects", []),
                 getattr(self, "staff_menu_at", None), getattr(self, "staff_menu", None))
        self.staff_rects = list(rows)
        self.staff_menu_rects = list(menus)
        try:
            hit = bool(self.click_staff(pos))
        except Exception:
            hit = False
        finally:
            self.staff_rects, self.staff_menu_rects = saved[0], saved[1]
            # 菜单在主窗口里画的：新开的菜单不给锚点，退回默认位置，别画到窗口坐标上
            self.staff_menu_at = None if getattr(self, "staff_menu", None) is not None else saved[2]
        if hit:
            self.draw_panel_window("staff")
            self.mark_dirty()
        return hit

    def _staff_win_chrome_click(self, pos) -> bool:
        """独立员工窗口标题条：收起按钮 / 拖窗口 / 点员工行。处理过返回 True。"""
        pw = getattr(self, "staff_win", None)
        if pw is None or not pos:
            return False
        close = getattr(self, "staff_win_close_rect", None)
        if isinstance(close, pygame.Rect) and close.w and close.collidepoint(pos):
            self.close_panel_window("staff", dock=True)
            return True
        bar = getattr(self, "staff_win_title_rect", None)
        if isinstance(bar, pygame.Rect) and bar.w and bar.collidepoint(pos):
            self._begin_win_drag("staff", pw)      # 自己拖：每帧跟鼠标走，拖到哪一侧那一侧的栏滑出来
            return True
        self._staff_win_row_click(pos)
        return True

    def _staff_win_chrome(self, surf, size, title_h: int):
        """独立员工窗口的自绘标题条：标题 + 一颗收起按钮，中间那块能拖着走。"""
        w, h = size
        self.staff_win_title_rect = pygame.Rect(1, 1, max(0, w - 2), title_h)
        btn = max(S(14), title_h - S(6))
        close = pygame.Rect(max(1, w - btn - S(6)), 1 + max(0, (title_h - btn) // 2), btn, btn)
        self.staff_win_close_rect = close
        pygame.draw.rect(surf, mix(C["panel"], C["hdr"], 0.45), self.staff_win_title_rect,
                         border_top_left_radius=STAFF_WIN_RADIUS, border_top_right_radius=STAFF_WIN_RADIUS)
        hover = getattr(self, "staff_win_mouse", None)
        if hover and close.collidepoint(hover):
            pygame.draw.rect(surf, mix(C["panel"], C["hdr"], 0.95), close, border_radius=S(4))
        pygame.draw.line(surf, C["text"], (close.x + S(4), close.y + S(4)),
                         (close.right - S(4), close.bottom - S(4)), S(2))
        pygame.draw.line(surf, C["text"], (close.right - S(4), close.y + S(4)),
                         (close.x + S(4), close.bottom - S(4)), S(2))
        text = ellipsize(self.small, lang("staff"), max(0, close.x - S(12)))
        t = utext(self.small, text, C["dim"])
        surf.blit(t, (S(8), max(0, (title_h - t.get_height()) // 2)))

    def _draw_panel_window_staff(self):
        """staff 的实际投影：只做渲染，状态和点击仍归主窗口管。每帧 blit 完都要 flip()。"""
        pw = getattr(self, "staff_win", None)
        if pw is None or not getattr(self, "staff_win_open", False):
            return
        w, h = pw.size()
        if w <= 0 or h <= 0:
            return
        real = self.screen
        try:
            surf = pygame.Surface((w, h))
            surf.fill(C["panel"])
            rad = STAFF_WIN_RADIUS
            panel = pygame.Rect(1, 1, max(0, w - 2), max(0, h - 2))
            pygame.draw.rect(surf, C["panel"], panel, border_radius=rad)
            title_h = min(S(STAFF_WIN_TITLE_H), max(0, h // 4))
            area = pygame.Rect(panel.x, panel.y + title_h,
                               max(0, panel.w), max(0, panel.h - title_h))
            self.staff_win_area = pygame.Rect(area)
            # 投影这次绘制不能覆盖主窗口的命中矩形：先存旧值，画完还原
            old = (getattr(self, "staff_rects", []), getattr(self, "staff_menu_rects", []),
                   getattr(self, "staff_last_rect", None), getattr(self, "staff_content_h", 0),
                   getattr(self, "staff_head_rect", None), getattr(self, "staff_panel_rect", None),
                   getattr(self, "staff_info", None))
            self.screen = surf
            self.staff_rects, self.staff_menu_rects = [], []
            try:
                if area.w > 8 and area.h > 8:
                    self.draw_staff(area)
            finally:
                self.screen = real
                self.staff_win_rects = list(getattr(self, "staff_rects", []))
                self.staff_win_menu_rects = list(getattr(self, "staff_menu_rects", []))
                self.staff_win_content_h = int(getattr(self, "staff_content_h", 0) or 0)
                self.staff_rects, self.staff_menu_rects = old[0], old[1]
                if old[2] is not None:
                    self.staff_last_rect = old[2]
                self.staff_content_h = old[3]
                if old[4] is not None:
                    self.staff_head_rect = old[4]
                if old[5] is not None:
                    self.staff_panel_rect = old[5]
                if old[6] is not None:
                    self.staff_info = old[6]
            pygame.draw.rect(surf, C["border"], panel, S(1), border_radius=rad)
            self._staff_win_chrome(surf, (w, h), title_h)
            pw.blit(surf, (0, 0))
            pw.flip()            # 关键一步：SDL 窗口表面必须自己 flip 才上屏（display.flip 只刷主窗口）
        except Exception:
            self.screen = real

    def handle_staff_window(self, e):
        """独立员工栏窗口的事件：投影窗口只把点击 / 滚轮转回主窗口状态，不是它的返回 None。"""
        pw = getattr(self, "staff_win", None)
        if pw is None or not getattr(self, "staff_win_open", False):
            return None
        mine = self._staff_event_mine(e)
        if e.type == pygame.WINDOWCLOSE:
            if mine:                                # 系统把这个窗口关了：员工栏归位
                self.close_panel_window("staff", dock=True)
                return True
            return None
        if not mine:                                # 不是独立员工窗口的事件
            return None
        if e.type in (pygame.WINDOWRESIZED, pygame.WINDOWSIZECHANGED):
            self.draw_panel_window("staff")
            self.mark_dirty()
            return True
        if e.type == pygame.MOUSEMOTION:
            self.staff_win_mouse = tuple(getattr(e, "pos", (0, 0)))
            self.draw_panel_window("staff")         # 悬停高亮跟着动（不在这里查归位：鼠标晃一下不该把窗口收回去）
            return True
        if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
            self.staff_win_mouse = tuple(getattr(e, "pos", (0, 0)))
            if e.type == pygame.MOUSEBUTTONDOWN and getattr(e, "button", 0) == 1:
                if self._staff_win_chrome_click(self.staff_win_mouse):
                    return True
            if e.type == pygame.MOUSEBUTTONUP:
                self._staff_check_dock()            # 拖回主窗口：松手就归位
            return True
        if e.type == pygame.MOUSEWHEEL:
            self._staff_win_wheel(e)
            self.draw_panel_window("staff")
            return True
        if e.type in (pygame.KEYDOWN, pygame.KEYUP, pygame.TEXTINPUT, pygame.TEXTEDITING):
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.close_panel_window("staff", dock=True)   # 窗口里按 Esc：员工栏归位
            return True
        return None

    def _staff_check_dock(self) -> bool:
        """独立员工栏窗口被拖到主窗口上（拖回右栏）：自动归位。"""
        if not getattr(self, "staff_win_open", False):
            return False
        zone = self._win_dock_zone(getattr(self, "staff_win", None))
        if zone and self._dock_drop("staff", zone):
            return True
        return False

    # ---------------- 主循环 ----------------

    def mark_dirty(self):
        """标记这一帧必须重绘。"""
        self._dirty = True

    def handle_screen_shot(self, req):
        """在独立线程里让 Playwright 截一张图，主线程不阻塞。"""
        def work():
            try:
                req.data = self._web_frame()               # 截图 + 网址 / 标题 / 是否在加载
            except Exception:
                req.data = b""
            finally:
                req.event.set()
        threading.Thread(target=work, daemon=True).start()

    def frame_state(self):
        """把会影响画面的状态汇成一个可比较的快照，脏帧检测用（拿不准返回 None = 直接重绘）。"""
        try:
            return (
                pygame.mouse.get_pos(),
                self.screen.get_size(),
                self.busy, self.restart_at, self.dropdown_open, self.settings_open,
                self.settings_panel, self.settings_focus,
                tuple(self.sizes.items()),
                tuple(sorted((str(k), v) for k, v in self.progress.items())),
                len(self.messages), len(self.flow_rects),
                self.panel.version, self.panel.scroll, self.panel.status,
                self.panel.tool, self.panel.stick,
                self.chat_view.scroll, self.flow_view.scroll, self.log_view.scroll,
                self.tree.scroll,
                self.pending_confirm is not None, bool(self.pending_delete),
                (len(self.pending_credentials.user) + len(self.pending_credentials.pwd),
                 self.pending_credentials.focus, self.pending_credentials.remember)
                if getattr(self, "pending_credentials", None) else None,
                (getattr(self, "pending_need", None).text, pygame.time.get_ticks() // 500)
                if getattr(self, "pending_need", None) else None,
                self.modal_scroll, self.modal_buttons and len(self.modal_buttons),
                getattr(self.pending_confirm, "kind", ""),
                tuple(sorted(getattr(self.pending_confirm, "picked", ()) or ()))
                if getattr(self, "pending_confirm", None) else None,
                self.agent is None, frozenset(self.active_workers),
                getattr(self, "staff_win_open", False), self.staff_scroll,
                getattr(self, "staff_card", None),
                tuple(getattr(self, "staff_win_area", pygame.Rect(0, 0, 0, 0))),
                id(getattr(self, "screen_shot", None)),
                getattr(self, "screen_mark", None), len(getattr(self, "screen_pending", []) or []),
                getattr(self, "screen_win_open", False), getattr(self, "screen_topmost", False),
                getattr(self, "screen_result", None) is not None,
                getattr(self, "_voice_busy", False),
                bool(getattr(self, "_voice_rec", None) and self._voice_rec.is_recording),
                self.log_cache[1] if getattr(self, "log_cache", None) else None,
                self.input_text, self.cursor, self.composing,
                self.settings_scroll, self.settings_scroll_max, self.settings_value_edit,
                self.settings_edit_text, self.settings_edit_err, self.settings_open_dd,
                self.settings_slider_drag, self.settings_sb_drag,
                self.live_layout, tuple(self.settings.get("top_hidden", []) or []),
                self.model, self.current_member, self.turn_answer is not None,
                self.selected_flow is not None,
                len(getattr(self, "_candy_bursts", None) or []),   # 糖果特效
                self.candy_btn_on(),
                tuple(getattr(self, "btn_candy", None).rect) if getattr(self, "btn_candy", None) is not None else (0, 0, 0, 0),
                pygame.time.get_ticks() // 530 % 2,        # 输入光标闪烁
                tuple((tuple(sorted(m.checked)), m.done, bool(m.req is not None and m.req.expired), m.custom,
                       getattr(self, "choice_typing", None) is m)
                      for m in self.messages if m.kind == "choice"),
                getattr(self, "toast", None) and (self.toast.get("text"), self.toast.get("at")),
            )
        except Exception:
            return None

    def animating(self) -> bool:
        """正在闪烁/动画时强制重绘。"""
        visible = [k for k in modules_api.keys() if k in self._dock_side_keys("left") + self._dock_side_keys("right")
                   or self.panel_window_open(k)]
        if visible and modules_api.needs_redraw(visible):    # 外接模块到点要重画（例如时钟每秒走一格）
            return True
        if getattr(self, "toast", None):
            return True
        if getattr(self, "economy", None):
            return True
        if self.busy or self.restart_at:
            return True
        if getattr(self.panel, "status", "") == "生成中…":      # 写入面板末尾的闪烁光标
            return True
        if self.pending_delete:                                # 删除确认的倒计时
            return True
        if self.settings_open and getattr(self, "key_edit", None) is not None:
            return True                                        # 设置里改 key 时的闪烁光标
        if getattr(self, "_candy_bursts", None):                # 糖果特效还在飘：一直重绘
            return True
        btn = getattr(self, "btn_candy", None)                 # 鼠标停在糖果按钮上：悬停光晕要动
        r = getattr(btn, "rect", None)
        if isinstance(r, pygame.Rect) and r.w > 0 and r.collidepoint(pygame.mouse.get_pos()):
            return True
        if not self.anim_on():                                 # 关掉动画：不加任何额外重绘
            return False
        for tw in (self._panel_tween, self._left_fade, self._prog_done_tween, self._dropdown_tween):
            if tw.busy():                                      # 还有缓动没走完：继续 60fps 推帧
                return True
        if self.dropdown_open or self.busy:
            return True
        if not self._card_anim_done():                         # 卡片入场还没淡完
            return True
        cache = getattr(self, "_fade_cache", {}) or {}
        for v in cache.values():                               # 设置面板 / 顶栏按钮还在淡入
            if isinstance(v, list) and v[2] < 1.0:
                return True
        return False

    def run(self):
        import run as launcher
        try:                                    # 系统 / 环境要求减少动效时整站关掉动画
            self.reduce_motion = bool(os.environ.get("TERMINIST_REDUCE_MOTION"))
        except Exception:
            self.reduce_motion = False
        running, first = True, True
        self._boot_t = time.time()
        hold = launcher.splash_holding()               # 开机特效还在放：窗口藏着，放完再出来
        if not hold:
            self.start_projection()                    # 屏幕上的常驻投影壳 + 屏幕外的真窗口（失败就自己显示在屏幕原位）
        self._dirty = True
        self._last_state = None
        self._last_draw = pygame.time.get_ticks()
        stall_log = None
        try:                                           # 卡顿记录：主循环一圈超过 3 秒，把所有线程卡在哪一行写进日志
            import faulthandler
            stall_path = Path.home() / ".terminist" / "logs" / "stall.log"
            stall_path.parent.mkdir(parents=True, exist_ok=True)
            stall_log = open(stall_path, "a", encoding="utf-8")
        except Exception:
            stall_log = None
        while running:
            if stall_log is not None:
                try:
                    faulthandler.cancel_dump_traceback_later()
                    faulthandler.dump_traceback_later(3.0, repeat=False, file=stall_log)
                except Exception:
                    stall_log = None
            dirty = False
            if not first and os.environ.get(launcher.SPLASH_ENV):   # 开机特效：Agent 装好（或等太久）就收尾
                rdy = getattr(self.agent, "ready", None)
                if rdy is None or rdy.is_set() or time.time() - self._boot_t > 30:
                    launcher.splash(1.0, "就绪")
            self.poll_staff_editor()                   # 员工编辑窗口关了：刷新头像 / 换人设
            if hold and not first and launcher.splash_finished():
                hold = False
                self.show_after_splash()
            if self.proj_tick():                       # 投影壳转来的输入：先塞进事件队列，这一圈就处理
                dirty = True
            for e in pygame.event.get():
                dirty = True
                if not self.handle(e):
                    running = False
            if dirty:                              # 有事件：一定有变化
                self._dirty = True
            req = getattr(self, "screen_req", None)     # 截图线程完成：主线程这边收下
            if req is not None and req.event.is_set():
                self.screen_req = None
                if req.data:
                    self._load_shot(req.data)
                    self._dirty = True
            if getattr(self, "_mem_pending", False) and self.agent and time.time() >= getattr(self, "_mem_retry_at", 0):
                self.restore_memory()                    # 重启后读记忆超时了：过一会儿再读
            # 重启后自检：只要 Agent 空着就发（没打开文件夹的聊天模式也要发；以前要求必须打开文件夹，标记被读走后自检就丢了）
            if self.pending_turns and not self.busy and self.agent:
                text = self.pending_turns.pop(0)
                self._selftest_log_request()            # 自检请求写工作流日志，不进聊天框
                self._submit_turn(text, display=False)  # 自检指令原文也不显示
            elif getattr(self, "resume_queue", False) and not self.busy and self.agent and not self.restart_at:
                self.resume_queue = False
                self.kick_queue()
            if self.restart_at and pygame.time.get_ticks() >= self.restart_at and not self.busy:
                self.restart_at = 0
                self.on_restart()
            self.check_restart()
            if self.quit_requested:
                running = False
            self.drain_events()
            try:
                self._tick_modules()                       # 外接模块的后台心跳（每秒一次，跟面板可见性无关）
            except Exception:
                pass
            if getattr(self, "win_drag", None):
                self._tick_win_drag()                   # 拖着小窗口：跟着鼠标走，栏实时滑出来
            self.remember_window_size()                # 窗口尺寸变了就在几帧内落盘，重启不靠退出那一次保存
            self._tick_taskbar_icon()                  # 任务栏图标：启动后补发几次，免得停在 python 默认图标
            state = self.frame_state()
            if state is None or state != self._last_state:   # 状态变了 / 拿不准：宁可重绘
                self._dirty = True
            if first or self.animating():
                self._dirty = True
            if not self._dirty and pygame.time.get_ticks() - self._last_draw >= 700:
                self._dirty = True                     # 兜底：日志、小屏幕这类后台变化最多 0.7 秒刷一次
            if self._dirty:
                self.draw()
                if self.screen_win_open:               # 独立小屏幕窗口自己那一帧
                    try:
                        self.draw_screen_window()
                    except Exception:
                        pass
                if getattr(self, "staff_win_open", False):   # 独立员工栏窗口自己那一帧（投影）
                    try:
                        self.draw_panel_window("staff")
                    except Exception:
                        pass
                self._dirty = False
                self._last_state = self.frame_state()
                self._last_draw = pygame.time.get_ticks()
                if first:                              # 第一帧画出来了：告诉等着的旧窗口可以关了
                    launcher.signal_ready()
                    launcher.splash(0.8, "正在等 Agent 就绪")
                    first = False
                self.clock.tick(60)
            else:                                      # 空闲：不重绘，降到 20fps
                self.clock.tick(60 if getattr(self, "shell_pid", None) else 20)   # 开着投影：空闲也要及时收壳转来的输入
        if stall_log is not None:
            try:
                faulthandler.cancel_dump_traceback_later()
                stall_log.close()
            except Exception:
                pass
        if self.agent:
            self.agent.stop()
            if hasattr(self.agent, "close"):         # Agent 进程：存好记忆再结束它
                self.agent.close()
        if self.pending_confirm:
            self.answer_confirm(False)
        while self.pending_delete:               # 关窗 = 不同意删除
            self.answer_delete(False)
        self.save_layout()                       # 退出兜底：把布局再存一次
        self.stop_projection()                   # 正常退出：关掉投影壳（重启时不关，壳留给新窗口）
        pygame.quit()


def main():
    App(sys.argv[1] if len(sys.argv) > 1 else None).run()


if __name__ == "__main__" and __import__("os").environ.get("TERMINIST_CANDY_TEST"):
    m = 8
    a = sweep_candy_slot(1280, 800, m, used=[])
    b = sweep_candy_slot(1280, 800, m, used=[(1280 - 46 - 16, 800 - 46 - 16, 46, 46)])
    print("free", a)
    print("shifting", b)
    print("no_overlap", bool(a) and bool(b) and a != b)


def layout_memory_selftest():
    """离线自检：模拟 settings 检查布局记忆（栏宽夹取、读回、save_layout 写盘键）。不启动界面。"""
    class _Fake:
        pass
    fake = _Fake()
    fake.screen = type("S", (), {"get_height": staticmethod(lambda: 800), "get_width": staticmethod(lambda: 1280)})()
    fake.settings = {"sizes": {"left": 0, "right": 99999, "input_h": -5}}
    fake.sizes = {"left": 300, "right": 400, "input_h": 120}
    fake.staff_panel = True
    clamped = App.clamp_sizes(fake, {"left": 0, "right": 99999, "input_h": -5})
    ok1 = S(160) <= clamped["left"] <= S(500) and S(160) <= clamped["right"] <= S(700) and clamped["input_h"] >= S(70)
    sizes = App.default_sizes(fake)                                  # 从 settings["sizes"] 读回并夹紧
    ok2 = S(160) <= sizes["left"] <= S(500) and S(160) <= sizes["right"] <= S(700)
    fake.sizes = {"left": 320, "right": 420, "input_h": 130}
    saved = {}
    global save_settings
    real = save_settings
    save_settings = lambda s: saved.update({"x": 1})                 # 拦住写盘
    try:
        App.save_layout(fake)
    finally:
        save_settings = real
    s = fake.settings
    ok3 = (s.get("sizes") == {"left": 320, "right": 420, "input_h": 130}
           and s.get("panel_left_w") == 320 and s.get("panel_right_w") == 420 and s.get("input_height") == 130)
    print("clamp", ok1, "read", ok2, "save", ok3)
    return ok1 and ok2 and ok3


if __name__ == "__main__" and __import__("os").environ.get("TERMINIST_LAYOUT_TEST"):
    layout_memory_selftest()


if __name__ == "__main__":
    if not (__import__("os").environ.get("TERMINIST_CANDY_TEST")
            or __import__("os").environ.get("TERMINIST_LAYOUT_TEST")):
        main()
