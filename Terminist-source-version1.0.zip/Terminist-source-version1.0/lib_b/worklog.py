"""
工作流日志：A库 / B库 / 助手 / 执行成员的每一步都按时间记进 ~/.terminist/logs/workflow.log。

- wrap(emit) 包住 A库 的事件回调：流式片段（思考 / 回复 / 工具参数）攒成一整条再写，其余事件一条一行
- 文件超过 MAX_BYTES 换到 workflow.1.log（只留一份旧的）
- read() 给 A库 的 worklog_read 工具用（B库 一直不达标时翻日志查原因）；tail() 给界面的日志视图用
放在 lib_b 里：B库 改不了，日志不会被要查的对象自己改掉。
"""

import itertools
import json
import threading
import time
from pathlib import Path

LOG_DIR = Path.home() / ".terminist" / "logs"
LOG_FILE = LOG_DIR / "workflow.log"
OLD_FILE = LOG_DIR / "workflow.1.log"
MAX_BYTES = 4 * 1024 * 1024
STREAM = ("reasoning", "assistant")          # 流式事件：一个 token 一条，要攒起来
# 界面状态不进日志；tool_args 是工具参数的流式 JSON 片段，tool_call 和 tool 重复（tool 那条已经有工具名和参数）
SKIP = ("context", "model_info", "penalty", "b_refresh", "image", "ui_command", "tool_args", "tool_call",
        "front_report")                       # front_report 由 builder._escalate 自己按 "[前台名] 前台:" 记
CAP = {"reasoning": 600, "assistant": 2500}   # 每条最多记多少字，其余 1500
KIND_NAME = {"reasoning": "思考", "assistant": "回复", "tool": "调用", "tool_call": "调用", "result": "结果",
             "info": "信息", "error": "错误", "stage": "进度", "start": "开始", "end": "结束", "done": "本轮结束",
             "delivered": "交工", "member": "成员", "input": "说", "mark": "====", "diagnose": "诊断",
             "front": "前台"}

_lock = threading.Lock()
_ids = itertools.count(int(time.time()) % 100000)


def _write(who: str, kind: str, text: str):
    text = str(text or "").strip()
    try:
        from lib_a.config import redact
        text = redact(text)                   # API key 不进日志
    except Exception:
        pass
    cap = CAP.get(kind, 1500)
    if len(text) > cap:
        text = text[:cap] + f"…（共 {len(text)} 字，后面省略）"
    head = f"{time.strftime('%m-%d %H:%M:%S')} [{who}] {KIND_NAME.get(kind, kind)}: "
    line = head + text.replace("\r", "").replace("\n", "\n    ") + "\n"
    with _lock:
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_BYTES:
                LOG_FILE.replace(OLD_FILE)
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line)
        except OSError:
            pass


def write(who: str, kind: str, text: str):
    _flush_all()
    _write(who, kind, text)


def mark(text: str) -> str:
    """写一条分隔标记，返回标记号；read(since=标记号) 只看这之后的日志。"""
    mid = f"#{next(_ids)}"
    write("Terminist", "mark", f"{mid} {text}")
    return mid


_buf: dict[tuple[str, str], list[str]] = {}
_buf_lock = threading.Lock()


def _flush(key):
    parts = _buf.pop(key, None)
    if parts:
        _write(key[0], key[1], "".join(parts))


def _flush_all(who: str | None = None):
    with _buf_lock:
        for key in [k for k in _buf if who is None or k[0] == who]:
            _flush(key)


def record(kind: str, text: str):
    """记一条 A库 事件（B库 的是 b_ 开头，助手 / 执行成员的是 worker）。"""
    if kind in SKIP:
        return
    who = "A库"
    if kind == "worker":
        try:
            ev = json.loads(text)
            who, kind, text = str(ev.get("w") or "成员"), str(ev.get("kind") or ""), str(ev.get("text") or "")
        except (ValueError, AttributeError):
            pass
    elif kind.startswith("b_"):
        who, kind = "B库", kind[2:]
    if kind in SKIP:
        return
    if kind in STREAM:
        with _buf_lock:
            for key in [k for k in _buf if k[0] == who and k[1] != kind]:   # 同一个人换了事件类型：前一段写完
                _flush(key)
            _buf.setdefault((who, kind), []).append(str(text))
            if sum(len(x) for x in _buf[(who, kind)]) > 20000:
                _flush((who, kind))
        return
    _flush_all(who)
    if kind == "done":
        _flush_all()
        if who == "A库":
            _write(who, kind, "")
        return
    _write(who, kind, text)


def wrap(emit):
    """包住事件回调：照常转发，同时记日志。记日志出错不影响界面。"""
    if getattr(emit, "_worklog", False):
        return emit

    def logged(kind, text):
        try:
            record(kind, text)
        except Exception:
            pass
        return emit(kind, text)
    logged._worklog = True
    return logged


# ---------------- 读 ----------------
def _entries() -> list[str]:
    """按条（一条可能多行）读出旧文件 + 当前文件。"""
    _flush_all()
    text = ""
    for f in (OLD_FILE, LOG_FILE):
        try:
            text += f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass
    out: list[str] = []
    for line in text.splitlines():
        if line.startswith("    ") and out:
            out[-1] += "\n" + line
        elif line:
            out.append(line)
    return out


def read(grep: str = "", lines: int = 80, since: str = "", who: str = "") -> str:
    """给 A库 翻日志：since=标记号 只看那之后；who 只看某个角色（A库 / B库 / 助手1…）；grep 按关键词（| 分隔多个）过滤。"""
    entries = _entries()
    if since:
        tag = f"[Terminist] ====: {since} "
        idx = next((i for i in range(len(entries) - 1, -1, -1) if tag in entries[i]), None)
        if idx is not None:
            entries = entries[idx:]
    if who:
        entries = [e for e in entries if f"[{who}" in e.split("]", 1)[0] + "]"]
    if grep:
        keys = [k.strip().lower() for k in grep.split("|") if k.strip()]
        entries = [e for e in entries if any(k in e.lower() for k in keys)]
    lines = max(1, min(int(lines or 80), 300))
    total = len(entries)
    entries = entries[-lines:]
    body = "\n".join(entries)
    if len(body) > 24000:
        body = "…（前面省略）\n" + body[-24000:]
    if not entries:
        return "日志里没有符合条件的记录"
    return f"[工作流日志 {LOG_FILE}，符合条件 {total} 条，显示最后 {len(entries)} 条]\n{body}"


def tail(n: int = 400) -> list[str]:
    """界面日志视图：最后 n 行（物理行）。"""
    _flush_all()
    try:
        with open(LOG_FILE, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 256 * 1024))
            data = f.read().decode("utf-8", errors="replace")
    except OSError:
        return []
    rows = data.splitlines()
    if size > 256 * 1024:
        rows = rows[1:]                           # 第一行可能是半截
    return rows[-n:]


def stamp() -> float:
    """日志文件的修改时间，界面用来判断要不要重读。"""
    try:
        return LOG_FILE.stat().st_mtime_ns
    except OSError:
        return 0


def read_tool_schema():
    from lib_a import _fn
    return _fn("worklog_read",
               "翻 Terminist 的工作流日志（A库、B库、助手、执行成员每一步的思考 / 工具调用 / 结果 / 错误都按时间记在里面）。"
               "排查 B库 改造为什么不达标、某次工具为什么失败时用。",
               {"grep": {"type": "string", "description": "可选，关键词过滤，多个用 | 分隔，例如 错误|Traceback|退回"},
                "lines": {"type": "integer", "description": "最多显示多少条，默认 80，最多 300"},
                "since": {"type": "string", "description": "可选，只看某个标记号（例如 #12345）之后的日志"},
                "who": {"type": "string", "description": "可选，只看某个角色：A库 / B库 / 助手1 / 助手2 …"}})


def read_tool(args: dict) -> str:
    a = args or {}
    return read(str(a.get("grep") or ""), a.get("lines") or 80, str(a.get("since") or ""), str(a.get("who") or ""))
