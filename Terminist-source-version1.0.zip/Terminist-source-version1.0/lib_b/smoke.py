"""
开发用的自检（B库 制作时不再自动运行，按规定只查编译错误）：编译所有代码 → 导入 A库 和 Surface → 加载扩展 → 无头跑一遍界面并喂一组模拟事件。
由 builder 在子进程里运行：python -m lib_b.smoke（工作目录为 Terminist 根目录），通过时退出码为 0。
"""

import json
import os
import py_compile
import sys
import tempfile
import traceback
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ["TERMINIST_SMOKE"] = "1"         # Surface 看到这个就不联网拉模型列表

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# 模拟一轮完整的对话事件，覆盖 Surface 处理事件的各个分支
FAKE_EVENTS = [
    ("member", "deepseek-flash"), ("model_info", "deepseek-flash"),
    ("context", json.dumps({"tokens": 1234, "limit": 1_000_000})),
    ("reasoning", "先看看文件。"), ("assistant", "我先看一下。"),
    ("tool_args", json.dumps({"i": 0, "name": "write_file", "delta": '{"path": "a.py", "content": "x = 1', "new": True})),
    ("tool", 'write_file({"path": "a.py"})'),
    ("tool_call", json.dumps({"name": "write_file", "args": '{"path": "a.py", "content": "x = 1"}'})),
    ("result", "已新建 a.py"),
    ("tool", 'dispatch({"goal": "测试"})'),
    ("worker", json.dumps({"w": 1, "kind": "start", "text": json.dumps({"title": "写 a.py", "files": ["a.py"], "model": "deepseek-flash"})})),
    ("worker", json.dumps({"w": 2, "kind": "start", "text": json.dumps({"title": "写 b.py", "files": ["b.py"], "model": "deepseek-flash"})})),
    ("worker", json.dumps({"w": 1, "kind": "tool_args", "text": json.dumps({"i": 0, "name": "write_file", "delta": '{"path": "a.py"', "new": True})})),
    ("worker", json.dumps({"w": 1, "kind": "tool", "text": 'write_file({"path": "a.py"})'})),
    ("worker", json.dumps({"w": 1, "kind": "tool_call", "text": json.dumps({"name": "write_file", "args": '{"path": "a.py", "content": "x"}'})})),
    ("worker", json.dumps({"w": 2, "kind": "error", "text": "测试错误"})),
    ("worker", json.dumps({"w": 1, "kind": "result", "text": "已新建 a.py"})),
    ("worker", json.dumps({"w": 1, "kind": "end", "text": json.dumps({"ok": True, "report": "写好了", "changed": ["a.py"]})})),
    ("worker", json.dumps({"w": 2, "kind": "end", "text": json.dumps({"ok": False, "report": "失败", "changed": []})})),
    ("result", "共 2 个子任务"),
    ("b_stage", "已存档当前版本 v000"), ("b_reasoning", "B库在想"), ("b_assistant", "B库说明"),
    ("b_tool", 'read_file({"path": "lib_a/core.py"})'), ("b_result", "1| ..."),
    ("b_delivered", json.dumps({"version": "v000", "files": ["lib_a/extensions/x.py"], "restart": False})),
    ("penalty", json.dumps({"A": 1, "B": 3, "R": 4})),
    ("worker", json.dumps({"w": "B助手1", "kind": "start", "text": json.dumps({"title": "改界面", "files": ["surface/gui.py"], "model": "deepseek-flash"})})),
    ("worker", json.dumps({"w": "B助手1", "kind": "end", "text": json.dumps({"ok": True, "report": "好了"})})),
    ("front_report", json.dumps({"who": "肥鱼", "text": "改造没成，原因是……"})),
    ("paused", ""), ("steer", "再加一个 f.txt"), ("resumed", ""), ("steer_applied", "- 再加一个 f.txt"),
    ("memory", "测试记忆提示"), ("assistant", "完成。"), ("info", "提示"), ("error", "错误示例"), ("done", ""),
]


def main() -> int:
    errors = []
    for f in sorted(ROOT.rglob("*.py")):          # B库 可以在任何目录加代码，全部都要能编译
        rel = f.relative_to(ROOT).parts
        if rel[0] in ("versions", "memory", ".git") or "__pycache__" in rel:
            continue
        try:
            py_compile.compile(str(f), doraise=True, cfile=os.devnull if os.name != "nt" else None)
        except py_compile.PyCompileError as e:
            errors.append(str(e))
    if errors:
        print("编译失败:\n" + "\n".join(errors))
        return 1
    print("编译通过")

    import lib_a
    errs = lib_a.load_extensions()
    if errs:
        print("扩展加载失败:\n" + "\n".join(errs))
        return 1
    print(f"扩展工具: {sorted(lib_a.EXT_TOOLS)}")

    import pygame
    from surface import console, gui
    em = console.ConsoleEmitter()       # 命令行界面：把同一组事件也喂一遍
    import contextlib, io
    with contextlib.redirect_stdout(io.StringIO()):
        for kind, payload in FAKE_EVENTS:
            em(kind, payload)

    with tempfile.TemporaryDirectory() as d:
        gui.SETTINGS_FILE = Path(d) / "settings.json"
        from lib_b import worklog              # 模拟事件不要记进真正的工作流日志
        worklog.LOG_DIR, worklog.LOG_FILE, worklog.OLD_FILE = Path(d), Path(d) / "workflow.log", Path(d) / "workflow.1.log"
        lib_a.core.MEMORY_DIR = Path(d) / "memory"
        chat = gui.App(None)                  # 不打开文件夹也能聊天
        if chat.agent is None or chat.agent.ws is not None:
            print("聊天模式 Agent 创建失败")
            return 1
        chat.draw()
        app = gui.App(d)
        if app.agent is None:
            print("Agent 创建失败")
            return 1
        tools = [t["function"]["name"] for t in app.agent.tools()]
        print(f"A库工具: {tools}")
        app.add("user", "自检")
        app.turn_flow = gui.Message("workflow")
        app.messages.append(app.turn_flow)
        app.busy = True
        for kind, payload in FAKE_EVENTS:
            app.agent.emit(kind, payload)        # 走 A库 的事件回调：界面和工作流日志都收到
        for _ in range(4):
            pygame.event.pump()
            app.drain_events()
            app.draw()
        app.flow_log = True                   # 右栏切到日志视图画一帧
        app.draw()
        if not worklog.tail(5):
            print("工作流日志没有记下来")
            return 1
        app.flow_log = False
        for setup in (app.on_open_settings, lambda: setattr(app, "dropdown_open", True)):
            app.settings_open = app.dropdown_open = False
            setup()
            app.draw()
        pygame.quit()
    print("界面无头运行通过")
    print("SMOKE OK")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
