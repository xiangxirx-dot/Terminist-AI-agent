"""
代码地图：Terminist 自己的代码里，哪一块（文件 + 函数 / 类 + 行号）负责什么。存在共享知识库里（memory/graph/shared.sqlite），
A库、B库、助手都能用，B库 边写代码边记，下次直接按地图找位置、只读那几行，不用再通读大文件（省 token）。

两种来源：
- 自动：按 AST 扫出每个类 / 函数（含方法）的行号范围和 docstring 第一行。文件改过（mtime 变了）才重扫，不花 token。
- B库 记的笔记（code_note）：一句话说清这一块负责什么、要注意什么。按「文件 + 符号」存，记下当时源码的指纹；
  后来那块代码被改了、笔记没跟着更新，检索时标「可能过时」。

检索（lookup）：按字二元组 + 稀有度给「路径 + 符号名 + docstring + 笔记」打分，返回最相关的几块，带行号。
"""

import ast
import hashlib
import math
import re
import sqlite3
import threading
import time
import unicodedata
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {"versions", "memory", ".git", "__pycache__", "root", "node_modules", ".venv", "venv", "runtime"}
NOTE_MAX = 300
_lock = threading.RLock()
_db: sqlite3.Connection | None = None
_db_path = None
_index = None                                   # (二元组倒排, 行表)：扫描 / 记笔记后作废

SCHEMA = """
CREATE TABLE IF NOT EXISTS code_files(path TEXT PRIMARY KEY, mtime REAL NOT NULL);
CREATE TABLE IF NOT EXISTS code_symbols(path TEXT NOT NULL, symbol TEXT NOT NULL, kind TEXT NOT NULL,
  start INTEGER NOT NULL, end INTEGER NOT NULL, doc TEXT NOT NULL DEFAULT '', hash TEXT NOT NULL DEFAULT '',
  PRIMARY KEY(path, symbol));
CREATE TABLE IF NOT EXISTS code_notes(path TEXT NOT NULL, symbol TEXT NOT NULL, note TEXT NOT NULL,
  hash TEXT NOT NULL DEFAULT '', by TEXT NOT NULL DEFAULT '', updated REAL NOT NULL, PRIMARY KEY(path, symbol));
"""


def _conn() -> sqlite3.Connection:
    """和知识库同一个文件（所有角色共享）。"""
    global _db, _db_path
    from base.graphrag import shared_path
    p = shared_path()
    with _lock:
        if _db is None or _db_path != p:
            p.parent.mkdir(parents=True, exist_ok=True)
            _db = sqlite3.connect(str(p), check_same_thread=False)
            _db.row_factory = sqlite3.Row
            _db.executescript(SCHEMA)
            _db_path = p
        return _db


def _rel(path) -> str:
    p = Path(str(path).replace("\\", "/"))
    try:
        if p.is_absolute():
            p = p.resolve().relative_to(APP_ROOT)
    except ValueError:
        pass
    return p.as_posix().lstrip("./")


# ---------------- 自动扫描（AST）----------------
def _symbols(text: str) -> list[tuple]:
    """[(符号, 类型, 起行, 止行, docstring 第一行, 源码指纹)]：顶层函数 / 类、类里的方法。"""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    lines = text.splitlines()
    out = []

    def add(node, name, kind):
        end = getattr(node, "end_lineno", node.lineno) or node.lineno
        doc = (ast.get_docstring(node) or "").strip().splitlines()
        src = "\n".join(lines[node.lineno - 1:end])
        out.append((name, kind, node.lineno, end, doc[0][:200] if doc else "",
                    hashlib.sha1(src.encode("utf-8")).hexdigest()[:16]))

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            add(node, node.name, "函数")
        elif isinstance(node, ast.ClassDef):
            add(node, node.name, "类")
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    add(sub, f"{node.name}.{sub.name}", "方法")
    return out


def scan(root: Path | None = None) -> int:
    """把改过的 .py 文件重扫一遍（没改过的跳过），返回重扫了几个文件。"""
    global _index
    root = Path(root or APP_ROOT)
    db = _conn()
    known = {r["path"]: r["mtime"] for r in db.execute("SELECT path, mtime FROM code_files")}
    seen, n = set(), 0
    for f in root.rglob("*.py"):
        rel = f.relative_to(root).as_posix()
        if set(rel.split("/")[:-1]) & SKIP_DIRS:
            continue
        seen.add(rel)
        try:
            mt = f.stat().st_mtime
        except OSError:
            continue
        if known.get(rel) == mt:
            continue
        try:
            syms = _symbols(f.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
        with _lock:
            db.execute("DELETE FROM code_symbols WHERE path=?", (rel,))
            db.executemany("INSERT OR REPLACE INTO code_symbols VALUES(?,?,?,?,?,?,?)",
                           [(rel, *s) for s in syms])
            db.execute("INSERT OR REPLACE INTO code_files VALUES(?,?)", (rel, mt))
        n += 1
    gone = set(known) - seen
    with _lock:
        for rel in gone:                         # 文件删掉了：符号跟着删（笔记留着，万一只是改名还能看到）
            db.execute("DELETE FROM code_symbols WHERE path=?", (rel,))
            db.execute("DELETE FROM code_files WHERE path=?", (rel,))
        db.commit()
    if n or gone:
        _index = None
    return n


# ---------------- B库 记的笔记 ----------------
def note(path: str, symbol: str, text: str, by: str = "B库", root: Path = APP_ROOT) -> str:
    """记一句「这一块负责什么」。symbol 写函数 / 方法名（类名.方法名 也行），整个文件的用途 symbol 写空。"""
    global _index
    rel, symbol, text = _rel(path), str(symbol or "").strip(), " ".join(str(text or "").split())[:NOTE_MAX]
    if not rel or not text:
        return "错误: path 和 note 都要写"
    h = ""
    f = Path(root) / rel
    if symbol and f.is_file():
        syms = {s[0]: s for s in _symbols(f.read_text(encoding="utf-8", errors="replace"))}
        hit = syms.get(symbol) or next((s for k, s in syms.items() if k.split(".")[-1] == symbol), None)
        if hit is None:
            return f"错误: {rel} 里没有 {symbol}（写函数名或 类名.方法名；整个文件的用途 symbol 留空）"
        symbol, h = hit[0], hit[5]
    db = _conn()
    with _lock:
        db.execute("INSERT OR REPLACE INTO code_notes VALUES(?,?,?,?,?,?)", (rel, symbol, text, h, by, time.time()))
        db.commit()
    _index = None
    return f"记住了：{rel}{'::' + symbol if symbol else ''} — {text}"


# ---------------- 检索 ----------------
def _flat(s: str) -> str:
    return re.sub(r"[\s\W_]+", "", unicodedata.normalize("NFKC", str(s)).casefold())


def _grams(s: str) -> set[str]:
    t = _flat(s)
    words = set(re.findall(r"[a-z][a-z0-9]{2,}", unicodedata.normalize("NFKC", str(s)).casefold()))
    return {t[i:i + 2] for i in range(len(t) - 1)} | words


def _rows():
    global _index
    with _lock:
        if _index is None:
            db = _conn()
            notes = {(r["path"], r["symbol"]): r for r in db.execute("SELECT * FROM code_notes")}
            rows = []
            for r in db.execute("SELECT * FROM code_symbols"):
                n = notes.pop((r["path"], r["symbol"]), None)
                rows.append({"path": r["path"], "symbol": r["symbol"], "kind": r["kind"], "start": r["start"],
                             "end": r["end"], "doc": r["doc"], "note": n["note"] if n else "",
                             "stale": bool(n and n["hash"] and n["hash"] != r["hash"])})
            for (path, symbol), n in notes.items():  # 文件级笔记（或者符号已经不在了）
                rows.append({"path": path, "symbol": symbol, "kind": "文件" if not symbol else "已不存在",
                             "start": 0, "end": 0, "doc": "", "note": n["note"], "stale": bool(symbol)})
            inv: dict[str, set[int]] = {}
            for i, r in enumerate(rows):
                name = r["symbol"].replace("_", " ").replace(".", " ")
                for g in _grams(f"{r['path']} {name} {r['doc']} {r['note']}"):
                    inv.setdefault(g, set()).add(i)
            _index = (inv, rows)
        return _index


def line(r: dict) -> str:
    where = f"{r['path']}:{r['start']}-{r['end']}" if r["start"] else r["path"]
    text = " | ".join(x for x in (r["doc"], ("笔记：" + r["note"]) if r["note"] else "") if x)
    stale = "（笔记可能过时：代码后来改过）" if r["stale"] else ""
    return f"- {where} {r['symbol'] or '（整个文件）'}" + (f" — {text}" if text else "") + stale


def lookup(query: str, k: int = 15, files: list[str] | None = None) -> list[dict]:
    """和 query 最相关的代码块。files 给了就优先这些文件里的。"""
    scan()
    inv, rows = _rows()
    qg = _grams(query)
    if not qg or not rows:
        return []
    n = len(rows)
    score: dict[int, float] = {}
    for g in qg:
        hits = inv.get(g, ())
        if not hits or (n >= 50 and len(hits) > n * 0.2):   # 太常见的词（def、self 之类）不算
            continue
        w = math.log(1 + n / len(hits))
        for i in hits:
            score[i] = score.get(i, 0) + w
    want = {_rel(f) for f in files or []}
    for i in list(score):
        r = rows[i]
        if r["note"]:
            score[i] *= 1.3                       # 有人记过笔记的更可信
        if r["path"] in want:
            score[i] *= 1.5
        if r["kind"] == "类" and r["end"] - r["start"] > 400:
            score[i] *= 0.3                       # 整个大类（App 这种几千行的）太粗，不如具体方法
    top = sorted(score.items(), key=lambda x: -x[1])[:k]
    return [rows[i] for i, s in top if s > 0]


def lookup_text(query: str, k: int = 15, files: list[str] | None = None) -> str:
    hits = lookup(query, k, files)
    if not hits:
        return ""
    return "\n".join(line(r) for r in hits)


def outline(path: str) -> str:
    """一个文件的提纲：每个函数 / 方法一行（行号 + docstring / 笔记），不用读全文就知道东西在哪。"""
    scan()
    rel = _rel(path)
    _, rows = _rows()
    mine = sorted((r for r in rows if r["path"] == rel), key=lambda r: (r["start"] or 0))
    if not mine:
        return f"代码地图里没有 {rel}（不是 .py 文件，或者路径不对）"
    return f"{rel} 的提纲（{len(mine)} 块）：\n" + "\n".join(line(r) for r in mine)


# ---------------- 工具 ----------------
def _fn(name, desc, props, req=()):
    return {"type": "function", "function": {"name": name, "description": desc,
                                             "parameters": {"type": "object", "properties": props,
                                                            "required": list(req)}}}


MAP_TOOL = _fn(
    "code_map",
    "代码地图（共享知识库）：查 Terminist 代码里哪一块负责什么，返回 文件:起止行 函数名 — 说明。"
    "找位置先查它，再按行号只读那一段（read_lines），别通读大文件。query 写要找的功能；path 给了就列这个文件的提纲。",
    {"query": {"type": "string", "description": "要找的功能 / 关键词"},
     "path": {"type": "string", "description": "可选：列出这个文件的提纲（每个函数一行）"}})

NOTE_TOOL = _fn(
    "code_note",
    "往代码地图里记一句「这一块负责什么 / 要注意什么」（共享知识库，下次谁来都能直接查到，省得再读一遍）。"
    "看懂或改完一个函数 / 方法、而它的 docstring 没说清时就记；和下一步的工具一起调，不要单独占一步。",
    {"path": {"type": "string", "description": "文件（相对 Terminist 根目录）"},
     "symbol": {"type": "string", "description": "函数名或 类名.方法名；整个文件的用途就留空"},
     "note": {"type": "string", "description": "一句话：负责什么、关键约定 / 坑（不写进度）"}},
    ["path", "note"])


def map_tool(a: dict) -> str:
    a = a or {}
    if a.get("path") and not a.get("query"):
        return outline(str(a["path"]))
    text = lookup_text(str(a.get("query") or ""), files=[a["path"]] if a.get("path") else None)
    return text or "代码地图里没找到相关的（换个说法，或者用 search 搜关键词）"


def note_tool(by: str, root=None):
    return lambda a: note(str((a or {}).get("path") or ""), str((a or {}).get("symbol") or ""),
                          str((a or {}).get("note") or ""), by=by, root=Path(root) if root else APP_ROOT)
