"""
B库（改造层）：A库 收到 "修改 Terminist 自己" 的指令时交给这里。

分工:
  A库（v4）  思考、读 Terminist 的代码、把需求拆成子任务；最后校对
  B库（flash）不思考，只写代码；自己做一部分，其余用 delegate 交给助手（也是 flash，固定 2 个）
  三个人在 Terminist 的**临时副本**里一起改，正式的代码在 A库 校对通过前不动

流程:
  1. 复制一份临时副本
  2. B库 + 助手们按子任务写代码；每做完一个子任务调用 subtask_done：编译检查，界面有变化就立刻刷新给用户看
  3. 整理副本（自动清理 + B库 删调试残留；哪一块负责什么由代码地图自动记录），只查编译错误和越界——不做功能自检
  4. A库 校对副本的改动
     - 通过：存档正式版本 → 把副本应用到正式的 Terminist → 按三人工作量的均衡度给 B库 奖励 → 交工
     - 退回：扣分（A库、B库 都扣，B库 扣得多），丢掉副本重新复制，B库 照意见重做
  5. 一直不达标（b_attempts 次都没过）：A库 翻工作流日志（lib_b/worklog.py）查原因
     - 能修：把诊断和修法交给 B库，再救一次（b_rescue 次）
     - 修不了 / 救了还不行：错误交给前台，用前台的口吻告诉用户（front_report 事件）
  所有次数都有硬上限，每轮活多久由时间上限收口（lib_a/config.py 的 LIMITS，受保护）。
"""

import copy
import json
import re
import threading
from pathlib import Path

from lib_a.core import is_balance_error
from lib_a.config import thinking_off
from lib_a import APP_ROOT, LEAD_MODEL, LIMITS, WORKER_MODEL, Agent, Workspace, _fn, load_extensions
from lib_a.staff import active_persona, active_staff, load_staff
from base import guard
from . import codemap, penalty, versions, worklog

PRECHECK_PASS = 80                  # 助手预核对：某一项「做到了」的概率 ≥ 这个，A库 就不再看这一项
PRECHECK_PROMPT = """你是 Terminist B库 的助手，帮 A库 预核对 B库 的改动。只看下面的 diff，对分给你的每一项验收标准，
估计「这一项在 diff 里已经做到了」的概率（0~100 的整数）：
- 只看功能有没有真的实现、接没接上（例如界面画了但点了没反应、调用了没定义的函数、存了但没读回来，都要给低分）；
- 拿不准、diff 里看不到证据的，给低分（不要高估，你给的高分 A库 就不会再看了）；
- 不评价代码风格。
只输出 JSON：{"items": [{"i": 编号, "p": 概率, "why": "一句依据"}]}"""
CODER_MODEL = WORKER_MODEL          # B库 和助手都用 flash，并在请求里关掉思考（thinking=False），只照着写代码
MAX_ASSISTANTS = 5
SETTINGS_FILE = APP_ROOT / "terminist_settings.json"     # 和界面共用的设置文件


class BalanceError(Exception):
    """DeepSeek 余额不足：改造立刻停下，不算 B库 失败。"""


ASSISTANTS = 2


def assistant_count() -> int:
    """B库 带几个助手：固定两个（以前能在设置里选 1~5，设置项删了）。"""
    return ASSISTANTS

_RULES = """权限:
- 受保护，不能改也不能删：__PROTECTED__
- 核心文件，可以改，但不能删除或移动：__CORE__
- 不要用 run_command 绕过这些限制；越界的话整次改造作废。
找代码（省 token）:
- 任务里附了 [代码地图]：哪个文件第几行到第几行是哪个函数、负责什么。先看地图，按行号用 read_lines 只读要改的那段，
  别通读大文件；地图里没有的再用 code_map 查（path 给文件名就列整个文件的提纲），最后才 search / grep。
- 边写边记：看懂或改完一个函数，而它的 docstring 没说清它负责什么、有什么坑，就用 code_note 记一句
  （和下一步的工具一起调，不要单独占一步）。新写的函数直接写好 docstring 第一行，地图会自动收进去。
写法（硬规定）:
- 不要思考，不要解释，不要给多个方案：照着子任务直接写出最简洁、最准确的代码。
- 有界面改动的，先把能看到的东西做出来（比如先加框和按钮，功能后补），做完立刻 subtask_done，系统会马上刷新界面给用户看。
- 界面新增的状态（App 的新属性）写在 surface/gui.py 的 App.hot_state() 里，用 setdefault 初始化。
- 给 A库 加能力优先在 lib_a/extensions/ 新建模块（参照 lib_a/extensions/file_stats.py）。
- 界面上加一个独立的小块（时钟、天气、待办小卡片之类）：写成模块包，不用改 surface/gui.py——源文件放 module_sources/<名字>/
  （module.json + main.py + assets/ 素材），用 python -m surface.modules_api pack module_sources/<名字> modules/<名字>.tmod 打包；
  照着 module_sources/clock/ 和 modules/README.md 写。用户在顶栏「模块」里刷新、放回、拖进左栏 / 右栏。
  扩展工具在没打开文件夹（只聊天）时也会提供给 A库，这时传进来的 ws 是 None：用不到 ws 的直接忽略它，
  要用 ws 的先判断 `if ws is None: return "要先打开文件夹"`；只是要存文件（下载、导出）的，没打开文件夹时退到桌面，
  参照 lib_a/extensions/web_download_image.py 的 _target。
- 新增用户可以调的界面设置（开关、选项、主题、字号等），必须在 surface/gui.py 的界面设置注册表里用 ui_setting(...) 登记
  （名字、选项、怎么生效；新设置的默认值加到 DEFAULT_SETTINGS），设置弹窗、/set 命令和 A库 的 set_ui 会自动接上；
  不要在设置弹窗里手写一行，也不要另写切换命令。新增主题只要往 THEMES 和 THEME_LABELS 里加。
- 文件和目录用小写英文 + 下划线命名；保持现有的中文注释和代码风格；不要装依赖、不要联网、不要改 API key。
- 系统只查编译错误，功能由 A库 校对。不要写测试，不要反复运行验证。""".replace(
    "__PROTECTED__", "、".join(versions.PROTECTED)).replace("__CORE__", "、".join(versions.CORE))

B_PROMPT = """你是 Terminist 的 B库（{model}），只负责写代码。A库（deepseek-v4-pro）已经想好方案、拆好了子任务。
你和 __N__ 个助手（__NAMES__，也是 flash）在 Terminist 的临时副本里一起改，副本根目录: {root}
- surface/ 界面（surface/gui.py、surface/console.py）；lib_a/ 执行层（core.py、team.py、extensions/）；lib_b/ 改造层；run.py 入口。
分工:
- 系统已经按工作量把子任务分好，助手的那份开工时就派出去并行写了；你只做分给你的那几件，不要去改助手负责的函数。
- 做的过程中发现还有能并行的新活，可以再用 delegate 交给空着的助手。大家的工作量越平均奖励越高。
- 每做完一个子任务调用一次 subtask_done。你自己的做完后写一句话说明就结束，系统会等助手做完。
""" + _RULES + """
操作系统: {os}
{team_info}"""

ASSIST_PROMPT = """你是 Terminist B库 的助手（{model}），只负责写代码，照着交给你的子任务做。
工作目录是 Terminist 的临时副本: {root}
- 只改交给你的文件，其他文件只读。做完调用 subtask_done，然后用一句话汇报就结束。
- 别人也在改的共用文件：只用 edit_file 改你负责的那几个函数，改前 read_lines 看最新原文，不要整个覆盖，也不要动别人那块。
""" + _RULES + """
操作系统: {os}
{team_info}"""

TIDY_PROMPT = """所有子任务都做完了，快速整理一下副本（最多几步）。这次改动的文件：{changed}
系统已经自动清掉了缓存、临时文件和空目录{auto}。当前结构：
{tree}
只整理，不改功能：删掉调试 / 试验 / 备份文件。不要改任何说明文档（哪一块负责什么由代码地图自动记录），
不要读大文件；没什么可删就直接说一句「不用整理」。
做完用一句话说明。"""

SUBTASK_TOOL = _fn(
    "subtask_done",
    "每做完一个子任务调用一次：系统检查编译错误；界面（surface/）有变化就立刻刷新给用户看。",
    {"title": {"type": "string", "description": "刚做完的子任务"}}, ["title"])

def delegate_tool(n: int) -> dict:
    return _fn(
        "delegate",
        f"把一个子任务交给助手（助手1~助手{n}）并行去写。交出去的文件归助手，你不要再改。",
        {"assistant": {"type": "integer", "enum": list(range(1, n + 1))},
         "title": {"type": "string"},
         "instruction": {"type": "string", "description": "照抄 A库 给的子任务说明，必要时补充具体位置"},
         "files": {"type": "array", "items": {"type": "string"}, "description": "助手负责的文件（相对副本根目录）"}},
        ["assistant", "title", "instruction", "files"])

DIAG_PROMPT = """你是 Terminist 的 A库（{model}）。你把一个修改 Terminist 自己的需求交给了 B库，B库 已经连续 {n} 次不达标。
现在你要翻工作流日志查清楚为什么，然后下结论（不写代码）：
- 用 worklog_read 翻日志：这次改造的日志从标记 {mark} 开始（传 since="{mark}"）；可以按 who=B库 / B助手1 / B助手2 … 看，
  也可以 grep 关键词（例如 错误|Traceback|退回|编译|越界|超时）；需要时用 terminist_read / terminist_search 看正式版本的源码；
- 最多 {steps} 步，查清楚就调用 diagnosis 提交结论；
- fixable=true：B库 再改一次就能做对。cause 写根因，advice 写 B库 下一次具体怎么改（哪个文件、哪里、怎么写），B库 会照做；
- fixable=false：B库 靠改代码解决不了，例如需求要动受保护文件、超出权限、缺依赖 / 网络 / API 出错、需求自相矛盾、
  时间上限根本不够。cause 写原因，user_action 写需要用户做什么（用户能看懂的话）。"""

DIAG_TOOL = _fn(
    "diagnosis",
    "提交诊断结论。",
    {"fixable": {"type": "boolean", "description": "B库 再改一次能不能做对"},
     "cause": {"type": "string", "description": "根因（引用日志里的关键证据）"},
     "advice": {"type": "string", "description": "fixable=true 时：B库 下一次具体怎么改"},
     "user_action": {"type": "string", "description": "fixable=false 时：需要用户做什么"}},
    ["fixable", "cause"])

FRONT_PROMPT = """{persona}

【这次的任务】主人让 Terminist 改造自己，但改造失败了，组长和 B库 实在解决不了，现在由你去告诉主人。
用你的人设口吻，简短（5 句以内）说清楚：要改什么、为什么没改成、主人需要做什么。正式的 Terminist 没有被改动，这一点要说。
不要编造下面没有的信息，不要说你会自己去修。"""

# A库 读 Terminist 自己代码的只读工具（用来想方案、拆子任务）
READ_TOOLS = {
    "terminist_list": _fn("terminist_list", "列出 Terminist 自己的文件（只读）。",
                          {"path": {"type": "string"}, "recursive": {"type": "boolean"}}),
    "terminist_read": _fn("terminist_read", "读 Terminist 自己的代码（只读，带行号）。",
                          {"path": {"type": "string"}, "start_line": {"type": "integer"},
                           "end_line": {"type": "integer"}}, ["path"]),
    "terminist_search": _fn("terminist_search", "在 Terminist 自己的代码里用正则搜索（只读）。",
                            {"pattern": {"type": "string"}, "path": {"type": "string"},
                             "file_glob": {"type": "string"}}, ["pattern"]),
}


def compile_errors(root: Path = APP_ROOT) -> list[str]:
    """检查文件夹里所有 Python 文件能不能编译（只编译，不运行，不写 .pyc）。"""
    errors = []
    for rel, f in versions._files(root).items():
        if not rel.endswith(".py"):
            continue
        try:
            compile(f.read_text(encoding="utf-8"), rel, "exec")
        except SyntaxError as e:
            errors.append(f"{rel}:{e.lineno}: {e.msg}")
        except (UnicodeDecodeError, ValueError) as e:
            errors.append(f"{rel}: {e}")
    return errors


def work_done(agent: Agent) -> int:
    """一个成员写了多少代码（按写入 / 修改的字符数估算，删除、移动各算 50）。"""
    n = 0
    for m in agent.messages:
        for tc in m.get("tool_calls") or []:
            try:
                a = json.loads(tc["function"]["arguments"] or "{}", strict=False)
            except ValueError:
                continue
            name = tc["function"]["name"]
            if name == "write_file":
                n += len(str(a.get("content", "")))
            elif name == "edit_file":
                n += len(str(a.get("new_str", ""))) + len(str(a.get("old_str", ""))) // 4
            elif name in ("delete_file", "move_file"):
                n += 50
    return n


def suggest(tasks: list[dict], n: int = 2) -> dict[int, list[int]]:
    """按工作量（说明长度 + 文件数）把子任务平均分给 B库(0) 和 n 个助手(1..n)。
    同一个文件可以分给不同人（各改各的函数，改的时候系统按文件加锁，只许局部改）；没写文件的子任务助手没法接，留给 B库。"""
    load = {k: 0 for k in range(n + 1)}
    plan: dict[int, list[int]] = {k: [] for k in range(n + 1)}
    order = sorted(range(len(tasks)), key=lambda k: -(len(tasks[k]["instruction"]) + 300 * len(tasks[k]["files"])))
    for k in order:
        t = tasks[k]
        who = min(load, key=load.get) if t["files"] else 0
        plan[who].append(k)
        load[who] += len(t["instruction"]) + 300 * len(t["files"])
    return plan


class Builder:
    def __init__(self, parent: Agent):
        self.parent = parent        # 提出需求、负责校对的 A库
        self.lock = threading.Lock()
        self.stage: Path | None = None
        self.ui_seen: dict[str, bytes] = {}
        self.ui_shown = False       # 用户是否看到过副本里的界面（退回时要刷回来）
        self.work: dict[str, int] = {}
        self.threads: list[threading.Thread] = []
        self.shared: set[Path] = set()   # 几个人一起改的文件（只许局部改）
        self.n = assistant_count()  # 这次改造带几个助手
        self.assistants = tuple(range(1, self.n + 1))

    # ---- 事件 ----
    def stage_msg(self, text: str):
        self.parent.emit("b_stage", text)

    def _relay(self, kind: str, text: str):
        if kind in ("done", "context", "member", "model_info"):    # B库 的这些事件不能当成 A库 的
            return
        self.parent.emit("b_" + kind, text)

    def _relay_assist(self, idx: int):
        def relay(kind: str, text: str):
            if kind not in ("done", "context", "member", "model_info"):
                self.parent.emit("worker", json.dumps({"w": f"B助手{idx}", "kind": kind, "text": text},
                                                      ensure_ascii=False))
        return relay

    # ---- 工作区 ----
    def _ws(self, write_roots=None) -> Workspace:
        base = self.parent.ws if self.parent.ws is not None else Workspace(APP_ROOT, auto_yes=True)
        ws = copy.copy(base)                  # 沿用 A库 的确认方式（GUI 弹窗 / 终端）
        ws.root = self.stage
        ws.write_roots = write_roots
        ws.protected = [self.stage / p for p in versions.PROTECTED]
        ws.protected_msg = "错误: 这是受保护的文件，不能改也不能删"
        ws.undeletable = [self.stage / p for p in versions.CORE]
        ws.locked = {}
        ws.shared = set(getattr(self, "shared", ()))     # 几个人一起改的文件：只许局部改
        ws.confirm_deletes = False            # 临时副本里删文件不弹窗；应用到正式版本时统一确认
        return ws

    # ---- 子任务完成：编译检查 + 界面热刷新 ----
    def _ui_changes(self) -> list[str]:
        out = []
        for rel in versions.stage_changes(self.stage):
            if not (rel.startswith("surface/") and rel.endswith(".py")):
                continue
            f = self.stage / rel
            data = f.read_bytes() if f.is_file() else b""
            if self.ui_seen.get(rel) != data:
                self.ui_seen[rel] = data
                out.append(rel)
        return out

    def _subtask_done(self, who: str, args: dict) -> str:
        title = str(args.get("title", ""))
        with self.lock:
            errors = compile_errors(self.stage)
            if errors:
                return "编译错误，修好后再调用 subtask_done：\n" + "\n".join(errors[:10])
            ui = self._ui_changes()
            if ui:
                self.ui_shown = True
                self.parent.emit("b_refresh", json.dumps({"files": ui, "title": f"{who}：{title}",
                                                          "root": str(self.stage)}, ensure_ascii=False))
        self.stage_msg(f"{who} 完成子任务：{title}" + ("（界面已刷新）" if ui else ""))
        return "编译通过" + ("，界面已经刷新给用户看了" if ui else "") + "。继续；全部做完就一句话结束，不要再检查或优化。"

    def _refresh_live(self):
        """界面换回正式版本（副本被丢掉时）。"""
        if self.ui_shown:
            self.parent.emit("b_refresh", json.dumps({"files": ["surface/gui.py"], "title": "退回正式版本"},
                                                     ensure_ascii=False))
            self.ui_shown = False
        self.ui_seen.clear()

    # ---- 助手 ----
    def _delegate(self, b: Agent, args: dict) -> str:
        idx = args.get("assistant")
        if idx not in self.assistants:
            return f"错误: assistant 只能是 1~{self.n}"
        files = [str(f) for f in args.get("files") or []]
        paths = []
        for f in files:
            try:
                p = b.ws.resolve(f)
            except ValueError as e:
                return f"错误: {e}"
            if err := b.ws.check_writable(p):
                return f"错误: {f} 不能交出去（{err}）"
            paths.append(p)
        name = f"助手{idx}"
        for p in paths:
            b.ws.locked[p] = name
        if self.parent.stop_requested:
            return "已停止，这个子任务不再派出去"
        task = {"title": str(args.get("title", "")), "instruction": str(args.get("instruction", "")), "files": files}
        t = threading.Thread(target=self._run_assistant, args=(idx, task, paths), daemon=True)
        self.threads.append(t)
        t.start()
        return f"已交给{name}（并行在写）。你继续做你自己的子任务。"

    def _auto_delegate(self, b: Agent, tasks: list[dict]) -> dict:
        """按工作量把子任务分给 B库 和助手，助手的那份系统直接派出去（不靠 B库 自己想起来 delegate）。
        几个人都要改的文件记成共用文件：大家只许局部改（edit_file 按文件加锁）。返回最终分工。"""
        plan = suggest(tasks, self.n)
        owners: dict[Path, set[int]] = {}
        resolved: dict[int, list[Path]] = {}
        for w, ks in plan.items():
            for k in list(ks):
                paths = []
                for f in tasks[k]["files"]:
                    try:
                        p = b.ws.resolve(f)
                    except ValueError:
                        p = None
                    if p is None or (w and b.ws.check_writable(p)):
                        paths = None                    # 文件不能交出去（受保护 / 越界）：这件留给 B库
                        break
                    paths.append(p)
                if paths is None and w:
                    ks.remove(k)
                    plan[0].append(k)
                    continue
                resolved[k] = paths or []
                for p in resolved[k]:
                    owners.setdefault(p, set()).add(w)
        self.shared = {p for p, ws in owners.items() if len(ws) > 1}
        b.ws.shared = set(self.shared)
        for w, ks in plan.items():
            if not w:
                continue
            for k in ks:
                for p in resolved[k]:
                    if p not in self.shared:
                        b.ws.locked[p] = f"助手{w}"   # 只归这个助手的文件：B库 不碰
            if not ks or self.parent.stop_requested:
                continue

            def run(w=w, ks=list(ks)):               # 同一个助手的几件活按顺序做（一个助手同时只有一个在写）
                for k in ks:
                    if self.parent.stop_requested:
                        break
                    self._run_assistant(w, tasks[k], resolved[k])
            t = threading.Thread(target=run, daemon=True)
            self.threads.append(t)
            t.start()
        n_helper = sum(len(ks) for w, ks in plan.items() if w)
        if n_helper:
            self.stage_msg(f"系统分工：B库 {len(plan[0])} 件，助手 {n_helper} 件并行"
                           + (f"（共用文件 {len(self.shared)} 个，只许局部改）" if self.shared else ""))
        return plan

    @staticmethod
    def _checklist_items(checklist: str) -> list[str]:
        """「验收：1) … 2) …」拆成一项一项。拆不出编号就按「；」/ 换行拆。"""
        body = checklist.split("：", 1)[1] if checklist.startswith("验收") and "：" in checklist else checklist
        parts = [p.strip(" ；;。\n") for p in re.split(r"(?:^|[\s；;。])\(?\d{1,2}[)）.、]\s*", body) if p.strip(" ；;。\n")]
        if len(parts) < 2:
            parts = [p.strip() for p in re.split(r"[；;\n]", body) if p.strip()]
        return parts[:20]

    def _precheck(self, checklist: str, diff: str) -> tuple[list[str], list[str]]:
        """B库 的助手过来帮 A库 预核对：验收项分给几个助手（flash、不思考）并行打「做到了」的概率。
        概率高的 A库 就不看了，只看剩下的。返回 (有把握的项（带概率和依据）, 要 A库 看的项)。出错就全交给 A库。"""
        items = self._checklist_items(checklist)
        n = max(1, min(len(self.assistants) or 1, len(items)))
        if len(items) < 2:
            return [], items
        groups = {w: [(i, it) for i, it in enumerate(items) if i % n == w] for w in range(n)}
        scores: dict[int, tuple[int, str]] = {}

        def check(w, grp):
            user = ("## 分给你的验收项\n" + "\n".join(f"{i + 1}) {it}" for i, it in grp)
                    + f"\n\n## 改动 (diff)\n{diff[:60000]}")
            try:
                msg = self.parent.client.chat.completions.create(
                    model=WORKER_MODEL, temperature=0, response_format={"type": "json_object"},
                    **thinking_off(),
                    messages=[{"role": "system", "content": PRECHECK_PROMPT}, {"role": "user", "content": user}],
                ).choices[0].message
                data = json.loads(msg.content or "{}", strict=False)
                for r in data.get("items") or []:
                    i = int(r.get("i", 0)) - 1
                    if any(i == k for k, _ in grp):
                        scores[i] = (max(0, min(100, int(r.get("p", 0)))), str(r.get("why", ""))[:120])
            except Exception as e:
                worklog.write(f"B助手{w + 1}", "info", f"预核对失败（{type(e).__name__}），这几项交给 A库")
        self.stage_msg(f"助手帮 A库 预核对：{len(items)} 项验收分给 {n} 个助手")
        ts = [threading.Thread(target=check, args=(w, g), daemon=True) for w, g in groups.items() if g]
        [t.start() for t in ts]
        [t.join(120) for t in ts]
        sure, left = [], []
        for i, it in enumerate(items):
            p, why = scores.get(i, (0, "没核出来"))
            (sure if p >= PRECHECK_PASS else left).append(f"{it}（助手：{p}%，{why}）" if p >= PRECHECK_PASS else it)
        self.stage_msg("助手预核对：" + "；".join(f"{i + 1}) {scores.get(i, (0, ''))[0]}%" for i in range(len(items)))
                       + f" → 有把握 {len(sure)} 项，A库 要看 {len(left)} 项")
        return sure, left

    def _run_assistant(self, idx: int, task: dict, paths: list[Path]):
        name = f"助手{idx}"
        relay = self._relay_assist(idx)
        relay("start", json.dumps({"title": task["title"], "files": task["files"], "model": CODER_MODEL},
                                  ensure_ascii=False))
        if self.parent.stop_requested:
            relay("end", json.dumps({"ok": False, "report": "已停止"}, ensure_ascii=False))
            return
        a = Agent(self._ws(write_roots=paths), emit=relay, model=CODER_MODEL, system_prompt=ASSIST_PROMPT,
                  persist=False, role="worker")
        a.thinking = False                   # 助手只照着写：关掉思考（省 token、更快）
        a.custom_tools["subtask_done"] = (SUBTASK_TOOL, lambda x: self._subtask_done(name, x))
        self._give_map(a, name)
        with self.lock:
            self.parent.children.append(a)
        ok, report = True, ""
        try:
            a.chat(f"[子任务] {task['title']}\n{task['instruction']}\n[你负责的文件] {', '.join(task['files'])}"
                   + self._map_text(f"{task['title']} {task['instruction']}", task["files"], k=10))
            report = next((m["content"] for m in reversed(a.messages) if m["role"] == "assistant" and m.get("content")),
                          "(没有汇报)")
        except Exception as e:
            ok, report = False, f"{type(e).__name__}: {e}"
        finally:
            with self.lock:
                self.parent.children.remove(a)
                self.work[name] = self.work.get(name, 0) + work_done(a)
        relay("end", json.dumps({"ok": ok, "report": report}, ensure_ascii=False))

    # ---- 主流程 ----
    def _task_text(self, requirement: str, tasks: list[dict], feedback: list[str], plan: dict | None = None) -> str:
        plan = plan or {0: list(range(len(tasks)))}
        mine = plan.get(0, [])
        lines = [f"[需求] {requirement}", "", "[你自己的子任务]"]
        for k in mine:
            t = tasks[k]
            lines.append(f"{k + 1}. {t['title']}（文件：{', '.join(t['files']) or '未指定'}）\n   {t['instruction']}")
        if not mine:
            lines.append("（没有分到：助手们在并行写。你等他们做完后检查整合——编译、接口对得上、有缺的补上）")
        others = [(w, ks) for w, ks in plan.items() if w and ks]
        if others:
            lines.append("\n[系统已经派给助手、正在并行写的]（不用再 delegate，也不要去改他们负责的那几个函数）")
            for w, ks in others:
                lines.append(f"- 助手{w}：" + "；".join(f"{k + 1}. {tasks[k]['title']}（{', '.join(tasks[k]['files'])}）"
                                                       for k in ks))
        if self.shared:
            lines.append("\n[几个人一起改的文件] " + "、".join(sorted({str(p.relative_to(self.stage)).replace(chr(92), '/')
                                                               for p in self.shared}))
                         + "：只能用 edit_file 改你负责的那几处，不要整个覆盖，改前 read_lines 看最新原文。")
        if feedback:
            lines.append("\n[上一次被 A库 退回，副本已经重做] 问题：\n" + "\n".join(f"- {fb}" for fb in feedback)
                         + "\n直接按意见改，不要讨论别的方案。")
        text = " ".join([requirement] + [f"{t['title']} {t['instruction']}" for t in tasks] + feedback)
        files = [f for t in tasks for f in t["files"]]
        return "\n".join(lines) + self._map_text(text, files, k=20)

    def _map_text(self, query: str, files: list[str], k: int) -> str:
        """[代码地图]：和这次活最相关的代码块（文件:起止行 函数 — 负责什么），让 B库 / 助手 按行号直接去读。"""
        try:
            text = codemap.lookup_text(query, k=k, files=files)
        except Exception:
            return ""
        return ("\n\n[代码地图：和这次的活最相关的位置（行号是正式版本的，副本开工时一样）]\n" + text) if text else ""

    def _give_map(self, ag: Agent, who: str):
        """code_map 查地图；code_note 边写边记（记在共享知识库里，指纹按副本里的代码算）。"""
        ag.custom_tools["code_map"] = (codemap.MAP_TOOL, codemap.map_tool)
        try:                                       # 本地代码语义搜索：一句话找到相关函数（行号是正式版本的，副本开工时一样）
            from base import codeindex
            from lib_a import APP_ROOT, _fn
            ag.custom_tools["code_search"] = (_fn(
                "code_search", "本地代码语义搜索：一句话问「X 在哪实现 / 怎么做的」，一次返回最相关的几段代码（带行号）。"
                "找位置先用它，比 terminist_search → terminist_read 一轮轮来回省。",
                {"query": {"type": "string"}, "k": {"type": "integer", "description": "返回几段，默认 5"}}, ["query"]),
                lambda a: codeindex.code_search({"Terminist": Path(APP_ROOT)}, str(a.get("query") or ""),
                                                int(a.get("k") or 5)))
        except Exception:
            pass
        ag.custom_tools["code_note"] = (codemap.NOTE_TOOL, codemap.note_tool(who, root=self.stage))

    def run(self, target: str, requirement: str, tasks: list | None = None, interface: str = "") -> str:
        tasks = [{"title": str(t.get("title") or f"子任务 {i + 1}"), "instruction": str(t.get("instruction") or ""),
                  "files": [str(f) for f in (t.get("files") or [])]}
                 for i, t in enumerate(tasks or []) if isinstance(t, dict)]
        if not tasks:
            tasks = [{"title": requirement[:40], "instruction": requirement, "files": []}]
        if interface.strip():                    # 接口约定抄进每个子任务：B库 和助手各写各的，也能对上
            for t in tasks:
                t["instruction"] += ("\n[接口约定（所有子任务共用，照着写，名字一个字都不能改）]\n" + interface.strip())
        try:
            return self._run(target, requirement, tasks)
        except BalanceError:
            if self.stage is not None:
                versions.drop_stage(self.stage)
                self.stage = None
            self.stage_msg("DeepSeek 余额不足，改造停下（不算 B库 失败、不扣分）；充值后再让我接着做")
            self.parent.emit("error", "[DeepSeek 余额不足：去 DeepSeek 开放平台充值后再继续]")
            return ("改造没做成：DeepSeek 账户余额不足（402）。不是 B库 做错了，正式的 Terminist 没有改动。"
                    "告诉主人去充值，充值后再接着做；这一轮别再调用任何工具，直接汇报。")

    def _run(self, target: str, requirement: str, tasks: list) -> str:
        attempts, rescue = LIMITS["b_attempts"], LIMITS.get("b_rescue", 1)
        self.log_mark = worklog.mark(f"B库改造开始（目标：{target}）：{requirement[:300]}")
        self.stage_msg(f"开始制作（目标：{target}，{len(tasks)} 个子任务，B库 + {self.n} 个助手，最多 {attempts} 次）")
        feedback: list[str] = []
        try:
            for attempt in range(1, attempts + 1):
                result = self._attempt(attempt, attempts, target, requirement, tasks, feedback)
                if result is not None:
                    return result
            # 一直不达标：A库 翻日志找原因，能修就带着诊断再救一次，修不了交给前台告诉用户
            diag = self._diagnose(requirement, tasks, feedback)
            for k in range(rescue if diag["fixable"] else 0):
                if self.parent.stop_requested:
                    break
                feedback.append(f"A库翻日志后的诊断：{diag['cause']}\n  修法（照做）：{diag['advice']}")
                self.stage_msg(f"A库查到原因，带着诊断再救一次（第 {attempts + k + 1} 次制作）")
                result = self._attempt(attempts + k + 1, attempts + rescue, target, requirement, tasks, feedback)
                if result is not None:
                    return result
                diag = {"fixable": False, "cause": f"{diag['cause']}\n按诊断重做后还是没通过：{feedback[-1]}",
                        "advice": "", "user_action": diag.get("user_action", "")}
            if self.parent.stop_requested:
                return "改造已中止，正式的 Terminist 没有任何改动。"
            return self._escalate(requirement, feedback, diag)
        finally:
            if self.stage is not None:
                versions.drop_stage(self.stage)
                self.stage = None

    def _attempt(self, attempt, attempts, target, requirement, tasks, feedback) -> str | None:
        """做一次。交工返回结果文字；没通过返回 None（feedback 里追加原因）。"""
        if self.stage is not None:
            versions.drop_stage(self.stage)
        self.stage = versions.make_stage()
        self.work = {"B库": 0, **{f"助手{k}": 0 for k in self.assistants}}
        self.threads = []
        if attempt > 1:
            self.stage_msg(f"第 {attempt} 次制作")
        prompt = B_PROMPT.replace("__N__", str(self.n)).replace("__NAMES__", "、".join(f"助手{k}" for k in self.assistants))
        b = Agent(self._ws(), emit=self._relay, model=CODER_MODEL, system_prompt=prompt + "\n" + penalty.note("B"),
                  persist=False, role="builder")
        b.thinking = False                   # 方案 A库 已经想好、按验收项拆好了：B库 只照着写，关掉思考
        b.custom_tools["subtask_done"] = (SUBTASK_TOOL, lambda x: self._subtask_done("B库", x))
        b.custom_tools["delegate"] = (delegate_tool(self.n), lambda x: self._delegate(b, x))
        self._give_map(b, "B库")
        self.parent.child = b
        errors, bad, report = [], [], ""
        try:
            plan = self._auto_delegate(b, tasks)
            b.chat(self._task_text(requirement, tasks, feedback, plan))
            report = next((m["content"] for m in reversed(b.messages) if m["role"] == "assistant" and m.get("content")),
                          "(B库没有给出说明)")
            for t in self.threads:           # 等助手做完（期间一直看停止标记）
                while t.is_alive():
                    t.join(0.2)
                    if self.parent.stop_requested:
                        self.parent._halt_children()
            self.work["B库"] = work_done(b)
            b.ws.locked.clear()
            if not (self.parent.stop_requested or b.stop_requested):
                removed = versions.auto_tidy(self.stage)
                b.chat(TIDY_PROMPT.format(changed=", ".join(versions.stage_changes(self.stage)) or "无",
                                          tree=versions.tree_text(self.stage),
                                          auto=f"（{', '.join(removed[:20])}）" if removed else ""))
                versions.auto_tidy(self.stage)
                errors = compile_errors(self.stage)
                for _ in range(LIMITS["b_compile_fixes"]):
                    if not errors or b.stop_requested or self.parent.stop_requested:
                        break
                    self.stage_msg(f"有编译错误，B库修复中：{errors[0]}")
                    b.chat("编译错误，只修这些，不要改别的：\n" + "\n".join(errors[:10]))
                    errors = compile_errors(self.stage)
                bad = versions.stage_violations(self.stage)
        except Exception as e:
            if is_balance_error(e):
                raise BalanceError() from e           # 余额不足：整个改造直接停，不算失败、不诊断
            errors = [f"B库出错: {type(e).__name__}: {e}"]
        finally:
            self.parent.child = None

        if self.parent.stop_requested or b.stop_requested:
            self._refresh_live()
            self.stage_msg("已中止，丢掉临时副本，正式的 Terminist 没有改动")
            return "改造已中止，正式的 Terminist 没有任何改动。"

        changed = versions.stage_changes(self.stage)
        if bad:
            reason = "越界：" + "；".join(bad)
        elif errors:
            reason = "编译错误：" + "；".join(errors[:5])
        elif not changed:
            reason = "没有改动任何文件"
        else:
            share = self._share_text()
            self.stage_msg(f"编译通过（改动 {len(changed)} 个文件；分工 {share}），交给 A库 校对")
            checklist = ""
            try:
                checklist = self.parent.acceptance_list(requirement)
            except Exception:
                pass
            diff = versions.stage_diff(self.stage)
            sure, left = self._precheck(checklist, diff) if checklist else ([], [])
            if checklist and sure and not left:     # 每一项助手都很有把握：A库 不用再看
                approved, fb = True, "助手预核对：验收清单每一项都有把握做到了，A库 免看。\n" + "\n".join(sure)
            else:
                if checklist:
                    self.stage_msg("A库 按验收清单逐条校对" + (f"（助手已核过 {len(sure)} 项，A库 只看剩下 {len(left)} 项）"
                                                               if sure else ""))
                approved, fb = self.parent.review_upgrade(
                    requirement, report, diff, "编译通过（按规定不做功能自检）", note=penalty.note("A"),
                    checklist=("验收：" + "；".join(left) + ("\n（下面几项助手已核对、很有把握，不用再看：" + "；".join(sure) + "）"
                                                          if sure else "")) if sure else checklist)
            if not approved and is_balance_error(fb):     # 校对请求本身因为余额不足失败：不算退回、不扣分
                raise BalanceError()
            if approved:
                return self._deliver(attempt, requirement, report, fb)
            reason = f"A库校对不通过：{fb}"
            s = penalty.punish(requirement, fb, a=not checklist)   # 按清单退回漏项是 A库 的本职：只扣 B库
            self.parent.emit("penalty", json.dumps(penalty.scores()))
            self.stage_msg(f"A库退回重做 → 扣分：" + (f"A库 -{penalty.WEIGHTS['A']}（累计 {s['A']}），" if not checklist else "")
                           + f"B库 -{penalty.WEIGHTS['B']}（累计 {s['B']}）")
        self._refresh_live()
        feedback.append(reason)
        self.stage_msg(f"{reason[:300]}\n→ 丢掉临时副本" + ("，重新制作" if attempt < attempts else ""))
        return None

    # ---- 一直不达标：A库 翻日志 → 能修再救 / 修不了交前台 ----
    def _diagnose(self, requirement: str, tasks: list[dict], feedback: list[str]) -> dict:
        """A库（v4）用 worklog_read 翻这次改造的日志，返回 {fixable, cause, advice, user_action}。"""
        steps = 8
        self.stage_msg(f"B库连续 {len(feedback)} 次不达标，A库开始翻工作流日志查原因（{worklog.LOG_FILE}）")
        worklog.write("A库", "diagnose", "开始翻日志诊断")
        reader = Workspace(APP_ROOT, auto_yes=True)
        reader.protected = [APP_ROOT]
        run = {"worklog_read": worklog.read_tool,
               "terminist_read": lambda a: reader.read_file(**a),
               "terminist_search": lambda a: reader.search(**a)}
        tools = [worklog.read_tool_schema(), READ_TOOLS["terminist_read"], READ_TOOLS["terminist_search"], DIAG_TOOL]
        task_text = "\n".join(f"{k}. {t['title']}：{t['instruction']}" for k, t in enumerate(tasks, 1))
        msgs = [{"role": "system", "content": DIAG_PROMPT.format(model=LEAD_MODEL, n=len(feedback),
                                                                 mark=self.log_mark, steps=steps)},
                {"role": "user", "content": f"## 需求\n{requirement}\n\n## 子任务\n{task_text}\n\n## 每次没通过的原因\n"
                                            + "\n".join(f"{i}. {fb}" for i, fb in enumerate(feedback, 1))}]
        fallback = {"fixable": False, "cause": "；".join(feedback[-2:]) or "原因不明", "advice": "",
                    "user_action": "看一下工作流面板里的日志，换个说法或拆小一点再提一次"}
        for step in range(steps):
            if self.parent.stop_requested:
                return fallback
            last = step == steps - 1
            try:
                msg = self.parent.client.chat.completions.create(
                    model=LEAD_MODEL, messages=msgs, tools=[DIAG_TOOL] if last else tools,
                    tool_choice={"type": "function", "function": {"name": "diagnosis"}} if last else "auto",
                ).choices[0].message
            except Exception as e:
                if is_balance_error(e):
                    raise BalanceError() from e
                self.stage_msg(f"A库诊断请求失败：{type(e).__name__}: {e}")
                return fallback
            calls = msg.tool_calls or []
            if not calls:
                msgs += [{"role": "assistant", "content": msg.content or ""},
                         {"role": "user", "content": "请调用 diagnosis 提交结论。"}]
                continue
            entry = {"role": "assistant", "content": msg.content or "",
                     "tool_calls": [{"id": c.id, "type": "function",
                                     "function": {"name": c.function.name, "arguments": c.function.arguments}}
                                    for c in calls]}
            if getattr(msg, "reasoning_content", None):
                entry["reasoning_content"] = msg.reasoning_content
            msgs.append(entry)
            for c in calls:
                try:
                    a = json.loads(c.function.arguments or "{}", strict=False)
                except ValueError:
                    a = {}
                if c.function.name == "diagnosis":
                    d = {"fixable": bool(a.get("fixable")), "cause": str(a.get("cause") or "原因不明"),
                         "advice": str(a.get("advice") or ""), "user_action": str(a.get("user_action") or "")}
                    if d["fixable"] and not d["advice"]:
                        d["fixable"] = False
                    self.stage_msg(("A库诊断：能修，再救一次" if d["fixable"] else "A库诊断：B库 解决不了，交给前台告诉你")
                                   + f"\n原因：{d['cause'][:500]}"
                                   + (f"\n修法：{d['advice'][:500]}" if d["fixable"] else ""))
                    worklog.write("A库", "diagnose", json.dumps(d, ensure_ascii=False))
                    return d
                fn = run.get(c.function.name)
                try:
                    out = str(fn(a)) if fn else f"错误: 没有这个工具 {c.function.name}"
                except Exception as e:
                    out = f"错误: {type(e).__name__}: {e}"
                self.parent.emit("b_stage", f"A库查日志：{c.function.name}({json.dumps(a, ensure_ascii=False)[:150]})")
                msgs.append({"role": "tool", "tool_call_id": c.id, "content": out[:30000]})
        return fallback

    def _escalate(self, requirement: str, feedback: list[str], diag: dict) -> str:
        """错误交给前台：用上岗员工的口吻（flash、不思考）告诉用户，界面上作为前台的一条回复显示。"""
        name = active_staff()
        info = load_staff().get(name)
        label = str(info.get("label") or name) if isinstance(info, dict) else name
        facts = (f"需求：{requirement}\n试了 {len(feedback)} 次都没通过。\n原因：{diag['cause']}\n"
                 f"需要主人做的：{diag.get('user_action') or '换个说法或把需求拆小一点再提'}\n"
                 f"详细过程在工作流面板的日志里（{worklog.LOG_FILE}）。")
        try:
            msg = self.parent.client.chat.completions.create(
                model=WORKER_MODEL, **thinking_off(),
                messages=[{"role": "system", "content": FRONT_PROMPT.format(persona=active_persona())},
                          {"role": "user", "content": facts}]).choices[0].message
            text = (msg.content or "").strip() or facts
        except Exception:
            text = facts
        worklog.write(label, "front", text)
        self.parent.emit("front_report", json.dumps({"who": label, "text": text}, ensure_ascii=False))
        return (f"B库改造失败，正式的 Terminist 没有任何改动。A库 已经翻过日志：{diag['cause']}\n"
                f"前台「{label}」已经把原因和需要用户做的事告诉用户了（界面上能看到）。"
                f"你只用一句话收尾，不要重复解释，也不要再提新的改造。")

    def _share_text(self) -> str:
        total = sum(self.work.values()) or 1
        return " · ".join(f"{k} {v * 100 // total}%" for k, v in self.work.items())

    def _deliver(self, attempt: int, requirement: str, report: str, review: str) -> str:
        conflicts = versions.stage_conflicts(self.stage)
        if conflicts:                                  # 干活期间这些文件被别人改过：一个都不覆盖，整次不交工
            self.stage_msg("没交工：B库 干活期间这些文件在正式版本里被别人改过（或新建了），直接交工会把别人的改动冲掉 / 删掉："
                           + "、".join(conflicts) + "。正式版本一个字都没动，需要在新版本上重做这次改造。")
            return ("B库 这次没交工：干活期间 " + "、".join(conflicts) + " 在正式版本里被别人改过。为了不覆盖别人的改动，"
                    "正式版本没有任何变化。告诉用户原因；如果还要这个改动，重新调用 request_upgrade（会基于最新的文件重做）。")
        if self.parent.stop_requested:
            return "改动已被用户停止，正式的 Terminist 没有任何改动。"
        snap = versions.snapshot(requirement)          # 存档正式版本（/rollback 和启动失败自动回滚用）
        deleted = [rel for rel in versions.stage_changes(self.stage)
                   if not (self.stage / rel).exists() and not versions.is_protected(rel)]
        allow = not deleted or guard.confirm_delete([str(APP_ROOT / rel) for rel in deleted],
                                                    "B库 的改动要删除 Terminist 里的这些文件")
        if not allow:
            self.stage_msg(f"用户没有确认删除，保留这些文件：{', '.join(deleted)}")
        changed = versions.apply_stage(self.stage, allow_delete=allow)
        versions.mark(snap, "已交工")
        errors = load_extensions()
        pts, bal, s = penalty.reward(requirement, dict(self.work))
        self.parent.emit("penalty", json.dumps(penalty.scores()))
        # 界面已经从副本热刷新过；只有 A库 / 其他 Python 代码变了才需要重启
        restart = any(f.endswith(".py") and not f.startswith(("lib_a/extensions/", "surface/")) for f in changed)
        self.stage_msg(f"A库校对通过，交工（第 {attempt} 次制作）：{', '.join(changed)}\n"
                       f"分工 {self._share_text()}，均衡度 {bal} → 奖励 B库 +{pts}（累计 {s['R']}）"
                       + ("\n改动涉及 A库 代码，重启 Terminist 后生效" if restart else ""))
        self.parent.emit("b_delivered", json.dumps({"version": snap, "files": changed, "restart": restart},
                                                   ensure_ascii=False))
        return (f"B库已交工（第 {attempt} 次制作），改动前的版本存档为 {snap}。\n"
                f"改动文件：{', '.join(changed)}\n分工：{self._share_text()}（均衡度 {bal}，奖励 +{pts}）\n"
                f"{'需要重启 Terminist 才能生效。' if restart else '改动已生效。'}"
                f"{'（扩展加载报错：' + '; '.join(errors) + '）' if errors else ''}\n"
                f"B库说明：{report}\nA库校对意见：{review}\n"
                f"直接向用户汇报结果即可，不要再检查或提出新的改进。")


def attach(agent: Agent):
    """给 A库 接上 B库：A库 可以只读 Terminist 自己的代码来拆任务，但不能直接改。"""
    agent.upgrader = lambda target, requirement, tasks=None, interface="": \
        Builder(agent).run(target, requirement, tasks, interface)
    if agent.ws is not None:
        agent.ws.protected = [APP_ROOT]

    # 工作流日志：A库 的事件（连同转过来的 B库、助手、执行成员的）都记一份；用户的话也记上
    agent.emit = worklog.wrap(agent.emit)
    chat = agent.chat

    def logged_chat(text: str):
        worklog.write("用户", "input", text)
        return chat(text)
    agent.chat = logged_chat
    agent.custom_tools["worklog_read"] = (worklog.read_tool_schema(), worklog.read_tool)

    # 画图奖励：规则和累计分写进 A库 的系统提示词；每轮结束按画的图结算
    base_prompt = agent.prompt_template

    def refresh_note():
        agent.prompt_template = base_prompt + "\n" + penalty.note("A_draw")
        agent._refresh_prompt()

    def settle(ag: Agent):
        req = next((m["content"] for m in reversed(ag.messages)
                    if m["role"] == "user" and not ag.is_internal(m)), "")
        pts, s = penalty.reward_diagrams(req, ag.turn_diagrams, ag.big_turn())
        if pts:
            names = "、".join(sorted({"flow": "流程图", "concept": "概念图"}.get(k, k)
                                     for k in set(ag.turn_diagrams) if k in penalty.DIAGRAM_REWARD))
            ag.emit("info", f"画图奖励：A库 +{pts}（大任务里画了{names}，累计 {s['RA']}）")
            ag.emit("penalty", json.dumps(penalty.scores()))
        refresh_note()

    refresh_note()
    agent.turn_hooks.append(settle)
    reader = Workspace(APP_ROOT, auto_yes=True)
    reader.protected = [APP_ROOT]                      # 只读
    agent.custom_tools.update({
        "terminist_list": (READ_TOOLS["terminist_list"], lambda a: reader.list_dir(**a)),
        "terminist_read": (READ_TOOLS["terminist_read"], lambda a: reader.read_file(**a)),
        "terminist_search": (READ_TOOLS["terminist_search"], lambda a: reader.search(**a)),
        "code_map": (codemap.MAP_TOOL, codemap.map_tool),              # 代码地图：哪一块负责什么（和 B库 共用）
        "code_note": (codemap.NOTE_TOOL, codemap.note_tool("A库")),
    })


def versions_command(cmd: str) -> str:
    """Surface 里的 /versions、/rollback、/penalty 命令。"""
    if cmd == "/penalty":
        return penalty.summary()
    if cmd == "/penalty reset":
        penalty.reset()
        return "扣分和奖励已清零"
    vs = versions.list_versions()
    if cmd == "/versions":
        if not vs:
            return "还没有存档（B库改造 Terminist 时会自动存档）"
        return "版本存档（改造前的样子）：\n" + "\n".join(
            f"  {name}  [{m.get('status', '?')}]  {m.get('time', '')}  {m.get('label', '')[:60]}" for name, m in vs[-15:])
    delivered = [name for name, m in vs if m.get("status") == "已交工"]
    if not delivered:
        return "没有可以回滚的改造（只有交工过的改造才能回滚）"
    target = delivered[-1]
    backup = versions.snapshot(f"回滚 {target} 之前的样子")
    versions.mark(backup, "回滚前备份")
    versions.restore(target)
    versions.mark(target, "已回滚")
    load_extensions()
    return f"已回滚到 {target}（最近一次改造之前的版本），回滚前的样子备份为 {backup}。重启 Terminist 后完全生效。"
