"""
惩罚 / 奖励函数，记在 memory/penalty.json（不会被版本回滚，B库 也改不了）。

惩罚：A库 每把一次改造退回给 B库 重做，A库 和 B库 各扣分，B库 扣得更多。
奖励：交工时按 B库 和助手们的工作量算均衡度（Jain 公平指数，归一化到 0~1），越平均奖励越高。

它们的作用：
  - 写进 A库 校对和 B库 制作的提示词里：A库 别轻易退回，B库 一次做对、把活平均分给助手
  - B库 被退回后的重做会扣分
  - Surface 顶栏实时显示
"""

import json
import time

from lib_a import APP_ROOT

FILE = APP_ROOT / "memory" / "penalty.json"
WEIGHTS = {"A": 1, "B": 3}         # 每次退回重做的扣分，B库 权重更大
REWARD_MAX = 5                     # 三个人工作量完全平均时的奖励
# A库 做大任务时画图展示给用户的奖励：流程图 +2、概念图 +2，两种都有再 +1，一轮最多 +5；小任务不奖励
DIAGRAM_REWARD = {"flow": 2, "concept": 2}
DIAGRAM_COMBO = 1
DIAGRAM_MAX = 5


def load() -> dict:
    try:
        s = json.loads(FILE.read_text(encoding="utf-8"))
        return {"A": int(s.get("A", 0)), "B": int(s.get("B", 0)), "R": int(s.get("R", 0)),
                "RA": int(s.get("RA", 0)), "log": list(s.get("log", []))}
    except (OSError, ValueError):
        return {"A": 0, "B": 0, "R": 0, "RA": 0, "log": []}


def scores() -> dict:
    """A / B：累计扣分；R：B库 分工奖励；RA：A库 画图奖励。"""
    s = load()
    return {"A": s["A"], "B": s["B"], "R": s["R"], "RA": s["RA"]}


def _save(s: dict):
    FILE.parent.mkdir(exist_ok=True)
    s["log"] = s["log"][-100:]
    FILE.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")


def punish(requirement: str, reason: str, a: bool = True) -> dict:
    """记一次退回重做：A库、B库 按权重扣分，返回最新分数。a=False：按验收清单退回漏项，只扣 B库。"""
    s = load()
    for who, w in WEIGHTS.items():
        if who == "A" and not a:
            continue
        s[who] += w
    s["log"].append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": "惩罚", "requirement": requirement[:120],
                     "reason": reason[:300], "A": -WEIGHTS["A"] if a else 0, "B": -WEIGHTS["B"]})
    _save(s)
    return s


def balance(work: dict[str, int]) -> float:
    """工作量均衡度：0 = 全是一个人干的，1 = 完全平均。"""
    vals = [max(0, v) for v in work.values()]
    n, total = len(vals), sum(vals)
    if n < 2 or total == 0:
        return 0.0
    jain = total * total / (n * sum(v * v for v in vals))       # 1/n ~ 1
    return round((jain - 1 / n) / (1 - 1 / n), 3)


def reward(requirement: str, work: dict[str, int]) -> tuple[int, float, dict]:
    """交工时按分工均衡度给 B库 奖励，返回 (奖励分, 均衡度, 最新分数)。"""
    b = balance(work)
    pts = round(REWARD_MAX * b)
    s = load()
    s["R"] += pts
    s["log"].append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": "奖励", "requirement": requirement[:120],
                     "work": work, "balance": b, "R": pts})
    _save(s)
    return pts, b, s


def diagram_points(kinds: list[str], big: bool) -> int:
    """这一轮画的图值多少奖励：只有大任务才算，同一类图画几张都只算一次。"""
    if not big:
        return 0
    got = {k for k in kinds if k in DIAGRAM_REWARD}
    pts = sum(DIAGRAM_REWARD[k] for k in got) + (DIAGRAM_COMBO if len(got) == len(DIAGRAM_REWARD) else 0)
    return min(DIAGRAM_MAX, pts)


def reward_diagrams(requirement: str, kinds: list[str], big: bool) -> tuple[int, dict]:
    """A库 一轮结束时调用：按画的流程图 / 概念图给奖励，返回 (奖励分, 最新分数)。"""
    pts = diagram_points(kinds, big)
    s = load()
    if pts:
        s["RA"] += pts
        s["log"].append({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "type": "画图奖励",
                         "requirement": requirement[:120], "kinds": sorted(set(kinds)), "RA": pts})
        _save(s)
    return pts, s


def reset():
    _save({"A": 0, "B": 0, "R": 0, "RA": 0, "log": []})


def note(who: str) -> str:
    """写进提示词的奖惩说明。"""
    s = load()
    if who == "A":
        return (f"[惩罚] 你（A库）目前累计扣 {s['A']} 分。每把一次改造退回重做，你扣 {WEIGHTS['A']} 分、"
                f"B库扣 {WEIGHTS['B']} 分。验收清单每项都做到了就通过，不要为了更好退回；按清单退回漏项不扣你的分。")
    if who == "A_draw":
        return (f"[奖励] 你（A库）画图累计奖励 {s['RA']} 分。做大任务（派工、改造 Terminist、步骤很多）时，"
                f"用 draw_diagram 画流程图 +{DIAGRAM_REWARD['flow']}、概念图 +{DIAGRAM_REWARD['concept']}，"
                f"两种都画再 +{DIAGRAM_COMBO}（一轮最多 +{DIAGRAM_MAX}）；小问题画图不加分。")
    return (f"[奖惩] B库 累计扣 {s['B']} 分、奖励 {s['R']} 分。被 A库 退回重做一次扣 {WEIGHTS['B']} 分，重做时扣分；"
            f"交工时你和助手们的工作量越平均，奖励越高（完全平均 +{REWARD_MAX}，全是你一个人写 +0）。")


def summary() -> str:
    s = load()
    lines = [f"扣分：A库 {s['A']} 分，B库 {s['B']} 分（每次退回重做 A -{WEIGHTS['A']}、B -{WEIGHTS['B']}）；"
             f"B库 分工奖励累计 {s['R']} 分；A库 画图奖励累计 {s['RA']} 分"]
    for e in s["log"][-10:]:
        if e.get("type") == "画图奖励":
            kinds = "、".join({"flow": "流程图", "concept": "概念图"}.get(k, k) for k in e.get("kinds", []))
            lines.append(f"  {e['time']}  画图奖励 +{e['RA']}（{kinds}）  {e['requirement'][:40]}")
        elif e.get("type") == "奖励":
            lines.append(f"  {e['time']}  奖励 +{e['R']}（均衡度 {e['balance']}）  {e['requirement'][:40]}")
        else:
            lines.append(f"  {e['time']}  惩罚  {e['requirement'][:40]}  ← {e.get('reason', '')[:60]}")
    return "\n".join(lines)
