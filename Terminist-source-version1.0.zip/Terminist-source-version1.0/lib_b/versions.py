"""
版本存档：每次 B库 改造前，把整个 Terminist 文件夹（记忆、存档本身、用户设置除外）存一份；不满意就整体恢复。

存档目录 versions/<版本名>/files/ 下是文件的原样副本；和上一个存档相同的文件用硬链接，不重复占空间。
旧格式的存档（只有 lib_a/ 和 surface/ 两层，没有 files/）仍然可以恢复。

也在这里定义 B库 的边界：
  PROTECTED  不能改也不能删（B库 自己、入口保险、API key、记忆、存档、用户设置）
  CORE       可以改，但不能删除或移动
"""

import difflib
import json
import os
import shutil
import tempfile
import time
from pathlib import Path

from lib_a import APP_ROOT

VERSIONS_DIR = APP_ROOT / "versions"
KEEP = 30                                         # 最多保留多少个存档
EXCLUDE_DIRS = {"versions", "memory", ".git", "root", "runtime"}     # 根目录下不存档、不回滚的目录（root 库谁都不能动，回滚也不行）
EXCLUDE_FILES = {"terminist_settings.json",
                 "Terminist.exe", "icon.ico", "build.py", "python_path.txt"}   # 根目录下不存档、不回滚的文件（用户设置 + build.py 编的启动器）
PROTECTED = ["root", "base", "lib_b", "run.py", "lib_a/config.py", "versions", "memory", "terminist_settings.json"]
CORE = ["lib_a/__init__.py", "lib_a/core.py", "lib_a/team.py",
        "surface/__init__.py", "surface/gui.py", "surface/console.py"]
KEEP_DIRS = {"lib_a", "lib_a/extensions", "surface", "lib_b"}    # 空了也不清理的目录
JUNK_SUFFIXES = (".pyc", ".pyo", ".tmp", ".bak", ".orig", ".swp", "~")
JUNK_NAMES = {"Thumbs.db", ".DS_Store", "desktop.ini"}
TEXT_SUFFIXES = {".py", ".md", ".txt", ".json", ".toml", ".cfg", ".ini", ".yaml", ".yml", ".csv", ".html", ".css",
                 ".js", ".bat", ".ps1", ".sh"}
LAYERS = ("lib_a", "surface")                     # 旧格式存档只包含这两层


NEVER_COPY = {"lib_a/config.py"}    # 受保护、B库 改不了，不用存档也不用回滚；不复制它，旧存档也不会把旧的 key 写法带回来


def _skip(rel: str) -> bool:
    parts = rel.split("/")
    return (parts[0] in EXCLUDE_DIRS or (len(parts) == 1 and parts[0] in EXCLUDE_FILES) or rel in NEVER_COPY
            or "__pycache__" in parts or rel.endswith((".pyc", ".pyo")))


def _files(base: Path, only: tuple | None = None) -> dict[str, Path]:
    """{相对路径: 文件}。only 给定时只看这些顶层目录（旧格式存档用）。"""
    out = {}
    if not base.is_dir():
        return out
    for f in base.rglob("*"):
        if not f.is_file():
            continue
        rel = f.relative_to(base).as_posix()
        if _skip(rel) or (only and rel.split("/")[0] not in only):
            continue
        out[rel] = f
    return out


def is_protected(rel: str) -> bool:
    return any(rel == p or rel.startswith(p + "/") for p in PROTECTED)


def is_core(rel: str) -> bool:
    return rel in CORE


def _snap_files(name: str) -> tuple[dict[str, Path], tuple | None]:
    """存档里的文件，以及它覆盖的范围（None = 整个文件夹；旧格式只有 LAYERS）。"""
    d = VERSIONS_DIR / name
    if (d / "files").is_dir():
        return _files(d / "files"), None
    return _files(d, LAYERS), LAYERS


def list_versions() -> list[tuple[str, dict]]:
    out = []
    for d in sorted(VERSIONS_DIR.glob("v[0-9][0-9][0-9]_*")):
        try:
            meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            meta = {}
        out.append((d.name, meta))
    return out


def _same(a: Path, b: Path) -> bool:
    try:
        return a.stat().st_size == b.stat().st_size and a.read_bytes() == b.read_bytes()
    except OSError:
        return False


def snapshot(label: str) -> str:
    """存档整个 Terminist 文件夹，返回版本名。"""
    VERSIONS_DIR.mkdir(exist_ok=True)
    vs = list_versions()
    nums = [int(n[1:4]) for n, _ in vs]
    name = f"v{max(nums, default=0) + 1:03d}_{time.strftime('%Y%m%d-%H%M%S')}"
    dest = VERSIONS_DIR / name / "files"
    prev = next((VERSIONS_DIR / n / "files" for n, _ in reversed(vs) if (VERSIONS_DIR / n / "files").is_dir()), None)
    for rel, f in _files(APP_ROOT).items():
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        old = prev / rel if prev else None
        if old is not None and old.is_file() and _same(old, f):
            try:
                os.link(old, target)              # 没变的文件用硬链接，不重复占空间
                continue
            except OSError:
                pass
        shutil.copy2(f, target)
    (VERSIONS_DIR / name / "meta.json").write_text(json.dumps(
        {"label": label[:500], "time": time.strftime("%Y-%m-%d %H:%M:%S"), "status": "存档"},
        ensure_ascii=False, indent=2), encoding="utf-8")
    trim_keep(KEEP)
    return name


def trim_keep(keep: int = KEEP) -> list[str]:
    """只留最新的 keep 个存档，返回删掉的版本名（从最老的开始）。"""
    vs = list_versions()
    gone = []
    for old, _ in vs[:-keep] if keep > 0 else vs:
        shutil.rmtree(VERSIONS_DIR / old, ignore_errors=True)
        gone.append(old)
    return gone


def mark(name: str, status: str):
    f = VERSIONS_DIR / name / "meta.json"
    try:
        meta = json.loads(f.read_text(encoding="utf-8"))
        meta["status"] = status
        f.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    except (OSError, ValueError):
        pass


def clear_pycache(root: Path = APP_ROOT) -> list[str]:
    """删掉所有 __pycache__（存档、记忆除外），运行时会自动重新生成。"""
    removed = []
    for d in list(root.rglob("__pycache__")):
        rel = d.relative_to(root).as_posix()
        if d.is_dir() and rel.split("/")[0] not in EXCLUDE_DIRS:
            shutil.rmtree(d, ignore_errors=True)
            removed.append(rel + "/")
    return removed


def remove_empty_dirs(root: Path = APP_ROOT) -> list[str]:
    """删掉空目录（存档、记忆和 KEEP_DIRS 除外），返回删掉的目录。"""
    removed = []
    dirs = sorted((d for d in root.rglob("*") if d.is_dir()), key=lambda d: len(d.parts), reverse=True)
    for d in dirs:
        rel = d.relative_to(root).as_posix()
        if rel.split("/")[0] in EXCLUDE_DIRS or rel in KEEP_DIRS:
            continue
        try:
            if not any(d.iterdir()):
                d.rmdir()
                removed.append(rel + "/")
        except OSError:
            pass
    return removed


def restore(name: str):
    """把 Terminist 文件夹恢复成存档 name 的样子：存档后新增的文件删掉，改过的文件换回去。"""
    snap, only = _snap_files(name)
    if not snap:
        raise FileNotFoundError(f"存档不完整: {name}")
    for rel, f in _files(APP_ROOT, only).items():
        if rel not in snap:
            f.unlink()
    for rel, f in snap.items():
        target = APP_ROOT / rel
        if target.is_file() and _same(f, target):
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            target.unlink()                       # 先删再拷，避免写进硬链接的另一端
        shutil.copy2(f, target)
    clear_pycache()                               # 否则只剩缓存的新目录删不掉
    remove_empty_dirs()


def changed_files(name: str) -> list[str]:
    """相对存档 name 新增、修改、删除的文件。"""
    snap, only = _snap_files(name)
    cur = _files(APP_ROOT, only)
    return [rel for rel in sorted(set(snap) | set(cur))
            if rel not in snap or rel not in cur or not _same(snap[rel], cur[rel])]


def violations(name: str) -> list[str]:
    """相对存档 name，有没有越界：改了受保护文件，或者删掉 / 移走了核心文件。"""
    out = [f"改动了受保护的文件 {rel}" for rel in changed_files(name) if is_protected(rel)]
    out += [f"核心文件 {rel} 不见了（不能删除或移动）" for rel in CORE if not (APP_ROOT / rel).is_file()]
    return out


def diff(name: str, limit: int = 40_000) -> str:
    """当前文件夹相对存档 name 的 unified diff（二进制文件只列出名字）。"""
    snap, only = _snap_files(name)
    cur = _files(APP_ROOT, only)
    parts = []
    for rel in changed_files(name):
        if Path(rel).suffix.lower() not in TEXT_SUFFIXES:
            state = "新增" if rel not in snap else "删除" if rel not in cur else "修改"
            parts.append(f"=== 二进制文件 {rel}：{state}")
            continue
        a = snap[rel].read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if rel in snap else []
        b = cur[rel].read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if rel in cur else []
        parts.append("".join(difflib.unified_diff(a, b, f"a/{rel}", f"b/{rel}")))
    text = "\n".join(parts)
    return text if len(text) <= limit else text[:limit] + f"\n...(diff 太长，已截断，共 {len(text)} 字符)"


def auto_tidy(root: Path = APP_ROOT) -> list[str]:
    """机械整理：删掉缓存、临时文件、备份文件和空目录（受保护的地方不动），返回清理掉的东西。"""
    removed = clear_pycache(root)
    for f in list(root.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(root).as_posix()
        if is_protected(rel) or rel.split("/")[0] in EXCLUDE_DIRS:
            continue
        if f.name in JUNK_NAMES or f.name.endswith(JUNK_SUFFIXES):
            try:
                f.unlink()
                removed.append(rel)
            except OSError:
                pass
    return removed + remove_empty_dirs(root)


def tree_text(root: Path = APP_ROOT, max_lines: int = 200) -> str:
    """当前文件夹结构（给 B库 整理时参考）。"""
    lines = []
    for rel, f in sorted(_files(root).items()):
        tag = " [受保护]" if is_protected(rel) else " [核心]" if is_core(rel) else ""
        lines.append(f"{rel}  ({f.stat().st_size} B){tag}")
        if len(lines) >= max_lines:
            lines.append("...(太多，已截断)")
            break
    return "\n".join(lines)


# ============================================================
# 临时副本：B库 和助手们在副本里一起改，A库 校对通过后才应用到正式的 Terminist
# ============================================================
_STAGE_BASE: dict[str, dict[str, str]] = {}      # 副本 → 复制那一刻正式文件夹每个文件的指纹（交工前查冲突用）


def _digest(f: Path) -> str:
    import hashlib
    try:
        return hashlib.sha1(f.read_bytes()).hexdigest()
    except OSError:
        return ""


def make_stage() -> Path:
    """把当前 Terminist 文件夹（记忆、存档、设置除外）复制一份到系统临时目录，并记下复制那一刻每个文件的指纹。"""
    d = Path(tempfile.mkdtemp(prefix="terminist_stage_"))
    base = {}
    for rel, f in _files(APP_ROOT).items():
        (d / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, d / rel)
        base[rel] = _digest(d / rel)
    _STAGE_BASE[str(d)] = base
    return d


def stage_conflicts(stage: Path) -> list[str]:
    """B库 干活期间，正式文件夹里被别人（用户、另一个 Agent、手动编辑）改过 / 新建的文件里，副本也要动的那些。
    交工时直接覆盖会把别人的改动冲掉，新建的还会被当成「副本里删掉了」而删除。"""
    base = _STAGE_BASE.get(str(stage))
    if base is None:
        return []
    live = _files(APP_ROOT)
    out = []
    for rel in stage_changes(stage):
        now = _digest(live[rel]) if rel in live else None
        if now != base.get(rel):                      # 复制以后正式文件变了（或者是后来才有的）
            out.append(rel)
    return out


def drop_stage(stage: Path):
    _STAGE_BASE.pop(str(stage), None)
    shutil.rmtree(stage, ignore_errors=True)


def stage_changes(stage: Path) -> list[str]:
    """副本相对正式文件夹新增、修改、删除的文件。"""
    live, new = _files(APP_ROOT), _files(stage)
    return [rel for rel in sorted(set(live) | set(new))
            if rel not in live or rel not in new or not _same(live[rel], new[rel])]


def stage_violations(stage: Path) -> list[str]:
    out = [f"改动了受保护的文件 {rel}" for rel in stage_changes(stage) if is_protected(rel)]
    out += [f"核心文件 {rel} 不见了（不能删除或移动）" for rel in CORE if not (stage / rel).is_file()]
    return out


def stage_diff(stage: Path, limit: int = 40_000) -> str:
    live, new = _files(APP_ROOT), _files(stage)
    parts = []
    for rel in stage_changes(stage):
        if Path(rel).suffix.lower() not in TEXT_SUFFIXES:
            state = "新增" if rel not in live else "删除" if rel not in new else "修改"
            parts.append(f"=== 二进制文件 {rel}：{state}")
            continue
        a = live[rel].read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if rel in live else []
        b = new[rel].read_text(encoding="utf-8", errors="replace").splitlines(keepends=True) if rel in new else []
        parts.append("".join(difflib.unified_diff(a, b, f"a/{rel}", f"b/{rel}")))
    text = "\n".join(parts)
    return text if len(text) <= limit else text[:limit] + f"\n...(diff 太长，已截断，共 {len(text)} 字符)"


def apply_stage(stage: Path, allow_delete: bool = True) -> list[str]:
    """把副本里的改动应用到正式的 Terminist 文件夹（受保护的文件永远不动），返回改动的文件。
    allow_delete=False 时，副本里删掉的文件在正式版本里保留（用户没确认删除）。"""
    changed = [rel for rel in stage_changes(stage) if not is_protected(rel)
               and (allow_delete or (stage / rel).exists())]
    for rel in changed:
        src, dst = stage / rel, APP_ROOT / rel
        if src.is_file():
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                dst.unlink()
            shutil.copy2(src, dst)
        elif dst.exists():
            dst.unlink()
    clear_pycache()
    remove_empty_dirs()
    return changed
