# -*- coding: utf-8 -*-
# 接管模块：一整块大按钮；黄色＝开始接管，红色＝正在接管（点它停止），
# 橙色＝已暂停（点它继续跑）。
# 状态真相在 App 上（ctx._app.takeover_active / takeover_paused），这里只读它决定颜色；
# 点击调 App.start_takeover() / App.stop_takeover() / App.toggle_takeover_pause()，
# App 上没方法就静默兜底。
import time
from pathlib import Path

import pygame

EYE_DIR = Path.home() / '.terminist' / 'eye'   # 眼睛日志（base/eye.py 写的）
EAR_DIR = Path.home() / '.terminist' / 'ear'   # 耳朵日志（base/ear_worker.py 子进程写的）


def _ear_tail(n=3):
    """今天耳朵日志的最后 n 段：[(时:分:秒~时:分:秒, 文字)]；「（耳朵开了）」这类附注不显示。"""
    path = EAR_DIR / f"ear-{time.strftime('%Y%m%d')}.log"
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            start = max(0, f.tell() - 6144)
            f.seek(start)
            lines = f.read().decode('utf-8', 'replace').splitlines()[1 if start else 0:]   # 从中间读才丢半行
    except OSError:
        return []
    out = []
    for ln in lines:
        head, _, text = ln.partition(' | ')
        span = head.split(' ', 1)[-1]
        a, _, b = span.partition('~')
        if not text or (text.startswith('（耳朵') and text.endswith('）')):
            continue
        out.append((f"{a[:8]}~{b[:8]}" if b and b[:8] != a[:8] else a[:8], text))
    return out[-n:]
_FRONT = {'at': 0.0, 'text': ''}


def _front():
    """现在最上层的前台窗口（base/winfo.py；半秒取一次）。前台是 Terminist 自己时显示它下面那个。"""
    now = time.monotonic()
    if now - _FRONT['at'] >= 0.5:
        _FRONT['at'] = now
        try:
            from base import winfo
            _FRONT['text'] = winfo.describe()
        except Exception:
            _FRONT['text'] = ''
    return _FRONT['text']

YELLOW = (255, 214, 64)
YELLOW_EDGE = (196, 150, 20)
YELLOW_FG = (58, 42, 0)
RED = (210, 60, 60)
RED_EDGE = (140, 28, 28)
RED_FG = (255, 245, 245)
ORANGE = (235, 140, 40)
ORANGE_EDGE = (160, 90, 20)
ORANGE_FG = (60, 38, 0)


def _active(ctx):
    return bool(getattr(getattr(ctx, '_app', None), 'takeover_active', False))


def _paused(ctx):
    """读 App 上的 takeover_paused；没这个属性按未暂停算。"""
    return bool(getattr(getattr(ctx, '_app', None), 'takeover_paused', False))


def _big(ctx, label, color, w, h):
    src = ctx.text(label, color=color)
    sw, sh = src.get_size()
    if sw <= 0 or sh <= 0 or w <= 4 or h <= 4:
        return src
    k = min(w / float(sw), h / float(sh))
    if 0.92 <= k <= 1.08:
        return src
    try:
        return pygame.transform.smoothscale(src, (max(1, int(sw * k)), max(1, int(sh * k))))
    except Exception:
        return src


def _eye_tail(n=40):
    """今天眼睛日志的最后几行（只读文件末尾一小段）；连着的「-」合成一行。"""
    path = EYE_DIR / f"eye-{time.strftime('%Y%m%d')}.log"
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            start = max(0, f.tell() - 8192)
            f.seek(start)
            lines = f.read().decode('utf-8', 'replace').splitlines()[1 if start else 0:]   # 从中间读才丢半行
    except OSError:
        return []
    out = []
    for ln in lines[-n:]:
        stamp, _, text = ln.partition(' | ')
        stamp = stamp.split(' ')[-1][:8]                      # 只留 时:分:秒
        if text == '-' and out and out[-1][1].startswith('-'):
            cnt = out[-1][1][1:].strip(' ×') or '1'
            out[-1] = (stamp, f"- ×{int(cnt) + 1}")
        else:
            out.append((stamp, text))
    return out


def _draw_eye(ctx, box):
    """按钮下面：眼睛最近看到了什么。"""
    x, y, w, h = box
    if h < ctx.s(40):
        return
    front = _front()                                         # 现在最上层、拿着键盘的窗口
    if front:
        y += ctx.text_box('前台窗口：' + front, (x, y, w, ctx.small.get_linesize() * 2), 'hdr', small=True) + ctx.s(6)
    ears = _ear_tail(3)                                      # 耳朵：电脑放的声音，10 秒一段
    lh = ctx.small.get_linesize()
    ctx.screen.blit(ctx.text('耳朵日志（10 秒一段，「-」= 没声音）', 'dim', small=True), (x, y))
    y += lh + ctx.s(2)
    if not ears:
        ctx.screen.blit(ctx.text('第一段还没听完…', 'dim', small=True), (x, y))
        y += lh
    for span, text in ears:
        y += ctx.text_box(f"{span} {text}", (x, y, w, lh * 2), 'dim' if text == '-' else None, small=True)
    y += ctx.s(8)
    ctx.screen.blit(ctx.text('眼睛日志（「-」= 画面没怎么变）', 'dim', small=True), (x, y))
    y += ctx.small.get_linesize() + ctx.s(4)
    rows = _eye_tail()
    if not rows:
        ctx.screen.blit(ctx.text('还没有记录', 'dim', small=True), (x, y))
        return
    lh = ctx.small.get_linesize()
    room = max(1, (box[1] + h - y) // lh)
    shown = []                                               # 从最新往回排，能放几行放几行（长的自动折行）
    for stamp, text in reversed(rows):
        lines = ctx.wrap(f"{stamp} {text}", w, small=True)
        if len(shown) + len(lines) > room:
            break
        shown = lines + shown
    for i, line in enumerate(shown):
        ctx.screen.blit(ctx.text(line, 'dim' if ' -' in line[:12] else None, small=True), (x, y + i * lh))


def draw(ctx):
    r = ctx.rect
    if r.w <= 4 or r.h <= 4:
        return
    full = r
    if _active(ctx) and r.h > ctx.s(160):                     # 接管中：上面按钮，下面实时眼睛日志
        r = pygame.Rect(r.x, r.y, r.w, max(ctx.s(70), int(r.h * 0.32)))
        _draw_eye(ctx, (full.x + ctx.s(8), r.bottom + ctx.s(8), full.w - ctx.s(16), full.bottom - r.bottom - ctx.s(12)))
    st = ctx.state
    st.setdefault('presses', 0)
    active = _active(ctx)
    paused = active and _paused(ctx)
    if paused:
        fill, edge, fg, label = ORANGE, ORANGE_EDGE, ORANGE_FG, '⏸ 已暂停'
    elif active:
        fill, edge, fg, label = RED, RED_EDGE, RED_FG, '停止接管'
    else:
        fill, edge, fg, label = YELLOW, YELLOW_EDGE, YELLOW_FG, '开始接管'
    radius = max(4, min(ctx.s(16), min(r.w, r.h) // 3))
    ctx.box(r.x, r.y, r.w, r.h, fill, radius=radius)
    try:
        hover = r.collidepoint(ctx.mouse)
    except Exception:
        hover = False
    ctx.box(r.x, r.y, r.w, r.h, edge, width=4 if hover else 2, radius=radius)
    surf = _big(ctx, label, fg, r.w - int(r.w * 0.18), r.h - int(r.h * 0.30))
    if surf is not None:
        ctx.screen.blit(surf, surf.get_rect(center=(r.centerx, r.centery)))
    st['last_active'] = active


def on_click(ctx, pos):
    try:
        r = ctx.rect
        if _active(ctx) and r.h > ctx.s(160):                 # 接管中按钮只占上面一块
            r = pygame.Rect(r.x, r.y, r.w, max(ctx.s(70), int(r.h * 0.32)))
        if not r.collidepoint(pos):
            return
    except Exception:
        return
    app = getattr(ctx, '_app', None)
    active = _active(ctx)
    paused = active and _paused(ctx)
    try:
        if app is not None:
            if paused:
                fn = getattr(app, 'toggle_takeover_pause', None)
                if fn is not None:
                    fn()
                else:
                    app.takeover_paused = False
            else:
                fn = getattr(app, 'stop_takeover' if active else 'start_takeover', None)
                if fn is not None:
                    fn()
                else:
                    app.takeover_active = not active
    except Exception:
        pass
    st = ctx.state
    st['presses'] = int(st.get('presses', 0) or 0) + 1
    try:
        ctx.save()
    except Exception:
        pass
    try:
        ctx.redraw()
    except Exception:
        pass


MODULE = {
    'key': 'takeover',
    'title': '接管',
    'sub': '开始接管模式 · 眼睛日志',
    'refresh': 1.0,
    'side': 'right',
    'hidden': True,
    'draw': draw,
    'on_click': on_click,
}
