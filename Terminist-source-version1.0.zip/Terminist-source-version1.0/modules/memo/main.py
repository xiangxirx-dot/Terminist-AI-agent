"""备忘录模块：两行式 iOS 滚轮 + 键盘补全。

第一行：干什么 输入框（带 Tab 候选补全/下拉）。
第二行：三列滚轮（几小时后 / 几分钟后 / 反复）。
下面是「＋ 添加」按钮和按时间排序的待办列表。
"""

import time

import pygame

REPEAT_OPTIONS = [("never", "永不"), ("5min", "5分钟后"), ("10min", "10分钟后")]
REPEAT_LABELS = {k: v for k, v in REPEAT_OPTIONS}
PRESET_WORDS = ["喝水", "休息一下", "起身活动", "该吃饭了", "吃药", "开个会", "买猫粮", "回消息", "写周报", "倒垃圾"]


# ---- 纯函数 ----
def _sort_key(it, now):
    """列表排序键：未超时在前（按 due 升序、无 due 最前），超时次之，已完成最后。"""
    done = 1 if it.get("done") else 0
    due = it.get("due") or 0
    overdue = 1 if (not it.get("done") and due and due <= now) else 0
    return (done, overdue, due)


def _fmt_remain(due, now):
    """把剩余秒数说成人话：已超时 / N秒后 / N分后 / N小时N分后 / N天后。"""
    sec = int(due - now)
    if sec <= 0:
        return "已超时"
    if sec < 60:
        return f"{sec}秒后"
    if sec < 3600:
        return f"{sec // 60}分后"
    if sec < 86400:
        return f"{sec // 3600}小时{sec % 3600 // 60}分后"
    return f"{sec // 86400}天后"


# ---- 后端：状态 ----
def _st(ctx):
    """取模块状态并补齐默认字段（全部可 JSON 序列化，绝不塞 Rect）。"""
    st = ctx.state
    st.setdefault("draft", "")
    st.setdefault("hour", 0)
    st.setdefault("min", 0)
    st.setdefault("repeat", "never")
    st.setdefault("items", [])
    st.setdefault("history", [])
    st.setdefault("cand_sel", 0)
    return st


def plus_hour(ctx, delta: int) -> None:
    """列1：几小时后 +delta，clamp 0~23。"""
    st = _st(ctx)
    st["hour"] = max(0, min(23, int(st.get("hour", 0)) + int(delta)))
    ctx.save(ctx.state)
    ctx.redraw()


def plus_min(ctx, delta: int) -> None:
    """列2：几分钟后 +delta，clamp 0~59。"""
    st = _st(ctx)
    st["min"] = max(0, min(59, int(st.get("min", 0)) + int(delta)))
    ctx.save(ctx.state)
    ctx.redraw()


def set_repeat(ctx, r: str) -> None:
    """列3：反复方式，只认 never/5min/10min，别的忽略。"""
    if r not in REPEAT_LABELS:
        return
    st = _st(ctx)
    st["repeat"] = r
    ctx.save(ctx.state)
    ctx.redraw()


def candidates(ctx) -> list:
    """候选列表：draft 空给「建议」（历史前5+预设前5），否则预设前缀匹配 + 历史前缀匹配，最多 8 条。"""
    st = _st(ctx)
    draft = str(st.get("draft", "")).strip()
    history = [h for h in st.get("history", []) if isinstance(h, str)]
    if not draft:
        out = []
        for h in history[:5] + PRESET_WORDS[:5]:
            if h not in out:
                out.append(h)
        return out
    low = draft.lower()
    preset = [w for w in PRESET_WORDS if w.lower().startswith(low)]
    hist = [h for h in history if h.lower().startswith(low) and h not in preset]
    return (preset + hist)[:8]


def _add(ctx, text: str, delay_sec: float, repeat: str = "never") -> dict:
    """加一条待办：delay_sec 秒后到点。界面的「添加」和给 Agent 的工具都走这里。"""
    st = _st(ctx)
    text = str(text or "").strip() or "待办"
    now = time.time()
    item = {"text": text, "due": now + max(0.0, float(delay_sec)), "done": False,
            "repeat": repeat if repeat in REPEAT_LABELS else "never", "next_fire": None}
    st["items"].append(item)
    if text not in st["history"] and text != "待办":
        st["history"].insert(0, text)
    ctx.notify(f"[备忘录] 已添加：{text}（{_fmt_remain(item['due'], now)}）")
    ctx.sound("tick.wav")
    ctx.save(ctx.state)
    ctx.redraw()
    return item


def add_item(ctx) -> None:
    """把顶栏草稿加进 items：空则用「待办」，due = now + hour 小时 + min 分。"""
    st = _st(ctx)
    _add(ctx, st.get("draft", ""), int(st.get("hour", 0)) * 3600 + int(st.get("min", 0)) * 60,
         st.get("repeat", "never"))
    st["draft"] = ""
    st["cand_sel"] = 0
    ctx.save(ctx.state)


# ---- 给 Agent 的工具：主人在对话里说「半小时后提醒我喝水」，Agent 直接调 ----
def tool_add(ctx, a) -> str:
    text = str(a.get("text") or "").strip()
    if not text:
        return "错误: 要写提醒什么（text）"
    minutes = float(a.get("minutes") or 0) + float(a.get("hours") or 0) * 60
    item = _add(ctx, text, minutes * 60, str(a.get("repeat") or "never"))
    when = time.strftime("%H:%M", time.localtime(item["due"]))
    return f"已加进备忘录：「{text}」，{when} 提醒（{_fmt_remain(item['due'], time.time())}）"


def tool_list(ctx, a) -> str:
    now = time.time()
    items = [it for it in _st(ctx)["items"] if not it.get("done")]
    if not items:
        return "备忘录里没有没做完的事"
    items.sort(key=lambda it: it.get("due") or 0)
    return "\n".join(f"- {it['text']}（{time.strftime('%m-%d %H:%M', time.localtime(it['due']))}，"
                     f"{_fmt_remain(it['due'], now)}"
                     f"{'，' + REPEAT_LABELS.get(it.get('repeat'), '') + '反复' if it.get('repeat') != 'never' else ''}）"
                     for it in items)


def tool_done(ctx, a) -> str:
    key = str(a.get("text") or "").strip()
    st = _st(ctx)
    hit = [it for it in st["items"] if not it.get("done") and key and key in it.get("text", "")]
    if not hit:
        return f"没找到包含「{key}」的待办"
    for it in hit:
        it["done"] = True
    ctx.save(ctx.state)
    ctx.redraw()
    return "已标记完成：" + "、".join(it["text"] for it in hit)


TOOLS = {
    "add": {"desc": "往主人的备忘录里加一条到点提醒（到点会弹通知、响提示音）。主人说「X 分钟 / 小时后提醒我…」时用。",
            "params": {"text": "提醒内容，比如「喝水」",
                       "minutes": {"type": "number", "description": "多少分钟后提醒（可以和 hours 一起用）"},
                       "hours": {"type": "number", "description": "多少小时后提醒"},
                       "repeat": {"type": "string", "enum": ["never", "5min", "10min"],
                                  "description": "到点后是否每 5 / 10 分钟再提醒一次，默认 never"}},
            "required": ["text"], "fn": tool_add},
    "list": {"desc": "列出备忘录里还没做完的事和各自的提醒时间。", "params": {}, "fn": tool_list},
    "done": {"desc": "把备忘录里包含某段文字的待办标记为完成（停止提醒）。",
             "params": {"text": "待办里包含的文字"}, "required": ["text"], "fn": tool_done},
}


def del_item(ctx, idx: int) -> None:
    """删掉 items[idx]。"""
    st = _st(ctx)
    items = st.get("items", [])
    if 0 <= idx < len(items):
        items.pop(idx)
        ctx.save(ctx.state)
        ctx.redraw()


def toggle_done(ctx, idx: int) -> None:
    """翻转 items[idx] 的 done。"""
    st = _st(ctx)
    items = st.get("items", [])
    if 0 <= idx < len(items):
        items[idx]["done"] = not items[idx].get("done")
        ctx.save(ctx.state)
        ctx.redraw()


def tick(ctx, now: float | None = None) -> None:
    """每秒巡检：到点的提醒一次；never 用 fired 去重，5min/10min 用 next_fire 循环。
    界面调的是 on_tick(ctx)（不带 now）：以前这里必须传 now，每秒都报错被吞掉，提醒从来没响过。"""
    now = time.time() if now is None else now
    st = _st(ctx)
    changed = False
    for it in st.get("items", []):
        if it.get("done"):
            continue
        due = it.get("due") or 0
        if not due or due > now:
            continue
        rp = it.get("repeat", "never")
        text = it.get("text", "")
        if rp == "never":
            if not it.get("fired"):
                ctx.notify(f"[备忘录] {text}")
                ctx.sound("alert.wav")
                it["fired"] = True
                changed = True
        else:
            gap = 600 if rp == "10min" else 300
            nf = it.get("next_fire")
            if nf is None or now >= nf:
                ctx.notify(f"[备忘录] {text}")
                ctx.sound("alert.wav")
                it["next_fire"] = now + gap
                changed = True
    if changed:
        ctx.save(ctx.state)


# ---- 界面 ----
def draw(ctx) -> None:
    """画两行式备忘录，并把本帧几何写进 st["_ui"]（纯数值）供 on_click/on_wheel 命中。"""
    st = _st(ctx)
    now = time.time()
    r = ctx.rect
    pad = ctx.s(10)
    ui = {}
    w = r.w - pad * 2

    # ---- 第一行：顶栏输入框 ----
    in_h = ctx.s(34)
    in_y = r.y + pad
    # 输入框交给框架：光标、选择、输入法、复制粘贴都不用自己写
    draft = ctx.input("draft", (r.x + pad, in_y, w, in_h), placeholder="干什么…",
                      on_submit=lambda c, _t: add_item(c), on_change=_draft_changed)
    tx = r.x + pad + ctx.s(8)

    focused = ctx.input_focused("draft")
    cands = candidates(ctx)
    sel = int(st.get("cand_sel", 0))
    y = in_y + in_h + ctx.s(2)

    # ---- 候选下拉 ----
    dd_h = 0
    ui["cands"] = []
    if cands and (draft or focused):
        row_h = ctx.s(22)
        for i, c in enumerate(cands):
            cy = y + i * row_h
            if cy + row_h > r.bottom:
                break
            if i == sel:
                ctx.box(r.x + pad, cy, w, row_h, ctx.color("btn"), radius=ctx.s(4))
                col = ctx.color("text")
            else:
                col = ctx.color("text")
            surf = ctx.text(c, col)
            ctx.screen.blit(surf, (tx, cy + (row_h - surf.get_height()) // 2))
            ui["cands"].append((r.x + pad, cy, w, row_h, i))
            dd_h = cy + row_h - y
    ui["dd_n"] = len(cands)
    ui["dd_h"] = dd_h
    ui["dd_rect"] = (r.x + pad, y, w, dd_h)
    y += dd_h + ctx.s(6)

    # ---- 第二行：三列 iOS 滚轮 ----
    col_w = w // 3
    title_h = ctx.s(14)
    row_h = ctx.s(24)          # 每档行高
    col_h = row_h * 3 + ctx.s(8)
    titles = ["几小时后", "几分钟后", "反复"]
    inert = st.get("_inert") or {}
    # 当前列值（惯性滑行中可能是小数）
    vals = [st.get("_hv"), st.get("_mv"), st.get("_rv")]
    disp = [str(st.get("hour", 0)), str(st.get("min", 0)),
            REPEAT_LABELS.get(st.get("repeat", "never"), "永不")]
    ui["cols"] = []
    ui["col_val"] = []
    ui["row_h"] = row_h
    ui["row_w"] = col_w
    for i in range(3):
        cx = r.x + pad + i * col_w
        cy = y
        ts = ctx.text(titles[i], ctx.color("dim"), small=True)
        ctx.screen.blit(ts, (cx + (col_w - ts.get_width()) // 2, cy))
        oy = cy + title_h
        mid_y = oy + row_h
        mid_x = cx + col_w // 2
        # 连续小数（惯性/拖拽中是小数）→ 像素级滚动偏移
        fallback = 0.0
        if i == 2:
            opts = [k for k, _ in REPEAT_OPTIONS]
            cur_key = st.get("repeat", "never")
            fallback = float(opts.index(cur_key) if cur_key in opts else 0)
            hv = vals[2] if isinstance(vals[2], (int, float)) else fallback
        else:
            fallback = float(st.get("hour" if i == 0 else "min", 0))
            hv = vals[i] if isinstance(vals[i], (int, float)) else fallback
        hv = float(hv)
        # 高亮格（固定不动）
        ctx.box(cx + ctx.s(2), mid_y, col_w - ctx.s(4), row_h, ctx.color("btn"), radius=ctx.s(6))
        if i == 2:
            # 第三列：纵向滚动，档距用 row_h（和第一/二列一致）
            n = len(REPEAT_OPTIONS)
            top = n - 1
            cur = max(0, min(top, int(round(hv))))
            frac = round(hv) - hv
            off_px = frac * row_h
            rows = []
            for d in (-1, 0, 1):
                j = cur + d
                if not (0 <= j <= top):
                    continue
                rows.append((j, mid_y + d * row_h + off_px))
            with ctx.clip((cx, oy, col_w, col_h)):
                for j, ty_c in rows:
                    label = REPEAT_LABELS.get(REPEAT_OPTIONS[j][0], "")
                    if j == cur:
                        ns = ctx.text(label, ctx.color("text"))
                    else:
                        ns = ctx.text(label, ctx.color("dim"), small=True)
                    ctx.screen.blit(ns, (mid_x - ns.get_width() // 2,
                                         ty_c - ns.get_height() // 2))
        else:
            # 第一/二列：纵向滚动
            top = 23 if i == 0 else 59
            cur = max(0, min(top, int(round(hv))))
            frac = round(hv) - hv
            off_px = frac * row_h
            rows = []
            for d in (-1, 0, 1):
                nv = cur + d
                if not (0 <= nv <= top):
                    continue
                rows.append((nv, mid_y + d * row_h + off_px))
            with ctx.clip((cx, oy, col_w, col_h)):
                for nv, ny in rows:
                    label = str(nv)
                    if nv == cur:
                        ns = ctx.text(label, ctx.color("text"))
                    else:
                        ns = ctx.text(label, ctx.color("dim"), small=True)
                    ctx.screen.blit(ns, (mid_x - ns.get_width() // 2,
                                         ny + (row_h - ns.get_height()) // 2))
        # 滑过档位（值非整数）→ 更亮描边
        if inert.get("col") == i and abs(hv - round(hv)) > 1e-6:
            ctx.box(cx + ctx.s(2), mid_y, col_w - ctx.s(4), row_h, ctx.color("btn_on"), width=1, radius=ctx.s(6))
        ui["col_val"].append((cx, mid_y, col_w, row_h))
        ui["cols"].append({
            "x": cx, "y": cy, "w": col_w, "h": col_h,
            "cur": (cx, mid_y, col_w, row_h),
        })
    y += col_h + ctx.s(6)

    # ---- 添加按钮（框架的按钮：悬停 / 按下效果、点击判定都不用自己写）----
    btn_h = ctx.s(34)
    ctx.button("add", (r.x + pad, y, w, btn_h), "＋ 添加", style="primary", on_click=add_item)
    y += btn_h + ctx.s(6)

    # ---- 分隔线 ----
    ctx.line([(r.x + pad, y), (r.right - pad, y)], ctx.color("border"))
    y += ctx.s(6)

    # ---- 列表（框架的滚动区：滚轮、滚动条、看不见的行点不到，都不用自己写）----
    items = st.get("items", [])
    order = sorted(range(len(items)), key=lambda j: _sort_key(items[j], now))
    row_h = ctx.s(24)
    chk = ctx.s(16)
    list_box = (r.x + pad, y, w, max(0, r.bottom - y - ctx.s(4)))
    if not order:
        ctx.screen.blit(ctx.text("还没有待办。也可以在对话里说「半小时后提醒我喝水」", "dim", True), (r.x + pad, y + ctx.s(4)))
    with ctx.scroll("list", list_box, content_h=len(order) * row_h) as top:
        for pos, idx in enumerate(order):
            it = items[idx]
            ry = top + pos * row_h
            if ry + row_h < list_box[1] or ry > list_box[1] + list_box[3]:
                continue
            done = bool(it.get("done"))
            due = it.get("due") or 0
            overdue = (not done) and due and due <= now
            bx = r.x + pad
            ctx.button(f"chk{idx}", (bx, ry + (row_h - chk) // 2, chk, chk), "✓" if done else "", style="ghost",
                       small=True, on_click=lambda c, i=idx: toggle_done(c, i))
            col = ctx.color("dim") if done else (ctx.color("warn") if overdue else ctx.color("text"))
            rem = _fmt_remain(due, now) if due else ""
            rem_s = ctx.text(rem, ctx.color("warn") if overdue else ctx.color("dim"), small=True)
            del_w = ctx.s(22)
            del_x = r.x + pad + w - del_w - ctx.s(8)
            ctx.button(f"del{idx}", (del_x, ry + ctx.s(1), del_w, row_h - ctx.s(2)), "✕", style="flat", color="warn",
                       on_click=lambda c, i=idx: del_item(c, i))
            rem_x = del_x - ctx.s(6) - rem_s.get_width()
            txt_x = bx + chk + ctx.s(8)
            label = ctx.ellipsize(it.get("text", ""), max(1, rem_x - ctx.s(6) - txt_x))
            ts = ctx.text(label, col)
            ctx.screen.blit(ts, (txt_x, ry + (row_h - ts.get_height()) // 2))
            if rem:
                ctx.screen.blit(rem_s, (rem_x, ry + (row_h - rem_s.get_height()) // 2))

    st["_ui"] = ui


def on_click(ctx, pos) -> None:
    """点击：先候选下拉，再输入框，再三列箭头，再添加按钮，再列表行，最后放焦点。"""
    st = _st(ctx)
    u = st.get("_ui") or {}
    x, y = int(pos[0]), int(pos[1])

    # 1. 候选下拉（必须真的画出来了才算命中：dd_n 数量 + dd_h 实际高度）
    if u.get("dd_n") and u.get("dd_h"):
        rx, ry, rw, rh = u.get("dd_rect", (0, 0, 0, 0))
        if rx <= x <= rx + rw and ry <= y <= ry + rh:
            for cx, cy, cw, ch, i in u.get("cands", []):
                if cx <= x <= cx + cw and cy <= y <= cy + ch:
                    cands = candidates(ctx)
                    if 0 <= i < len(cands):
                        ctx.set_input("draft", cands[i])
                    st["cand_sel"] = 0
                    ctx.save(ctx.state)
                    ctx.redraw()
                    return

    # 2. 顶栏输入框：框架（ctx.input）自己处理点击和焦点，点到这里的都是框外

    # 3. 三列滚轮：按下即刹停 + 开拖拽
    cvs = u.get("col_val") or []
    for i, (cx, cy, cw, ch) in enumerate(cvs):
        if cx <= x <= cx + cw and cy <= y <= cy + ch:
            st["_inert"] = None          # 刹停，不叠加动量
            st["_mt"] = 0.0
            st["_mv_last"] = None
            if i == 0:
                base = float(int(st.get("hour", 0)))
            elif i == 1:
                base = float(int(st.get("min", 0)))
            else:
                opts = [k for k, _ in REPEAT_OPTIONS]
                cur = st.get("repeat", "never")
                base = float(opts.index(cur) if cur in opts else 0)
            st["_drag"] = {"col": i, "base": base, "px": float(x), "py": float(y),
                           "vx": 0.0, "vy": 0.0}
            ctx.redraw()
            return

    # 4. 添加按钮、5. 列表的勾选 / 删除：都是框架控件（ctx.button），这里不用管

    # 6. 点到输入框以外：框架已经放掉了焦点
    ctx.redraw()


def on_wheel(ctx, pos, dy) -> None:
    """滚轮：列1/列2 按 dy 加减，列3 在 REPEAT_OPTIONS 里前后切换（列表的滚动框架管）。"""
    st = _st(ctx)
    u = st.get("_ui") or {}
    x, y = int(pos[0]), int(pos[1])
    step = 1 if dy > 0 else -1

    st["_inert"] = None
    st["_drag"] = None
    for i, c in enumerate(u.get("cols") or []):
        cx, cy, cw, ch = c.get("x", 0), c.get("y", 0), c.get("w", 0), c.get("h", 0)
        if cx <= x <= cx + cw and cy <= y <= cy + ch:
            if i == 0:
                plus_hour(ctx, step)
            elif i == 1:
                plus_min(ctx, step)
            else:
                opts = [k for k, _ in REPEAT_OPTIONS]
                cur = st.get("repeat", "never")
                j = opts.index(cur) if cur in opts else 0
                j = max(0, min(len(opts) - 1, j + step))
                set_repeat(ctx, opts[j])
            return

    # 列表区滚动：框架的 ctx.scroll 自己处理


def _row_size(ctx):
    """取每档像素尺寸 (row_h, row_w)，和 draw 里保持一致。"""
    u = _st(ctx).get("_ui") or {}
    return float(u.get("row_h") or ctx.s(24)), float(u.get("row_w") or ctx.s(80))


def _set_col(ctx, st, col, val):
    """把浮点列值写进对应字段（列0 hour / 列1 min / 列2 repeat），列值 clamp。"""
    if col == 0:
        st["hour"] = max(0, min(23, int(round(val))))
    elif col == 1:
        st["min"] = max(0, min(59, int(round(val))))
    else:
        j = max(0, min(len(REPEAT_OPTIONS) - 1, int(round(val))))
        st["repeat"] = REPEAT_OPTIONS[j][0]


def on_motion(ctx, pos) -> None:
    """拖拽跟手：off = round(位移 / 每档像素)，值 = clamp(base + off)，并采样速度（档/秒）。"""
    st = _st(ctx)
    drag = st.get("_drag")
    if not drag:
        return
    col = int(drag.get("col", 0))
    row_h, row_w = _row_size(ctx)
    x, y = float(pos[0]), float(pos[1])
    if col < 2:
        # 垂直列：x 得在列范围内
        cvs = (st.get("_ui") or {}).get("col_val") or []
        if col < len(cvs):
            cx, _cy, cw, _ch = cvs[col]
            if not (cx <= x <= cx + cw):
                return
        span = row_h
        delta = float(drag.get("py", y)) - y
        lo, hi = (0, 23) if col == 0 else (0, 59)
    else:
        cvs = (st.get("_ui") or {}).get("cols") or []
        if col < len(cvs):
            cx, cy, cw, ch = cvs[col]["x"], cvs[col]["y"], cvs[col]["w"], cvs[col]["h"]
            if not (cy <= y <= cy + ch):
                return
        span = row_h
        delta = float(drag.get("py", y)) - y
        lo, hi = 0, len(REPEAT_OPTIONS) - 1
    off = delta / span if span else 0
    new_v = max(float(lo), min(float(hi), float(drag.get("base", 0)) + off))

    now = time.time()
    last_t = float(st.get("_mt") or 0.0)
    last_v = st.get("_mv_last")
    if last_t and last_v is not None and now > last_t:
        dt = now - last_t
        vel = (new_v - float(last_v)) / dt
        drag["vy"] = vel
    st["_mt"] = now
    st["_mv_last"] = new_v

    _set_col(ctx, st, col, new_v)
    if col == 0:
        st["_hv"] = new_v
    elif col == 1:
        st["_mv"] = new_v
    else:
        st["_rv"] = new_v
    st["_drag"] = drag
    ctx.redraw()


def on_up(ctx, pos) -> None:
    """松手：把最后采到的速度交给惯性（_inert），不直接定档。"""
    st = _st(ctx)
    drag = st.get("_drag")
    if not drag:
        return
    col = int(drag.get("col", 0))
    if col < 2:
        vel = float(drag.get("vy") or 0.0)
        cur = float(st.get("hour" if col == 0 else "min", 0))
        _v = st.get("_hv" if col == 0 else "_mv")
        if isinstance(_v, (int, float)):
            cur = float(_v)
        d = "v"
    else:
        vel = float(drag.get("vy") or 0.0)
        _v = st.get("_rv")
        if isinstance(_v, (int, float)):
            cur = float(_v)
        else:
            opts = [k for k, _ in REPEAT_OPTIONS]
            c = st.get("repeat", "never")
            cur = float(opts.index(c) if c in opts else 0)
        if col == 2:
            cur = max(0.0, min(float(len(REPEAT_OPTIONS) - 1), cur))
        d = "v"
    st["_inert"] = {"col": col, "value": cur, "vel": vel, "dir": d}
    st["_drag"] = None
    st["_mt"] = 0.0
    st["_mv_last"] = None
    ctx.redraw()


def on_frame(ctx, dt) -> None:
    """惯性：value += vel*dt，vel 指数衰减；低于阈值缓动吸附到最近档，到位清 _inert。"""
    st = _st(ctx)
    inert = st.get("_inert")
    if not inert:
        return
    dt = max(0.0, min(0.25, float(dt or 0.0)))
    if dt <= 0:
        return
    col = int(inert.get("col", 0))
    if col == 0:
        lo, hi = 0.0, 23.0
    elif col == 1:
        lo, hi = 0.0, 59.0
    else:
        lo, hi = 0.0, float(len(REPEAT_OPTIONS) - 1)
    val = float(inert.get("value", 0.0))
    vel = float(inert.get("vel", 0.0))

    if abs(vel) >= 0.5:
        val += vel * dt
        vel *= 0.90 ** (dt * 60)
    else:
        target = float(round(val))
        val += (target - val) * min(1.0, dt * 18)
        vel = 0.0
        if abs(target - val) < 0.01:
            val = target
            st["_inert"] = None
    if val < lo:
        val = lo
        vel = 0.0
    elif val > hi:
        val = hi
        vel = 0.0

    _set_col(ctx, st, col, val)
    if col == 0:
        st["_hv"] = val
    elif col == 1:
        st["_mv"] = val
    else:
        st["_rv"] = val
    if st.get("_inert"):
        inert["value"] = val
        inert["vel"] = vel
        st["_inert"] = inert
    ctx.redraw()


def _draft_changed(ctx, _text) -> None:
    """输入框文字变了：候选从头选，顺手存盘。"""
    _st(ctx)["cand_sel"] = 0
    ctx.save(ctx.state)


def on_key(ctx, ekey, etext) -> None:
    """输入框没处理的键：Tab 补全，上下选候选（打字、退格、Enter、Esc 都由框架处理）。"""
    st = _st(ctx)

    if ekey == pygame.K_TAB:
        cands = candidates(ctx)
        if cands:
            j = max(0, min(len(cands) - 1, int(st.get("cand_sel", 0))))
            ctx.set_input("draft", cands[j])
            st["cand_sel"] = 0
            ctx.save(ctx.state)
        return

    if ekey == pygame.K_UP:
        st["cand_sel"] = max(0, int(st.get("cand_sel", 0)) - 1)
        ctx.redraw()
        return

    if ekey == pygame.K_DOWN:
        n = len(candidates(ctx))
        st["cand_sel"] = min(max(0, n - 1), int(st.get("cand_sel", 0)) + 1)
        ctx.redraw()
        return


MODULE = {"tools": TOOLS, "draw": draw, "on_click": on_click, "on_wheel": on_wheel,
          "on_motion": on_motion, "on_up": on_up, "on_tick": tick,
          "on_key": on_key, "on_frame": on_frame}
