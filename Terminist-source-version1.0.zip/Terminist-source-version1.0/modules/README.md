# Terminist 模块制作教程（功能大全）

这个文件夹放 **模块包**（`.tmod` 文件）。Terminist 启动时会自动解包、读进来；运行中放进新的包，点顶栏「模块」→「刷新模块」（或者在输入框打 `/modules reload`）就能用，不用重启。

读进来的模块先出现在「模块管理」里，点「放回」放进左栏 / 右栏；它和内置模块（员工栏、工作流、经济栏……）一样，能拖成独立小窗口，再拖回左栏 / 右栏。

> 自带的例子：`clock.tmod`（时钟，带表盘贴图和滴答声），源文件在 Terminist 根目录的 `module_sources/clock/`。照着它改最快。

---

## 一、模块包里有什么

模块包就是一个 zip 压缩包，扩展名改成 `.tmod`（直接用 `.zip` 也认）。里面是这样：

```
my_module/
├── module.json      ← 模块的名字、标题、放哪一栏……（必须）
├── main.py          ← 模块代码：怎么画、点了怎么办（必须）
└── assets/          ← 素材：贴图、音效、字体……（可选）
    ├── icon.png
    └── ding.wav
```

---

## 二、一步一步做一个模块

下面做一个「点一下就加一」的计数器，带一张贴图和一个音效。

### 1. 建文件夹

在 Terminist 根目录的 `module_sources/` 里新建一个文件夹，比如 `module_sources/counter/`。
（做的时候别放在 `modules/` 里：那里只放打好的包。要边改边试，见第七节。）

### 2. 写 `module.json`

```json
{
  "key": "counter",
  "title": "计数器",
  "side": "right",
  "sub": "点一下加一",
  "refresh": 0,
  "entry": "main.py",
  "version": "1.0",
  "author": "你的名字",
  "description": "一句话说明这个模块是干什么的"
}
```

| 字段 | 必须 | 说明 |
|---|---|---|
| `key` | 是 | 唯一的英文名（字母、数字、下划线）。不能和别的模块重名，也不能用内置模块的名字：`staff` `screen` `economy` `flow` `write` `board` `tree` |
| `title` | 是 | 标题条上显示的名字 |
| `side` | 否 | 默认放哪一栏：`left` 或 `right`（默认 `right`） |
| `sub` | 否 | 标题下面那行小字 |
| `refresh` | 否 | 每隔几秒自动重画一次。时钟这种一直在变的写 `1`；平时不变的写 `0`（只在界面有变化时画，省电） |
| `entry` | 否 | 入口代码文件，默认 `main.py` |
| `version` / `author` / `description` | 否 | 版本、作者、说明 |

> **可以不用 module.json**：单个 `.py` 模块（不需要素材时）把 `key` / `title` / `side` 这些也写进 MODULE 字典就行，见第七节。

### 3. 写 `main.py`

```python
import pygame


def draw(ctx):
    """每次重画都会调用：在 ctx.rect 这块里画你的内容。"""
    r = ctx.rect
    n = ctx.state.get("n", 0)                       # ctx.state：这个模块自己的小本子，跨帧保留

    icon = ctx.image("icon.png", (ctx.s(48), ctx.s(48)))   # 读 assets/icon.png，缩放到 48×48
    ctx.screen.blit(icon, (r.x + ctx.s(12), r.y + ctx.s(12)))

    t = ctx.text(f"点了 {n} 下", ctx.color("hdr"))  # 渲染文字（中文、主题色都处理好了）
    ctx.screen.blit(t, t.get_rect(center=r.center))


def on_click(ctx, pos):
    """在你这块里点了一下：pos 是点的位置。"""
    ctx.state["n"] = ctx.state.get("n", 0) + 1
    ctx.sound("ding.wav", 0.6)                      # 播 assets/ding.wav，音量 0.6


MODULE = {"draw": draw, "on_click": on_click}       # 名字、标题这些写在 module.json 里
```

### 4. 放素材

把 `icon.png`、`ding.wav` 放进 `assets/` 文件夹。

### 5. 打包

在 Terminist 根目录打开终端，运行：

```bash
python -m surface.modules_api pack module_sources/counter modules/counter.tmod
```

打包前会先按 Terminist 读模块的方式试读一遍：`key` 写错、找不到 `main.py`、没有 `draw` 函数，都会当场报出来，不会打出一个读不进去的包。

### 6. 装上

包已经在 `modules/` 里了：点顶栏「模块」→「刷新模块」，「计数器」就会出现在列表里，点「放回」。

要给别人用，把 `counter.tmod` 发给对方，让对方放进他的 `modules/` 文件夹，再点「刷新模块」。

---

## 三、`ctx` 能用的东西（完整清单）

`draw(ctx)` 和事件函数（`on_click` 等）拿到的 `ctx`，是给模块用的小接口——不把整个界面对象交出去，模块写错了也只会坏自己这一块。

### 画布与字体

| 名字 | 是什么 |
|---|---|
| `ctx.screen` | 要画上去的 pygame Surface。已经裁到你这一块，画出界也不会盖到别人 |
| `ctx.rect` | 你的内容区（标题条下面那块），pygame `Rect` |
| `ctx.text(文字, color=None, small=False)` | 渲染文字，返回 Surface。中文没问题，`small=True` 用小号字 |
| `ctx.font` / `ctx.small` | 大 / 小号字体（想自己 `render` 时用） |
| `ctx.text_size(文字, small=False)` | 量文字渲染后的 `(宽, 高)`，不落笔 |
| `ctx.s(像素)` | 按界面缩放换算像素。尺寸都过一下它，界面放大缩小时你的模块跟着变 |

### 颜色与图形

| 名字 | 是什么 |
|---|---|
| `ctx.color(名字)` | 主题颜色，换主题自动跟着变：`text` 正文、`dim` 灰字、`hdr` 标题蓝、`panel` 底色、`bg` 更深的底色、`border` 边框、`add` 绿、`del` 红 |
| `ctx.box(x, y, w, h, color, width=0, radius=0)` | 矩形。`width=0` 填充、`>0` 只描边；`radius>0` 圆角 |
| `ctx.circle(cx, cy, r, color, width=0)` | 圆。`width=0` 填充、`>0` 只描边 |
| `ctx.line([(x, y), …], color, width=1)` | 折线 |
| `ctx.polygon([(x, y), …], color, width=0)` | 多边形。`width=0` 填充、`>0` 只描边 |
| `ctx.clip((x, y, w, h))` | 可 `with` 的裁剪区：`with ctx.clip(box):` 里画的东西只在这块可见，退出恢复整块 |

> 图形函数的 `color` 可以是主题色名字（`"hdr"`）、RGB 元组或 `pygame.Color`。

### 素材

| 名字 | 是什么 |
|---|---|
| `ctx.image(文件名, size=None)` | 读贴图（png / jpg），返回 Surface。读一次就缓存，每帧调用也不卡。`size=(宽, 高)` 顺便缩放 |
| `ctx.sound(文件名, volume=1.0)` | 播音效（wav / ogg）。电脑没声卡、文件读不了都静默跳过，不报错 |
| `ctx.asset(文件名)` | 素材的完整路径（想自己读 json、字体之类时用） |

> 素材文件名先在 `assets/` 里找，再在模块根目录找；不能用 `..` 跑出模块文件夹。

### 状态

| 名字 | 是什么 |
|---|---|
| `ctx.state` | 你这个模块自己的 dict，跨帧保留（存开关、计数、选项）。刷新模块时也保留 |
| `ctx.mouse` | 鼠标现在的位置 |
| `ctx.now` | 现在的时间（`time.time()`） |
| `ctx.title` / `ctx.side` / `ctx.refresh` | 模块标题 / 停在哪一栏 / 自动重画间隔（只读） |
| `ctx.redraw()` | 让模块下一帧马上重画（不等 refresh） |
| `ctx.save(data=None) -> bool` | 把状态存成文件（默认存 `ctx.state`）；成功 True，失败 False |
| `ctx.load() -> dict` | 读回存过的状态；没文件 / 读坏了返回 `{}` |

---

## 四、鼠标事件大全

MODULE 里除了 `draw`，还能挂这些**可选**事件函数：

| 名字 | 什么时候调 | 参数 |
|---|---|---|
| `on_click(ctx, pos)` | 左键按下 | `pos` 是 (x, y) |
| `on_up(ctx, pos)` | 左键抬起 | `pos` 是 (x, y) |
| `on_wheel(ctx, pos, dy)` | 滚轮 | `pos` 是鼠标 (x, y)；`dy` 往上滚为正、往下滚为负 |
| `on_motion(ctx, pos)` | 鼠标移动 | `pos` 是 (x, y) |
| `on_enter(ctx)` | 鼠标进入你的那块 | 无 |
| `on_leave(ctx)` | 鼠标离开你的那块 | 无 |
| `on_key(ctx, key, text)` | 拿着键盘焦点时按键 / 打字（输入框不处理的键也会到这里） | pygame 键码、文字 |
| `on_drop(ctx, path)` | 从资源管理器把文件拖到你的那块上 | 文件完整路径 |

**不是鼠标的事件**（同样写进 MODULE，都可选）：

| 名字 | 什么时候调 |
|---|---|
| `on_load(ctx)` | 模块读进来（包括刷新后重读）之后第一帧 |
| `on_unload(ctx)` | 模块要被换掉 / 删掉 / 停用之前：在这里停掉自己开的线程、关文件 |
| `on_resize(ctx, w, h)` | 面板尺寸变了（包括第一次画之前） |
| `on_tick(ctx)` | 每秒一次，面板没打开也照跑（闹钟、到点提醒） |
| `on_frame(ctx, dt)` | 每帧一次（做动画；要重画就调 `ctx.redraw()`） |
| `on_global(ctx, name, value)` | 任何模块改了一个全局变量 |
| `on_message(ctx, event, data, sender)` | 别的模块 `ctx.emit(...)` 发消息过来 |
| `on_agent(ctx, kind, text)` | Agent 有动态：`kind` 是 `tool`（调了什么工具）/ `result` / `done`（这一轮做完）/ `error` / `info` |
| `on_theme(ctx)` | 主人换了界面主题（深色 / 浅色……） |

所有事件函数出错都只记下来（见「八、出问题怎么查」），不会弄坏界面。

都写进 MODULE 字典：

```python
MODULE = {"draw": draw, "on_click": onclick, "on_wheel": onwheel, "on_motion": onmove}
```

> 这些事件统一由内部的 `event(kind, …)` 入口分发，`kind` 是 `down / up / wheel / motion / enter / leave`。事件函数出错只会让那一次事件失效，不会弄坏界面。

### 输入框：只给位置，别的框架全包

**不要自己用 `on_key` 拼输入框**（自己写的没有光标、输入法预览、粘贴、选择）。在 `draw` 里调一句：

```python
def draw(ctx):
    r = ctx.rect
    text = ctx.input("name", (r.x + 10, r.y + 10, r.w - 20, ctx.s(32)),
                     placeholder="输入点什么…",
                     on_submit=lambda ctx, t: ctx.notify("你写了：" + t))
```

- 文字就存在 `ctx.state["name"]`，`ctx.save()` 会一起存盘；返回值是当前文字。
- 框架负责：画框（有焦点亮边）、点一下拿焦点、光标闪烁、打字、中文输入法预览和候选框位置、退格 / Delete / ←→ / Home / End、Shift 选择 / 拖拽选择 / 双击全选、Ctrl+A/C/X/V、文字太长自动横向滚动、Esc 或点框外放掉焦点。
- 可选参数：`placeholder`、`password=True`（显示圆点、不许复制）、`max_len`、`small=True`（小号字）、`on_submit(ctx, text)`（按 Enter）、`on_change(ctx, text)`（文字变了）。
- 输入框不处理的键（Tab、↑↓、没给 `on_submit` 时的 Enter）照常进你的 `on_key(ctx, key, text)`，可以用来做补全。
- 一个模块可以放几个输入框，`name` 不同就行。辅助：`ctx.input_focused(name=None)`、`ctx.focus_input(name)`、`ctx.set_input(name, text)`（改文字并把光标放到末尾）。

### 全局变量：所有模块共用的设置

`ctx.state` 只有你自己的模块能看到。要和别的模块共用的东西（城市、单位、音量、深色模式开关……），在 MODULE 里声明成**全局变量**：

```python
MODULE = {
    "draw": draw,
    "globals": {
        "city": "北京",                                        # 简写：只给默认值，类型按默认值推断
        "volume": {"default": 5, "min": 0, "max": 10, "title": "提示音音量", "desc": "0 是静音"},
        "unit": {"options": ["摄氏", "华氏"], "title": "温度单位"},   # 有 options 就是下拉选择
        "quiet": {"default": False, "title": "勿扰模式"},
    },
    "on_global": on_global,          # 可选：任何模块改了全局变量都会调它
}

def draw(ctx):
    city = ctx.get_global("city")    # 读：改过的值 > 默认值

def on_global(ctx, name, value):
    if name == "city":
        ctx.state["weather"] = None  # 城市换了：重新取天气
```

- `module.json` 里也能写 `"globals": {...}`，和 MODULE 里的合并（module.json 优先）。
- `type` 可写 `str` / `int` / `float` / `bool` / `choice`，不写就按默认值推断。数字可以给 `min` / `max`。
- 读写：`ctx.get_global(name, default=None)`、`ctx.set_global(name, value)`（按类型转换，`"8"` 会转成 8；转不了或超范围抛 `ValueError`；值没变返回 False）、`ctx.reset_global(name)`（恢复默认）、`ctx.globals`（所有当前值的拷贝）。
- **任何模块都能读写任何全局变量**，不管是谁声明的；值存在 `modules/.state/_globals.json`，重启不丢。
- 谁改了，所有模块马上重画，带 `on_global(ctx, name, value)` 的都会收到通知。
- 两个模块声明了同名变量：类型一样就是同一个（标题、默认值以先读到的为准）；类型不一样会在「模块管理」里报错。
- 主人可以在顶栏「模块」→「全局模块设置」面板里直接改：文字和数字用输入框，开关点一下切换，选项点一下换下一个，改过的有「默认」可以恢复。

### 控件：按钮、勾选、滑块、下拉、滚动区（只给位置）

和输入框一样，**别自己算坐标判断点没点中**，在 `draw` 里直接用：

```python
def draw(ctx):
    r, s = ctx.rect, ctx.s
    if ctx.button("save", (r.x + 10, r.y + 10, s(80), s(30)), "保存", style="primary"):
        ctx.notify("存好了")                                 # 点了一次：这一帧返回 True
    ctx.checkbox("auto", (r.x + 10, r.y + 50, s(200), s(24)), "自动刷新", switch=True)
    ctx.slider("vol", (r.x + 10, r.y + 80, s(220), s(24)), 0, 10)
    ctx.select("city", (r.x + 10, r.y + 110, s(160), s(28)), ["北京", "上海", ("gz", "广州")])
    items = ctx.state.get("items", [])
    with ctx.scroll("list", (r.x + 10, r.y + 150, r.w - 20, r.h - 160), content_h=len(items) * s(28)) as top:
        for i, it in enumerate(items):
            y = top + i * s(28)
            ctx.text_box(it, (r.x + 14, y, r.w - 80, s(28)))
            ctx.button(f"del{i}", (r.right - 40, y, s(24), s(24)), "✕", style="flat", color="warn",
                       on_click=lambda c, i=i: c.state["items"].pop(i))
```

| 控件 | 值存在哪 | 说明 |
|---|---|---|
| `ctx.button(name, box, label, on_click=fn(ctx), style=…, enabled=True, small=False, color=None)` | — | 按下再在按钮上松开算点击；调 `on_click`，这一帧返回 True。`style`：`normal` / `primary` / `danger` / `ghost`（描边）/ `flat`（只有字，悬停才有底） |
| `ctx.checkbox(name, box, label, on_change=fn(ctx, v), switch=False)` | `ctx.state[name]`（True / False） | `switch=True` 画成开关 |
| `ctx.slider(name, box, lo, hi, step=1, on_change=…, show_value=True, fmt=fn(v))` | `ctx.state[name]` | 拖、点、滚轮都能改；`lo`、`step` 是整数就存整数 |
| `ctx.select(name, box, options, on_change=…, placeholder="请选择")` | `ctx.state[name]` | `options` 写字符串，或 `(值, "显示的字")`；展开的列表画在最上层，列表里能滚轮 |
| `with ctx.scroll(name, box, content_h) as top:` | 滚动位置自己记 | 里面按 `y = top + …` 画；滚轮、拖滚动条框架管；滚出去的控件 / 输入框点不到。`ctx.scroll_to(name, 0)` 回到顶部 |

**文字排版**：`ctx.wrap(text, width, small=False)` 折成几行（返回行列表）；`ctx.ellipsize(text, width)` 太长截断加「…」；`ctx.text_box(text, (x, y, w, h), color=None, small=False, align="left")` 在框里画一段自动换行的文字（放不下的最后一行加「…」），返回用掉的高度。颜色参数都认主题色名字（`"dim"`、`"warn"`……）。

### 给 Agent 用的工具：让模块和对话连起来

模块可以声明工具，**Agent 在对话里直接调**。比如备忘录声明了「加提醒」，主人说「半小时后提醒我喝水」，Agent 就会调它：

```python
def add(ctx, a):                      # a 是 Agent 传来的参数 dict
    ctx.state.setdefault("todo", []).append(a["text"])
    ctx.save()
    return f"已记下：{a['text']}"      # 返回给 Agent 看的结果（字符串；dict / list 会转成 JSON）

MODULE = {
    "draw": draw,
    "tools": {
        "add": {"desc": "往待办里加一条。主人说「记一下…」时用。",
                "params": {"text": "要记的内容",                              # 只写一句话 = 字符串参数
                           "minutes": {"type": "number", "description": "几分钟后提醒"}},
                "required": ["text"],
                "fn": add},
    },
}
```

- Agent 看到的工具名是 `<模块key>__<工具名>`（比如 `memo__add`），说明前面会注明来自哪个模块。**`desc` 要写清楚什么时候该用它**，Agent 靠这句话决定调不调。
- 工具函数在界面主线程里跑（和 `draw` 同一个线程，改 `ctx.state` 不会打架），最多 60 秒。
- 刷新 / 停用模块后，Agent 下一次请求就看到新的工具表。
- 反过来，模块也能**请 Agent 做事**：`ctx.ask_agent("帮我把今天的待办整理成一份周报")`。像主人在对话框里说了一句（会注明是哪个模块请的）；Agent 正在忙就排着，空了马上交。

### 后台做事：不卡界面

`draw` 每秒可能跑几十次，里面**绝对不要**直接联网或做慢的事。用这两个：

```python
def draw(ctx):
    r = ctx.fetch("https://api.example.com/weather?city=北京", cache=600)   # 第一次是 None
    if r is None:
        ctx.text_box("加载中…", (ctx.rect.x + 10, ctx.rect.y + 10, 200, 30))
    elif r["error"]:
        ctx.text_box("出错了：" + r["error"], (ctx.rect.x + 10, ctx.rect.y + 10, 300, 30), "warn")
    else:
        ctx.text_box(f"{r['json']['temp']}°", (ctx.rect.x + 10, ctx.rect.y + 10, 200, 30))
```

- `ctx.fetch(url, on_done=None, method="GET", data=None, json_body=None, headers=None, cache=60, timeout=15)`：后台请求，**马上返回**缓存里的结果（没有就是 None），取回来以后模块自动重画；给了 `on_done` 就在主线程调 `on_done(ctx, result)`。`result` 是 `{"status", "text", "json", "error"}`。能发 POST（`method="POST", json_body={...}`）。同一个请求在 `cache` 秒内不重复发，同时发了好几次也只真发一次。
- `ctx.run_bg(fn, on_done=None)`：后台跑任意耗时的 `fn()`（读大文件、算东西），跑完在主线程调 `on_done(ctx, result, error)`。`fn` 里别碰 `ctx.screen`。
- 老的 `ctx.http_get(url)` 还能用，但它会**卡住界面直到请求回来**，新代码请用 `ctx.fetch`。

### 模块之间互相说话

- `ctx.emit(event, data=None, to=None)`：发消息给别的模块，它们的 `on_message(ctx, event, data, sender)` 收到（`sender` 是发消息的模块 key）。`to="某个key"` 只发给它。返回收到的模块数。
- 要「一直共用的值」用全局变量（上一节）；要「发生了一件事」用 `emit`。

### 系统能力

| 名字 | 是什么 |
|---|---|
| `ctx.clipboard_get()` / `ctx.clipboard_set(text)` | 读 / 写系统剪贴板 |
| `ctx.toast(text)` | 弹 Windows 系统通知（右下角，Terminist 最小化了也看得到）；弹不了就退回界面里的通知 |
| `ctx.open_url(url)` | 用系统浏览器打开网址（只认 http / https） |
| `ctx.browse(url_or_words)` | 在 Terminist 的小屏幕（内置小浏览器）里打开网址或搜索词 |
| `ctx.colors` / `ctx.dark` | 当前主题所有颜色的拷贝 / 是不是深色主题 |
| `on_drop(ctx, path)` | 文件拖到你的那块上（见上面事件表） |

**主题色名字**（`ctx.color(名字)`，也能直接写在 `ctx.box` / `ctx.text` / 控件的颜色参数里）：
`bg`（主背景）`panel`（面板）`text`（正文）`dim`（次要文字）`border`（分割线 / 边框）`btn`（按钮）`btn_on`（主色按钮）`on_text`（彩色按钮上的白字）`input_bg` `input_border` `input_focus`（输入框）`hdr`（标题 / 强调色）`warn`（警告橙）`add`（成功绿）`del`（删除红）。换主题时这些都会变，所以**别把颜色写死成 RGB**，写名字，模块就自动跟着主题走。

---

## 五、数据读入、后台任务与联网

模块是普通 Python 代码，本来就能 `import`、读文件、联网。但 Terminist 给了一组**受约束**的接口，防止模块乱写系统文件：

| 名字 | 是什么 |
|---|---|
| `ctx.read_file(name)` | 读模块目录里的文本文件（名字不许跑出模块目录，跑出去抛异常） |
| `ctx.write_file(name, text) -> bool` | 把 text 写进模块目录里的文件；成功 True，路径跑出模块目录 / 失败返回 False |
| `ctx.fetch(url, on_done=None, …)` | **推荐**：后台请求网址，不卡界面（见上面「后台做事」） |
| `ctx.run_bg(fn, on_done=None)` | 后台跑耗时的函数（见上面「后台做事」） |
| `ctx.http_get(url, timeout=10) -> dict` | 老接口：GET 一个网址，**会卡住界面直到回来**；返回 `{"status", "text", "json", "error"}`；同一个 url 60 秒内用缓存 |
| `ctx.tool(name, **kwargs) -> str` | 只读调用 A库工具，白名单制（见下），返回字符串 |
| `ctx.import_lib(name)` | import `lib_a` 下的模块，返回模块对象；越界 / 失败返回 None |
| `ctx.notify(text)` | 在界面左下角弹一条通知 |
| `on_tick(ctx)` | 主循环每秒调一次，面板不可见也照跑，给闹钟 / 定时提醒这类后台任务用（写进 MODULE 字典即可） |

`ctx.tool` 的**只读白名单**（只有这些名字能用，写类工具一律返回空串）：

```
now  file_stats  find_files  grep_files  read_lines
web_history  web_last  bg_list  bg_output
credentials_list  credentials_get
graph_query  recall  web_search  web_open
```

---

## 六、自定义斜杠命令

模块可以注册自己的 `/命令`：用户在输入框敲「`/hi 你好`」，就调用你写的函数，返回的文字直接上屏（像 A库 说话一样）。

### 怎么声明

在 MODULE 里写 `commands` 字段，格式 `{前缀: 函数}`：

```python
def cmd_hi(ctx, arg):
    """用户敲 /hi 你好 时调用，arg = "你好"；敲 /hi 时 arg = ""。"""
    return "你好" + ("，你说：" + arg if arg else "")


def cmd_quiet(ctx, arg):
    """返回 None 就不上屏（适合只做副作用、或者自己用 ctx 画）。"""
    ctx.state["quiet"] = arg or "(空)"
    return None


MODULE = {"key": "my_cmd", "title": "我的命令", "draw": draw,
          "commands": {"hi": cmd_hi, "quiet": cmd_quiet}}
```

### 规则

- **前缀**：纯英文、字母开头（字母 / 数字 / 下划线），小写，不带斜杠。写错了加载时报错。
- **函数签名**：`fn(ctx, arg)`。`ctx` 和 `draw` 里拿到的一样；`arg` 是 `/前缀` 后面的剩余字符串，可能为空串 `""`。
- **返回值**：返回 `str` 上屏；返回 `None`（或空串）不上屏。
- **冲突**：两个模块注册同一个前缀，读模块时报错，会指明是哪两个模块撞了。
- **busy 时也能跑**：哪怕 A库 正在忙、普通斜杠命令被暂时拦下，模块命令照样能跑。
- **内置命令优先**：`/stop` `/pause` `/plan` `/criticize` `/queue` 这些内置命令永远排在模块命令前面，不会被模块抢。
- **看得见**：输入 `/help` 会把所有模块注册的命令前缀列出来。

> 现成的最小示例：`modules/_example_cmd/main.py`，照着抄即可（不想要就整个删掉）。

---

## 七、边改边试（不用每次打包）

做模块的时候，可以把整个文件夹（例如 `counter/`）直接放进 `modules/` 里。Terminist 认得「没打包的模块文件夹」，你改了代码或素材，点「刷新模块」就能看到效果。

**改了就自动生效**：Terminist 每 1.5 秒看一眼 `modules/`，文件改了、加了、删了会自动重新读（旧的那份先收到 `on_unload`），不用再点「刷新模块」。模块自己的 `ctx.state` 重读后保留。

**不开界面自测**：在 Terminist 根目录下执行

```
python -m surface.modules_api test 模块文件夹或.tmod
```

它在一份临时拷贝上（不碰你真的状态）把模块读进来、在两种尺寸下画、点每一个控件、往每个输入框打字回车、滚轮、按键、跑 `on_tick` / `on_frame`、检查给 Agent 的工具定义、最后 `on_unload`，每一步打印「通过 / 出错」，出错的带完整报错位置。打包前跑一遍。

**停用而不删**：「模块管理」→「已装的外接模块」里每个模块后面有「停用 / 启用」，停用的不读、不跑（记在 `modules/.disabled.json`）。

做完以后，记得把这个文件夹从 `modules/` 里拿出来，打成 `.tmod` 包再放回去，不然文件夹和包会因为 `key` 重名，只有一个能读进来。

**怎么打成包（分发）**

在 Terminist 根目录下执行：

```
python -m surface.modules_api pack 模块文件夹名
```

比如 `python -m surface.modules_api pack memo`。打出来叫 `memo.tmod`，放在文件夹旁边。打之前会自动按 Terminist 读模块的方式试读一遍，`key` / 入口 / `draw` 有问题当场报错，读不了就不打。把 `.tmod` 拷进 `modules/` 给别人，别人点「刷新模块」就能装上。

最简单的模块甚至可以只是一个 `.py` 文件（不需要素材时），直接放进 `modules/`，在文件里用 `MODULE = {"key": ..., "title": ..., "side": ..., "draw": ...}` 把名字也写上。

---

## 八、出问题怎么查

- **「模块管理」里写着「读不了 xxx：……」**：读包的时候就出错了，后面写的就是原因，常见的有 `key` 没写或重名、找不到入口代码、没有 `draw` 函数、`module.json` 不是合法的 JSON、`commands` 前缀写错或撞名。
- **模块那块写着「模块出错：……」**：读进来了，但 `draw` 运行出错，后面是报错的最后一行。改好代码保存，会自动重新读。只有你这一块会出错，Terminist 别的部分不受影响。
- **完整的出错位置**：模块里任何代码出错（`draw`、事件函数、工具、`on_tick`、后台的 `run_bg`……）都会把完整的报错（哪个文件第几行）追加到 `modules/.logs/<key>.log`。「模块管理」里出过错的模块会标红。
- **自己没法复现**：用 `python -m surface.modules_api test 模块文件夹` 不开界面点一遍（见「七」）。
- **换了新包没生效**：点一下「刷新模块」。Terminist 发现包变了，会重新解包、重新读。
- **解开的文件在哪**：`modules/_unpacked/<包名>/`。这是 Terminist 自动生成的，删了也没事，下次读的时候会重新解。

---

## 九、注意

- **安全**：模块是普通的 Python 代码，和 Terminist 跑在同一个进程里，能做 Terminist 能做的任何事（读写你的文件、联网、启动程序）。上面说的「只读白名单」「不许写出模块目录」只管 `ctx.tool` / `ctx.write_file` 这几个接口，**拦不住模块自己 `import os` 去做别的**。装别人的 `.tmod` 就等于运行别人的代码：**只装你信得过的模块包**。第一次装上新模块时 Terminist 会提醒一次；不想要了在「模块管理」里停用。
- `draw` 会被频繁调用（`refresh` 写了秒数时，每隔那么久一次；界面有变化时也会调用），里面别做慢的事情（联网、读大文件）：用 `ctx.fetch` / `ctx.run_bg`，结果到了模块会自动重画。
- 一个模块包解开最多 200MB。
