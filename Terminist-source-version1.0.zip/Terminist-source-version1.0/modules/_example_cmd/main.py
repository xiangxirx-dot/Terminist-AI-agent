# -*- coding: utf-8 -*-
"""示例模块：示例命令（用户可以随便删掉这个文件夹）。

— 怎么声明命令 —
在 MODULE 里写 "commands" 字段，格式 {前缀: 函数}：
    MODULE["commands"] = {"hi": fn}
  · 前缀：纯英文、字母开头（字母 / 数字 / 下划线），小写，不带斜杠。
  · 用户在输入框打「/hi 你好」就调用 fn(ctx, "你好")。

— 函数签名 —
    def fn(ctx, arg):
        ...
  · ctx：和 draw 里拿到的一样（ctx.screen / ctx.text / ctx.state / ctx.color …）。
  · arg：/前缀 后面剩下的那串字符串，可能为空串 ""（用户只打「/hi」时）。

— 返回值 —
  · 返回 str：内容直接上屏，显示在对话里（像 A库 说话一样）。
  · 返回 None（或空串）：不上屏，什么都不显示（适合只做副作用、或者自己用 ctx 画东西）。

— 另外 —
  · on_click / on_wheel / on_motion / on_enter / on_leave / on_tick 都是可选的，见 modules/README.md。
  · 这个模块本身就是给你照着抄的模板，不想要就整个文件夹删掉。
"""

import pygame


def cmd_hi(ctx, arg):
    """示例命令 /hi [要说的话]：返回一行字，直接上屏。"""
    return "你好" + ("，你说：" + arg if arg else "")


def cmd_quiet(ctx, arg):
    """示例命令 /quiet：返回 None 就不上屏（这里只是示范返回 None 的写法）。"""
    ctx.state["last_quiet"] = arg or "(空)"
    return None


def draw(ctx):
    """面板区随便画一行字（这个面板的存在只是为了让你看到模块长什么样）。"""
    r = ctx.rect
    x, y = r.x + 12, r.y + 8
    ctx.text("示例模块（可删）", color=ctx.color("hdr"))
    ctx.text("命令：/hi 你要说的话", color=ctx.color("dim"), small=True) if "dim" in ctx._colors \
        else ctx.text("命令：/hi 你要说的话", small=True)
    pygame.draw.line(ctx.screen, ctx.color("dim") if "dim" in ctx._colors else ctx.color("text"),
                     (x, y + 44), (r.right - 12, y + 44), 1)


MODULE = {
    "key": "example_cmd",
    "title": "示例命令",
    "side": "right",
    "draw": draw,
    "commands": {"hi": cmd_hi, "quiet": cmd_quiet},
}
