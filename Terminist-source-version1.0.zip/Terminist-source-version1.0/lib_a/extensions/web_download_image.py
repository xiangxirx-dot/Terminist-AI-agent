"""
扩展：按 URL 把网络图片下载到本地文件。

用标准库 urllib 实现，不依赖第三方库。
  - 只允许 http/https；
  - 目标路径先按工作区解析（遵守沙箱和只写目录限制）；没打开文件夹或不在工作区里时退到桌面，Terminist 自己的文件夹除外；
  - 没写后缀时按 Content-Type 自动补（未知用 .jpg）；
  - 带浏览器 User-Agent 和可选 Referer，避免图片站防盗链 403；
  - 只接受 image/* 的 Content-Type，防止把 HTML 错误页当图片存下来；
  - 15 秒超时，20MB 上限，超限会删掉半截文件。

用法：先用 web_open/web_click 找到图片详情页或原图地址，再用本工具下载。
"""

import urllib.error
import urllib.parse
import urllib.request

from lib_a import tool

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
TIMEOUT = 15
MAX_BYTES = 20 * 1024 * 1024
CHUNK = 64 * 1024

# Content-Type -> 扩展名
CT_EXT = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
    "image/bmp": ".bmp",
    "image/avif": ".avif",
    "image/x-icon": ".ico",
    "image/vnd.microsoft.icon": ".ico",
    "image/tiff": ".tiff",
}


def _target(ws, path: str):
    """先按工作区解析；没打开文件夹、或路径不在工作区里时，退到桌面（和 desktop_* 工具同样的授权）。"""
    if ws is not None:
        try:
            return ws, ws.resolve(path)
        except ValueError:
            pass
    from pathlib import Path
    from base.tools import desktop_dir
    from lib_a import APP_ROOT, Workspace
    desk = Workspace(desktop_dir(), auto_yes=True)
    desk.protected = [Path(APP_ROOT).resolve()]
    desk.protected_msg = "错误: 这是 Terminist 自己的文件夹，不能往里面存图片"
    try:
        return desk, desk.resolve(path)
    except ValueError:
        raise ValueError(f"只能存到当前工作区或桌面（{desk.root}）里：{path}") from None


@tool("web_download_image",
      "按 URL 把网络图片下载到本地文件。先用 web_open/web_click 找到图片详情页或原图地址，再用本工具保存。",
      {"url": {"type": "string", "description": "图片原图地址（只支持 http/https）"},
       "path": {"type": "string", "description": "保存路径：相对工作区的路径，或桌面里的绝对路径（没打开文件夹时相对桌面）；没写后缀会按图片类型自动补"},
       "referer": {"type": "string", "description": "可选，来源页地址，部分图片站需要"}},
      ["url", "path"])
def web_download_image(ws, url: str, path: str, referer: str = "") -> str:
    url = (url or "").strip()
    path = (path or "").strip()
    referer = (referer or "").strip()
    if not url:
        return "错误: url 不能为空"
    if not path:
        return "错误: path 不能为空"
    if urllib.parse.urlparse(url).scheme.lower() not in ("http", "https"):
        return "错误: 只支持 http/https 链接"
    try:
        ws, p = _target(ws, path)
    except Exception as e:
        return f"错误: {e}"
    if err := ws.check_writable(p):
        return err
    if p.is_dir():
        return f"错误: {path} 是目录，请给一个文件名"

    req = urllib.request.Request(url, headers={"User-Agent": UA})
    if referer:
        req.add_header("Referer", referer)
    try:
        resp = urllib.request.urlopen(req, timeout=TIMEOUT)
    except urllib.error.HTTPError as e:
        return f"错误: 下载失败 HTTP {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return f"错误: 下载失败 {e.reason}"
    except Exception as e:
        return f"错误: 下载失败 {e}"

    size = 0
    try:
        ct = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if not ct.startswith("image/"):
            return f"错误: 这不是图片（Content-Type: {ct or '未知'}），已放弃下载"
        if not p.suffix:
            p = p.with_name(p.name + CT_EXT.get(ct, ".jpg"))
        err = ws.check_writable(p)
        if err:
            return err
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "wb") as f:
                while True:
                    chunk = resp.read(CHUNK)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_BYTES:
                        break
                    f.write(chunk)
        except OSError as e:
            p.unlink(missing_ok=True)
            return f"错误: 写入失败 {e}"
        if size > MAX_BYTES:
            p.unlink(missing_ok=True)
            return "错误: 图片超过 20MB 上限，已删除"
    finally:
        try:
            resp.close()
        except Exception:
            pass

    if size < 1024 * 1024:
        size_text = f"{size / 1024:.1f} KB"
    else:
        size_text = f"{size / 1024 / 1024:.2f} MB"
    return f"已保存 {p}（{size_text}，{ct}）"
