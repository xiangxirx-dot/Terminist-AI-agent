"""
扩展：网页要求注册/登录时，向主人请求账号密码并保存到本地。

只在网页确实要求登录/注册时才用：
  - 不要自己编造账号密码，也不要自己注册；
  - 用户可能拒绝，被拒绝就请主人自己登录；
  - 明文密码只落在本地存储文件里，返回给 A库 的字符串里永远不带密码，
    要填密码时用 web_type 传本地保存的密码。
"""

from lib_a import tool

try:
    from lib_a.extensions import credentials_store
except Exception:
    credentials_store = None


@tool("web_need_credentials",
      "网页要求注册或登录、又需要填账号密码时，向主人请求账号密码并保存到本地。"
      "只在网页确实要求登录/注册时才调用；不要自己编造账号密码，也不要自己注册。"
      "用户可能拒绝，被拒绝就请主人自己登录。",
      {"site": {"type": "string", "description": "网站名或域名"},
       "note": {"type": "string", "description": "可选，为什么要账号，例如：要先注册才能看"}},
      ["site"])
def web_need_credentials(ws, site: str, note: str = "") -> str:
    site = (site or "").strip()
    note = (note or "").strip()
    if not site:
        return "错误: site 不能为空"
    if ws is None or not hasattr(ws, "ask_credentials"):
        return "当前没有工作区，无法向主人请求账号密码（请先打开文件夹）。"

    try:
        res = ws.ask_credentials(site, note)
    except Exception:
        res = None
    if not isinstance(res, dict) or not res.get("ok"):
        return ("用户拒绝提供账号密码：不要猜、不要编造账号密码，也不要自己注册；"
                "告诉主人这一步需要他/她自己登录，或者等主人提供。")

    username = str(res.get("username") or "").strip()
    password = str(res.get("password") or "")
    remember = bool(res.get("remember"))
    path_text = "本地"
    saved = False
    if credentials_store is not None:
        try:
            credentials_store.save(site, site, username, password, remember)
            saved = True
            path_text = str(credentials_store.store_path())
        except Exception:
            saved = False
    if not saved:
        return (f"用户已提供账号 {username}，但保存到本地失败；"
                "用 web_type 把账号填进对应的输入框，密码请主人自己输入，不要把密码写进对话。")
    return (f"用户已提供账号 {username}，密码已保存到本地（{path_text}）；"
            "用 web_type 把账号和密码填进对应的输入框，不要把密码写进对话。")
