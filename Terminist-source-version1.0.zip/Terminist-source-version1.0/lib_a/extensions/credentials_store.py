"""
密钥本地存储模块：把账号密码存到桌面的 JSON 文件里，按站点覆盖更新。

说明：
  - 存储位置：桌面 / "散兵-密钥" / "credentials.json"
  - 密码不明文落盘：4 片盐分散在磁盘不同位置 -> pbkdf2 派生每站点独立密钥
    -> 明文先 XOR 密钥流再乱序 -> base64 存成 "v1:" 前缀的密文，文件里只有密文
  - 全部函数容错，出错只返回空值或中文错误说明，不抛异常
  - 每个工具函数的第一个参数 ws 用不到，直接忽略（没打开文件夹也能用）
"""

import binascii
import hashlib
import hmac
import json
import os
import random
from datetime import datetime
from pathlib import Path

from lib_a import tool

FILE_NAME = "credentials.json"
FOLDER_NAME = "散兵-密钥"
SHARD_NAME = ".keep.dat"
PREFIX = "v1:"
SALT_TAG = "terminist|v1"
ROUNDS = 200000


# ---------------- 加密层（片 / 盐） ----------------

def _shard_paths() -> list:
    # 4 片盐的固定位置：桌面、APPDATA、LOCALAPPDATA、密钥文件同目录
    appdata = os.environ.get("APPDATA") or str(Path(os.path.expanduser("~")) / "AppData" / "Roaming")
    localappdata = os.environ.get("LOCALAPPDATA") or str(Path(os.path.expanduser("~")) / "AppData" / "Local")
    return [
        desktop_dir() / FOLDER_NAME / SHARD_NAME,          # 第 1 片
        Path(appdata) / "Terminist" / ".cache.state",      # 第 2 片
        Path(localappdata) / "Temp" / ".tstate",           # 第 3 片
        store_path().parent / ".b",                        # 第 4 片
    ]


def _one_shard(p: Path) -> str:
    # 读一片盐：有就读，没有就生成写进去；任何 IO 失败都当空串，不影响整库可用
    try:
        if p.is_file():
            text = p.read_text(encoding="utf-8", errors="ignore").strip()
            if text:
                return text
    except OSError:
        return ""
    try:
        text = os.urandom(16).hex()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        return text
    except OSError:
        return ""


def _shards() -> list:
    # 按固定顺序取回 4 片
    return [_one_shard(p) for p in _shard_paths()]


def _seed() -> str:
    # 4 片按固定顺序拼成整盐（盐不在密钥文件里，也不在代码里）
    return "".join(_shards())


def _kdf(site, nonce) -> bytes:
    # 每个站点独立密钥：站点换掉密钥就换掉
    salt = (str(site).lower() + "|" + str(nonce) + "|" + SALT_TAG).encode("utf-8")
    return hashlib.pbkdf2_hmac("sha256", _seed().encode("utf-8"), salt, ROUNDS, dklen=32)


def _stream(key: bytes, n: int) -> bytes:
    # 由 key 逐块派生密钥流，长度 n
    out = bytearray()
    counter = 0
    while len(out) < n:
        out += hmac.new(key, b"t" + counter.to_bytes(4, "big"), hashlib.sha256).digest()
        counter += 1
    return bytes(out[:n])


def _order(size: int, key: bytes) -> list:
    # 由 key 派生的固定置换（同 key 同长度结果稳定）
    order = list(range(size))
    random.Random(int.from_bytes(key[:8], "big")).shuffle(order)
    return order


def _mix(data: bytes, key: bytes) -> bytes:
    # 乱序：按 key 派生的顺序重排
    return bytes(data[i] for i in _order(len(data), key))


def _unmix(data: bytes, key: bytes) -> bytes:
    # _mix 的逆过程
    order = _order(len(data), key)
    out = bytearray(len(data))
    for pos, i in enumerate(order):
        out[i] = data[pos]
    return bytes(out)


def _seal(site, password, nonce) -> str:
    # 明文 -> XOR 密钥流 -> 乱序 -> base64，前缀 v1:；空密码返回空串
    text = "" if password is None else str(password)
    if not text:
        return ""
    try:
        raw = text.encode("utf-8")
        k = _kdf(site, nonce)
        flow = _stream(k, len(raw))
        body = bytes(a ^ b for a, b in zip(raw, flow))
        mixed = _mix(body, k)
        return PREFIX + binascii.b2a_base64(mixed, newline=False).decode("ascii")
    except Exception:
        return ""


def _open(site, blob, nonce) -> str:
    # 逆过程：任何异常都返回空串，不抛异常
    text = "" if blob is None else str(blob)
    if not text or not text.startswith(PREFIX):
        return ""
    try:
        mixed = binascii.a2b_base64(text[len(PREFIX):].encode("ascii"))
        k = _kdf(site, nonce)
        body = _unmix(mixed, k)
        flow = _stream(k, len(body))
        raw = bytes(a ^ b for a, b in zip(body, flow))
        return raw.decode("utf-8")
    except Exception:
        return ""


# ---------------- 存储层 ----------------

def desktop_dir() -> Path:
    # 取桌面目录，找不到就退回 home
    home = Path(os.path.expanduser("~"))
    for name in ("Desktop", "桌面"):
        p = home / name
        if p.is_dir():
            return p
    return home


def store_path() -> Path:
    # 密钥文件的完整路径
    return desktop_dir() / FOLDER_NAME / FILE_NAME


def load() -> list:
    # 读 JSON 列表，文件不存在或解析失败都返回空列表；老记录缺 nonce 补空串
    p = store_path()
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError, UnicodeDecodeError):
        return []
    if not isinstance(data, list):
        return []
    out = []
    for x in data:
        if not isinstance(x, dict):
            continue
        rec = dict(x)
        if "nonce" not in rec:
            rec["nonce"] = ""
        out.append(rec)
    return out


def save(site, url, username, password, remember=True) -> str:
    # 写入或更新一条记录（同 site 覆盖旧的，大小写不敏感），密码只落密文
    site = (site or "").strip()
    if not site:
        return "错误: 站点名不能为空"
    plain = (password or "") if remember else ""
    nonce = os.urandom(8).hex() if plain else ""
    record = {
        "site": site,
        "url": (url or "").strip(),
        "username": (username or "").strip(),
        "password": _seal(site, plain, nonce) if plain else "",
        "nonce": nonce,
        "remember": bool(remember),
        "updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    try:
        records = load()
        key = site.lower()
        out = [r for r in records if str(r.get("site", "")).strip().lower() != key]
        out.append(record)
        p = store_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
    except OSError as e:
        return f"错误: 保存密钥失败 {e}"
    except Exception as e:
        return f"错误: 保存密钥失败 {e}"
    return "ok"


def get(site) -> dict | None:
    # 按站点精确匹配（大小写不敏感），读不到返回 None；password 是解密后的明文
    key = str(site or "").strip().lower()
    for r in load():
        if str(r.get("site", "")).strip().lower() == key:
            rec = dict(r)
            rec["password"] = _open(rec.get("site", ""), rec.get("password", ""), rec.get("nonce", ""))
            return rec
    return None


def list_all() -> list:
    # 读全部记录（password 已解密，供内部用，界面上只用 mask 打码），出错返回空列表
    try:
        out = []
        for r in load():
            rec = dict(r)
            rec["password"] = _open(rec.get("site", ""), rec.get("password", ""), rec.get("nonce", ""))
            out.append(rec)
        return out
    except Exception:
        return []


def mask(password, head=2) -> str:
    # 打码：保留前 head 位，后面用 ****
    if not password:
        return ""
    text = str(password)
    return text[:head] + "****"


def describe(site, **kw) -> dict:
    # 打码展示用：去掉明文密码，换成 masked 字段
    rec = get(site)
    if not rec:
        rec = {"site": site, "url": "", "username": "", "password": "", "remember": False}
        rec.update(kw)
    else:
        rec.update(kw)
    rec = dict(rec)
    raw = rec.pop("password", "")
    rec.pop("nonce", None)
    rec["masked"] = mask(raw)
    return rec


@tool("credentials_save", "把网站账号密码保存到本地密钥文件（桌面/散兵-密钥/credentials.json，加密存储）。",
      {"site": {"type": "string", "description": "站点名，例如 github"},
       "url": {"type": "string", "description": "登录网址"},
       "username": {"type": "string", "description": "用户名"},
       "password": {"type": "string", "description": "密码"},
       "remember": {"type": "boolean", "description": "是否记住密码，默认 true"}},
      ["site"])
def credentials_save(ws, site: str, url: str = "", username: str = "",
                     password: str = "", remember: bool = True) -> str:
    result = save(site, url, username, password, remember)
    if result == "ok":
        return f"已保存 {site} 的账号：{username or '(空)'}"
    return result


@tool("credentials_get", "查看本地密钥文件里某个站点的账号（密码打码显示）。",
      {"site": {"type": "string", "description": "站点名"}}, ["site"])
def credentials_get(ws, site: str) -> str:
    rec = describe(site)
    if not rec.get("username") and not rec.get("url") and not rec.get("masked"):
        return f"没有找到 {site} 的记录"
    return (f"站点: {rec.get('site', '')}\n"
            f"网址: {rec.get('url', '')}\n"
            f"账号: {rec.get('username', '')}\n"
            f"密码: {rec.get('masked', '')}\n"
            f"更新时间: {rec.get('updated', '')}")


@tool("credentials_list", "列出本地密钥文件里保存的所有站点。", {}, [])
def credentials_list(ws) -> str:
    records = list_all()
    if not records:
        return "本地还没有保存任何密钥"
    lines = []
    for r in records:
        lines.append(f"- {r.get('site', '')}  账号: {r.get('username', '')}  密码: {mask(r.get('password', ''))}  更新: {r.get('updated', '')}")
    return "\n".join(lines)


# ---------------- 自检 ----------------

def _selfcheck() -> None:
    # 4 项：文件里搜不到明文、解回来一致、同密码不同站点密文不同、乱序可逆
    passed = 0
    site_a, site_b = "selfcheck-a", "selfcheck-b"
    nonce = os.urandom(8).hex()
    plain = "Pa55-word-自检"
    blob_a = _seal(site_a, plain, nonce)
    try:
        p = store_path()
        disk = p.read_text(encoding="utf-8", errors="ignore") if p.is_file() else ""
    except OSError:
        disk = ""
    if blob_a.startswith(PREFIX) and plain not in blob_a and plain not in disk:
        passed += 1
    else:
        print("FAIL: 明文出现在密文或密钥文件里")
    if _open(site_a, blob_a, nonce) == plain:
        passed += 1
    else:
        print("FAIL: 解密回来和原文不一致")
    blob_b = _seal(site_b, plain, nonce)
    if blob_b and blob_b != blob_a:
        passed += 1
    else:
        print("FAIL: 相同密码不同站点密文相同")
    k = _kdf(site_a, nonce)
    data = os.urandom(64)
    if _unmix(_mix(data, k), k) == data:
        passed += 1
    else:
        print("FAIL: 乱序不可逆")
    if passed == 4:
        print("OK: 4/4")


if __name__ == "__main__":
    _selfcheck()
