"""
精细读文件的工具：只读大文件的某一段，避免一次读整个大文件把上下文撑爆。

路径越界检查与 Workspace.resolve 效果相同（core.py 是受保护的，所以这里自己判断）。
"""

from pathlib import Path

from lib_a import tool
from lib_a.extensions._sandbox import resolve_root, under


@tool("read_lines", "读取文件的指定行范围（带行号）。只看大文件的某一段时用它，比 read_file 省上下文。",
      {"path": {"type": "string", "description": "相对工作区的文件路径"},
       "start": {"type": "integer", "description": "开始行号，从 1 开始，默认 1"},
       "end": {"type": "integer", "description": "结束行号（含），不写就读到文件末尾"}},
      ["path"])
def read_lines(ws, path: str, start: int = 0, end: int = 0, **alias) -> str:
    """读取文件的指定行范围（带行号）。参数名写成 start_line / end_line 也认。
    大文件没给行号：返回提纲（每个函数一行带行号），不读开头 400 行。"""
    start = int(alias.get("start_line") or start or 0)
    end = int(alias.get("end_line") or end or 0)
    try:
        root, err = resolve_root(ws, path)
        if err:
            return err
        if Path(path).is_absolute():
            p = Path(path).resolve()
        else:
            p = (root / path).resolve()
        if not under(root, p):
            return f"错误: 路径越界: {path}"
        if not p.is_file():
            from lib_a.core import _terminist_hint
            return f"错误: 文件不存在 {path}" + _terminist_hint(path)
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        total = len(lines)
        if not start and not end:
            from lib_a import outline
            if outline.is_big(lines):
                return outline.outline(p, path, lines)
        start = int(start or 1)
        if start < 1:
            start = 1
        if start > total:
            return f"错误: 文件只有 {total} 行，start={start} 超出范围"
        end = int(end or 0)
        if end == 0:
            end = total
        if end > total:
            end = total
        if end < start:
            return "错误: end 不能小于 start"
        # 一次最多返回 400 行，避免上下文爆掉
        truncated = False
        if end - start + 1 > 400:
            end = start + 399
            truncated = True
        out = [f"{n}| {lines[n - 1]}" for n in range(start, end + 1)]
        if truncated:
            out.append(f"...(已截断，还有更多行；继续读用 start={end + 1})")
        out.append(f"（共 {total} 行，本次第 {start}~{end} 行）")
        return "\n".join(out)
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
