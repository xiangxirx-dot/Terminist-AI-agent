"""
扩展：浏览记录（重启后还在）。

- `web_history`：查最近的浏览记录（最多 30 条，最新在最上面），第一行是现在停留的页面
- `web_last`：看当前浏览器停在哪个网页（网址 + 标题）
- 记录存 memory/web_history.json（最近 100 条），web_open / web_click / web_back 成功之后自动记一条
- 存储和实时页面读取在 _web_history_store.py（`_` 开头不注册工具，只被这里 import）；
  base/ 是受保护的，所以这里给 base.web 的 open_url / click / back 包一层，调完记历史，记录出错不影响上网
"""

import importlib.util
import os

from base import web as _web
from lib_a import tool

_STORE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_web_history_store.py")
_spec = importlib.util.spec_from_file_location("lib_a_web_history_store", _STORE_PATH)
store = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(store)                 # 同一目录下的公共模块，按路径加载，不走包导入


def _autosave(fn):
    """包一层：上网操作成功之后，把当前页面记进浏览记录（记录失败静默忽略，不影响浏览）。"""
    def run(*args, **kwargs):
        out = fn(*args, **kwargs)
        try:
            store.record_current()
        except Exception:
            pass
        return out
    run._web_history_patched = True
    return run


for _name in ("open_url", "click", "back"):
    _orig = getattr(_web, _name, None)
    if _orig is not None and not getattr(_orig, "_web_history_patched", False):
        setattr(_web, _name, _autosave(_orig))


@tool("web_history", "查最近浏览过哪些网页（重启后仍在），最新在最上面；第一行是现在停留的页面。", {})
def web_history(ws) -> str:
    try:
        return store.history_text(30)
    except Exception as e:
        return f"错误: 读浏览记录失败 {type(e).__name__}: {e}"


@tool("web_last", "看当前浏览器停在哪个网页（网址 + 标题）。", {})
def web_last(ws) -> str:
    try:
        return store.last_page()
    except Exception as e:
        return f"错误: 读当前网页失败 {type(e).__name__}: {e}"
