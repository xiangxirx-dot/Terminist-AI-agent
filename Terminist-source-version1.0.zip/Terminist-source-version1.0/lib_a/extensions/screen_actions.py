"""
小屏幕手动操作：主人在界面左栏的实时画面上右键标点、左键确认、滚轮滚网页。

现在改成立即执行（surface/gui.py 的 _screen_run）：界面上一有动作就直接打给浏览器，
不再排队等 A库 的工具调用。这里只保留 drain() 空实现做兼容 —— 拿一次队列把它清空，
始终返回空串，保证老的调用点不报错。

- 下面的点击 / 滚轮 / 结果回写辅助函数留着做参考，但不再被调用
"""

from base import web as _web

_STEP = 100          # 滚轮一格滚多少像素


def _click(b, x: int, y: int, button: str) -> str:
    """在网页视口坐标 (x, y) 上单击一次。"""
    b.page.mouse.click(x, y, button="right" if button == "right" else "left", timeout=8000)
    return f"{'右' if button == 'right' else '左'}键点击 ({x},{y})"


def _wheel(b, x: int, y: int, amount: int) -> str:
    """在 (x, y) 处滚轮：amount > 0 往下滚。"""
    b.page.mouse.move(x, y)
    b.page.mouse.wheel(0, amount * _STEP)
    return f"在 ({x},{y}) 滚轮 {amount} 格"


def _where(b) -> str:
    """当前网页标题和网址（拿不到就空串）。"""
    try:
        b.page.wait_for_timeout(300)
    except Exception:
        pass
    try:
        return f"当前网页：{b.page.title()}（{b.page.url}）"
    except Exception:
        return ""


def _taker(ws):
    """拿到界面侧「取走小屏幕排队动作」的函数。

    正常情况是 ws.take_screen_actions（GuiWorkspace 转给 App）；界面没接的话，
    顺着 agent.emit 的闭包 / ws.screen_owner 找到界面 App（它上面有 take_screen_actions）。
    """
    fn = getattr(ws, "take_screen_actions", None)
    if callable(fn):
        return fn
    holders = [getattr(ws, "screen_owner", None), getattr(ws, "agent", None)]
    for holder in holders:
        fn = getattr(holder, "take_screen_actions", None)
        if callable(fn):
            return fn
    for holder in holders:
        emit = getattr(holder, "emit", None)
        for cell in getattr(emit, "__closure__", None) or ():
            try:
                obj = cell.cell_contents
            except ValueError:
                continue
            fn = getattr(obj, "take_screen_actions", None)
            if callable(fn):
                return fn
    return None


def _push_result(ws, short: str, ok: bool) -> None:
    """把这次执行结果回写给界面（界面小屏幕旁边的结果条）。

    找 set_screen_result 的思路和 _taker 一样：ws 本身、ws.screen_owner、ws.agent，
    再顺着 emit 的闭包找界面 App。找不到就什么也不做，绝不抛异常。
    """
    if ws is None:
        return
    holders = [ws, getattr(ws, "screen_owner", None), getattr(ws, "agent", None)]
    for holder in holders:
        fn = getattr(holder, "set_screen_result", None)
        if callable(fn):
            try:
                fn(short, ok)
            except Exception:
                pass
            return
    for holder in holders[1:]:
        emit = getattr(holder, "emit", None)
        for cell in getattr(emit, "__closure__", None) or ():
            try:
                obj = cell.cell_contents
            except ValueError:
                continue
            fn = getattr(obj, "set_screen_result", None)
            if callable(fn):
                try:
                    fn(short, ok)
                except Exception:
                    pass
                return


def _short(done, fails) -> str:
    """一句话结果：已执行几条 + 成功的动作 + 第一条失败原因（太长截到 80 字）。"""
    text = f"已执行 {len(done)} 个"
    if done:
        text += "：" + "；".join(done)
    if fails:
        text += "；失败：" + fails[0]
    if len(text) > 80:
        text = text[:79] + "…"
    return text


def _notify_window(ws, page_wh):
    """告诉界面网页现在的尺寸，界面据此把独立小屏幕窗口对齐到网页大小。"""
    for obj in (ws, getattr(ws, 'screen_owner', None), getattr(ws, 'agent', None)):
        fn = getattr(obj, 'align_screen_window', None) if obj is not None else None
        if callable(fn):
            try:
                fn(*page_wh)
                return True
            except Exception:
                return False
    return False


def drain(ws) -> str:
    """兼容空实现：清掉界面上残留的旧队列，始终返回空串（操作已经在界面里立即执行了）。"""
    try:
        from base import web as _web
        size = getattr(_web, 'page_size', None)
        if callable(size):
            _notify_window(ws, size())
    except Exception:
        pass
    take = _taker(ws) if ws is not None else None
    if take is not None:
        try:
            take()
        except Exception:
            pass
    return ""
