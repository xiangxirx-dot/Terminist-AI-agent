"""
停掉 run_bg 起的后台任务：进程还占着端口或 CPU 时用它。

先 terminate() 给进程一个体面退出的机会，轮询最多 3 秒；还不退就 kill()，
再等 1 秒。全程复用 run_bg 模块里的 _PROCS 任务表，所以不会杀错别的进程。
"""

import gc
import importlib
import sys
import time
import types

from lib_a import tool


def _load_procs():
    """拿到 run_bg 模块里的任务表 _PROCS；拿不到返回 (None, 错误信息)。

    注意：绝不能再用 spec_from_file_location 重新 exec run_bg.py——那会得到
    另一份模块对象，_PROCS 是另一个空字典，永远查不到真正起过的任务。
    """
    # 1) 正常路径：模块已注册进 sys.modules
    try:
        _rb = importlib.import_module("lib_a.extensions.run_bg")
        procs = getattr(_rb, "_PROCS", None)
        if isinstance(procs, dict):
            return procs, ""
    except Exception:
        pass
    # 2) core.load_extensions 用别的 key 注册时，按后缀在 sys.modules 里找
    try:
        for key, mod in list(sys.modules.items()):
            if not key or not key.endswith("run_bg"):
                continue
            if not isinstance(mod, types.ModuleType):
                continue
            procs = getattr(mod, "_PROCS", None)
            if isinstance(procs, dict):
                return procs, ""
    except Exception:
        pass
    # 3) 兜底：遍历 gc，拿到已被 exec 过的那份模块
    try:
        for obj in gc.get_objects():
            if not isinstance(obj, types.ModuleType):
                continue
            if not getattr(obj, "__name__", "").endswith("run_bg"):
                continue
            procs = getattr(obj, "_PROCS", None)
            if isinstance(procs, dict):
                return procs, ""
    except Exception:
        pass
    return None, "错误: 找不到 run_bg 模块的任务表"


@tool("bg_kill",
      "停掉 run_bg 起的后台任务（进程还占着端口/CPU 时用）。",
      {"job": {"type": "string", "description": "run_bg 返回的任务 id，例如 job1"}},
      ["job"])
def bg_kill(ws, job: str) -> str:
    """终止一个后台任务：先 terminate，3 秒不退再 kill。"""
    try:
        procs, err = _load_procs()
        if procs is None:
            return err or "错误: 拿不到 run_bg 的任务表"
        key = (job or "").strip()
        task = procs.get(key)
        if task is None:
            return f"错误: 没有这个任务 {job}，用 bg_list 看现有任务"
        proc = task["proc"]
        cmd = task.get("command") or ""
        short = cmd if len(cmd) <= 80 else cmd[:80] + "…"
        code = proc.poll()
        if code is not None:
            task["done"] = True
            task["code"] = code
            return f"{key} 早就结束了（退出码 {code}）"
        # 先礼后兵：terminate 后最多等 3 秒
        proc.terminate()
        for _ in range(30):
            if proc.poll() is not None:
                break
            time.sleep(0.1)
        if proc.poll() is None:
            proc.kill()
            for _ in range(10):
                if proc.poll() is not None:
                    break
                time.sleep(0.1)
            task["done"] = True
            task["code"] = proc.poll()
            return f"已强制杀死 {key}：{short}"
        task["done"] = True
        task["code"] = proc.poll()
        return f"已停止 {key}：{short}"
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
