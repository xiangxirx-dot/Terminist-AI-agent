"""
主人已授权目录的白名单（多根）。

白名单内容由主人的授权决定，这里只记录已授权目录（含其所有子目录）。
不再限制「不能放桌面」——桌面本身已经在主人授权范围内。
以 _ 开头的文件不注册为工具，只作为被其他扩展 import 的公共模块。
"""

from pathlib import Path

# 主人已授权的目录，按优先级排列（越靠前越优先）。
SANDBOX_ROOTS = [                       # 按当前用户的桌面算，不写死某台电脑的路径
    Path.home() / "Desktop",
    Path.home() / "Desktop" / "散兵-工具自测",
]


def allowed_roots(ws) -> list:
    """本次操作允许使用的根目录列表。
    - ws 不为 None（打开了文件夹）：只有 ws.root。
    - ws 为 None（只聊天）：返回 SANDBOX_ROOTS 里存在且是目录的项，
      resolve 后去重，保持原有顺序；一个都没有返回 []。
    """
    try:
        if ws is not None:
            return [Path(ws.root).resolve()]
        out = []
        for p in SANDBOX_ROOTS:
            try:
                if p.exists() and p.is_dir():
                    rp = Path(p).resolve()
                    if rp not in out:
                        out.append(rp)
            except Exception:
                continue
        return out
    except Exception:
        return []


def resolve_root(ws, rel_path: str = ".") -> tuple:
    """决定本次操作要用的根目录。返回 (root 或 None, 错误信息)。
    - ws 不为 None：用 ws.root，err 为空（保持原有行为）。
    - ws 为 None：在 allowed_roots(None) 里挑第一个能覆盖本次路径的根；
      rel_path 是绝对路径时挑包含它的根，否则直接用第一个根。
    """
    try:
        if ws is not None:
            return Path(ws.root), ""
        roots = allowed_roots(None)
        if not roots:
            return None, ("错误: 白名单目录不存在: "
                          + ", ".join(str(p) for p in SANDBOX_ROOTS)
                          + "，请先创建或改用打开文件夹")
        try:
            target = Path(rel_path)
            is_abs = target.is_absolute()
        except Exception:
            is_abs = False
        if is_abs:
            for r in roots:
                if under(r, target):
                    return r, ""
            # 绝对路径不在任何白名单根下：仍返回第一个根，交由 under() 拦下
            return roots[0], ""
        return roots[0], ""
    except Exception as e:
        return None, f"错误: {type(e).__name__}: {e}"


def under(root: Path, target: Path) -> bool:
    """target（已 resolve）是否就是 root 或落在 root 之下。"""
    try:
        r = Path(root).resolve()
        t = Path(target).resolve()
        return t == r or r in t.parents
    except Exception:
        return False
