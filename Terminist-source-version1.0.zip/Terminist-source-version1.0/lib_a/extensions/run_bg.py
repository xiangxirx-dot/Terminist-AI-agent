"""
后台命令工具：解决 run_command 必须等命令跑完才能拿到输出、不能后台起服务、
不能追加读取输出的问题。

三个工具配合使用：
  - run_bg     起一条后台命令，立刻返回任务 id（job1、job2 …）
  - bg_output  反复读任务的新增输出，任务结束后会提示退出码
  - bg_list    看所有后台任务及运行状态

实现要点：输出重定向到临时文件而不是 PIPE，避免缓冲区写满把子进程堵死。
"""

import os
import subprocess
import tempfile
import threading

from lib_a import tool
from lib_a.extensions._sandbox import resolve_root

# 模块级任务表：{任务 id: {"proc": Popen, "out": 输出文件路径, "command": 原命令, "pos": 已读到字节, "done": 是否结束, "code": 退出码}}
_PROCS: dict = {}
_JOB_SEQ = [0]
_LOCK = threading.Lock()


def _next_job() -> str:
    """生成下一个任务 id：job1、job2 …"""
    with _LOCK:
        _JOB_SEQ[0] += 1
        return f"job{_JOB_SEQ[0]}"


def _decode(raw: bytes) -> str:
    """后台输出解码：优先 utf-8，失败试 gb18030，最后 replace 兜底。"""
    if not raw:
        return ""
    for enc in ("utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _prepare(cmd: str):
    """返回 (最终命令, env)。Windows 下统一 UTF-8 代码页。"""
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    if os.name == "nt":
        low = cmd.lstrip().lower()
        if not low.startswith("chcp"):
            cmd = "chcp 65001 >nul && " + cmd
    return cmd, env


@tool("run_bg",
      "在后台运行一条命令，立刻返回任务 id；之后用 bg_output 看输出、bg_list 看所有任务。"
      "适合起服务、长构建这类要等很久的命令。",
      {"command": {"type": "string", "description": "要执行的命令，和 run_command 一样"}},
      ["command"])
def run_bg(ws, command: str) -> str:
    """后台启动一条命令。"""
    try:
        root, err = resolve_root(ws, ".")
        if err:
            return err
        cwd = str(root)
        if not root.is_dir():
            return err or f"错误: 目录不存在: {cwd}"
        fd, out = tempfile.mkstemp(prefix="terminist_bg_", suffix=".log")
        handle = os.fdopen(fd, "wb")
        real_cmd, env = _prepare(command)
        # Windows 下不弹黑色控制台窗口
        flags = 0x08000000 if os.name == "nt" else 0   # CREATE_NO_WINDOW
        try:
            proc = subprocess.Popen(real_cmd, shell=True, cwd=cwd,
                                    stdout=handle, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, env=env,
                                    creationflags=flags)
        finally:
            handle.close()
        job = _next_job()
        _PROCS[job] = {"proc": proc, "out": out, "command": command,
                       "pos": 0, "done": False, "code": None}
        return (f"已后台启动 {job}：{command}\n"
                f"用 bg_output({job}) 查看输出，bg_list 看全部任务")
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"


@tool("bg_output",
      "读后台任务的输出（可以反复读，每次读从上次读到的地方继续）。任务结束后会提示退出码。",
      {"job": {"type": "string", "description": "run_bg 返回的任务 id，例如 job1"}},
      ["job"])
def bg_output(ws, job: str) -> str:
    """读后台任务的新增输出。"""
    try:
        task = _PROCS.get((job or "").strip())
        if task is None:
            return f"错误: 没有这个任务 {job}，用 bg_list 看现有任务"
        proc = task["proc"]
        code = proc.poll()
        if code is not None:
            task["done"] = True
            task["code"] = code
        chunk = ""
        try:
            with open(task["out"], "rb") as f:
                f.seek(task["pos"])
                data = f.read()
                task["pos"] += len(data)
            chunk = _decode(data)
        except FileNotFoundError:
            chunk = ""
        if not chunk.strip():
            chunk = "（暂无新输出）"
        if len(chunk) > 4000:
            chunk = "...(前面内容已省略)" + chunk[-4000:]
        if task["done"]:
            chunk += f"\n[任务已结束，退出码 {task['code']}]"
        return chunk
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"


@tool("bg_list", "列出所有后台任务及其运行状态。", {})
def bg_list(ws) -> str:
    """列出所有后台任务。"""
    try:
        if not _PROCS:
            return "没有后台任务"
        lines = []
        for job, task in _PROCS.items():
            proc = task["proc"]
            code = proc.poll()
            if code is not None:
                task["done"] = True
                task["code"] = code
            state = f"已结束(退出码 {code})" if task["done"] else "运行中"
            cmd = task["command"]
            if len(cmd) > 80:
                cmd = cmd[:80] + "…"
            lines.append(f"{job}｜{state}｜{cmd}")
        return "\n".join(lines)
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"


@tool("bg_wait",
      "等后台任务：一直等到它跑完（或者输出里出现 until 这段文字 / 正则），再一次性返回这段时间的新输出；最多等 timeout 秒。"
      "等的过程中不发请求、不花钱。代替 bg_output → wait → 再 bg_output 一轮轮地轮询。",
      {"job": {"type": "string", "description": "run_bg 返回的任务 id，例如 job1"},
       "until": {"type": "string", "description": "可选：输出里出现这段文字（可以写正则）就不等了，例如 Running on|ready"},
       "timeout": {"type": "integer", "description": "最多等几秒，默认 120，最多 900"}},
      ["job"])
def bg_wait(ws, job: str, until: str = "", timeout: int = 120) -> str:
    """阻塞等后台任务结束或输出出现 until；返回期间的新输出（和 bg_output 共用读取位置）。主人按停止能打断。"""
    import re
    import time
    try:
        task = _PROCS.get((job or "").strip())
        if task is None:
            return f"错误: 没有这个任务 {job}，用 bg_list 看现有任务"
        try:
            pat = re.compile(until) if until else None
        except re.error:
            pat = re.compile(re.escape(until))
        limit = max(1, min(900, int(timeout or 120)))
        agent = getattr(ws, "agent", None)
        t0 = time.time()
        got = b""
        why = "超时"
        while True:
            try:
                with open(task["out"], "rb") as f:
                    f.seek(task["pos"])
                    data = f.read()
                    task["pos"] += len(data)
                got += data
            except FileNotFoundError:
                pass
            code = task["proc"].poll()
            if pat is not None and pat.search(_decode(got)):
                why = f"输出里出现了「{until}」"
                break
            if code is not None:
                task["done"], task["code"] = True, code
                why = f"任务已结束，退出码 {code}"
                break
            if time.time() - t0 >= limit:
                break
            if agent is not None and getattr(agent, "stop_requested", False):
                why = "被停止"
                break
            time.sleep(0.5)
        text = _decode(got).strip() or "（这段时间没有新输出）"
        if len(text) > 4000:
            text = "...(前面内容已省略)\n" + text[-4000:]
        return f"[{job} 等了 {time.time() - t0:.0f} 秒：{why}]\n{text}"
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
