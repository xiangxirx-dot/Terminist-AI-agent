"""
内容搜索工具：按正则在文件内容里搜索。

解决只看文件名找不到「某个函数在哪定义、这个字符串哪用到」的问题：
递归遍历工作区文件，逐行 re.search，返回 相对路径:行号: 内容。
跳过 .git、__pycache__、node_modules 等噪音目录和超大文件。
"""

import re
from pathlib import Path

from lib_a import tool
from lib_a.extensions._sandbox import resolve_root, under

# 这些目录名出现在任意一层就整层跳过
SKIP = {".git", "__pycache__", "node_modules", ".venv", "venv", "runtime",
        "dist", "build", ".idea", ".mypy_cache", ".pytest_cache"}

MAX_FILE = 2 * 1024 * 1024   # 单个文件超过 2MB 跳过
MAX_LINE = 200               # 单行展示最多 200 字符
SCAN_CAP = 5000              # 总命中统计到 5000 条就停
MAX_CHARS = 8000             # 返回结果整体上限


@tool("grep_files", "用正则在文件内容里搜索，返回 文件:行号: 内容。找某个函数/字符串在哪定义在哪用到时用它。",
      {"pattern": {"type": "string", "description": "正则表达式，例如 def main、TODO|FIXME"},
       "file_glob": {"type": "string", "description": "只搜哪些文件，例如 *.py，默认 *"},
       "path": {"type": "string", "description": "从哪个子目录开始搜，不写就是工作区根目录"},
       "limit": {"type": "integer", "description": "最多返回多少条，默认 150"}},
      ["pattern"])
def grep_files(ws, pattern: str, file_glob: str = "*", path: str = ".", limit: int = 150) -> str:
    """按正则递归搜索工作区文件内容。"""
    try:
        # ws 不为 None：根就是工作区本身；ws 为 None：在白名单里挑根
        if ws is not None:
            root = Path(ws.root).resolve()
        else:
            root, err = resolve_root(ws, path)
            if err:
                return err
            root = Path(root).resolve()
        # path 可以是相对工作区的子目录，也可以是绝对路径
        base = Path(path) if Path(path).is_absolute() else (root / path)
        base = base.resolve()
        # 防越界：起始目录必须是工作区本身或在它之下
        if not under(root, base):
            return f"错误: 路径越界: {path}"
        if base.is_file():                       # 给的是文件：就只搜它
            file_glob, base = base.name, base.parent
        if not base.is_dir():
            return f"错误: {path} 不是目录"

        try:
            rx = re.compile(pattern)
        except re.error as e:
            return f"错误: 正则表达式无效: {e}"

        hits = []
        total = 0
        capped = False
        for f in base.rglob(file_glob):
            try:
                if not f.is_file():
                    continue
                if any(part in SKIP for part in f.parts):
                    continue
                if f.stat().st_size > MAX_FILE:
                    continue
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            rel = f.relative_to(root).as_posix()
            for n, line in enumerate(text.splitlines(), start=1):
                if not rx.search(line):
                    continue
                total += 1
                # 只留前 limit 条，后面的只计数
                if len(hits) < limit:
                    line = line.strip()
                    if len(line) > MAX_LINE:
                        line = line[:MAX_LINE] + "…"
                    hits.append(f"{rel}:{n}: {line}")
                if total >= SCAN_CAP:
                    capped = True
                    break
            if capped:
                break

        if not hits:
            return f"没有匹配 {pattern} 的内容"

        tail = []
        if total > len(hits):
            tail.append(f"...(共 {total} 条命中，超过 limit 已截断)")
        if capped:
            tail.append(f"...(扫描命中到 {SCAN_CAP} 条就停了，已截断)")

        out = "\n".join(hits + tail)
        if len(out) > MAX_CHARS:
            out = out[:MAX_CHARS] + "\n...(结果太长，已截断)"
        return out
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
