"""
等待工具：解决构建、安装、服务启动这类需要等一会儿再看结果的情况，避免一轮轮空转。

只用标准库 time / datetime，只睡一次，不做循环轮询。
"""

import time
from datetime import datetime

from lib_a import tool


@tool("wait", "睡一会儿再继续（最多 60 秒）。用来等构建、安装、服务启动完成，之后再用 bg_output / run_command 检查结果。",
      {"seconds": {"type": "integer", "description": "等多少秒，1~60，超过 60 按 60 算"}},
      ["seconds"])
def wait(ws, seconds: int) -> str:
    """睡一会儿再继续。"""
    try:
        n = int(seconds)
        if n < 1:
            n = 1
        if n > 60:
            n = 60
        time.sleep(n)
        return f"已等待 {n} 秒，现在是 {datetime.now().strftime('%H:%M:%S')}。可以继续检查结果了。"
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
