"""
前台工具：直接开 / 关小屏幕独立窗口，立刻生效，不用派 Agent。

界面（surface/gui.py 的 App）上有 open_screen_window / close_screen_window，
以及记录当前状态的 screen_win_open。这里顺着 ws、ws.screen_owner、ws.agent
找到那个对象，直接调它的方法。

- tools(ws) 返回 {工具名: (schema, fn(参数 dict) -> str)}，照 custom_tools 的格式
"""

from lib_a import _fn


def _action(action) -> str:
    """把 action 归一化成 open / close / toggle，认不出来的按 toggle。"""
    text = str(action or "").strip().lower()
    if text in ("open", "开", "打开", "弹出"):
        return "open"
    if text in ("close", "关", "关闭", "收起"):
        return "close"
    return "toggle"


def find_screen_owner(ws):
    """找到带 close_screen_window 的界面对象：ws 本身、ws.screen_owner、ws.agent，找不到返回 None。"""
    if ws is None:
        return None
    holders = [ws, getattr(ws, "screen_owner", None), getattr(ws, "agent", None)]
    for holder in holders:
        if holder is None:
            continue
        fn = getattr(holder, "close_screen_window", None)
        if callable(fn):
            return holder
    return None


def screen_window(ws, action="toggle") -> str:
    """开 / 关 / 切换小屏幕独立窗口，返回一句中文结果，不抛异常。"""
    try:
        act = _action(action)
        owner = find_screen_owner(ws)
        if owner is None:
            return "界面还没起来，小窗口开不了"
        opened = bool(getattr(owner, "screen_win_open", False))
        if act == "toggle":
            act = "close" if opened else "open"
        if act == "open":
            if opened:
                return "小屏幕本来就是开着的"
            fn = getattr(owner, "open_screen_window", None)
            if not callable(fn):
                return "界面还没起来，小窗口开不了"
            fn()
            return "小屏幕已开"
        # 关
        if not opened:
            return "小屏幕没开"
        fn = getattr(owner, "close_screen_window", None)
        if not callable(fn):
            return "界面还没起来，小窗口开不了"
        fn()
        return "小屏幕已收起"
    except Exception as e:
        return f"小屏幕操作没成功：{type(e).__name__}: {e}"


def tools(ws) -> dict:
    """返回给 A库 的工具表（custom_tools 格式）。"""
    schema = _fn(
        "screen_window",
        "直接开 / 关小屏幕独立窗口，立刻生效，不用派 Agent。"
        "用户说开小窗口/弹出小屏幕/关掉小窗口/收起小屏幕时调它。",
        {"action": {"type": "string", "enum": ["open", "close", "toggle"],
                    "description": "open 开、close 关、toggle 切换（默认）"}},
        [])
    return {"screen_window": (schema, lambda a: screen_window(ws, a.get("action", "toggle")))}
