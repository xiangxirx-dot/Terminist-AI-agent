"""
扩展：重置 A库 / B库 的惩罚分和奖励分（清空奖惩记录）。

记在 memory/penalty.json，由 lib_b/penalty.py 维护；这里只做整体重置。
ws 用不到，没打开文件夹（ws 为 None）也能用。
"""

from lib_a import tool
from lib_b import penalty

_WHICH = {"all": "全部", "A": "A库扣分", "B": "B库扣分", "reward": "B库奖励", "punish": "惩罚"}


def _fmt(s: dict) -> str:
    return f"A扣{s['A']} B扣{s['B']} R奖{s['R']} RA奖{s['RA']}"


@tool("penalty_reset",
      "重置 A库 / B库 的惩罚分和奖励分（会清空奖惩记录）。只在前台（主人）明确说重置时才调用，"
      "不要自己主动重置。",
      {"which": {"type": "string", "enum": ["all", "A", "B", "reward", "punish"],
                 "description": "要重置哪部分，默认 all（目前只支持整体重置）"}}, [])
def penalty_reset(ws, which: str = "all") -> str:
    which = (which or "all").strip() or "all"
    before = penalty.scores()
    penalty.reset()
    after = penalty.scores()
    msg = f"已重置：重置前 {_fmt(before)} → 现在全部为 0（奖惩记录已清空）。"
    if which != "all":
        name = _WHICH.get(which, which)
        msg = f"目前只支持一次全部重置，「{name}」也一起归零了。" + msg
    return msg
