"""
扩展示例：统计文件的行数、字符数和大小。

A库的扩展写法：
  - 在 lib_a/extensions/ 下新建一个 .py 文件（以 _ 开头的不加载）
  - 用 @tool(工具名, 说明, 参数定义, 必填参数) 注册函数，函数签名为 func(ws, **参数)，返回字符串
  - ws 是当前工作区（lib_a.Workspace），用 ws.resolve(path) 把相对路径转成安全的绝对路径
"""

from lib_a import tool


@tool("file_stats", "统计文件的行数、字符数和字节大小。",
      {"path": {"type": "string", "description": "相对工作区的文件路径"}}, ["path"])
def file_stats(ws, path: str) -> str:
    p = ws.resolve(path)
    if not p.is_file():
        return f"错误: 文件不存在 {path}"
    text = p.read_text(encoding="utf-8", errors="replace")
    return f"{path}: {len(text.splitlines())} 行，{len(text)} 字符，{p.stat().st_size} 字节"
