"""
本机当前日期时间：回答"现在几点了"这类问题。

无参数工具，只用标准库 datetime（base 是受保护目录，所以这个能力放在扩展里）。
"""

from datetime import datetime

from lib_a import tool


@tool("now", "看现在的日期和时间：返回本机当前日期、时间、星期几。", {})
def now(ws) -> str:
    """本机当前日期时间。"""
    dt = datetime.now()
    week = "一二三四五六日"[dt.weekday()]
    return (f"现在是 {dt.strftime('%Y-%m-%d %H:%M:%S')} 星期{week}"
            f"（本机本地时间，时区 {dt.astimezone().tzname()}）")
