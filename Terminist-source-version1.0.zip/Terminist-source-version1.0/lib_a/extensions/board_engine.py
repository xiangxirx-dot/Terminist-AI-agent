"""
画板引擎：笔画数据 + 用 pygame 离屏渲染成 PNG。

- 笔画存在 ~/.terminist/board/strokes.json（纯 JSON，能重放），渲染结果存 board.png；
- 只在内存 Surface 上画，绝不调用 pygame.display.set_mode，所以能脱离窗口跑；
- pick() 校验参数并给中文提示，draw_op() 把一次作画规整成 op，apply() 处理换色/配色/撤销/清空/画布；
- 出错统一抛 BoardError（中文原因），不把英文 traceback 抛给上层。
"""

import io
import json
import math
import os
import random
import re
from collections import deque
from pathlib import Path

# 不让 pygame 往 stderr 打欢迎语，免得弄脏界面输出
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

BOARD_DIR = Path.home() / ".terminist" / "board"
STROKES = BOARD_DIR / "strokes.json"
PNG = BOARD_DIR / "board.png"

MAX_STROKES = 50          # 最多保留多少笔可重放历史
MAX_SIDE = 4096           # 画布边长上限
MIN_SIDE = 16
FILL_WARN_SIDE = 2048     # 泛洪超过这个边长会慢，提前提示
DEFAULT_COLOR = "#333333"
DEFAULT_BG = "#ffffff"

# 中文字体候选（找不到就退 SysFont）
FONT_PATHS = [
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    r"C:\Windows\Fonts\simsun.ttc",
    r"C:\Windows\Fonts\Deng.ttf",
]
FONT_BOLD_PATHS = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
]

DRAW_TOOLS = ["brush", "pencil", "marker", "airbrush", "fill", "shape", "text", "eraser"]
ACTION_TOOLS = ["swap", "palette", "undo", "clear", "canvas"]
SHAPES = ["line", "rect", "circle", "ellipse", "polygon", "triangle", "star", "heart"]
ALIGNS = ["left", "center", "right"]

# 8 套预设配色，每套 6~8 个颜色
PALETTES = {
    "pastel": ["#ffd6e0", "#ffe7ba", "#fff9c4", "#c8f4d4", "#c7e9ff", "#dcd2f7"],
    "retro": ["#2b2b2b", "#8b5e3c", "#c68b59", "#e6c79c", "#7d9d9c", "#4a5a63"],
    "cyber": ["#0d0221", "#ff2a6d", "#05d9e8", "#d1f7ff", "#7b2ff7", "#f9f871"],
    "ink": ["#1c1c1c", "#3a3a3a", "#5c5c5c", "#7f7f7f", "#b8b8b8", "#e8e8e8"],
    "oil": ["#3e2723", "#8d5524", "#c68642", "#e0ac69", "#2e4057", "#a4243b", "#f4d35e"],
    "candy": ["#ff4f81", "#ff8c42", "#ffd23f", "#3bceac", "#4d6cfa", "#a45dea", "#ff9ec4"],
    "sunset": ["#2b2d42", "#ef476f", "#ff7b54", "#ffb26b", "#ffd56b", "#8d99ae"],
    "morandi": ["#a3a7a0", "#b7a99a", "#c9c0b6", "#8f9aa6", "#a89a9a", "#9aab9f", "#b3a7b8"],
}

TOOLS = {
    "brush": {
        "label": "毛笔",
        "args": {
            "points": {"type": "points", "required": True, "desc": "坐标点 [[x,y], ...]，至少 2 个"},
            "color": {"type": "color", "default": DEFAULT_COLOR, "desc": "颜色 #RRGGBB"},
            "width": {"type": "number", "default": 8, "min": 0.5, "max": 400, "desc": "笔宽 0.5~400"},
            "alpha": {"type": "number", "default": 255, "min": 0, "max": 255, "desc": "不透明度 0~255"},
            "closed": {"type": "bool", "default": False, "desc": "首尾是否连起来"},
        },
        "hint": "points=[[100,100],[300,260],[520,140]]，可再加 color/width/alpha/closed。",
    },
    "pencil": {
        "label": "铅笔",
        "args": {
            "points": {"type": "points", "required": True, "desc": "坐标点 [[x,y], ...]，至少 2 个"},
            "color": {"type": "color", "default": DEFAULT_COLOR, "desc": "颜色 #RRGGBB"},
            "width": {"type": "number", "default": 2, "min": 1, "max": 6, "desc": "笔宽 1~6"},
        },
        "hint": "线条细而硬，width=2 最像铅笔，适合打草稿。",
    },
    "marker": {
        "label": "马克笔",
        "args": {
            "points": {"type": "points", "required": True, "desc": "坐标点 [[x,y], ...]，至少 2 个"},
            "color": {"type": "color", "default": "#ff8c42", "desc": "颜色 #RRGGBB"},
            "width": {"type": "number", "default": 24, "min": 4, "max": 400, "desc": "笔宽 4~400"},
            "alpha": {"type": "number", "default": 120, "min": 0, "max": 255, "desc": "不透明度 0~255"},
        },
        "hint": "宽扁方头、半透明，适合涂高亮和色块。",
    },
    "airbrush": {
        "label": "喷枪",
        "args": {
            "points": {"type": "points", "required": True, "desc": "坐标点 [[x,y], ...]，至少 2 个"},
            "color": {"type": "color", "default": "#05d9e8", "desc": "颜色 #RRGGBB"},
            "radius": {"type": "number", "default": 18, "min": 2, "max": 200, "desc": "喷洒半径 2~200"},
            "alpha": {"type": "number", "default": 60, "min": 1, "max": 255, "desc": "不透明度 1~255"},
        },
        "hint": "沿线撒半透明圆点，radius 越大越雾，适合喷渐变和光晕。",
    },
    "fill": {
        "label": "油漆桶",
        "args": {
            "x": {"type": "number", "required": True, "min": -1000000, "max": 1000000, "desc": "填充起点 x"},
            "y": {"type": "number", "required": True, "min": -1000000, "max": 1000000, "desc": "填充起点 y"},
            "color": {"type": "color", "default": "#ffd56b", "desc": "颜色 #RRGGBB"},
            "tolerance": {"type": "number", "default": 24, "min": 0, "max": 255, "desc": "容差 0~255"},
        },
        "hint": "从 (x,y) 向外泛洪填色，tolerance=0 只填完全同色的区域。",
    },
    "shape": {
        "label": "图形",
        "args": {
            "shape": {"type": "shape", "required": True, "desc": "line/rect/circle/ellipse/polygon/triangle/star/heart"},
            "ref": {"type": "ref", "default": None, "desc": "外框 [x,y,w,h] 或 \"x,y,w,h\""},
            "points": {"type": "points", "default": None, "desc": "多边形/线的顶点 [[x,y], ...]"},
            "color": {"type": "color", "default": DEFAULT_COLOR, "desc": "线条颜色 #RRGGBB"},
            "fill_color": {"type": "color", "default": None, "desc": "填充色 #RRGGBB，不填只描边"},
            "width": {"type": "number", "default": 3, "min": 1, "max": 80, "desc": "线宽 1~80"},
        },
        "hint": "用 ref=[x,y,w,h] 定外框，或用 points 逐点画；fill_color 填色。",
    },
    "text": {
        "label": "文字",
        "args": {
            "text": {"type": "str", "required": True, "desc": "要写的文字，支持中文和换行"},
            "x": {"type": "number", "default": 60, "min": -1000000, "max": 1000000, "desc": "横坐标"},
            "y": {"type": "number", "default": 60, "min": -1000000, "max": 1000000, "desc": "纵坐标"},
            "size": {"type": "number", "default": 32, "min": 6, "max": 400, "desc": "字号 6~400"},
            "color": {"type": "color", "default": DEFAULT_COLOR, "desc": "颜色 #RRGGBB"},
            "bold": {"type": "bool", "default": False, "desc": "是否加粗"},
            "align": {"type": "str", "default": "left", "options": ALIGNS, "desc": "对齐 left/center/right"},
        },
        "hint": "text=\"测试中文\"、size=48、align=center 时 x 是中线。",
    },
    "eraser": {
        "label": "橡皮",
        "args": {
            "points": {"type": "points", "required": True, "desc": "坐标点 [[x,y], ...]，至少 2 个"},
            "size": {"type": "number", "default": 24, "min": 1, "max": 400, "desc": "橡皮大小 1~400"},
        },
        "hint": "用画布底色擦，size 越大擦得越宽。",
    },
    "swap": {
        "label": "换色",
        "args": {
            "color": {"type": "color", "default": None, "desc": "新的画笔颜色 #RRGGBB"},
            "colors": {"type": "colors", "default": None, "desc": "新的轮换配色，2~8 个 #RRGGBB"},
        },
        "hint": "swap(color=\"#ff4f81\") 换画笔色，swap(colors=[...]) 换整组配色。",
    },
    "palette": {
        "label": "配色",
        "args": {
            "name": {"type": "str", "default": None, "desc": "预设名：" + "/".join(PALETTES)},
            "colors": {"type": "colors", "default": None, "desc": "自定义配色 2~8 个 #RRGGBB"},
        },
        "hint": "palette(name=\"cyber\") 或 palette(colors=[\"#111111\",\"#ff2a6d\"])。",
    },
    "undo": {
        "label": "撤销",
        "args": {},
        "hint": "去掉最后一笔，只改数据不落笔。",
    },
    "clear": {
        "label": "清空",
        "args": {},
        "hint": "清掉画板上所有笔画。",
    },
    "canvas": {
        "label": "画布",
        "args": {
            "width": {"type": "number", "default": None, "min": MIN_SIDE, "max": MAX_SIDE, "desc": f"宽 {MIN_SIDE}~{MAX_SIDE}"},
            "height": {"type": "number", "default": None, "min": MIN_SIDE, "max": MAX_SIDE, "desc": f"高 {MIN_SIDE}~{MAX_SIDE}"},
            "background": {"type": "color", "default": None, "desc": "底色 #RRGGBB"},
        },
        "hint": "canvas(width=1200, height=900, background=\"#fffaf0\") 改画布。",
    },
}


class BoardError(Exception):
    """画板引擎自己的错误，消息一律中文。"""


# ---------- 小工具：数字、颜色、坐标 ----------

def _num(value, default, lo=None, hi=None):
    """把任意值转成数字并按区间夹住，转不了就用 default。"""
    try:
        f = float(value)
    except (TypeError, ValueError):
        try:
            f = float(default)
        except (TypeError, ValueError):
            f = 0.0
    if f != f:  # nan
        f = float(default) if str(default) not in ("None", "") else 0.0
    if lo is not None:
        f = max(float(lo), f)
    if hi is not None:
        f = min(float(hi), f)
    return f


def _hex_str(value):
    """规整成 #rrggbb，认不出就抛 BoardError。"""
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return "#%02x%02x%02x" % tuple(max(0, min(255, int(c))) for c in value[:3])
        except (TypeError, ValueError):
            raise BoardError(f"颜色要写成 #RRGGBB：{value}") from None
    s = str(value or "").strip().lower()
    if not s:
        raise BoardError("颜色不能为空，要写成 #RRGGBB")
    if not s.startswith("#"):
        s = "#" + s
    if len(s) == 4:
        s = "#" + "".join(ch * 2 for ch in s[1:])
    if len(s) != 7 or any(ch not in "0123456789abcdef" for ch in s[1:]):
        raise BoardError(f"颜色要写成 #RRGGBB：{value}")
    return s


def _safe_hex(value, fallback):
    """容错版 _hex_str，读旧数据时用。"""
    try:
        return _hex_str(value)
    except BoardError:
        return fallback


def _rgb(value, default=DEFAULT_COLOR):
    """颜色字符串 -> (r, g, b)，画图用，不抛异常。"""
    try:
        h = _hex_str(value)
    except BoardError:
        h = _safe_hex(default, DEFAULT_BG) or DEFAULT_BG
    try:
        return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))
    except ValueError:
        return (51, 51, 51)


def _pts(value):
    """坐标 -> [(x, y), ...]，坏点直接丢。"""
    out = []
    if not isinstance(value, (list, tuple)):
        return out
    for p in value:
        if isinstance(p, (list, tuple)) and len(p) >= 2:
            try:
                out.append((int(round(float(p[0]))), int(round(float(p[1])))))
            except (TypeError, ValueError):
                continue
    return out


def _nums(value):
    """从 [x,y,w,h] 或 "x,y,w,h" 里取一串数字。"""
    if isinstance(value, (list, tuple)):
        items = list(value)
    else:
        items = [s for s in re.split(r"[,，\s]+", str(value or "").strip()) if s]
    out = []
    for it in items:
        try:
            out.append(float(it))
        except (TypeError, ValueError):
            return []
    return out


# ---------- 存取 ----------

def _default_doc():
    return {
        "width": 1024,
        "height": 768,
        "background": DEFAULT_BG,
        "tool": "brush",
        "color": DEFAULT_COLOR,
        "colors": [],
        "strokes": [],
    }


def _ensure_dir():
    try:
        BOARD_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass


def load():
    """读画笔数据；文件不存在或坏了就返回默认 1024x768 白底空画板。"""
    doc = _default_doc()
    try:
        raw = json.loads(STROKES.read_text(encoding="utf-8"))
    except Exception:
        return doc
    if not isinstance(raw, dict):
        return doc
    doc["width"] = int(_num(raw.get("width"), doc["width"], MIN_SIDE, MAX_SIDE))
    doc["height"] = int(_num(raw.get("height"), doc["height"], MIN_SIDE, MAX_SIDE))
    doc["background"] = _safe_hex(raw.get("background"), doc["background"])
    doc["color"] = _safe_hex(raw.get("color"), doc["color"])
    colors = raw.get("colors")
    if isinstance(colors, list):
        doc["colors"] = [c for c in (_safe_hex(x, None) for x in colors[:8]) if c]
    tool = str(raw.get("tool") or "")
    if tool in TOOLS:
        doc["tool"] = tool
    strokes = raw.get("strokes")
    if isinstance(strokes, list):
        good = [op for op in strokes if isinstance(op, dict) and op.get("tool") in DRAW_TOOLS]
        doc["strokes"] = good[-MAX_STROKES:]
    return doc


def save(doc):
    """写回画笔数据，出问题也不崩。"""
    try:
        _ensure_dir()
        STROKES.parent.mkdir(parents=True, exist_ok=True)
        STROKES.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
        return True
    except Exception:
        return False


def push(doc, op):
    """追加一笔，超过 50 笔丢掉最老的。"""
    strokes = doc.get("strokes")
    if not isinstance(strokes, list):
        strokes = doc["strokes"] = []
    strokes.append(op)
    if len(strokes) > MAX_STROKES:
        del strokes[:len(strokes) - MAX_STROKES]
    save(doc)
    return op


def undo(doc):
    """撤销最后一笔。"""
    strokes = doc.get("strokes")
    if not isinstance(strokes, list) or not strokes:
        return "画板上没有可撤销的笔画"
    strokes.pop()
    save(doc)
    return f"已撤销最后一笔，还剩 {len(strokes)} 笔"


def clear(doc):
    """清空所有笔画。"""
    doc["strokes"] = []
    save(doc)
    return "画板已清空"


# ---------- 参数校验 ----------

def _coerce(label, key, meta, value):
    """按 TOOLS 里的声明把参数规整成能重放的值。"""
    kind = meta.get("type", "str")
    if kind == "points":
        pts = _pts(value)
        if not pts:
            raise BoardError(f"{label}的 {key} 要写成 [[x,y],[x,y],...]")
        return [[p[0], p[1]] for p in pts]
    if kind == "number":
        lo = meta.get("min")
        hi = meta.get("max")
        v = _num(value, meta.get("default"), lo, hi)
        return int(v) if float(v).is_integer() else round(v, 2)
    if kind == "color":
        return _hex_str(value)
    if kind == "colors":
        items = value
        if isinstance(value, str):
            items = [s for s in re.split(r"[,，\s]+", value.strip()) if s]
        if not isinstance(items, (list, tuple)) or len(items) < 2:
            raise BoardError(f"{label}的 {key} 至少要 2 个 #RRGGBB 颜色")
        return [_hex_str(c) for c in list(items)[:8]]
    if kind == "bool":
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on", "是", "真")
        return bool(value)
    if kind == "shape":
        s = str(value or "").strip().lower()
        if s not in SHAPES:
            raise BoardError(f"没有这个图形：{s or '空'}，可用：" + "/".join(SHAPES))
        return s
    if kind == "ref":
        nums = _nums(value)
        if len(nums) < 4:
            raise BoardError(f"{label}的 {key} 要写成 [x,y,w,h] 或 \"x,y,w,h\"")
        return [int(round(n)) for n in nums[:4]]
    s = str(value or "").strip()
    if not s:
        raise BoardError(f"{label}的 {key} 不能为空")
    options = meta.get("options")
    if options and s.lower() not in options:
        raise BoardError(f"{label}的 {key} 只能是 " + "/".join(options))
    return s.lower() if options else s


def pick(tool, args=None):
    """校验工具和参数，返回 {"ok": True/False, ...}，绝不抛异常。"""
    try:
        name = str(tool or "").strip()
        if name not in TOOLS:
            raise BoardError(f"没有这个工具：{name or '空'}。可用：" + "、".join(TOOLS))
        spec = TOOLS[name]
        label = spec["label"]
        given = dict(args) if isinstance(args, dict) else {}
        norm = {}
        for key, meta in spec["args"].items():
            value = given.get(key)
            if value is None:
                if meta.get("required"):
                    raise BoardError(f"{label}缺少必填参数 {key}（{meta.get('desc', '')}）")
                if "default" in meta:
                    norm[key] = meta["default"]
                continue
            norm[key] = _coerce(label, key, meta, value)

        # 各工具的额外规则
        if spec["args"].get("points", {}).get("required"):
            pts = norm.get("points") or []
            if len(pts) < 2:
                raise BoardError(f"{label}的 points 至少要 2 个 [x,y] 点，现在只有 {len(pts)} 个")
        if name == "text" and not norm.get("text"):
            raise BoardError("文字工具必填 text，例如 text=\"测试中文\"")
        if name == "shape":
            if not norm.get("ref") and len(norm.get("points") or []) < 2:
                raise BoardError("图形工具要 ref=[x,y,w,h] 或至少 2 个 points")
            if norm["shape"] in ("polygon", "triangle") and not norm.get("ref") \
                    and len(norm.get("points") or []) < 3:
                raise BoardError(f"{label}画 {norm['shape']} 至少要 3 个 points")
        if name == "swap" and not (norm.get("color") or norm.get("colors")):
            raise BoardError("换色要给出 color 或 colors")
        if name == "palette":
            if norm.get("name") and norm["name"] not in PALETTES:
                raise BoardError(f"没有这套配色：{norm['name']}，可用：" + "/".join(PALETTES))
            if not norm.get("name") and not norm.get("colors"):
                raise BoardError("配色要给出预设 name 或自定义 colors")

        msg = f"已取用{label}（{name}）：{spec['hint']}"
        if name in DRAW_TOOLS:
            msg += " 顺序用 draw_op() 落笔。"
        else:
            msg += " 这类操作用 apply() 生效。"
        return {"ok": True, "tool": name, "args": norm, "message": msg}
    except BoardError as e:
        return {"ok": False, "message": str(e)}
    except Exception as e:
        return {"ok": False, "message": f"参数有误：{e}"}


# ---------- 落笔 / 生效 ----------

def draw_op(doc, tool, args=None):
    """把一次作画规整成 op 并追加进 strokes，返回 op。"""
    res = pick(tool, args)
    if not res["ok"]:
        raise BoardError(res["message"])
    name = res["tool"]
    if name not in DRAW_TOOLS:
        raise BoardError(f"{TOOLS[name]['label']}不是笔画工具，请用 apply(doc, \"{name}\", args)")
    op = {"tool": name}
    op.update(res["args"])
    doc["tool"] = name
    if op.get("color"):
        doc["color"] = op["color"]
    push(doc, op)
    return op


def apply(doc, tool, args=None):
    """换色/配色/撤销/清空/画布这类不进 strokes 的操作，返回中文说明。"""
    res = pick(tool, args)
    if not res["ok"]:
        raise BoardError(res["message"])
    name = res["tool"]
    norm = res["args"]

    if name == "swap":
        if norm.get("color"):
            doc["color"] = norm["color"]
        if norm.get("colors"):
            doc["colors"] = list(norm["colors"])
            doc["color"] = doc["colors"][0]
        save(doc)
        colors = doc.get("colors") or []
        tail = f"，轮换配色 {len(colors)} 个（{'、'.join(colors)}）" if colors else ""
        return f"画笔颜色换成 {doc['color']}{tail}"

    if name == "palette":
        if norm.get("name"):
            doc["colors"] = list(PALETTES[norm["name"]])
            doc["color"] = doc["colors"][0]
            save(doc)
            return f"配色换成预设 {norm['name']}：{'、'.join(doc['colors'])}"
        doc["colors"] = list(norm["colors"])
        doc["color"] = doc["colors"][0]
        save(doc)
        return f"配色换成自定义：{'、'.join(doc['colors'])}"

    if name == "undo":
        return undo(doc)

    if name == "clear":
        return clear(doc)

    if name == "canvas":
        w = int(_num(norm.get("width") or doc.get("width"), doc.get("width", 1024), MIN_SIDE, MAX_SIDE))
        h = int(_num(norm.get("height") or doc.get("height"), doc.get("height", 768), MIN_SIDE, MAX_SIDE))
        bg = norm.get("background") or _safe_hex(doc.get("background"), DEFAULT_BG)
        doc["width"], doc["height"], doc["background"] = w, h, bg
        save(doc)
        return f"画布改成 {w}x{h}，底色 {bg}（{len(doc.get('strokes') or [])} 笔已保留）"

    # 笔画工具也顺手支持，方便一条命令画完
    op = draw_op(doc, name, norm)
    return f"已落笔：{TOOLS[name]['label']}（共 {len(doc.get('strokes') or [])} 笔）"


# ---------- 渲染 ----------

def _new_layer(pygame, canvas):
    return pygame.Surface(canvas.get_size(), pygame.SRCALPHA)


def _blend(canvas, layer, alpha):
    """把半透明图层贴到画布上，alpha=255 直接贴。"""
    if alpha >= 255:
        canvas.blit(layer, (0, 0))
    else:
        layer.set_alpha(int(alpha))
        canvas.blit(layer, (0, 0))


def _caps(dense, width):
    """沿线补圆点，做圆头和圆角；点太多就抽稀。"""
    if not dense:
        return []
    if len(dense) <= 800:
        return dense
    step = max(1, len(dense) // 800)
    return dense[::step] + [dense[-1]]


def _catmull_rom(points, steps=10, limit=3000):
    """catmull-rom 平滑，把折线插成顺滑的点列。"""
    if len(points) < 3:
        return list(points)
    pts = [points[0]] + list(points) + [points[-1]]
    out = []
    for i in range(len(pts) - 3):
        p0, p1, p2, p3 = pts[i], pts[i + 1], pts[i + 2], pts[i + 3]
        for s in range(steps):
            t = s / steps
            t2 = t * t
            t3 = t2 * t
            x = 0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t
                       + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                       + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            y = 0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t
                       + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                       + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            out.append((int(round(x)), int(round(y))))
            if len(out) >= limit:
                out.append(points[-1])
                return out
    out.append(points[-1])
    return out


def _font(pygame, size, bold=False):
    """找个能写中文的字体。"""
    size = int(_num(size, 32, 6, 400))
    paths = list(FONT_BOLD_PATHS if bold else FONT_PATHS)
    for p in paths + FONT_PATHS:
        if not os.path.isfile(p):
            continue
        try:
            f = pygame.font.Font(p, size)
            if bold:
                f.set_bold(True)
            return f
        except Exception:
            continue
    try:
        f = pygame.font.SysFont("microsoftyahei", size)
        if bold:
            f.set_bold(True)
        return f
    except Exception:
        raise BoardError("找不到中文字体，文字画不出来") from None


def _flood_fill(pygame, canvas, x, y, color, tolerance):
    """deque BFS 泛洪填充，不会改画布之外的东西。"""
    w, h = canvas.get_size()
    x = int(_num(x, 0))
    y = int(_num(y, 0))
    if not (0 <= x < w and 0 <= y < h):
        raise BoardError(f"油漆桶坐标超出画布：({x}, {y})，画布是 {w}x{h}")
    tol = int(_num(tolerance, 24, 0, 255))
    fill_px = canvas.map_rgb(color)
    pa = pygame.PixelArray(canvas)
    try:
        target = int(pa[x, y])
        if target == fill_px:
            return
        tc = canvas.unmap_rgb(target)
        tr, tg, tb = int(tc.r), int(tc.g), int(tc.b)

        def near(px):
            if px == target:
                return True
            if tol <= 0:
                return False
            c = canvas.unmap_rgb(px)
            return (abs(int(c.r) - tr) <= tol and abs(int(c.g) - tg) <= tol
                    and abs(int(c.b) - tb) <= tol)

        seen = bytearray(w * h)
        dq = deque([y * w + x])
        seen[y * w + x] = 1
        while dq:
            idx = dq.popleft()
            cx, cy = idx % w, idx // w
            pa[cx, cy] = fill_px
            if cx > 0 and not seen[idx - 1] and near(int(pa[cx - 1, cy])):
                seen[idx - 1] = 1
                dq.append(idx - 1)
            if cx + 1 < w and not seen[idx + 1] and near(int(pa[cx + 1, cy])):
                seen[idx + 1] = 1
                dq.append(idx + 1)
            if cy > 0 and not seen[idx - w] and near(int(pa[cx, cy - 1])):
                seen[idx - w] = 1
                dq.append(idx - w)
            if cy + 1 < h and not seen[idx + w] and near(int(pa[cx, cy + 1])):
                seen[idx + w] = 1
                dq.append(idx + w)
    finally:
        del pa


def _shape_box(op):
    """图形外框：优先 ref，其次 points 的包围盒。"""
    nums = _nums(op.get("ref"))
    if len(nums) >= 4:
        return (int(nums[0]), int(nums[1]), max(1, int(nums[2])), max(1, int(nums[3])))
    pts = _pts(op.get("points"))
    if len(pts) >= 2:
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return (min(xs), min(ys), max(1, max(xs) - min(xs)), max(1, max(ys) - min(ys)))
    raise BoardError("图形工具需要 ref=[x,y,w,h] 或至少 2 个 points")


def _star_points(box, tips=5):
    x, y, w, h = box
    cx, cy = x + w / 2.0, y + h / 2.0
    r_out = min(w, h) / 2.0
    r_in = r_out * 0.42
    out = []
    for i in range(tips * 2):
        ang = -math.pi / 2 + i * math.pi / tips
        r = r_out if i % 2 == 0 else r_in
        out.append((int(round(cx + r * math.cos(ang))), int(round(cy + r * math.sin(ang)))))
    return out


def _heart_points(box, steps=28):
    x, y, w, h = box
    cx, cy = x + w / 2.0, y + h / 2.0
    out = []
    for i in range(steps):
        t = 2 * math.pi * i / steps
        hx = 16 * math.sin(t) ** 3
        hy = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        out.append((int(round(cx + hx * w / 34.0)), int(round(cy - hy * h / 34.0))))
    return out


def _draw_brush(pygame, canvas, op, bg):
    pts = _pts(op.get("points"))
    if len(pts) < 2:
        return
    color = _rgb(op.get("color"))
    width = int(round(_num(op.get("width"), 8, 0.5, 400)))
    alpha = int(_num(op.get("alpha"), 255, 0, 255))
    if op.get("closed") and len(pts) >= 3:
        pts = list(pts) + [pts[0]]
    dense = _catmull_rom(pts)
    layer = _new_layer(pygame, canvas)
    for a, b in zip(dense, dense[1:]):
        pygame.draw.line(layer, color, a, b, width)
    r = max(1, width // 2)
    for p in _caps(dense, width):
        pygame.draw.circle(layer, color, p, r)
    _blend(canvas, layer, alpha)


def _draw_pencil(pygame, canvas, op, bg):
    pts = _pts(op.get("points"))
    if len(pts) < 2:
        return
    color = _rgb(op.get("color"))
    width = int(round(_num(op.get("width"), 2, 1, 6)))
    for a, b in zip(pts, pts[1:]):
        pygame.draw.line(canvas, color, a, b, width)
    r = max(1, width // 2)
    for p in pts:
        pygame.draw.circle(canvas, color, p, r)


def _draw_marker(pygame, canvas, op, bg):
    pts = _pts(op.get("points"))
    if len(pts) < 2:
        return
    color = _rgb(op.get("color"))
    width = int(round(_num(op.get("width"), 24, 4, 400)))
    alpha = int(_num(op.get("alpha"), 120, 0, 255))
    dense = _catmull_rom(pts, steps=6, limit=1500)
    layer = _new_layer(pygame, canvas)
    for a, b in zip(dense, dense[1:]):
        pygame.draw.line(layer, color, a, b, width)
    # 方头：两端补短横线压平
    half = max(1, width // 2)
    for p, q in ((dense[0], dense[1]), (dense[-1], dense[-2])):
        dx, dy = q[0] - p[0], q[1] - p[1]
        n = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / n, dx / n
        pygame.draw.line(layer, color,
                         (int(p[0] - nx * half), int(p[1] - ny * half)),
                         (int(p[0] + nx * half), int(p[1] + ny * half)), max(1, width // 3))
    _blend(canvas, layer, alpha)


def _draw_airbrush(pygame, canvas, op, bg):
    pts = _pts(op.get("points"))
    if len(pts) < 2:
        return
    color = _rgb(op.get("color"))
    radius = int(round(_num(op.get("radius"), 18, 2, 200)))
    alpha = int(_num(op.get("alpha"), 60, 1, 255))
    dense = _catmull_rom(pts, steps=6, limit=600)
    rnd = random.Random(20240808)  # 固定种子，重放结果一致
    layer = _new_layer(pygame, canvas)
    dots = max(6, int(radius / 3))
    r2 = radius * radius
    for p in dense:
        for _ in range(dots):
            dx = int(rnd.uniform(-radius, radius))
            dy = int(rnd.uniform(-radius, radius))
            if dx * dx + dy * dy > r2:
                continue
            d = 1 + (1 if rnd.random() < 0.3 else 0)
            pygame.draw.circle(layer, color, (p[0] + dx, p[1] + dy), d)
    _blend(canvas, layer, alpha)


def _draw_fill(pygame, canvas, op, bg):
    color = _rgb(op.get("color"))
    _flood_fill(pygame, canvas, op.get("x"), op.get("y"), color,
                _num(op.get("tolerance"), 24, 0, 255))


def _draw_poly(pygame, canvas, color, fill_rgb, width, points):
    if len(points) < 2:
        return
    if len(points) >= 3 and fill_rgb is not None:
        pygame.draw.polygon(canvas, fill_rgb, points)
        pygame.draw.polygon(canvas, color, points, width)
    elif len(points) >= 3:
        pygame.draw.polygon(canvas, color, points, width)
    else:
        pygame.draw.line(canvas, color, points[0], points[1], width)


def _draw_shape(pygame, canvas, op, bg):
    name = str(op.get("shape") or "rect").lower()
    if name not in SHAPES:
        raise BoardError(f"没有这个图形：{name}")
    color = _rgb(op.get("color"))
    width = int(round(_num(op.get("width"), 3, 1, 80)))
    fill_rgb = _rgb(op.get("fill_color")) if op.get("fill_color") else None
    pts = _pts(op.get("points"))
    box = _shape_box(op)
    x, y, w, h = box

    if name == "line":
        a, b = (pts[0], pts[1]) if len(pts) >= 2 else ((x, y), (x + w, y + h))
        pygame.draw.line(canvas, color, a, b, width)
        return
    if name == "polygon":
        _draw_poly(pygame, canvas, color, fill_rgb, width, pts)
        return
    if name == "triangle":
        tri = pts[:3] if len(pts) >= 3 else \
            [(x + w // 2, y), (x + w, y + h), (x, y + h)]
        _draw_poly(pygame, canvas, color, fill_rgb, width, tri)
        return
    if name == "star":
        _draw_poly(pygame, canvas, color, fill_rgb, width, _star_points(box))
        return
    if name == "heart":
        _draw_poly(pygame, canvas, color, fill_rgb, width, _heart_points(box))
        return

    rect = pygame.Rect(x, y, w, h)
    if name == "rect":
        if fill_rgb is not None:
            pygame.draw.rect(canvas, fill_rgb, rect)
        pygame.draw.rect(canvas, color, rect, width)
        return
    if name == "circle":
        cx, cy = x + w // 2, y + h // 2
        r = max(1, min(w, h) // 2)
        if fill_rgb is not None:
            pygame.draw.circle(canvas, fill_rgb, (cx, cy), r)
        pygame.draw.circle(canvas, color, (cx, cy), r, width)
        return
    if name == "ellipse":
        if fill_rgb is not None:
            pygame.draw.ellipse(canvas, fill_rgb, rect)
        pygame.draw.ellipse(canvas, color, rect, width)
        return
    raise BoardError(f"没有这个图形：{name}")


def _draw_text(pygame, canvas, op, bg):
    text = str(op.get("text") or "")
    if not text:
        raise BoardError("文字的 text 是空的")
    size = int(round(_num(op.get("size"), 32, 6, 400)))
    color = _rgb(op.get("color"))
    bold = bool(op.get("bold"))
    align = str(op.get("align") or "left").lower()
    if align not in ALIGNS:
        align = "left"
    x = _num(op.get("x"), 60)
    y = _num(op.get("y"), 60)
    font = _font(pygame, size, bold)
    line_h = font.get_linesize()
    for i, line in enumerate(text.split("\n")):
        surf = font.render(line, True, color)
        px = x
        if align == "center":
            px = x - surf.get_width() / 2.0
        elif align == "right":
            px = x - surf.get_width()
        canvas.blit(surf, (int(round(px)), int(round(y + i * line_h))))


def _draw_eraser(pygame, canvas, op, bg):
    pts = _pts(op.get("points"))
    if len(pts) < 2:
        return
    size = int(round(_num(op.get("size"), 24, 1, 400)))
    dense = _catmull_rom(pts, steps=6, limit=1500)
    for a, b in zip(dense, dense[1:]):
        pygame.draw.line(canvas, bg, a, b, size)
    r = max(1, size // 2)
    for p in _caps(dense, size):
        pygame.draw.circle(canvas, bg, p, r)


_DRAWERS = {
    "brush": _draw_brush,
    "pencil": _draw_pencil,
    "marker": _draw_marker,
    "airbrush": _draw_airbrush,
    "fill": _draw_fill,
    "shape": _draw_shape,
    "text": _draw_text,
    "eraser": _draw_eraser,
}


def render(doc):
    """把整份文档离屏画成 PNG 字节流。"""
    try:
        import pygame
    except Exception as e:
        raise BoardError(f"没有 pygame，画不出来：{e}") from None
    try:
        return _render(pygame, doc or {})
    except BoardError:
        raise
    except Exception as e:
        raise BoardError(f"画板渲染失败：{e}") from None


def _render(pygame, doc):
    try:
        pygame.init()
    except Exception:
        pass
    w = int(_num(doc.get("width"), 1024, MIN_SIDE, MAX_SIDE))
    h = int(_num(doc.get("height"), 768, MIN_SIDE, MAX_SIDE))
    bg = _rgb(doc.get("background"), DEFAULT_BG)
    try:
        canvas = pygame.Surface((w, h))
    except Exception as e:
        raise BoardError(f"建不出 {w}x{h} 的画布：{e}") from None
    canvas.fill(bg)

    for op in doc.get("strokes") or []:
        if not isinstance(op, dict):
            continue
        tool = op.get("tool")
        drawer = _DRAWERS.get(tool)
        if drawer is None:
            continue
        try:
            drawer(pygame, canvas, op, bg)
        except BoardError:
            raise
        except Exception as e:
            label = TOOLS.get(tool, {}).get("label", str(tool))
            raise BoardError(f"{label}这一笔画不出来：{e}") from None

    buf = io.BytesIO()
    try:
        pygame.image.save(canvas, buf, "board.png")
    except Exception as e:
        raise BoardError(f"导出 PNG 失败：{e}") from None
    return buf.getvalue()


def save_png(doc=None):
    """渲染并存到 board.png，返回路径。"""
    data = render(doc if doc is not None else load())
    try:
        _ensure_dir()
        PNG.parent.mkdir(parents=True, exist_ok=True)
        PNG.write_bytes(data)
    except Exception as e:
        raise BoardError(f"PNG 写不进去：{e}") from None
    return PNG
