"""
文件定位工具：按通配符在工作区里找文件。

解决 list_dir recursive 结果太多被截断、找不到具体文件的问题：
直接按通配符递归匹配文件名，跳过 .git、__pycache__、node_modules 等目录，
结果按修改时间从新到旧排序，只返回相对工作区路径、大小和修改时间。

只依赖标准库 pathlib（base 是受保护目录，所以这个能力放在扩展里）。
"""

from datetime import datetime
from pathlib import Path

from lib_a import tool
from lib_a.extensions._sandbox import resolve_root, under

# 这些目录名出现在任意一层就整层跳过
SKIP = {".git", "__pycache__", "node_modules", ".venv", "venv", "runtime",
        "dist", "build", ".idea", ".mypy_cache", ".pytest_cache"}


def _human(n: int) -> str:
    """字节数转成人类可读的大小。"""
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


@tool("find_files", "按通配符在工作区里找文件，比 list_dir 精确。支持递归，可只看文件名或相对路径。",
      {"pattern": {"type": "string", "description": "通配符，例如 *.py、test_*.txt、**/config.json（会按文件名匹配）"},
       "path": {"type": "string", "description": "从哪个子目录开始找，不写就是工作区根目录"},
       "limit": {"type": "integer", "description": "最多返回多少个，默认 200"}},
      ["pattern"])
def find_files(ws, pattern: str, path: str = ".", limit: int = 200) -> str:
    """按通配符递归找工作区里的文件。"""
    try:
        # 没打开文件夹时回退到用户许可的沙箱目录
        root, err = resolve_root(ws, path)
        if err:
            return err
        root = Path(root).resolve()
        base = (root / path).resolve()
        # 防越界：起始目录必须是工作区本身或在它之下
        if not under(root, base):
            return f"错误: 路径越界: {path}"
        if not base.is_dir():
            return f"错误: {path} 不是目录"

        hits = []
        for f in base.rglob(pattern):
            if not f.is_file():
                continue
            if any(part in SKIP for part in f.parts):
                continue
            try:
                st = f.stat()
            except OSError:
                continue
            hits.append((st.st_mtime, f, st.st_size))

        if not hits:
            return f"没有匹配 {pattern} 的文件"

        hits.sort(key=lambda x: x[0], reverse=True)
        total = len(hits)
        shown = hits[:limit]
        lines = []
        for mtime, f, size in shown:
            rel = f.relative_to(root).as_posix()
            ts = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
            lines.append(f"{rel}（{_human(size)}，{ts}）")
        if total > len(shown):
            lines.append(f"...(共找到 {total} 个，只显示前 {len(shown)} 个)")
        return "\n".join(lines)
    except Exception as e:
        return f"错误: {type(e).__name__}: {e}"
