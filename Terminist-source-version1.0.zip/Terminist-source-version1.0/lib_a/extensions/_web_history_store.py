"""
扩展：浏览记录（web_history / web_last）的存储层。

- 记录存在 memory/web_history.json：{"last": {"url","title","time"}, "history": [{"url","title","time"}, ...]}
- history 只留最近 100 条，最新在最前面；同一个网址连续重复打开不重复插一条（只刷新 last 的 time）
- 时间是 "YYYY-MM-DD HH:MM:SS" 字符串
- 写文件放到后台守护线程里做，不阻塞浏览器线程；写失败（磁盘 / 权限）静默忽略，浏览照常
- 工具和自动记录在 lib_a/extensions/web_history.py
"""

import datetime
import json
import os
import threading

from lib_a import APP_ROOT          # Terminist 根目录

HIST_PATH = os.path.join(str(APP_ROOT), "memory", "web_history.json")
MAX_HISTORY = 100


def _now() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _load_history() -> dict:
    """读浏览记录；文件不存在、内容坏了都当空的。"""
    try:
        with open(HIST_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {"last": None, "history": []}
    if not isinstance(data, dict):
        return {"last": None, "history": []}
    if not isinstance(data.get("history"), list):
        data["history"] = []
    data.setdefault("last", None)
    return data


def _save_history_async(data: dict):
    """后台守护线程里写文件，失败静默忽略。"""
    def _run():
        try:
            os.makedirs(os.path.dirname(HIST_PATH), exist_ok=True)
            with open(HIST_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


def record(url: str, title: str):
    """记一条：刷新 last；同一个网址连续重复打开不重复插一条，但刷新时间。"""
    url = (url or "").strip()
    if not url:
        return
    title = (title or "").strip() or url
    data = _load_history()
    item = {"url": url, "title": title, "time": _now()}
    data["last"] = item
    hist = data["history"]
    if hist and isinstance(hist[0], dict) and hist[0].get("url") == url:
        hist[0]["time"] = item["time"]
        hist[0]["title"] = title
    else:
        hist.insert(0, item)
    data["history"] = hist[:MAX_HISTORY]
    _save_history_async(data)


def live_page():
    """浏览器现在停留的页面 (url, title)；没打开过、还没起来就返回 None（不启动浏览器、不阻塞等待）。"""
    from base import web
    b = getattr(web, "_browser", None)
    if b is None or not b.is_alive() or not b.ready.is_set():
        return None
    try:
        url, title = b.call(lambda x: (x.page.url or "", x.page.title() or ""), timeout=10)
    except Exception:
        return None
    if not url or url.startswith("about:"):
        return None
    return url, title


def record_current():
    """把浏览器当前页面记进历史（web_open / web_click / web_back 成功后自动调这个）。"""
    page = live_page()
    if page:
        record(*page)


def last_page() -> str:
    """当前浏览器停在哪：优先读实时 page.url，读到顺手同步回文件的 last；都没有就文件回退。"""
    page = live_page()
    if page:
        record(*page)
        url, title = page
        return f"{title or url} — {url}"
    data = _load_history()
    last = data.get("last")
    if isinstance(last, dict) and last.get("url"):
        return f"{last.get('title') or last['url']} — {last['url']}"
    return "浏览器还没打开过网页"


def history_text(limit: int = 30) -> str:
    """最近的浏览记录：第一行是现在停留的页面，然后最多 limit 条（最新在最上面）。"""
    data = _load_history()
    last = data.get("last") if isinstance(data.get("last"), dict) else None
    hist = [h for h in data.get("history") or [] if isinstance(h, dict) and h.get("url")][:max(1, int(limit))]
    if not last and not hist:
        return "还没有浏览记录"
    lines = []
    if last:
        lines.append(f"当前停留：{last.get('time') or ''}  {last.get('title') or last['url']}  —  {last['url']}")
        lines.append("")
    lines += [f"{h.get('time') or ''}  {h.get('title') or h['url']}  —  {h['url']}" for h in hist]
    return "\n".join(lines)
