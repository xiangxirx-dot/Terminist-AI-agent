"""
「让主人勾选」的工具已迁到界面层（surface/gui.py 的 gui_tools 里的 choose），
这样没打开文件夹（ws=None）时也能弹勾选框，不再依赖 ws.confirm。

本文件保留说明，不再注册工具：否则 EXT_TOOLS 里会留着 choose，
core.py 的 call_tool 会优先走 EXT_TOOLS → self.ws.confirm，ws=None 时崩。
"""
