"""
画板工具（A库扩展）：board_pick 取工具，board_draw 作画/撤销/清空/存图。

引擎接口在 lib_a/extensions/board_engine.py：
  load / save / push / undo / clear / TOOLS / PALETTES / pick / render / draw_op / apply / PNG / STROKES / BoardError
"""

import json

from lib_a import tool

try:
    import lib_a.extensions.board_engine as board
except Exception:
    try:
        from . import board_engine as board
    except Exception as e:      # 引擎还没装好时，工具仍然注册成功，调用时返回中文错误
        board = None
        _ENGINE_ERROR = f"画板引擎加载失败：{type(e).__name__}: {e}"
    else:
        _ENGINE_ERROR = ""
else:
    _ENGINE_ERROR = ""

TOOL_LABELS = {
    "brush": "毛笔", "pencil": "铅笔", "marker": "马克笔", "airbrush": "喷枪",
    "fill": "油漆桶", "shape": "图形", "text": "文字", "eraser": "橡皮",
    "swap": "换色", "palette": "配色", "undo": "撤销", "clear": "清空", "canvas": "画布",
}

PICK_DESC = ("从画板的美术工具箱里取一件工具，并记住它的参数，下一步 board_draw 直接画。"
             "可用工具：毛笔 brush / 铅笔 pencil / 马克笔 marker / 喷枪 airbrush / 油漆桶 fill / "
             "图形 shape / 文字 text / 橡皮 eraser / 换色 swap / 配色 palette / 撤销 undo / 清空 clear / 画布 canvas")

DRAW_DESC = ("画板操作：action=use 把画板抽出来（右栏展开）；draw 执行一次作画；undo 撤销；clear 清空；"
             "save 存图并插进对话并收起画板；show/hide 显示/收起画板；pick 取工具。"
             "默认用 board_pick 取好的工具和参数，也可以在 args 里临时覆盖。")

DRAW_ACTIONS = ["use", "show", "hide", "draw", "undo", "clear", "save", "pick"]


def _label(tool_name: str) -> str:
    return TOOL_LABELS.get(tool_name, tool_name or "毛笔")


def _get(res, key, default=None):
    """pick / apply 的返回值可能是 dict 也可能是对象，两个都兼容。"""
    if isinstance(res, dict):
        return res.get(key, default)
    return getattr(res, key, default)


def _msg(res, fallback: str) -> str:
    """引擎里 undo/clear 直接返回说明字符串，pick/apply 返回 dict。"""
    if isinstance(res, str):
        return res or fallback
    return str(_get(res, "message", "") or fallback)


def _doc(doc) -> dict:
    """统一成 dict，方便数笔数。"""
    return doc if isinstance(doc, dict) else {}


def _strokes(doc) -> int:
    d = _doc(doc)
    key = getattr(board, "STROKES", "strokes")
    v = d.get(key, d.get("strokes", []))
    try:
        return len(v)
    except Exception:
        return 0


def _agent_of(ws):
    return getattr(ws, "agent", None) if ws is not None else None


def _emit(agent, kind: str, text: str) -> None:
    """给界面发事件；没有 agent 就跳过，不报错。"""
    if agent is None:
        return
    try:
        agent.emit(kind, text)
    except Exception:
        pass


def _emit_board(agent, open_: bool, tool_name: str) -> None:
    _emit(agent, "board", json.dumps({"open": open_, "tool": tool_name}, ensure_ascii=False))


def _check_engine() -> str:
    return "" if board is not None else (_ENGINE_ERROR or "画板引擎不可用")


def _pick(ws, tool_name: str, args: dict) -> str:
    err = _check_engine()
    if err:
        return err
    try:
        res = board.pick(tool_name, args or {})
    except Exception as e:
        return f"取工具失败：{type(e).__name__}: {e}"
    ok = _get(res, "ok", True)
    msg = _msg(res, f"已取工具：{_label(tool_name)}")
    if not ok:
        return str(msg)
    agent = _agent_of(ws)
    if agent is not None:
        try:
            setattr(agent, "board_tool", tool_name)
            setattr(agent, "board_args", dict(args or {}))
        except Exception:
            pass
    return str(msg)


def _save_png(doc) -> str:
    """重渲染 PNG 到 board.PNG，返回错误串（空字符串表示成功）。"""
    try:
        png = board.render(_doc(doc) or doc)
    except Exception as e:
        return f"渲染画板失败：{type(e).__name__}: {e}"
    try:
        target = getattr(board, "PNG", None)
        if target is not None:
            from pathlib import Path
            target = Path(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(png)
    except Exception as e:
        return f"保存画板图片失败：{type(e).__name__}: {e}"
    return ""


@tool("board_pick", PICK_DESC,
      {"tool": {"type": "string", "description": "工具名：brush / pencil / marker / airbrush / fill / shape / text / eraser / swap / palette / undo / clear / canvas"},
       "args": {"type": "object", "description": "这件工具的参数，例如颜色 color、粗细 width、文字 text、坐标 x/y"}},
      ["tool"])
def board_pick(ws, tool: str, args: dict = None) -> str:
    try:
        return _pick(ws, tool, args or {})
    except Exception as e:
        return f"取工具失败：{type(e).__name__}: {e}"


@tool("board_draw", DRAW_DESC,
      {"action": {"type": "string", "enum": DRAW_ACTIONS, "description": "use / show / hide / draw / undo / clear / save / pick"},
       "tool": {"type": "string", "description": "工具名（可选，临时覆盖 board_pick 取的工具）"},
       "args": {"type": "object", "description": "工具参数（可选，与 board_pick 取好的参数合并，这里的覆盖）"},
       "title": {"type": "string", "description": "存图时插进对话的标题，默认「画板成品」"}},
      ["action"])
def board_draw(ws, action: str, tool: str = "", args: dict = None, title: str = "") -> str:
    try:
        return _draw(ws, action, tool, args or {}, title)
    except Exception as e:
        return f"画板操作失败：{type(e).__name__}: {e}"


def _draw(ws, action: str, tool_name: str, args: dict, title: str) -> str:
    err = _check_engine()
    if err and action not in ("use", "show", "hide"):
        return err
    agent = _agent_of(ws)
    saved_tool = getattr(agent, "board_tool", "") if agent is not None else ""
    cur = tool_name or saved_tool or "brush"
    act = (action or "use").strip().lower()

    if act in ("use", "show"):
        _emit_board(agent, True, cur)
        return (f"画板已抽出，当前工具：{_label(cur)}。"
                f"接下来 board_draw(action='draw', args={{...}}) 作画")

    if act == "hide":
        _emit_board(agent, False, cur)
        return "画板已收起"

    if act == "pick":
        return _pick(ws, tool_name or cur, args)

    if act == "draw":
        merged = dict(getattr(agent, "board_args", {}) or {}) if agent is not None and cur == saved_tool else {}
        merged.update(args or {})
        try:
            doc = board.load()
            op = board.draw_op(doc, cur, merged)
            strokes = doc.get("strokes") if isinstance(doc, dict) else None
            if not isinstance(strokes, list) or not strokes or strokes[-1] is not op:
                board.push(doc, op)      # 引擎没自己 push 时补上
            board.save(doc)
        except Exception as e:
            return f"作画失败：{type(e).__name__}: {e}"
        e2 = _save_png(doc)
        if e2:
            return e2
        _emit_board(agent, True, cur)
        # 落笔后参数清空，免得下一笔重复带旧参数
        if agent is not None:
            try:
                setattr(agent, "board_args", {})
            except Exception:
                pass
        return json.dumps({"ok": True, "action": "draw",
                           "summary": f"已用{_label(cur)}落一笔（共 {_strokes(doc)} 笔）",
                           "tool": cur, "args": merged}, ensure_ascii=False)

    if act in ("undo", "clear"):
        try:
            doc = board.load()
            if act == "undo":
                res = board.undo(doc)
            else:
                res = board.clear(doc)
            board.save(doc)
        except Exception as e:
            return f"{_label(act)}失败：{type(e).__name__}: {e}"
        e2 = _save_png(doc)
        if e2:
            return e2
        _emit_board(agent, True, cur)
        msg = _msg(res, "已撤销上一笔" if act == "undo" else "已清空画布")
        return msg if "剩" in msg else f"{msg}，剩余 {_strokes(doc)} 笔"

    if act == "save":
        try:
            doc = board.load()
        except Exception as e:
            return f"读取画板失败：{type(e).__name__}: {e}"
        e2 = _save_png(doc)
        if e2:
            return e2
        if agent is None:
            return "画板已渲染完成，但没有对话窗口可以插进去"
        try:
            from base.tools import _insert_image
            mark = _insert_image(agent, board.PNG, title or "画板成品")
        except Exception as e:
            return f"插进对话失败：{type(e).__name__}: {e}"
        _emit_board(agent, False, cur)
        return f"已画完，成品已插进对话。{mark}"

    # swap / palette / canvas 这类不落笔的，以及其它工具：都走 apply
    try:
        doc = board.load()
        res = board.apply(doc, tool_name or act, args)
        board.save(doc)
    except Exception as e:
        return f"画板操作失败：{type(e).__name__}: {e}"
    e2 = _save_png(doc)
    if e2:
        return e2
    _emit_board(agent, True, tool_name or cur)
    msg = _msg(res, f"已执行{_label(tool_name or act)}")
    return f"{msg}（共 {_strokes(doc)} 笔）"
