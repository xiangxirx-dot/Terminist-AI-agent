"""
网页视口尺寸：查 / 设浏览器里网页内容的宽高，供独立小屏幕窗口对齐用。

- `base/web.py` 在受保护目录里不能改，所以这两个能力在这里实现，并在加载时
  把同名函数挂到 `base.web` 上（界面那边 `getattr(base.web, 'page_size')` 就能直接用）
- 浏览器没起来 / 读不到尺寸时返回 `base.config.WEB_VIEWPORT`，不抛异常、不新开浏览器
"""

from base.config import WEB_VIEWPORT


def _live():
    """已经起来的浏览器；没有就返回 None（不会为了读尺寸去新开一个）。"""
    from base import web as _w
    b = getattr(_w, "_browser", None)
    try:
        if b is not None and b.is_alive():
            return b, _w
    except Exception:
        pass
    return None, _w


def page_size(ws=None) -> tuple[int, int]:
    """当前网页视口的宽高（浏览器没起 / 读不到就返回 config.WEB_VIEWPORT）。"""
    b, _w = _live()
    if b is None:
        return (int(WEB_VIEWPORT[0]), int(WEB_VIEWPORT[1]))
    try:
        size = b.call(lambda br: br.page.evaluate(
            "() => [window.innerWidth, window.innerHeight]"), timeout=8)
        if isinstance(size, (list, tuple)) and len(size) == 2:
            w, h = int(size[0]), int(size[1])
            if w > 0 and h > 0:
                return (w, h)
    except Exception:
        pass
    return (int(WEB_VIEWPORT[0]), int(WEB_VIEWPORT[1]))


def set_page_size(width: int, height: int, ws=None) -> bool:
    """把浏览器视口改成给定宽高；成功 True，没浏览器 / 出错 False（不抛异常）。"""
    try:
        w, h = int(width), int(height)
    except Exception:
        return False
    if w <= 0 or h <= 0:
        return False
    b, _w = _live()
    if b is None:
        return False
    try:
        b.call(lambda br: br.page.set_viewport_size({"width": w, "height": h}), timeout=8)
        return True
    except Exception:
        return False


def _install():
    """把 page_size / set_page_size 挂到 base.web 上（已有就不动）。"""
    try:
        from base import web as _w
        if not callable(getattr(_w, "page_size", None)):
            _w.page_size = page_size
        if not callable(getattr(_w, "set_page_size", None)):
            _w.set_page_size = set_page_size
    except Exception:
        pass


_install()
