"""
边干活边聊天：A库 跑工作流的时候，主人说的话交给这里的"旁聊 Agent"（前台人设，flash 不思考，回得快）。

和以前的独立闲聊 Agent 不同，它跟干活的 Agent 共用一份记忆和现场：
- 每次回话前现拼上下文：干活 Agent 最近的对话、这一轮的任务、进度、是否暂停、实时动态（A库 的动作、B库 的阶段、
  执行成员开始 / 结束），所以主人问"到哪了""刚才那个改好没"都答得上
- 它能直接操作真正的工作流：看进度、暂停、继续、停止、把新的方案 / 改动转给干活的 Agent（下一步就采纳）
- 这一轮干完，旁聊的内容并进干活 Agent 的记忆：两边是同一段历史，下一轮它知道你们聊过什么
- 它没有文件工具，不会和干活的 Agent 抢着改同一个文件
"""

import json
import threading
import time
from collections import deque

from . import taskq
from .core import WORKER_MODEL, Agent, _fn

try:                                     # 小屏幕窗口工具：没装好也只是少了这一个工具，不影响旁聊
    from .extensions.screen_window_tool import tools as screen_window_tools
except Exception:
    screen_window_tools = None

SIDE_PROMPT = """你是 Terminist 的前台，在干活的 Agent 跑工作流的同时陪主人说话。你自己不写代码、不改文件。
你能做的：
- workflow_status：看工作流现在做到哪、进度、最近的动作。主人问进度 / 在干嘛 / 到哪了 / 某件事做了没，先调它再回答，不要猜。
- queue_manage：任务队列（干活的 Agent 会一件件做到清空）。主人要做的每一件「新的事」都 add 进去，一件一项，
  主人一口气说了几件就 add 几项（「再加一件…」「还有…」「另外帮我…」「顺便把 X 也做了」这种独立的活都算新的事）；
  要改某个排队任务就 edit；要调顺序（「先做 t5」「把它往前挪」「放最后」）就 move；说不要了就 drop。都按编号（t3）操作。
  正在做的那项 queue_manage 动不了。
- workflow_add_plan：只用于改「现在正在做的这件事」的做法（「改成…」「别用 X 用 Y」「这个要加上 Z 功能」），
  把主人的要求原样、完整地转过去，干活的 Agent 下一步就会采纳。独立的新任务不要走它，走 queue_manage add。转完 / 加完告诉主人。
- workflow_pause：主人说"等一下""先停一停""暂停"。workflow_resume：主人说"继续""接着干"。
- workflow_stop：主人说"别干了""取消这一轮""停掉"。拿不准是暂停还是停掉，就暂停，再问主人。
- screen_window：主人说开小窗口 / 弹出小屏幕 / 关掉小窗口 / 收起小屏幕时，直接调它，立刻生效（action=open / close / toggle）；这是你自己的能力，不用转给任何人。
- 别的就是正常聊天：简短、口语、用你的人设语气。主人只是闲聊就别去碰工作流。
- 主人的话后面附了［知识库自动检索］：主人说的是歌词 / 台词 / 梗里的一句，就照原文先接出下一句，再用人设搭一句；不相关就当没看见。
主人每说一句，前面都会附上当时最新的共享上下文（干活 Agent 的最近对话和工作流现场），以最新那份为准。"""

MAX_SHARED = 6000          # 共享上下文里放多少字的最近对话


def _text(m: dict) -> str:
    c = m.get("content")
    return c if isinstance(c, str) else ""


class SideChat:
    def __init__(self, main: Agent, emit, on_stop=None, label=lambda: "前台"):
        self.main = main
        self.emit = emit
        self.on_stop = on_stop or main.stop_all     # 界面要在主线程里停（GUI 传自己的）
        self.label = label                          # 前台员工的名字（合并进记忆时用）
        self.lock = threading.Lock()
        self.feed: deque = deque(maxlen=60)         # 实时动态 (时间, 文字)
        self.session: list[dict] = []               # 这次干活期间的旁聊（user / assistant 文字）
        self.turn_started = 0.0
        self.turn_task = ""
        self.busy = False                           # 旁聊 Agent 正在回话
        self._watch_main()
        self.agent = Agent(main.ws, emit=emit, model=WORKER_MODEL, system_prompt=SIDE_PROMPT, persist=False)
        self.agent.gated = False                     # 暂停的是工作流，不是它
        self.agent.tools = self._tools               # 只给它操作工作流的几个工具（不给文件工具，也不给它自己的 stop_workflow）
        self.agent.custom_tools = {
            "workflow_status": (_fn("workflow_status", "看工作流现场：任务、进度、是否暂停、最近的动作（带时间）。", {}, []),
                                lambda a: self.status()),
            "workflow_add_plan": (_fn("workflow_add_plan", "把主人对这次的活的新要求 / 新方案 / 改动转给干活的 Agent，下一步就采纳。",
                                      {"instruction": {"type": "string", "description": "主人的原话（完整，不要改意思）"}},
                                      ["instruction"]),
                                  lambda a: self.main.add_instruction(str(a.get("instruction", "")))),
            "workflow_pause": (_fn("workflow_pause", "暂停工作流（当前这一步做完就停住，B库、执行成员也停）。", {}, []),
                               lambda a: self.main.pause()),
            "workflow_resume": (_fn("workflow_resume", "继续被暂停的工作流。", {}, []), lambda a: self.main.resume()),
            "workflow_stop": (_fn("workflow_stop", "停掉这一轮工作流（取消，不是暂停）。", {}, []), lambda a: self._stop()),
            # 排队中的任务：前台能直接加、改、排序、删（正在做的那项动不了，要改它走 workflow_add_plan）
            "queue_manage": (taskq.front_tool()[0], self._queue_manage),
        }
        if screen_window_tools is not None:      # 开 / 关小屏幕窗口：前台自己调，立刻生效，不派 Agent
            try:
                self.agent.custom_tools.update(screen_window_tools(self.agent.ws))
            except Exception:
                pass

    def _tools(self) -> list:
        return [schema for schema, _ in self.agent.custom_tools.values()]

    def _queue_manage(self, a: dict) -> str:
        """前台改排队任务。干活的 Agent 正在跑时，把变化和新的队列顺序转给它（下一步就看到）：
        不然它还按开工时读到的旧队列往下做，前台加的、挪的都被它漏掉。"""
        res = taskq.front_tool()[1](a)
        act = str((a or {}).get("action") or "list").lower()
        if act in ("add", "edit", "move", "drop") and not res.startswith("错误") and self.main.live_busy:
            order = "；".join(f"[{t['id']}] {t['title'][:40]}" for t in taskq.open_tasks())
            self.main.add_instruction(f"前台按主人的意思改了任务队列：{res.splitlines()[0]}。"
                                      f"现在的顺序（做完手上这件就按这个来）：{order or '空'}")
        elif act in ("add", "resume") and not res.startswith("错误") and not self.main.live_busy:
            self.main.emit("queue_kick", "")          # 干活的 Agent 闲着：界面马上让它开工
            res += "\n（干活的 Agent 现在闲着，已让它开工）"
        return res

    def _stop(self) -> str:
        if not self.main.live_busy:
            return "现在没有正在跑的工作流"
        self.on_stop()
        return "已停掉这一轮工作流"

    # ---------------- 实时动态：盯着干活 Agent 的事件 ----------------
    def _watch_main(self):
        emit, chat = self.main.emit, self.main.chat

        def watched(kind, text):
            try:
                self._observe(kind, text)
            except Exception:
                pass
            return emit(kind, text)

        def tracked(text):
            with self.lock:
                self.turn_started, self.turn_task = time.time(), str(text)[:300]
                self.feed.clear()
            self._note(f"开始干活：{str(text)[:80]}")
            return chat(text)

        self.main.emit, self.main.chat = watched, tracked

    def _note(self, text: str):
        with self.lock:
            self.feed.append((time.time(), " ".join(str(text).split())[:160]))

    def _observe(self, kind: str, text: str):
        if kind == "tool":
            self._note("A库 " + str(text).split("(", 1)[0] + "（" + str(text).split("(", 1)[-1][:60].rstrip(")") + "）")
        elif kind == "b_stage":
            self._note("B库：" + str(text).splitlines()[0])
        elif kind == "worker":
            ev = json.loads(text)
            who, k = ev.get("w"), ev.get("kind")
            who = who if isinstance(who, str) else f"执行成员{who}"
            if k == "start":
                try:
                    title = json.loads(ev.get("text") or "{}").get("title", "")
                except ValueError:
                    title = ""
                self._note(f"{who} 开始：{title}")
            elif k == "end":
                try:
                    ok = json.loads(ev.get("text") or "{}").get("ok", True)
                except ValueError:
                    ok = True
                self._note(f"{who} {'做完了' if ok else '失败了'}")
            elif k == "error":
                self._note(f"{who} 出错：{ev.get('text', '')}")
        elif kind == "error":
            self._note("出错：" + str(text))
        elif kind == "paused":
            self._note("工作流暂停")
        elif kind == "resumed":
            self._note("工作流继续")
        elif kind == "steer_applied":
            self._note("A库 采纳了追加指示：" + str(text).replace("\n", " ")[:100])
        elif kind == "done":
            self._note("这一轮干完了")

    def status(self) -> str:
        m = self.main
        now = time.time()
        with self.lock:
            feed = list(self.feed)[-14:]
            started, task = self.turn_started, self.turn_task
        if not m.live_busy:
            head = "工作流没在跑" + ("（上一轮已经干完）" if started else "")
        else:
            head = ("⏸ 已暂停（等主人说继续）" if m.paused else "正在干活") + (f"，已经跑了 {int(now - started)} 秒" if started else "")
        p = m.progress or {}
        lines = [head]
        if task:
            lines.append(f"这一轮的任务：{task}")
        if p.get("total"):
            lines.append(f"进度：{p.get('done', 0)}/{p['total']}" + (f"（当前：{p['label']}）" if p.get("label") else ""))
        if m.child is not None:
            lines.append("现在在等 B库 改造 Terminist")
        if m.children:
            lines.append(f"现在有 {len(m.children)} 个执行成员在并行干活")
        if m.steer:
            lines.append("还没采纳的追加指示：" + "；".join(m.steer))
        if feed:
            lines.append("最近的动态（越往下越新）：")
            lines += [f"  - {int(now - t)} 秒前：{x}" for t, x in feed]
        return "\n".join(lines)

    # ---------------- 回话 ----------------
    def _shared(self) -> str:
        """干活 Agent 最近的对话（不含工具细节）+ 实时现场。"""
        out, used = [], 0
        for m in reversed(self.main.messages[1:]):
            role = m.get("role")
            t = _text(m).strip()
            if role not in ("user", "assistant") or not t or m.get("tool_calls") and not t:
                continue
            who = "主人" if role == "user" and not Agent.is_internal(m) else ("干活的 Agent" if role == "assistant" else "（系统记录）")
            t = t if len(t) <= 600 else t[:600] + "…"
            if used + len(t) > MAX_SHARED:
                break
            out.append(f"{who}：{t}")
            used += len(t)
        recent = "\n".join(reversed(out)) or "（还没有对话）"
        return f"## 干活 Agent 最近的对话\n{recent}\n\n## 工作流现场（实时）\n{self.status()}"

    def ask(self, text: str):
        """主人说了一句（在后台线程里调用，阻塞到回完）。事件由构造时的 emit 发出（GUI 加 chat_ 前缀）。"""
        a = self.agent
        with self.lock:
            self.busy = True
            history = list(self.session)
        a.set_persona(self._persona())
        # 系统提示词（规则 + 人设）不变、之前的旁聊不变，DeepSeek 的缓存能命中；实时的共享上下文跟在主人这句话前面
        a.messages = [{"role": "system", "content": a._system_prompt()}] + history
        n0 = len(a.messages)
        try:
            a.chat(f"[共享上下文（实时）]\n{self._shared()}\n\n[主人刚说]\n{text}")
        finally:
            reply = next((_text(m) for m in reversed(a.messages[n0:]) if m.get("role") == "assistant" and _text(m)), "")
            with self.lock:
                self.session += [{"role": "user", "content": text}, {"role": "assistant", "content": reply or "（没回上）"}]
                self.busy = False

    def _persona(self) -> str:
        from .staff import active_persona
        try:
            return active_persona()
        except Exception:
            return ""

    def merge_into_main(self) -> bool:
        """这一轮干完（或旁聊在空闲时结束）：把旁聊并进干活 Agent 的记忆，两边就是同一段历史。"""
        with self.lock:
            if self.busy or not self.session:
                return False
            session, self.session = self.session, []
        name = self.label()
        lines = [f"{'主人' if m['role'] == 'user' else name}：{m['content']}" for m in session]
        note = ("[干活期间的对话] 你刚才干活的时候，主人和前台（" + name + "）聊了下面这些；其中对工作的要求已经当场转给过你。"
                "以后主人提到这些内容时你要知道。\n" + "\n".join(lines))
        meta = Agent._meta()                          # 当时几点、哪个员工（重启后聊天栏按它画，不按现在上岗的）
        self.main.messages += [{"role": "user", "content": note[:8000], **meta},
                               {"role": "assistant", "content": "好的，干活期间的对话我知道了。", **meta}]
        try:
            self.main.save_memory()
        except Exception:
            pass
        return True
