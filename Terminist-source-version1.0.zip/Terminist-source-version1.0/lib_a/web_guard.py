"""
网页操作超时 / 长时间无响应 → 自动截图回传（内置机制，不靠模型自己记得）。

- 任何一个网页工具（web_open / web_search / web_click / web_type / web_scroll / web_back）单次执行
  超过 WEB_SLOW_SECONDS 秒，或抛 WebError（包括「网页操作超时」），自动截当前页面一张图；
- 图落到 WEB_SHOTS_DIR，同时交给本地看图模型（Qwen-VL）转成文字，附在返回给模型的工具结果里，
  结果里带 [[image:路径|标题]] 标记，界面会把图插进对话；
- 截图自己失败（浏览器没起来 / 页面还没打开）时只附一句说明，绝不二次抛异常；
- 每次网页操作开始时会给界面发一个 "web_seen" 事件，界面据此决定要不要开独立小屏幕窗口。

base 是受保护的中心库，所以这里不改 base/web.py，而是用 install() 在运行时把 base.web 的对外函数
包一层：必须在 base.attach(agent) 之前调用，attach 注册工具时拿到的就是包过的函数。
"""

import json
import time
import uuid
from pathlib import Path

from base import vision
from base import web as _web

IMAGE_MARK = "[[image:{path}|{title}]]"     # 和 base/tools.py 的 IMAGE_MARK 同一个格式约定


def _conf(name: str, default):
    """优先用 base.config 里的设置（那边加了同名配置就直接生效，没加就用默认值）。"""
    try:
        from base import config
        return getattr(config, name, default)
    except Exception:
        return default


WEB_SLOW_SECONDS = _conf("WEB_SLOW_SECONDS", 8)                                  # 秒；超过就自动截图
WEB_SHOTS_DIR = Path(_conf("WEB_SHOTS_DIR", Path.home() / ".terminist" / "web_shots"))

# base.web 里的对外函数 -> 工具名（工具名用来写进截图说明，让模型知道自己看的是哪一步的画面）
_INTERFACE = {
    "open_url": "web_open",
    "search": "web_search",
    "click": "web_click",
    "type_into": "web_type",
    "scroll": "web_scroll",
    "back": "web_back",
}

# 让模型知道超时会自动带截图（base/tools.py 受保护，attach 之后在这里补描述）
WEB_TOOL_DESC = {
    "web_open": "打开网址，返回标题、正文文字和链接列表。超时或长时间无响应时会自动截图并把画面描述附在结果里"
                "（带 [[image:...]] 标记，界面会插进对话），不需要自己再截图。",
    "web_click": "点击链接：写链接编号（web_open / web_search 列出的），或者页面上的文字。"
                 "点击失败或很慢时会自动截图回传当前画面。",
    "web_search": "用必应搜索，返回前几条结果（标题、网址、摘要）。超时会自动截图回传。",
}

_agent = None          # attach 之后记下来：截到图就顺手让界面插进对话
_installed = False


def _snap_current(reason: str = "") -> str:
    """网页操作超时 / 无响应时：截当前页面一张图，落盘 + 交给本地看图模型转文字。绝不抛异常。"""
    try:
        WEB_SHOTS_DIR.mkdir(parents=True, exist_ok=True)
        raw = _web.browser().call(lambda b: b.page.screenshot(type="jpeg", quality=75, full_page=False), timeout=25)
        p = WEB_SHOTS_DIR / f"timeout_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.jpg"
        p.write_bytes(raw)
    except Exception as e:
        return f"（自动截图失败：{type(e).__name__}: {e}）"
    try:                                     # 真插进对话；失败也不影响文字说明
        if _agent is not None:
            _agent.emit("image", json.dumps(
                {"path": str(p), "title": "网页超时截图", "kind": "other"}, ensure_ascii=False))
    except Exception:
        pass
    try:
        url = _web.browser().call(lambda b: b.page.url, timeout=10)
    except Exception:
        url = ""
    try:
        desc = vision.describe(raw, "这是网页操作超时时自动截下的画面。请说明页面当前显示了什么、"
                                    "是还在加载/空白/报错，还是弹了窗口挡住。")
    except Exception as e:
        desc = f"（本地看图不可用：{e}）"
    return (f"\n\n[网页操作超时自动截图] 触发原因：{reason or '操作耗时过长'}；当前网址：{url or '(未知)'}\n"
            f"{IMAGE_MARK.format(path=p, title='网页超时截图')}\n画面：{desc}")


def _poke_ui(action: str = "") -> None:
    """告诉界面：网页开始动了（界面据此开独立小屏幕窗口）。失败绝不抛。"""
    try:
        if _agent is not None:
            _agent.emit("web_seen", json.dumps({"action": action}, ensure_ascii=False))
    except Exception:
        pass


def _guarded(name: str, fn, *args, **kwargs):
    """跑一次网页操作：超时（> WEB_SLOW_SECONDS）或抛错时自动截图并附加说明。"""
    _poke_ui(name)
    t0 = time.monotonic()
    try:
        out, err = fn(*args, **kwargs), None
    except _web.WebError as e:
        out, err = "", e
    cost = time.monotonic() - t0
    if err is not None:
        shot = _snap_current(f"{name} 失败：{err}")
        raise _web.WebError(f"{err}{shot}") from err
    if cost > WEB_SLOW_SECONDS:
        out += _snap_current(f"{name} 耗时 {cost:.1f} 秒")
    return out


def _wrap(name: str, fn):
    def run(*args, **kwargs):
        return _guarded(name, fn, *args, **kwargs)
    return run


def install() -> None:
    """把 base.web 的对外函数包一层（重复调用没副作用）。要在 base.attach(agent) 之前调。"""
    global _installed
    if _installed:
        return
    for attr, name in _INTERFACE.items():
        fn = getattr(_web, attr, None)
        if callable(fn):
            setattr(_web, attr, _wrap(name, fn))
    _installed = True


def describe_tools(agent) -> None:
    """attach 之后调：补网页工具的描述，并记住 agent 好把截图插进对话。"""
    global _agent
    _agent = agent
    try:
        for name, desc in WEB_TOOL_DESC.items():
            entry = agent.custom_tools.get(name)
            if entry and isinstance(entry[0], dict):
                entry[0]["function"]["description"] = desc
    except Exception:
        pass
