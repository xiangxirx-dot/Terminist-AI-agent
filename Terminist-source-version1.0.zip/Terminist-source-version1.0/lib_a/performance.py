"""性能模式：四档参数（省token / 正常token / 高均衡 / Ultra*），供 Agent 按档位覆盖实例级上下文与工具压缩参数。"""

import json
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent      # Terminist 根目录（和 core.APP_ROOT 一致，避免循环导入）
SETTINGS_FILE = APP_ROOT / "terminist_settings.json"

DEFAULT_MODE = "normal"

# 每档：标签 + 参数。normal 档＝原有默认值，必须保持一致
MODES: dict[str, dict] = {
    "save": {"label": "省token模式", "front_context": 4_000, "context_limit": 120_000,
             "old_tool_chars": 800, "max_tool_chars": 4_000, "recall_k": 3,
             "team_mode": False, "thinking": False},
    "normal": {"label": "正常token模式", "front_context": 8_000, "context_limit": 200_000,
               "old_tool_chars": 1_500, "max_tool_chars": 8_000, "recall_k": 5,
               "team_mode": True, "thinking": True},
    "balanced": {"label": "高均衡模式", "front_context": 16_000, "context_limit": 320_000,
                 "old_tool_chars": 3_000, "max_tool_chars": 16_000, "recall_k": 8,
                 "team_mode": True, "thinking": True},
    "ultra": {"label": "Ultra*", "front_context": 32_000, "context_limit": 600_000,
              "old_tool_chars": 8_000, "max_tool_chars": 32_000, "recall_k": 12,
              "team_mode": True, "thinking": True},
}

# 用户 / 模型可能写的别名 -> 档位键
ALIASES: dict[str, str] = {
    "省token": "save", "节约": "save", "save": "save",
    "正常": "normal", "normal": "normal", "标准": "normal",
    "均衡": "balanced", "高均衡": "balanced", "balanced": "balanced",
    "ultra": "ultra", "Ultra": "ultra", "Ultra*": "ultra", "极限": "ultra",
}


def normalize(mode) -> str:
    """把各种写法归一成档位键；认不出返回空字符串。"""
    s = str(mode or "").strip()
    if not s:
        return ""
    if s.lower() in MODES:
        return s.lower()
    return ALIASES.get(s, "")


def read_perf_mode() -> str:
    """读 terminist_settings.json 里的 perf_mode（默认 normal，未知值也回 normal）。"""
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        mode = normalize(data.get("perf_mode"))
        return mode or DEFAULT_MODE
    except Exception:
        return DEFAULT_MODE


def params(mode: str | None = None) -> dict:
    """当前（或指定）档位的参数，含 label；别名写法也能认。"""
    key = normalize(mode) or DEFAULT_MODE
    return dict(MODES[key])


def apply_perf_mode(mode: str) -> dict:
    """按名字取一档参数，非法值抛 ValueError；返回该档参数（含档位名 mode）。"""
    key = normalize(mode)
    if not key:
        raise ValueError(f"未知的性能模式: {mode}")
    out = dict(MODES[key])
    out["mode"] = key
    return out
