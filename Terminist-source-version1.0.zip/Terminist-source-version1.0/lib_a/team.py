"""
A库 工作组：组长用 dispatch 把子任务派给多个执行成员并行完成。

- 每个成员是一个独立的 Agent（WORKER_MODEL），只能改分配给它的文件，其他文件只读
- 文件有重叠的子任务不会同时跑，会排到下一批
- 成员的事件以 ("worker", {"w": 编号, "kind": 事件类型, "text": 内容}) 的形式转给 Surface
- 全部做完后把每个成员的汇报交回组长，由组长查工
"""

import copy
import json
import threading

from .core import MAX_WORKERS, WORKER_MODEL, Agent

WORKER_PROMPT = """你是 Terminist 工作组里的执行成员（{model}），负责完成组长分配给你的一个子任务。
工作区文件夹: {root}
操作系统: {os}

规则:
- 只做分配给你的子任务，只修改分配给你的文件；其他文件可以读，但不能改。
- 先读相关代码再动手；修改已有文件用 edit_file 做小范围替换，新建文件用 write_file。
- 能验证就用 run_command 验证一次就够了。
- 不要反复思考，不要给多个方案：直接写出最简洁、最准确的实现，写完就汇报。
- 做完后用与用户相同的语言汇报：改了哪些文件、改了什么、怎么验证的、还有什么没做完或拿不准。不要夸大。
{team_info}"""

_DONE_PREFIXES = ("已新建 ", "已覆盖 ", "已修改 ", "已删除 ")


def _norm(path: str) -> str:
    p = str(path).replace("\\", "/").strip()
    while p.startswith("./"):
        p = p[2:]
    return p.rstrip("/") or "."


def _waves(tasks: list[dict]) -> list[list[int]]:
    """把子任务分批：同一批里的子任务不碰同一个文件，且不超过 MAX_WORKERS 个。"""
    waves: list[tuple[list[int], set]] = []
    for k, t in enumerate(tasks):
        files = {_norm(f) for f in t["files"]}
        for idx, used in waves:
            if len(idx) < MAX_WORKERS and not (used & files):
                idx.append(k)
                used |= files
                break
        else:
            waves.append(([k], set(files)))
    return [idx for idx, _ in waves]


def _changed_files(agent: Agent) -> list[str]:
    out = []
    for m in agent.messages:
        c = m.get("content") or ""
        if m["role"] == "tool" and c.startswith(_DONE_PREFIXES):
            f = c.split(" ", 1)[1].strip()
            if f not in out:
                out.append(f)
    return out


def _report(agent: Agent) -> str:
    for m in reversed(agent.messages):
        if m["role"] == "assistant" and m.get("content"):
            return m["content"]
    return "(没有汇报)"


def dispatch(lead: Agent, goal: str, tasks: list) -> str:
    tasks = [{"title": str(t.get("title") or f"子任务 {i + 1}"),
              "instruction": str(t.get("instruction") or ""),
              "files": [str(f) for f in (t.get("files") or [])]}
             for i, t in enumerate(tasks) if isinstance(t, dict)]
    if not tasks:
        return "错误: 没有有效的子任务（每个子任务需要 title、instruction、files）"

    results: list[dict | None] = [None] * len(tasks)
    lock = threading.Lock()
    first_id = lead.worker_seq + 1
    lead.worker_seq += len(tasks)

    def run_one(k: int):
        task, wid = tasks[k], first_id + k

        def relay(kind: str, text: str):
            if kind not in ("done", "context", "member", "model_info"):
                lead.emit("worker", json.dumps({"w": wid, "kind": kind, "text": text}, ensure_ascii=False))

        ws = copy.copy(lead.ws)               # 沿用组长的确认方式和受保护目录
        roots = []
        for f in task["files"]:
            try:
                roots.append(lead.ws.resolve(f))
            except ValueError:
                pass
        ws.write_roots = roots                # 只能改分配给自己的文件
        relay("start", json.dumps({"title": task["title"], "files": task["files"], "model": WORKER_MODEL},
                                  ensure_ascii=False))
        w = Agent(ws, emit=relay, model=WORKER_MODEL, system_prompt=WORKER_PROMPT, persist=False, role="worker")
        with lock:
            lead.children.append(w)
        ok, err = True, ""
        try:
            w.chat(f"[总目标]\n{goal}\n\n[你的子任务] {task['title']}\n{task['instruction']}\n\n"
                   f"[你负责的文件] {', '.join(task['files']) or '(无，只读)'}")
            ok = not w.stop_requested
        except Exception as e:
            ok, err = False, f"{type(e).__name__}: {e}"
        finally:
            with lock:
                lead.children.remove(w)
        res = {"ok": ok, "report": err or _report(w), "changed": _changed_files(w)}
        results[k] = res
        relay("end", json.dumps(res, ensure_ascii=False))

    for wave in _waves(tasks):
        if lead.stop_requested:
            break
        threads = [threading.Thread(target=run_one, args=(k,), daemon=True) for k in wave]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    lines = [f"共 {len(tasks)} 个子任务，执行成员 {WORKER_MODEL}。"]
    for k, (task, res) in enumerate(zip(tasks, results)):
        if res is None:
            lines.append(f"\n## 子任务 {first_id + k}：{task['title']}\n状态：未执行（已停止）")
            continue
        lines.append(f"\n## 子任务 {first_id + k}：{task['title']}\n"
                     f"状态：{'完成' if res['ok'] else '失败'}\n"
                     f"负责文件：{', '.join(task['files']) or '无'}\n"
                     f"实际改动：{', '.join(res['changed']) or '无'}\n"
                     f"成员汇报：{res['report']}")
    lines.append("\n请你作为组长查工：读改动过的文件、能运行的跑一下；有问题就再用 dispatch 派返工，说清楚哪里不对。")
    return "\n".join(lines)
