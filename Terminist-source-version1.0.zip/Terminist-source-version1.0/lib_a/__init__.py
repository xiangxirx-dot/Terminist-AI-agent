"""A库（执行层）。详见 lib_a/core.py。"""

from .core import *                                       # noqa: F401,F403
from .core import _fn, EXT_TOOLS, load_extensions, tool   # noqa: F401
from . import graph_memory                                # noqa: F401  知识库进库边界（代码级兜底）

graph_memory.install()                                    # 导入时装好：base.attach 之后自动挂上边界
