"""Terminist 配置：AI 接口（地址、模型、key）和硬限制。"""


# ============================================================
# API key：不写在代码里。在设置里填（或命令行 /apikey），加密存在 ~/.terminist/api_key.dpapi；
# 也可以用环境变量 DEEPSEEK_API_KEY（优先级最高）。
# 加密用 Windows 自带的 DPAPI：只有这台电脑上的这个 Windows 账户能解开，文件拷走或被别的账户读到也没用。
# ============================================================
import ctypes
import os
import sys
from pathlib import Path

KEY_DIR = Path.home() / ".terminist"
KEY_FILE = KEY_DIR / "api_key.dpapi"          # 加密后的 key（不在 Terminist 文件夹里：不进存档，Agent 的工具读不到）
_PLAIN_FILE = KEY_DIR / "api_key"             # 旧版本存的明文 key：读到就自动加密迁移，然后删掉
ENV_KEY = "DEEPSEEK_API_KEY"
_ENTROPY = b"Terminist API key"


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(data: bytes, encrypt: bool) -> bytes:
    """Windows DPAPI 加 / 解密（绑定当前 Windows 账户）。"""
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    src = _Blob(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)), ctypes.POINTER(ctypes.c_char)))
    ent = _Blob(len(_ENTROPY), ctypes.cast(ctypes.create_string_buffer(_ENTROPY, len(_ENTROPY)), ctypes.POINTER(ctypes.c_char)))
    out = _Blob()
    fn = crypt32.CryptProtectData if encrypt else crypt32.CryptUnprotectData
    if encrypt:
        ok = fn(ctypes.byref(src), "Terminist", ctypes.byref(ent), None, None, 0x1, ctypes.byref(out))   # 0x1 = 不弹界面
    else:
        ok = fn(ctypes.byref(src), None, ctypes.byref(ent), None, None, 0x1, ctypes.byref(out))
    if not ok:
        raise OSError(f"DPAPI {'加密' if encrypt else '解密'}失败（错误码 {ctypes.GetLastError()}）")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def _seal(key: str) -> bytes:
    if sys.platform == "win32":
        return _dpapi(key.encode("utf-8"), True)
    return key.encode("utf-8")                # 非 Windows：没有 DPAPI，只能靠文件权限（下面设成仅本人可读）


def _unseal(blob: bytes) -> str:
    if sys.platform == "win32":
        return _dpapi(blob, False).decode("utf-8")
    return blob.decode("utf-8")


# ============================================================
# 多个 AI 接口（都是 OpenAI 兼容的 chat/completions）：地址、模型名存在 ~/.terminist/providers.json，
# 每个接口的 key 各自用 DPAPI 加密存一份（DeepSeek 沿用原来的 api_key.dpapi）。当前用哪个也记在 providers.json。
# 换接口要重启：模型名、客户端都是启动时定的。
# ============================================================
import json as _json

PROVIDERS_FILE = KEY_DIR / "providers.json"
KEYS_DIR = KEY_DIR / "keys"
DEFAULT_PROVIDER = "deepseek"
PRESETS = {                                    # 新建接口时的预设：地址填好；模型名拉接口的模型列表来选（各家改名太勤，不写死）
    "deepseek": {"name": "DeepSeek", "base_url": "https://api.deepseek.com",
                 "main": "deepseek-v4-pro", "fast": "deepseek-flash"},
    "kimi": {"name": "Kimi（月之暗面）", "base_url": "https://api.moonshot.cn/v1"},
    "qwen": {"name": "通义千问（阿里云百炼）", "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1"},
    "glm": {"name": "智谱 GLM", "base_url": "https://open.bigmodel.cn/api/paas/v4"},
    "siliconflow": {"name": "硅基流动", "base_url": "https://api.siliconflow.cn/v1"},
    "openai": {"name": "OpenAI", "base_url": "https://api.openai.com/v1"},
    "openrouter": {"name": "OpenRouter", "base_url": "https://openrouter.ai/api/v1"},
    "custom": {"name": "自定义（OpenAI 兼容）", "base_url": ""},
}


def load_providers() -> dict:
    """{"active": 接口 id, "providers": {id: {name, base_url, main, fast}}}。DeepSeek 一直在。"""
    try:
        data = _json.loads(PROVIDERS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    provs = data.get("providers") if isinstance(data.get("providers"), dict) else {}
    ds = provs.setdefault("deepseek", {})
    for k, v in PRESETS["deepseek"].items():
        ds.setdefault(k, v)
    active = data.get("active") if data.get("active") in provs else DEFAULT_PROVIDER
    return {"active": active, "providers": provs}


def save_providers(data: dict):
    KEY_DIR.mkdir(parents=True, exist_ok=True)
    tmp = PROVIDERS_FILE.with_suffix(".tmp")
    tmp.write_text(_json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(PROVIDERS_FILE)


def active_id() -> str:
    return load_providers()["active"]


def provider(pid: str | None = None) -> dict:
    """某个接口（不传就是当前在用的）的设定，带上 id。"""
    data = load_providers()
    pid = pid or data["active"]
    info = dict(data["providers"].get(pid) or {})
    info["id"] = pid
    return info


def base_url(pid: str | None = None) -> str:
    return str(provider(pid).get("base_url") or "").rstrip("/")


def is_deepseek(pid: str | None = None) -> bool:
    """DeepSeek 自家的接口：只有它认「关思考」参数和 reasoning_content 字段，别家发过去可能直接 400。"""
    return "api.deepseek.com" in base_url(pid)


def thinking_off() -> dict:
    """关思考的请求参数：DeepSeek 要显式带；别的接口不认这个参数，什么都不带。"""
    return {"extra_body": {"thinking": {"type": "disabled"}}} if is_deepseek() else {}


def models(pid: str | None = None) -> tuple[str, str]:
    """(主模型, 快模型)：主模型想方案 / 干活，快模型给前台、B库助手、记忆这些。快模型没填就用主模型。"""
    p = provider(pid)
    main = str(p.get("main") or "").strip() or PRESETS["deepseek"]["main"]
    fast = str(p.get("fast") or "").strip() or main
    return main, fast


def upsert_provider(pid: str, name: str, url: str, main: str = "", fast: str = ""):
    data = load_providers()
    data["providers"][pid] = {"name": name.strip() or pid, "base_url": url.strip().rstrip("/"),
                              "main": main.strip(), "fast": fast.strip()}
    save_providers(data)


def new_provider_id(preset: str) -> str:
    provs = load_providers()["providers"]
    if preset not in provs:
        return preset
    n = 2
    while f"{preset}{n}" in provs:
        n += 1
    return f"{preset}{n}"


def remove_provider(pid: str) -> str:
    """删掉一个接口和它的 key。返回空字符串 = 删了，否则是原因。"""
    data = load_providers()
    if pid == DEFAULT_PROVIDER:
        return "DeepSeek 不能删（锦衣卫审查一直用它），只能清空 key"
    if pid == data["active"]:
        return "正在用，先换别的接口再删"
    if pid not in data["providers"]:
        return "没有这个接口"
    data["providers"].pop(pid)
    save_providers(data)
    set_api_key("", pid)
    return ""


def set_active(pid: str) -> str:
    """换成用这个接口（下次启动生效）。返回空字符串 = 换了，否则是原因。"""
    data = load_providers()
    if pid not in data["providers"]:
        return "没有这个接口"
    if key_source(pid) == "none":
        return "这个接口还没填 key"
    if not base_url(pid):
        return "这个接口还没填地址"
    if not str(data["providers"][pid].get("main") or "").strip():
        return "这个接口还没选模型"
    data["active"] = pid
    save_providers(data)
    return ""


def key_file(pid: str | None = None) -> Path:
    pid = pid or active_id()
    return KEY_FILE if pid == DEFAULT_PROVIDER else KEYS_DIR / f"{pid}.dpapi"


def _migrate_plain():
    """旧版本把 key 明文存在 ~/.terminist/api_key：加密存一份，再删掉明文。"""
    try:
        key = _PLAIN_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return
    if key and not KEY_FILE.exists():
        set_api_key(key, DEFAULT_PROVIDER)
    _PLAIN_FILE.unlink(missing_ok=True)


def get_api_key(pid: str | None = None) -> str:
    """当前（或指定）接口的 key。DeepSeek：环境变量 DEEPSEEK_API_KEY 优先，其次是设置里填过的（加密存储）。"""
    pid = pid or active_id()
    if pid == DEFAULT_PROVIDER:
        env = os.environ.get(ENV_KEY, "").strip()
        if env:
            return env
        _migrate_plain()
    try:
        key = _unseal(key_file(pid).read_bytes()).strip()
        if key:
            return key
    except (OSError, UnicodeDecodeError):
        pass
    name = provider(pid).get("name") or pid
    raise NotImplementedError(f"还没有 {name} 的 API key：到顶栏「隐私」里填一个"
                              + ("（或者设环境变量 DEEPSEEK_API_KEY）" if pid == DEFAULT_PROVIDER else ""))


def set_api_key(key: str, pid: str | None = None):
    """加密保存新 key；传空字符串 = 删掉这个接口已保存的 key。"""
    key = (key or "").strip()
    f = key_file(pid)
    if not key:
        f.unlink(missing_ok=True)
        return
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_bytes(_seal(key))
    if sys.platform != "win32":
        os.chmod(tmp, 0o600)
    tmp.replace(f)


def key_source(pid: str | None = None) -> str:
    """这个接口的 key 从哪来：env（环境变量，只有 DeepSeek）/ custom（设置里填的，加密存储）/ none。"""
    pid = pid or active_id()
    if pid == DEFAULT_PROVIDER:
        if os.environ.get(ENV_KEY, "").strip():
            return "env"
        _migrate_plain()
    return "custom" if key_file(pid).exists() else "none"


def mask_key(key: str) -> str:
    """界面上只显示前 3 位和后 4 位。"""
    key = (key or "").strip()
    return f"{key[:3]}…{key[-4:]}" if len(key) > 10 else ("已填写" if key else "未填写")


_redact_cache: tuple = (None, ())


def _all_keys() -> list[str]:
    out = []
    for pid in load_providers()["providers"]:
        try:
            out.append(get_api_key(pid))
        except NotImplementedError:
            pass
    return out


def redact(text: str) -> str:
    """把文字里出现的任何一个已保存的 API key 换成打码的样子（工具输出、日志、记忆都过一遍，key 不会被模型看到或写进文件）。"""
    global _redact_cache
    if not text:
        return text
    try:
        files = [KEY_FILE] + (sorted(KEYS_DIR.glob("*.dpapi")) if KEYS_DIR.exists() else [])
        stamp = (os.environ.get(ENV_KEY, ""), tuple((str(f), f.stat().st_mtime_ns) for f in files if f.exists()))
        if _redact_cache[0] != stamp:            # 日志每条都要过一遍：key 没换就不重复解密
            _redact_cache = (stamp, tuple(k for k in _all_keys() if len(k) > 10))
        for key in _redact_cache[1]:
            if key in text:
                text = text.replace(key, mask_key(key) + "(已隐藏)")
    except OSError:
        pass
    return text


BASE_URL = base_url() or PRESETS["deepseek"]["base_url"]   # 启动时定下来：换接口会重启


# ============================================================
# 硬限制：这个文件受保护，B库改不了。到了上限就自动停下，不会一直跑。
# ============================================================
LIMITS = {
    # 每轮最长运行多少秒
    "turn_seconds": {"lead": 1800, "worker": 1800, "solo": 1800, "builder": 1800},
    "max_dispatch": 2,          # 组长每轮最多派几次工（第一次 + 一次返工）
    "b_attempts": 2,            # B库 每个改造需求最多做几次（第一次 + 一次重做）
    "b_compile_fixes": 1,       # 编译出错时最多让 B库 修几轮
    "b_rescue": 1,              # 都没通过时 A库 翻日志诊断，能修的话再救几次
}
