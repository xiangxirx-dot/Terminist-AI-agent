"""
记忆库进程：单独一个进程（不占 Agent 进程），用本地小模型（Ollama 上的 qwen2.5:3b，不花 API 的钱）慢慢消化记忆。

- 缓存带：新记忆（对话概要、歌词原文、资料）先写进 inbox 表（base/graphrag.py 的 keep_text），不等打分；
  这个进程每隔几秒取一批，打完重要性分再正式收进记忆库（passages 表）。还在缓存带里的照样检索得到。
- 打分：本地模型打 0~10 分；规则类（主人定的规矩、约定、偏好、「以后都要 / 不要……」）一律 10 分并钉住，永不遗忘；
  提到名字 / 生日 / 宠物 / 「记住」的不低于 8 分。
- 遗忘曲线：半衰期由重要性决定（0 分 3 天、5 分约一个月、9 分约 7 个月、10 分永不遗忘），
  每被检索出来用一次就像复习一遍：强度回满，半衰期再翻倍（base/graphrag.py 的 half_life_days / retention）。
- 整理（每 6 小时，启动时先一次）：强度 < 5% 且重要性 ≤ 4 的删掉；强度 < 25% 的相近记忆合成一条更模糊的概要。
- 生命周期：Agent 进程起它（start），它盯着 Agent 进程，Agent 进程没了它就退出；同一时间只有一个（锁文件）。
  Ollama 没开 / 模型没装：记忆留在缓存带里（照样查得到），等它开了再消化。代码地图（code_map）不参与遗忘。

单独运行：python -m lib_a.memory_keeper <父进程 pid> <记忆目录>
"""

import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

OLLAMA = "http://127.0.0.1:11434"
MODEL = "qwen2.5:3b"
SCORE_BATCH = 10
TICK = 5                        # 秒：多久看一次缓存带
MAINTAIN_EVERY = 6 * 3600       # 秒：多久整理一次（删 / 合并）
FORGET_BELOW = 0.05             # 强度低于这个、重要性又不高（≤ FORGET_MAX_IMPORTANCE）的删掉
FORGET_MAX_IMPORTANCE = 4
MERGE_BELOW = 0.25              # 强度低于这个的相近记忆合成一条
MERGE_SIMILAR = 0.25            # 字面相似度（二元组 Jaccard）到这个算「相近」

SCORE_PROMPT = """你是记忆管理员，给每条记忆打「以后还用得上」的分（0-10），并判断它是不是「规则」。
规则 = 主人定的规矩、约定、要求、偏好、「以后都要 / 不要 / 每次都……」这类长期有效的话 —— 规则一律 10 分。
其它的按这个标准：
9-10：主人的个人信息（家人、宠物、名字、生日）、明确要求记住的事、截止日期
6-8：主人感兴趣的知识（梗、歌词、资料）、做过的重要决定
3-5：一般的工作记录，可能还会提到
0-2：一次性的测试、简单问答、寒暄闲聊
只输出 JSON：{"scores":[{"i":编号,"s":分数,"rule":true或false}]}"""

MERGE_PROMPT = """下面几条记忆说的是相近的事，而且都快记不清了。把它们合成一条更模糊的中文概要（一两句话）：
保留人名、物名、文件名、功能名、数字这些关键词，丢掉细节。只输出 JSON：{"text":"合成后的一条"}"""

# 规则类：一律 10 分、钉住（永不遗忘）
_RULE = re.compile(r"规矩|规则|规定|约定|守则|偏好|以后都|以后每次|以后不要|以后别|每次都|每次要|"
                   r"必须|强制|一定要|不许|不准|禁止|不要再|别再|不要用|别用|少用|多用|一律|务必|千万别忘")
# 个人信息：不低于 8 分（本地小模型偶尔会把「主人的猫叫什么」这种打低）
_FLOOR = re.compile(r"叫|名字|生日|喜欢|讨厌|住在|家人|老婆|女朋友|男朋友|宠物|猫|狗|记住|别忘|截止|deadline")


# ---------------- 本地模型 ----------------
def _ollama(system: str, user: str, timeout: float = 120) -> dict | None:
    """调本地模型，要 JSON。连不上 / 出错返回 None。keep_alive 5 分钟：闲下来就把显存让出来。"""
    body = json.dumps({"model": MODEL, "stream": False, "format": "json", "keep_alive": "5m",
                       "options": {"temperature": 0},
                       "messages": [{"role": "system", "content": system},
                                    {"role": "user", "content": user}]}).encode("utf-8")
    try:
        req = urllib.request.Request(f"{OLLAMA}/api/chat", body, {"Content-Type": "application/json"})
        data = json.loads(urllib.request.urlopen(req, timeout=timeout).read())
        return json.loads(data["message"]["content"])
    except Exception:
        return None


def available() -> bool:
    """Ollama 开着、而且装了这个模型。"""
    try:
        tags = json.loads(urllib.request.urlopen(f"{OLLAMA}/api/tags", timeout=3).read())
        return any(m.get("name", "").startswith(MODEL) for m in tags.get("models") or [])
    except Exception:
        return False


def judge(text: str, score: float, rule: bool = False) -> tuple[float, bool]:
    """最终的重要性和是否钉住：规则类（模型判的或者字面上看得出来的）一律 10 分钉住；个人信息不低于 8 分。"""
    if rule or _RULE.search(text):
        return 10.0, True
    if _FLOOR.search(text) and not text.strip().endswith("闲聊"):
        return max(score, 8.0), False
    return score, False


def _score(texts: list[str]) -> list[tuple[float, bool]] | None:
    data = _ollama(SCORE_PROMPT, "\n".join(f"{i + 1}. {t[:300]}" for i, t in enumerate(texts)))
    if data is None:
        return None
    got = {}
    for x in data.get("scores") or []:
        try:
            got[int(x.get("i", 0)) - 1] = (float(x.get("s", 5)), bool(x.get("rule")))
        except (TypeError, ValueError):
            continue
    return [judge(t, *got.get(i, (5.0, False))) for i, t in enumerate(texts)]


# ---------------- 消化 / 打分 / 整理 ----------------
def digest_inbox(g, limit: int = SCORE_BATCH) -> int:
    """从缓存带取一批：打分后正式收进记忆库。本地模型不在就原样留着。返回消化了几条。"""
    rows = g.inbox_batch(limit)
    if not rows:
        return 0
    res = _score([r["text"] for r in rows])
    if res is None:
        return 0
    for r, (s, pin) in zip(rows, res):
        g.digest(r, s, pin)
    return len(rows)


def score_pending(g, limit: int = SCORE_BATCH) -> int:
    """记忆库里以前没打过分的（缓存带出现之前存进来的）补打。"""
    rows = g.unscored(limit)
    if not rows:
        return 0
    res = _score([r["text"] for r in rows])
    if res is None:
        return 0
    for r, (s, pin) in zip(rows, res):
        g.set_importance(r["id"], s, pin)
    return len(rows)


def _similar(g, a: str, b: str) -> float:
    x, y = set(g._grams2(a)), set(g._grams2(b))
    return len(x & y) / max(1, len(x | y))


def maintain(g, now: float | None = None) -> dict:
    """按遗忘曲线整理一遍：彻底淡掉的删掉，快淡掉的相近记忆合成一条。返回 {forgot, merged}。"""
    now = now or time.time()
    forget, fading = [], []
    for r in g.memory_rows():
        ret = g.retention(r, now)
        if ret < FORGET_BELOW and r["importance"] <= FORGET_MAX_IMPORTANCE:
            forget.append(r["id"])
        elif ret < MERGE_BELOW:
            fading.append(r)
    g.forget_passages(forget)
    merged, used = 0, set()
    for i, r in enumerate(fading):                # 同一来源、字面相近的凑成一组（贪心）
        if r["id"] in used:
            continue
        group = [r] + [o for o in fading[i + 1:] if o["id"] not in used and o["source"] == r["source"]
                       and _similar(g, r["text"], o["text"]) >= MERGE_SIMILAR]
        if len(group) < 2:
            continue
        data = _ollama(MERGE_PROMPT, "\n".join(f"- {o['text'][:300]}" for o in group[:8]))
        if not data or not str(data.get("text") or "").strip():
            continue
        g.merge_memories(group[:8], data["text"])
        used.update(o["id"] for o in group[:8])
        merged += len(group[:8])
    return {"forgot": len(forget), "merged": merged}


# ---------------- 进程 ----------------
def _alive(pid: int) -> bool:
    """进程还在不在（Windows 上不能用 os.kill(pid, 0)：那是发 Ctrl+C）。"""
    if pid <= 0:
        return False
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)      # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    ok = ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
    ctypes.windll.kernel32.CloseHandle(h)
    return bool(ok) and code.value == 259                           # STILL_ACTIVE


def _lock_path(memory_dir: Path) -> Path:
    return Path(memory_dir) / "graph" / "memory_keeper.pid"


def _take_lock(memory_dir: Path, wait: float = 180) -> bool:
    """同一时间只有一个记忆库进程。重启时旧的还没退：等它退（它的父进程没了它就会退）。"""
    p = _lock_path(memory_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.time() + wait
    while time.time() < deadline:
        try:
            other = int(p.read_text(encoding="utf-8").strip() or 0)
        except (OSError, ValueError):
            other = 0
        if other and other != os.getpid() and _alive(other):
            time.sleep(3)
            continue
        p.write_text(str(os.getpid()), encoding="utf-8")
        return True
    return False


def _log(msg: str):
    try:
        from lib_b import worklog
        worklog.write("记忆库", "info", msg)
    except Exception:
        pass


def run(parent: int, memory_dir: str):
    """记忆库进程的主循环。父进程（Agent 进程）没了就退出。"""
    import lib_a
    lib_a.core.MEMORY_DIR = lib_a.MEMORY_DIR = Path(memory_dir)
    if not _take_lock(Path(memory_dir)):
        return
    from base.graphrag import Graph, shared_path
    g = Graph(shared_path())
    _log(f"记忆库进程起来了（pid {os.getpid()}，本地模型 {MODEL}）")
    last_maintain = 0.0
    while _alive(parent):
        try:
            if available():
                n = digest_inbox(g) or score_pending(g)
                if not n and time.time() - last_maintain > MAINTAIN_EVERY:
                    res = maintain(g)
                    last_maintain = time.time()
                    if res["forgot"] or res["merged"]:
                        _log(f"记忆整理：淡忘 {res['forgot']} 条，合并 {res['merged']} 条")
                if n:
                    continue                      # 缓存带还有：马上接着消化
        except Exception as e:
            _log(f"记忆库出错（继续跑）：{type(e).__name__}: {e}")
        time.sleep(TICK)
    try:
        if int(_lock_path(Path(memory_dir)).read_text(encoding="utf-8").strip() or 0) == os.getpid():
            _lock_path(Path(memory_dir)).unlink()
    except (OSError, ValueError):
        pass


_started = False
_lock = threading.Lock()


def start(agent=None, emit=None):
    """Agent 进程里调一次：单独起记忆库进程（不弹窗口），它盯着这个进程，这边没了它就退出。"""
    global _started
    with _lock:
        if _started:
            return
        _started = True
    import lib_a
    app_root = Path(__file__).resolve().parent.parent
    log = Path.home() / ".terminist" / "logs" / "memory_keeper.log"
    try:
        log.parent.mkdir(parents=True, exist_ok=True)
        flags = 0x08000000 if sys.platform == "win32" else 0           # CREATE_NO_WINDOW
        subprocess.Popen([sys.executable, "-m", "lib_a.memory_keeper", str(os.getpid()), str(lib_a.MEMORY_DIR)],
                         cwd=str(app_root), stdout=open(log, "a", encoding="utf-8"), stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, creationflags=flags)
    except Exception as e:
        if emit:
            emit("error", f"[记忆库进程没起来：{type(e).__name__}: {e}；新记忆先留在缓存带里]")


if __name__ == "__main__":
    run(int(sys.argv[1]), sys.argv[2])
