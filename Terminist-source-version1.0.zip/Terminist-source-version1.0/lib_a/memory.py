"""
分层记忆库 + 混合检索。

记忆按工作区分目录，分热/温/冷三层；检索按需召回，不整段塞上下文。
目录结构（memory/ 下）：
  index.json        总索引：{workspace_hash: {"root": ..., "updated": ...}}
  ws/<hash>/        每个工作区一份
    session.json    热层：最近对话（完整 messages 列表）
    facts.jsonl     温层：结构化事实，每行一条 JSON
    summary.md      冷层：长期摘要

检索：混合打分 = 关键词命中 + 重要性 + 时间衰减，取 top-k。
"""

import hashlib
import json
import re
import time
from pathlib import Path

MEMORY_ROOT = Path(__file__).resolve().parent.parent / "memory"


def _hash(text: str) -> str:
    return hashlib.sha1(str(text).lower().encode("utf-8")).hexdigest()[:16]


def workspace_dir(root) -> Path:
    """某个工作区（root 是 Path 或 None）的记忆目录。None 表示只聊天。"""
    key = _hash(str(root) if root is not None else "__chat__")
    return MEMORY_ROOT / "ws" / key


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _tokenize(text: str) -> list[str]:
    """中文按单字+相邻双字切，英文/数字按空白和标点切，用于关键词打分。"""
    text = text.lower()
    ascii_words = re.findall(r"[a-z0-9_]+", text)
    cjk = re.findall(r"[\u4e00-\u9fff]", text)
    bigrams = ["".join(cjk[i:i + 2]) for i in range(len(cjk) - 1)]
    return ascii_words + cjk + bigrams


def _score(fact: dict, query: str, now: float) -> float:
    """给一条事实打分：关键词命中 + 重要性 + 时间衰减。"""
    q = set(_tokenize(query))
    if not q:
        return 0.0
    body = (fact.get("text") or "") + " " + " ".join(fact.get("tags") or [])
    toks = _tokenize(body)
    hit = sum(1 for t in toks if t in q)
    importance = float(fact.get("importance") or 0.5)
    age_days = max(0.0, (now - float(fact.get("ts") or now)) / 86400.0)
    decay = 0.5 ** (age_days / 30.0)          # 30 天衰减一半
    hits_bonus = min(1.0, float(fact.get("hits") or 0) * 0.1)
    return hit * (0.5 + importance) * decay + hits_bonus


class MemoryStore:
    """一个工作区的记忆：会话、事实、摘要。"""

    def __init__(self, root=None):
        self.root = Path(root) if root is not None else None
        self.dir = workspace_dir(root)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.session_path = self.dir / "session.json"
        self.facts_path = self.dir / "facts.jsonl"
        self.summary_path = self.dir / "summary.md"

    def save_session(self, messages: list):
        tmp = self.session_path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"messages": messages}, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.session_path)

    def load_session(self) -> list:
        data = _load_json(self.session_path, {})
        return list(data.get("messages") or [])

    def facts(self) -> list[dict]:
        out = []
        try:
            for line in self.facts_path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        except OSError:
            pass
        return out

    def add_fact(self, text: str, type_: str = "fact", tags: list | None = None,
                 importance: float = 0.5):
        """记一条事实/偏好/经验，返回条目。"""
        fact = {"id": _hash(text + str(time.time())), "type": type_, "text": text,
                "tags": list(tags or []), "ts": time.time(), "importance": importance,
                "hits": 0}
        with self.facts_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(fact, ensure_ascii=False) + "\n")
        return fact

    def recall(self, query: str, k: int = 5) -> list[str]:
        """混合检索最相关的 k 条事实，返回文本列表（按相关度从高到低）。只读，不写文件。"""
        now = time.time()
        scored = sorted(self.facts(), key=lambda f: _score(f, query, now), reverse=True)
        return [f["text"] for f in scored[:k] if _score(f, query, now) > 0]

    def set_summary(self, text: str):
        self.summary_path.write_text(text, encoding="utf-8")

    def summary(self) -> str:
        try:
            return self.summary_path.read_text(encoding="utf-8")
        except OSError:
            return ""
