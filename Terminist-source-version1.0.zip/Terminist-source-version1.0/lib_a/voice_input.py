"""
语音输入：本地录音 + faster-whisper 转文字（给主界面输入框用）。

- VoiceRecorder：开始 / 停止一段录音，落到临时 wav（16kHz 单声道）；
- transcribe_wav(path)：用本地 faster-whisper 把 wav 转成纯文字（不带时间戳）；
  transcribe_wav 会按停顿断句，返回多行文本；
- 所有对外失败统一抛 VoiceError，界面上只提示、不崩。
"""

import threading
import time
import tempfile
import wave
from pathlib import Path

SAMPLE_RATE = 16000
CHANNELS = 1


class VoiceError(Exception):
    """语音输入相关的可预期错误（界面上提示一下就行）。"""


class VoiceRecorder:
    """一段式录音器：start 开始，stop 落盘返回 wav 路径。"""

    def __init__(self):
        self._stream = None
        self._frames = []
        self._recording = False
        self._path = None
        self._lock = threading.Lock()

    @property
    def is_recording(self):
        return bool(self._recording)

    def start(self):
        """开始录音，成功返回 True；失败抛 VoiceError。"""
        if self._recording:
            self.cancel()
        try:
            import sounddevice as sd
        except Exception:
            raise VoiceError("没有安装 sounddevice：pip install sounddevice")

        def cb(indata, frames, t, status):
            self._frames.append(bytes(indata))

        try:
            self._frames = []
            self._stream = sd.RawInputStream(
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype='int16',
                callback=cb,
            )
            self._stream.start()
        except VoiceError:
            raise
        except Exception as e:
            raise VoiceError(f"打不开麦克风：{type(e).__name__}: {e}")
        self._recording = True
        return True

    def stop(self):
        """停止录音并把音频写到临时 wav，返回路径；没在录返回 None。"""
        if not self._recording:
            return None
        try:
            if self._stream is not None:
                self._stream.stop()
        except Exception:
            pass
        self._recording = False
        frames = self._frames
        self._frames = []
        p = Path(tempfile.gettempdir()) / f"terminist_voice_{int(time.time())}.wav"
        try:
            wf = wave.open(str(p), 'wb')
            try:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(2)
                wf.setframerate(SAMPLE_RATE)
                wf.writeframes(b''.join(frames))
            finally:
                wf.close()
        except VoiceError:
            raise
        except Exception as e:
            raise VoiceError(f"保存录音失败：{type(e).__name__}: {e}")
        self._path = p
        return str(p)

    def cancel(self):
        """放弃这次录音，不抛异常。"""
        try:
            if self._stream is not None:
                self._stream.stop()
        except Exception:
            pass
        self._recording = False
        self._frames = []


_model = None
_lock = threading.Lock()


def _load():
    """加载（并缓存）本地 faster-whisper 模型。"""
    global _model
    if _model is not None:
        return _model
    model_name = "large-v3-turbo"
    model_dir = Path.home() / ".terminist" / "models" / "whisper"
    try:
        from base import config
        model_name = getattr(config, "WHISPER_MODEL", model_name) or model_name
        model_dir = Path(getattr(config, "WHISPER_DIR", model_dir) or model_dir)
    except Exception:
        pass
    try:
        from faster_whisper import WhisperModel
    except Exception:
        raise VoiceError("没有安装 faster-whisper：pip install faster-whisper")
    try:
        model_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    last = None
    for device, compute_type in (("cuda", "float16"), ("cpu", "int8")):
        try:
            _model = WhisperModel(
                model_name,
                device=device,
                compute_type=compute_type,
                download_root=str(model_dir),
            )
            return _model
        except Exception as e:
            last = e
    raise VoiceError(f"Whisper 加载失败：{last}")


SILENCE_GAP = 0.45   # 两个 segment 之间的静音超过这么多秒算一次停顿（换句）
LONG_SEG = 28        # 单句超过这么多字，在句中第一个标点处再切一刀
CLAUSE_MARKS = "，,、；;"
SENT_END = "。！？!?…"


def _end_piece(text) -> str:
    """给一句话收尾：去首尾空白和尾巴上的逗号顿号分号，缺句末标点就补「。」。"""
    t = str(text or "").strip()
    if not t:
        return ""
    t = t.rstrip("，,、；;").strip()
    if not t:
        return ""
    if t[-1] in SENT_END:
        return t
    return t + "。"


def _split_long(text) -> list[str]:
    """把过长的一句在长度 1/3~2/3 之间的第一个句中标点处切一刀，返回列表。"""
    t = str(text or "").strip()
    if not t:
        return []
    if len(t) <= LONG_SEG:
        return [t]
    lo = max(1, len(t) // 3)
    hi = max(lo, (len(t) * 2) // 3)
    best = -1
    for i in range(lo, min(hi + 1, len(t) - 1)):
        if t[i] in CLAUSE_MARKS:
            best = i
            break
    if best < 0:
        return [t]
    return [t[:best], t[best + 1:]]


def split_sentences(segments) -> list[str]:
    """把 whisper 的 segment 序列按停顿切成一句一句，返回带句末标点的多行列表。"""
    lines = []
    buf = ""
    last_end = None
    for seg in segments:
        text = str(getattr(seg, "text", "") or "").strip()
        if not text:
            continue
        try:
            start = float(getattr(seg, "start", 0) or 0)
        except (TypeError, ValueError):
            start = 0.0
        try:
            end = float(getattr(seg, "end", start) or start)
        except (TypeError, ValueError):
            end = start
        # 和上一段之间停顿够长，先把攒着的句子收掉
        if last_end is not None and buf and start - last_end >= SILENCE_GAP:
            lines.append(_end_piece(buf))
            buf = ""
        last_end = end
        buf += text  # 中文之间不加空格，保持紧凑
        # 这段本身已经带着句末标点，直接收一句
        if buf[-1] in SENT_END:
            lines.append(_end_piece(buf))
            buf = ""
            continue
        # 太长就在句中标点处切一刀，前面的收句，尾巴继续攒
        if len(buf) > LONG_SEG:
            pieces = _split_long(buf)
            for piece in pieces[:-1]:
                lines.append(_end_piece(piece))
            buf = pieces[-1] if pieces else ""
    if buf:
        lines.append(_end_piece(buf))
    return [x for x in lines if x]


def transcribe_wav(path) -> str:
    """把 wav 转成纯文字（中文，带 VAD），按停顿断句、一句一行。"""
    p = Path(path)
    if not p.exists():
        raise VoiceError(f"录音文件不见了：{path}")
    try:
        with _lock:
            model = _load()
            segments, info = model.transcribe(
                str(p), language='zh', vad_filter=True, beam_size=5
            )
            lines = split_sentences(segments)
    except VoiceError:
        raise
    except Exception as e:
        raise VoiceError(f"识别失败：{type(e).__name__}: {e}")
    return "\n".join(lines).strip()
