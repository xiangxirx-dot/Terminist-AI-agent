"""
旧「目标文件」接口的兼容层：现在任务都在任务队列里（lib_a/taskq.py，memory/taskq.json）。

以前目标写在自由文本「散兵-目标.txt」里，按行号增删挪，越改越乱（详见 taskq.py 开头）。
这里保留旧函数名，内部全部转到任务队列，B库 以前写的、还在调这些函数的代码照样能用。ws 参数不再起作用（全程序一份队列）。
"""

from pathlib import Path

from . import taskq

GOAL_NAME = "散兵-目标.txt"
APP_ROOT = Path(__file__).resolve().parent.parent


def path(ws=None) -> Path:
    """旧接口：现在返回任务队列文件的位置。"""
    return taskq.store_path()


def read(ws=None) -> str:
    return taskq.list_text()


def status(ws=None) -> str:
    return taskq.list_text()


def queue(ws=None) -> list[dict]:
    """[{"i": 序号, "id": 编号, "text": 标题, "status": 状态}]，i 从 0 起。"""
    return [{"i": n, "id": t["id"], "text": t["title"], "status": t["status"]}
            for n, t in enumerate(taskq.open_tasks())]


def remaining(ws=None) -> tuple[list[str], int, int]:
    data = taskq.load()
    todo = [t["title"] for t in data["tasks"]]
    done = sum(1 for t in data["history"] if t["status"] == "done")
    return todo, done, len(todo) + done


def _id(i) -> str:
    tasks = taskq.open_tasks()
    i = int(i)
    if not 0 <= i < len(tasks):
        raise ValueError(f"队列里没有第 {i + 1} 项")
    return tasks[i]["id"]


def tick(ws=None, text: str = "") -> str:
    """把一项标成完成：给了 text 按包含匹配，否则完成正在做的那项（没有就第一项）。"""
    tasks = taskq.open_tasks()
    hit = next((t for t in tasks if text and text in t["title"]), None) if text else None
    hit = hit or next((t for t in tasks if t["status"] == "active"), None) or (tasks[0] if tasks else None)
    if hit is None:
        return "任务队列是空的"
    return taskq.done(hit["id"])


def add(ws=None, text: str = "", before=None) -> str:
    pos = "bottom" if before is None else str(int(before) + 1)
    return taskq.add(text, position=pos, by="user")


def move(ws=None, i: int = 0, to: int = 0) -> str:
    return taskq.move(_id(i), str(int(to) + 1), by="user")


def up(ws=None, i: int = 0) -> str:
    return taskq.move(_id(i), "up", by="user")


def down(ws=None, i: int = 0) -> str:
    return taskq.move(_id(i), "down", by="user")


def remove(ws=None, i: int = 0) -> str:
    return taskq.drop(_id(i), "主人删掉的", by="user")


def edit(ws=None, i: int = 0, text: str = "") -> str:
    return taskq.edit(_id(i), title=text, by="user")
