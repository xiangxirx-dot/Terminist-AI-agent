"""
知识库（graph_ingest / 向量库）的进库边界：只放「未来有概率被检索到的知识」，事务性内容一律不进库。

- 知识性内容：概念、事实、约定、代码结构、用户长期偏好、查证过的资料；
- 事务性内容：进度、任务过程、跑腿流水、工作流日志、当轮待办、一次性操作记录、「我刚干了什么」这类。
- 判断标准一句话：这句话以后会不会被当参考检索出来？会才写。

这里做的是代码级兜底，不靠模型自觉：
- ingest_guard(text)：写库前先做一次轻量判定，明显是事务性的输入直接拒绝并返回说明，
  让模型改用 worker_progress / task_queue 或者直接回复主人；只做保守拦截（宁可漏拦不要错杀）。
- install()：base 是受保护的中心库，所以运行时把 base.attach 包一层，attach 之后
  把 agent.custom_tools["graph_ingest"] 的工具描述换成带边界的版本，并给写库入口套上 ingest_guard。
- 检索侧：每轮按主人的话本地自动查一次（原文模糊匹配 + 图里的实体事实），命中的附在主人消息后面，不把整库塞进去。
"""

# 事务性特征词：命中且没有知识性特征时才拒绝（保守拦截）
TRANSACTION_HINTS = ("进度", "已完成", "正在", "刚刚", "刚才", "跑完", "第", "步", "日志",
                     "待办", "已提交", "已上传", "进行中", "本轮", "这一轮")
# 知识性特征词：有这些就优先放行，不误杀
KNOWLEDGE_HINTS = ("歌词", "台词", "原文", "原话", "定义", "原理", "约定", "规则", "配置", "结构", "用法", "原因", "是……的",
                   "表示", "指的是", "应该", "不能", "必须", "放在", "位于")

# 工具描述（模型看得到的地方，写同一句边界）
INGEST_DESC = ("把知识写进知识库（向量库）：自动抽实体和关系，同一事物的不同写法归到一起，互相矛盾的说法会标出来。"
               "只存「未来有概率被检索到的知识性内容」（概念、事实、约定、代码结构、资料、用户长期偏好）。"
               "事务性内容一律不写：进度、任务过程、跑腿流水、工作流日志、当轮待办、一次性操作记录。"
               "判断标准：这句话以后会不会被当参考检索出来？会才写。")

_installed = False


def ingest_guard(text: str) -> str:
    """进库边界：只放「未来有概率被检索到的知识」；进度/流水/日志这类事务性内容一律拒绝写库。返回空串=放行，否则返回拒绝说明。"""
    t = (text or "").strip()
    if not t:
        return "错误：没有内容可写。"
    if any(k in t for k in KNOWLEDGE_HINTS):
        return ""                      # 有知识性特征：优先放行，不误杀
    if any(k in t for k in TRANSACTION_HINTS):
        return ("错误：这条像进度/流水这类事务性内容，不进知识库。"
                "知识库只存「未来有概率被检索到的知识」（概念、事实、约定、代码结构、长期偏好）；"
                "进度用 task_queue done 标完成，结论直接回复主人。")
    return ""


def describe_tools(agent) -> None:
    """attach 之后调：换掉 graph_ingest 的工具描述，并给它套上进库边界。"""
    try:
        entry = agent.custom_tools.get("graph_ingest")
    except Exception:
        return
    if not entry:
        return
    schema, run = entry[0], entry[1]
    if isinstance(schema, dict):
        try:
            schema["function"]["description"] = INGEST_DESC
        except Exception:
            pass
    if getattr(run, "_ingest_guarded", False):
        return
    def guarded(args):
        a = args or {}
        if not str(a.get("path") or ""):        # 给了 path 的内容交给原来的逻辑读文件，这里不误杀
            msg = ingest_guard(str(a.get("text") or ""))
            if msg:
                return msg
        return run(args)
    guarded._ingest_guarded = True
    try:
        agent.custom_tools["graph_ingest"] = (schema, guarded)
    except Exception:
        pass


def install() -> None:
    """把 base.attach 包一层：每次 attach 完顺手装上进库边界（重复调用没副作用）。"""
    global _installed
    if _installed:
        return
    _installed = True
    try:
        import base as _base
    except Exception:
        return
    orig = getattr(_base, "attach", None)
    if not callable(orig):
        return
    def attach(agent):
        out = orig(agent)
        describe_tools(agent)
        return out
    _base.attach = attach
