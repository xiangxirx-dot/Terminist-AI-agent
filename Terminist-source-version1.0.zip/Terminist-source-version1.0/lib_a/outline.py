"""
大文件提纲：不带行号整个读大文件时，不把开头几百行 / 几万字塞给模型（多半不是要改的地方，还会一直留在对话里被反复重发），
改成返回提纲——每个函数 / 类一行（行号 + docstring 第一行），让模型按行号只读要改的那几段。
"""

import ast
from pathlib import Path

BIG_LINES = 300            # 超过这么多行算大文件：不带行号整个读时返回提纲
COMPACT_OVER = 250         # 函数多于这么多个：只列名字和行号，不带说明（不然提纲本身就太长）


def is_big(lines: list) -> bool:
    return len(lines) > BIG_LINES


def outline(p: Path, rel: str, lines: list | None = None) -> str:
    """文件提纲（.py 按函数 / 类；别的文件给开头一段和行数）。"""
    text = Path(p).read_text(encoding="utf-8", errors="replace")
    lines = lines if lines is not None else text.splitlines()
    head = (f"{rel} 有 {len(lines)} 行，太大，不整个返回（整段塞进对话会一直被重发，很费钱）。"
            f"下面是提纲：按行号用 read_lines(path, start, end) 只读要改的那几段；找功能可以先用 code_map 查。\n")
    if Path(p).suffix.lower() != ".py":
        body = "\n".join(f"{i:>5}| {l}" for i, l in enumerate(lines[:60], 1))
        return head + f"（不是 Python 文件，没有函数提纲；这是开头 60 行）\n{body}"
    try:
        tree = ast.parse(text)
    except SyntaxError as e:
        return head + f"（解析不了：{e}；直接按行号读）"
    rows: list[tuple[str, str]] = []

    def add(node, name, kind, indent=""):
        doc = (ast.get_docstring(node) or "").strip().splitlines()
        end = getattr(node, "end_lineno", node.lineno)
        rows.append((f"{indent}{node.lineno}-{end} {kind} {name}", doc[0][:90] if doc else ""))

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            add(node, node.name, "def")
        elif isinstance(node, ast.ClassDef):
            add(node, node.name, "class")
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    add(sub, f"{node.name}.{sub.name}", "def", "  ")
        elif isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
            if names and names[0].isupper():          # 模块级常量（大写）也列上：经常要改它们
                rows.append((f"{node.lineno} const {', '.join(names)}", ""))
    compact = len(rows) > COMPACT_OVER
    if compact:
        head += f"（{len(rows)} 项，太多，只列名字和行号；某个函数负责什么用 code_map 查）\n"
    return head + "\n".join(r if compact or not d else f"{r} — {d}" for r, d in rows)
