"""
任务队列：手头正在做的活（主人这次交代的几件事、干活中追加的），统一存在一个结构化文件里（memory/taskq.json），谁改都走这里的函数。
它不是愿望清单 / 远期计划：进了队列就是要做的，干活的 Agent 一轮做完会自动接着做下一项，直到队列清空（见 core.Agent._drain_queue）。

为什么不用以前的「散兵-目标.txt」：那是一份自由文本，未完成和已完成混在一起，一条目标常常带好几行缩进说明，
按「第几行」去挪 / 删时只挪了第一行，说明留在原地挂到别的条目下面；序号一变就改错条；Agent 还会直接用文件工具手改；
文件还可能在工作区、Terminist 文件夹、桌面各有一份。所以越改越乱。

这里的规矩：
- 每个任务有固定编号（t1、t2…），改 / 挪 / 删都按编号，不按位置，不会改错
- 标题一行（最多 120 字），其余写进 detail；同样标题的未完成任务不会重复加
- 只放正在做的活：进了队列就会被做掉；远期想法不进队列
- 队列里只放没做完的（pending 待办 / active 正在做 / blocked 卡住了）；做完、放弃的挪进历史，队列永远干净
- 同一时间最多一个 active，而且永远排在最前面
- 前台（旁聊）只能动 pending / blocked 的任务：加、改、排序、删；正在做的那条它碰不了
- 文件在 memory/ 里（受保护，文件工具写不进去），只能通过这里改；界面进程和 Agent 进程都会改，所以加了文件锁、原子写
"""

import json
import os
import re
import threading
import time
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
TITLE_MAX = 120
HISTORY_MAX = 300
STATUS_NAME = {"pending": "待办", "active": "正在做", "blocked": "卡住", "done": "已完成", "dropped": "已放弃"}
_lock = threading.Lock()
_cache: tuple = (None, None)


def store_path() -> Path:
    from . import core
    return Path(core.MEMORY_DIR) / "taskq.json"


# ---------------- 读写（带跨进程文件锁）----------------
class _FileLock:
    def __init__(self, path: Path):
        self.path = path.with_suffix(".lock")

    def __enter__(self):
        deadline = time.time() + 10
        while True:
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode())
                os.close(fd)
                return self
            except FileExistsError:
                try:                                   # 上一个进程拿着锁死掉了：10 秒没动的锁当作作废
                    if time.time() - self.path.stat().st_mtime > 10:
                        self.path.unlink()
                        continue
                except OSError:
                    continue
                if time.time() > deadline:
                    raise TimeoutError("任务队列被占用，稍后再试")
                time.sleep(0.02)

    def __exit__(self, *exc):
        try:
            self.path.unlink()
        except OSError:
            pass


def _empty() -> dict:
    return {"next_id": 1, "tasks": [], "history": [], "updated": time.time()}


def _read(p: Path) -> dict:
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("tasks"), list):
            data.setdefault("history", [])
            data.setdefault("next_id", 1)
            return data
    except (OSError, ValueError):
        pass
    return _empty()


def load() -> dict:
    """读队列（只读，文件没变就用缓存：界面每帧都要读）。"""
    global _cache
    p = store_path()
    try:
        stamp = p.stat().st_mtime_ns
    except OSError:
        return _empty()
    if _cache[0] == stamp:
        return _cache[1]
    data = _read(p)
    _cache = (stamp, data)
    return data


def _mutate(fn):
    """在锁里读 → 改 → 原子写回。fn(data) 返回给调用方的结果文字。"""
    p = store_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with _lock, _FileLock(p):
        data = _read(p)
        out = fn(data)
        data["updated"] = time.time()
        tmp = p.with_suffix(f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, p)
    return out


# ---------------- 工具函数 ----------------
def _split(title: str, detail: str = "") -> tuple[str, str]:
    """标题只要一行：多行 / 太长的部分挪进 detail。"""
    title = str(title or "").strip()
    lines = [l.strip() for l in title.splitlines() if l.strip()]
    head = lines[0] if lines else ""
    rest = "\n".join(lines[1:])
    if len(head) > TITLE_MAX:
        rest = (head[TITLE_MAX:] + ("\n" + rest if rest else "")).strip()
        head = head[:TITLE_MAX]
    detail = "\n".join(x for x in (rest, str(detail or "").strip()) if x)
    return head, detail


def _norm(s: str) -> str:
    return re.sub(r"\s+", "", str(s)).lower()


def _find(data: dict, tid: str):
    tid = str(tid or "").strip().lower()
    if tid.isdigit():
        tid = "t" + tid
    for i, t in enumerate(data["tasks"]):
        if t["id"] == tid:
            return i, t
    return None, None


def _resolve(data: dict, ref) -> tuple:
    """按编号（t3）找；也接受「队列里第 3 条」这种写法（界面 / 斜杠命令用）。"""
    s = str(ref or "").strip().lower()
    i, t = _find(data, s)
    if t is None and s.startswith("#") and s[1:].isdigit():
        n = int(s[1:]) - 1
        if 0 <= n < len(data["tasks"]):
            return n, data["tasks"][n]
    return i, t


def _line(t: dict, n: int | None = None) -> str:
    mark = {"active": "▶ ", "blocked": "⏸ "}.get(t["status"], "")
    why = f"（卡在：{t['blocked_on']}）" if t["status"] == "blocked" and t.get("blocked_on") else ""
    pre = f"{n}. " if n is not None else ""
    return f"{pre}{mark}[{t['id']}] {t['title']}{why}"


def _active_first(data: dict):
    act = [t for t in data["tasks"] if t["status"] == "active"]
    data["tasks"] = act + [t for t in data["tasks"] if t["status"] != "active"]


def _can_touch(t: dict, by: str) -> str:
    if by == "front" and t["status"] == "active":
        return f"[{t['id']}] 正在做，前台不能改它；要改正在做的事请用 workflow_add_plan 转给干活的 Agent"
    return ""


# ---------------- 操作（都返回给模型 / 界面看的文字）----------------
def list_text(history: int = 5) -> str:
    data = load()
    tasks = data["tasks"]
    lines = [f"任务队列（{len(tasks)} 项没做完）："]
    lines += [_line(t, n) for n, t in enumerate(tasks, 1)] or ["（空）"]
    if history and data["history"]:
        lines.append(f"最近完成 / 放弃的（共 {len(data['history'])} 条）：")
        for t in data["history"][-history:][::-1]:
            res = f" → {t['result'][:60]}" if t.get("result") else ""
            lines.append(f"  - [{t['id']}] {STATUS_NAME.get(t['status'], t['status'])}：{t['title']}{res}")
    return "\n".join(lines)


def show(ref) -> str:
    data = load()
    _, t = _resolve(data, ref)
    if t is None:
        t = next((h for h in data["history"] if h["id"] == str(ref).strip().lower()), None)
        if t is None:
            return f"错误: 没有任务 {ref}"
    parts = [_line(t), f"状态：{STATUS_NAME.get(t['status'], t['status'])}，由{t.get('by', '?')}添加"]
    if t.get("detail"):
        parts.append("说明：\n" + t["detail"])
    if t.get("result"):
        parts.append("结果：" + t["result"])
    return "\n".join(parts)


def add(title: str, detail: str = "", position: str = "bottom", by: str = "agent") -> str:
    head, det = _split(title, detail)
    if not head:
        return "错误: 任务标题是空的"

    def fn(data):
        for t in data["tasks"]:                       # 一样的未完成任务不重复加
            if _norm(t["title"]) == _norm(head):
                if det and det not in t.get("detail", ""):
                    t["detail"] = (t.get("detail", "") + "\n" + det).strip()
                    t["updated"] = time.time()
                return f"已有一样的任务 [{t['id']}]，没有重复加" + ("（把新说明补进去了）" if det else "")
        tid = f"t{data['next_id']}"
        data["next_id"] += 1
        now = time.time()
        task = {"id": tid, "title": head, "detail": det, "status": "pending", "by": by,
                "created": now, "updated": now}
        err = _place(data, task, position)
        if err:
            return err
        return f"已加入队列 [{tid}] {head}（第 {data['tasks'].index(task) + 1} 位）"
    return _mutate(fn)


def _place(data: dict, task: dict, position: str) -> str:
    """把 task 放到 position：top / bottom / before:t3 / after:t3 / 数字（第几位）。正在做的那条永远在最前。"""
    pos = str(position or "bottom").strip().lower()
    tasks = data["tasks"]
    if task in tasks:
        tasks.remove(task)
    floor = 1 if tasks and tasks[0]["status"] == "active" and task["status"] != "active" else 0
    if pos in ("top", "first", "顶", "最前"):
        idx = floor
    elif pos in ("bottom", "last", "end", "底", "最后", ""):
        idx = len(tasks)
    elif pos.startswith(("before:", "after:")):
        kind, _, ref = pos.partition(":")
        i, other = _find(data, ref)
        if other is None:
            tasks.insert(len(tasks), task)
            return f"错误: 没有任务 {ref}"
        idx = i + (1 if kind == "after" else 0)
    elif pos.lstrip("#").isdigit():
        idx = int(pos.lstrip("#")) - 1
    else:
        tasks.append(task)
        return f"错误: 位置看不懂：{position}（可以写 top / bottom / up / down / before:t3 / after:t3 / 数字）"
    tasks.insert(max(floor, min(idx, len(tasks))), task)
    _active_first(data)
    return ""


def edit(ref, title: str | None = None, detail: str | None = None, by: str = "agent") -> str:
    def fn(data):
        _, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        if err := _can_touch(t, by):
            return "错误: " + err
        if title is not None and str(title).strip():
            head, extra = _split(title)
            t["title"] = head
            if extra:
                t["detail"] = (extra + "\n" + t.get("detail", "")).strip()
        if detail is not None:
            t["detail"] = str(detail).strip()
        t["updated"] = time.time()
        return f"已修改 {_line(t)}"
    return _mutate(fn)


def move(ref, position: str, by: str = "agent") -> str:
    def fn(data):
        i, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        if err := _can_touch(t, by):
            return "错误: " + err
        if t["status"] == "active":
            return f"[{t['id']}] 正在做，固定在最前面"
        pos = str(position or "").strip().lower()
        if pos in ("up", "上移"):
            pos = str(max(1, i))                         # 第 i+1 位 → 第 i 位
        elif pos in ("down", "下移"):
            pos = str(i + 2)
        err = _place(data, t, pos)
        if err:
            return err
        return f"已把 [{t['id']}] 挪到第 {data['tasks'].index(t) + 1} 位\n" + "\n".join(
            _line(x, n) for n, x in enumerate(data["tasks"], 1))
    return _mutate(fn)


def start(ref, by: str = "agent") -> str:
    def fn(data):
        _, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        cur = next((x for x in data["tasks"] if x["status"] == "active"), None)
        if cur is not None and cur is not t:
            return f"错误: [{cur['id']}] 还在做；先 done / block 它，再开始新的"
        t["status"], t["updated"] = "active", time.time()
        t.pop("blocked_on", None)
        _active_first(data)
        return f"开始做 [{t['id']}] {t['title']}"
    return _mutate(fn)


def _close(ref, status: str, note: str, by: str) -> str:
    def fn(data):
        i, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        if status == "dropped" and (err := _can_touch(t, by)):
            return "错误: " + err
        data["tasks"].pop(i)
        t["status"], t["updated"] = status, time.time()
        t["result"] = str(note or "").strip()[:500]
        data["history"] = (data["history"] + [t])[-HISTORY_MAX:]
        left = len(data["tasks"])
        nxt = next((x for x in data["tasks"] if x["status"] == "pending"), None)
        return (f"[{t['id']}] {STATUS_NAME[status]}。队列还剩 {left} 项"
                + (f"，下一项 [{nxt['id']}] {nxt['title']}" if nxt else ""))
    return _mutate(fn)


def done(ref, result: str = "", by: str = "agent") -> str:
    return _close(ref, "done", result, by)


def drop(ref, reason: str = "", by: str = "agent") -> str:
    return _close(ref, "dropped", reason, by)


def block(ref, reason: str, by: str = "agent") -> str:
    def fn(data):
        _, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        t["status"], t["blocked_on"], t["updated"] = "blocked", str(reason or "").strip()[:300], time.time()
        _active_first(data)
        return f"[{t['id']}] 卡住了：{t['blocked_on'] or '（没写原因）'}"
    return _mutate(fn)


def resume(ref, by: str = "user") -> str:
    """卡住 / 正在做的任务放回待办（排在最前），Agent 接着做。"""
    def fn(data):
        _, t = _resolve(data, ref)
        if t is None:
            return f"错误: 没有任务 {ref}"
        if t["status"] == "pending":
            return f"[{t['id']}] 本来就在排队"
        t["status"], t["blocked_on"], t["updated"] = "pending", "", time.time()
        data["tasks"].remove(t)
        data["tasks"].insert(1 if data["tasks"] and data["tasks"][0]["status"] == "active" else 0, t)
        return f"[{t['id']}] 放回队列，接着做：{t['title']}"
    return _mutate(fn)


def open_tasks() -> list[dict]:
    return list(load()["tasks"])


def next_up() -> dict | None:
    """接下来该做的：正在做的那项，没有就排最前的待办（卡住的等主人，不算）。"""
    return next((t for t in load()["tasks"] if t["status"] in ("active", "pending")), None)


def fingerprint() -> tuple:
    """队列现在的样子（编号 + 状态 + 改动时间）：自动续做一轮后没变，说明这一轮没推进。"""
    return tuple((t["id"], t["status"], t.get("updated")) for t in load()["tasks"])


def summary() -> str:
    """一句话：还差几项、正在做哪项（Agent 汇报结尾用）。"""
    tasks = load()["tasks"]
    act = next((t for t in tasks if t["status"] == "active"), None)
    return f"任务队列还有 {len(tasks)} 项没做完" + (f"，正在做 [{act['id']}] {act['title']}" if act else "")


# ---------------- 旧目标文件迁移 ----------------
_ITEM = re.compile(r"^(\s*)[-*]?\s*\[( |x|X)\]\s*(.*?)\s*$")


def parse_legacy(text: str) -> list[dict]:
    """把旧的「散兵-目标.txt」拆成任务：[ ] / [x] 开头的是一条；它下面更深缩进的行属于它——
    以「- 」开头的是说明，其余是被折行的标题后半截。"""
    out, cur, indent = [], None, 0
    for raw in text.splitlines():
        m = _ITEM.match(raw)
        if m:
            cur = {"done": m.group(2).lower() == "x", "title": m.group(3).strip(), "detail": []}
            indent = len(m.group(1).expandtabs())
            out.append(cur)
            continue
        if cur is None or not raw.strip():
            continue
        if len(raw) - len(raw.lstrip()) <= indent:      # 回到同级或更外层：这条结束
            cur = None
            continue
        line = raw.strip()
        if line.startswith(("-", "*", "•")) or cur["detail"]:
            cur["detail"].append(line.lstrip("-*• ").strip())
        else:
            cur["title"] += line
    return out


def migrate_legacy() -> str:
    """把旧目标文件导进来，旧文件改名留底（不删）。不再自动调用：旧文件是愿望清单，不是正在做的活。"""
    p = store_path()
    if p.exists():
        return ""
    if p.parent.resolve() != (APP_ROOT / "memory").resolve():
        return ""                                       # 测试 / 冒烟用的临时记忆目录：绝不去动真的目标文件
    sources = [APP_ROOT / "散兵-目标.txt", Path.home() / "Desktop" / "散兵-目标.txt"]
    data = _empty()
    seen, moved = set(), []
    now = time.time()
    for src in sources:
        try:
            text = src.read_text(encoding="utf-8")
        except OSError:
            continue
        for it in parse_legacy(text):
            head, det = _split(it["title"], "\n".join(it["detail"]))
            key = _norm(head)
            if not head or key in seen or "示例" in head and len(head) < 10:
                continue
            seen.add(key)
            tid = f"t{data['next_id']}"
            data["next_id"] += 1
            task = {"id": tid, "title": head, "detail": det, "status": "done" if it["done"] else "pending",
                    "by": "旧目标文件", "created": now, "updated": now}
            (data["history"] if it["done"] else data["tasks"]).append(task)
        moved.append(src)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for src in moved:                                   # 改名留底：Agent 以后不会再去读 / 手改它
        try:
            src.rename(src.with_name(f"散兵-目标.已迁移到任务队列-{stamp}.txt"))
        except OSError:
            pass
    return f"从旧目标文件导入了 {len(data['tasks'])} 项待办、{len(data['history'])} 项已完成"


# ---------------- 给 Agent / 前台的工具 ----------------
def _schema(name: str, desc: str, actions: list[str]) -> dict:
    from . import _fn
    return _fn(name, desc, {
        "action": {"type": "string", "enum": actions},
        "id": {"type": "string", "description": "任务编号，例如 t3"},
        "title": {"type": "string", "description": "add / edit：一句话标题（多出来的会自动挪进说明）"},
        "detail": {"type": "string", "description": "add / edit：补充说明、验收标准"},
        "position": {"type": "string", "description": "add / move：top / bottom / up / down / before:t3 / after:t3 / 第几位"},
        "note": {"type": "string", "description": "done：做成了什么；block：卡在哪、要用户给什么；drop：为什么不做"}},
        ["action"])


def _run(a: dict, by: str) -> str:
    act = str(a.get("action") or "list").lower()
    tid = a.get("id") or ""
    try:
        if act == "list":
            return list_text()
        if act == "show":
            return show(tid)
        if act == "add":
            return add(a.get("title", ""), a.get("detail", ""), a.get("position") or "bottom", by)
        if act == "edit":
            return edit(tid, a.get("title"), a.get("detail"), by)
        if act == "move":
            return move(tid, a.get("position", ""), by)
        if act == "drop":
            return drop(tid, a.get("note", ""), by)
        if act == "resume":                         # 卡住的放回队列接着做（主人说「继续」时）
            return resume(tid, by)
        if by != "front":
            if act == "start":
                return start(tid, by)
            if act == "done":
                return done(tid, a.get("note", ""), by)
            if act == "block":
                return block(tid, a.get("note", ""), by)
        return f"错误: 不能做 {act}"
    except TimeoutError as e:
        return f"错误: {e}"


AGENT_DESC = ("任务队列：手头正在做的活（唯一的一份）。主人一次交代几件事、或干活中追加新要求时，每件 add 一项（一句话标题，细节写 detail）；"
              "单件事不用管：系统在你第一次动手时自动把主人这一轮的要求记成正在做、收尾时自动标完成。进了队列就要做：你一轮结束后系统会自动让你接着做下一项，直到清空。"
              "动手做某项前 start；做完 done 并在 note 里写做成了什么；必须主人给东西才能继续时 block 写清卡在哪；主人说不要了就 drop；主人说卡住的那项继续做就 resume。"
              "edit / move 按编号改。只用这个工具管理任务，不要自己写任何目标 / 待办文件，也不要把远期想法放进来。")
FRONT_DESC = ("改排队中的任务（队列里是干活 Agent 手头要做完的活，它会一直做到清空）：list 看队列；主人要加事 add（Agent 闲着就马上开工）；"
              "改还没开始的任务 edit；调顺序 move（top / up / down / before:t3）；不要了 drop。"
              "正在做的那一项你动不了（要改正在做的事用 workflow_add_plan）。")


def agent_tool():
    return (_schema("task_queue", AGENT_DESC, ["list", "show", "add", "edit", "move", "start", "done", "block", "resume", "drop"]),
            lambda a: _run(a, "agent"))


def front_tool():
    return (_schema("queue_manage", FRONT_DESC, ["list", "show", "add", "edit", "move", "resume", "drop"]),
            lambda a: _run(a, "front"))
