"""成本计价模块。

公式：cost = 未命中输入 token×in_miss + 命中缓存输入 token×in_hit + 输出 token×out，
按 1M token 计价；非峰值时段单价 × OFF_PEAK_RATIO。定价来源：DeepSeek 官方 Pricing 页。
"""
import datetime

# 峰值单价（美元 / 1M tokens）
PRICING = {
    "deepseek-flash": {"in_miss": 0.3, "in_hit": 0.006, "out": 1.2},
    "deepseek-v4-pro": {"in_miss": 1.32, "in_hit": 0.044, "out": 3.96},
}

OFF_PEAK_RATIO = 0.5

USD_TO_CNY = 7.2

# 2026 年中国法定节假日
CHINA_HOLIDAYS = [
    "2026-01-01",
    "2026-02-16", "2026-02-17", "2026-02-18", "2026-02-19", "2026-02-20",
    "2026-02-21", "2026-02-22",
    "2026-04-05",
    "2026-05-01",
    "2026-06-19",
    "2026-09-24",
    "2026-10-01", "2026-10-02", "2026-10-03", "2026-10-04", "2026-10-05",
    "2026-10-06", "2026-10-07",
]

_ALIASES = {"deepseek-v4-flash": "deepseek-flash"}


def is_peak(dt=None):
    """DeepSeek off-peak(5折)：北京时间 00:30–08:30；先转 UTC+8 再判断。"""
    try:
        if dt is None:
            dt = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=8)
        if dt.weekday() >= 5:            # 周末非峰
            return False
        if dt.date().isoformat() in CHINA_HOLIDAYS:   # 法定节假日非峰
            return False
        minutes = dt.hour * 60 + dt.minute
        if 30 <= minutes < 510:          # 00:30–08:30 off-peak（5折）
            return False
        return True
    except Exception:
        return False


def _as_int(v):
    try:
        n = int(v)
    except Exception:
        return 0
    return n if n > 0 else 0


def token_cost(model, in_tokens, out_tokens, cache_hit_tokens=0):
    """返回本次请求的美元成本（未取整）；异常返回 0.0。"""
    try:
        name = str(model or "").strip().lower()
        name = _ALIASES.get(name, name)
        price = PRICING.get(name) or PRICING["deepseek-v4-pro"]
        ratio = 1.0 if is_peak() else OFF_PEAK_RATIO
        inp = _as_int(in_tokens)
        out = _as_int(out_tokens)
        hit = min(_as_int(cache_hit_tokens), inp)
        miss = inp - hit
        usd = (miss * price["in_miss"] + hit * price["in_hit"] + out * price["out"]) / 1000000.0
        return usd * ratio
    except Exception:
        return 0.0


def fmt_cost(usd):
    """美元格式化：小于 0.005 显示 "$<0.01"，否则 "$0.42"。"""
    try:
        v = float(usd)
    except Exception:
        v = 0.0
    if v < 0.005:
        return "$<0.01"
    return "$%.2f" % v


def fmt_cost_cny(usd):
    """人民币估算格式化：例如 "¥3.02"。"""
    try:
        v = float(usd)
    except Exception:
        v = 0.0
    return "¥%.2f" % (v * USD_TO_CNY)
