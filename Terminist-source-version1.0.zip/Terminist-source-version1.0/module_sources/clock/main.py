"""
时钟模块（模块包的例子）：表盘贴图 + 指针 + 数字时间 + 日期星期，每秒走一格；可以开滴答声。
点内容区换样式（表盘 + 数字 → 只有大字数字 → 12 小时制）；点左下角「声音」开 / 关滴答声。

素材都在 assets/ 里：face.png（表盘底图）、tick.wav（滴答声），用 ctx.image / ctx.sound 读。
只用 ctx 提供的东西画（见 surface/modules_api.py），不碰 Terminist 内部，所以界面怎么改都不会把它弄坏。
"""

import math
import time

import pygame

WEEK = "一二三四五六日"
STYLES = ("dial", "digits", "dial12")


def _hand(ctx, c, angle, length, width, color):
    x = c[0] + math.sin(angle) * length
    y = c[1] - math.cos(angle) * length
    pygame.draw.line(ctx.screen, color, c, (x, y), width)


def _tick(ctx, t):
    """开着声音、秒数变了：滴答一声。"""
    if ctx.state.get("sound") and ctx.state.get("last_sec") != t.tm_sec:
        ctx.sound("tick.wav", 0.4)
    ctx.state["last_sec"] = t.tm_sec


def draw(ctx):
    r = ctx.rect
    t = time.localtime(ctx.now)
    _tick(ctx, t)
    style = ctx.state.get("style", "dial")
    h24 = style != "dial12"
    hour = t.tm_hour if h24 else (t.tm_hour % 12 or 12)
    ampm = "" if h24 else (" 上午" if t.tm_hour < 12 else " 下午")
    digits = f"{hour:02d}:{t.tm_min:02d}:{t.tm_sec:02d}{ampm}"
    date = f"{t.tm_year}-{t.tm_mon:02d}-{t.tm_mday:02d}  星期{WEEK[t.tm_wday]}"

    if style == "digits":                              # 只有数字：大字居中
        big = ctx.text(digits, ctx.color("hdr"))
        scale = min(3.0, max(1.0, (r.w - ctx.s(24)) / max(1, big.get_width())))
        if scale > 1.05:
            big = pygame.transform.smoothscale(big, (int(big.get_width() * scale), int(big.get_height() * scale)))
        ctx.screen.blit(big, big.get_rect(center=(r.centerx, r.centery - ctx.s(10))))
        d = ctx.text(date, ctx.color("dim"), small=True)
        ctx.screen.blit(d, d.get_rect(center=(r.centerx, r.centery + big.get_height() // 2 + ctx.s(6))))
    else:                                              # 表盘贴图 + 指针 + 数字
        txt_h = ctx.small.get_linesize() * 3 + ctx.s(18)
        rad = max(10, min(r.w, r.h - txt_h) // 2 - ctx.s(10))
        c = (r.centerx, r.y + ctx.s(8) + rad)
        try:
            face = ctx.image("face.png", (rad * 2, rad * 2))      # 素材：表盘底图
            ctx.screen.blit(face, face.get_rect(center=c))
        except Exception:
            pygame.draw.circle(ctx.screen, ctx.color("bg"), c, rad)  # 读不到贴图就画个圆顶上
        pygame.draw.circle(ctx.screen, ctx.color("border"), c, rad, max(1, ctx.s(2)))
        sec = t.tm_sec
        mins = t.tm_min + sec / 60
        hrs = (t.tm_hour % 12) + mins / 60
        _hand(ctx, c, hrs / 12 * math.tau, rad * 0.5, max(2, ctx.s(5)), ctx.color("text"))
        _hand(ctx, c, mins / 60 * math.tau, rad * 0.75, max(2, ctx.s(3)), ctx.color("text"))
        _hand(ctx, c, sec / 60 * math.tau, rad * 0.85, max(1, ctx.s(1)), ctx.color("del"))
        pygame.draw.circle(ctx.screen, ctx.color("del"), c, max(2, ctx.s(4)))
        y = c[1] + rad + ctx.s(8)
        d1 = ctx.text(digits, ctx.color("hdr"))
        ctx.screen.blit(d1, d1.get_rect(midtop=(r.centerx, y)))
        d2 = ctx.text(date, ctx.color("dim"), small=True)
        ctx.screen.blit(d2, d2.get_rect(midtop=(r.centerx, y + d1.get_height() + ctx.s(2))))
    # 左下角「声音」开关（点它开 / 关滴答声；点别处换样式）
    on = bool(ctx.state.get("sound"))
    lab = ctx.text(f"声音：{'开' if on else '关'}", ctx.color("add" if on else "dim"), small=True)
    btn = lab.get_rect(bottomleft=(r.x + ctx.s(10), r.bottom - ctx.s(6))).inflate(ctx.s(12), ctx.s(6))
    pygame.draw.rect(ctx.screen, ctx.color("border"), btn, 1, border_radius=ctx.s(6))
    ctx.screen.blit(lab, lab.get_rect(center=btn.center))
    ctx.state["sound_btn"] = btn


def on_click(ctx, pos):
    btn = ctx.state.get("sound_btn")
    if btn is not None and btn.collidepoint(pos):
        ctx.state["sound"] = not ctx.state.get("sound")
        if ctx.state["sound"]:
            ctx.sound("tick.wav", 0.4)                 # 打开时先响一声，让人知道开了
        return
    i = STYLES.index(ctx.state.get("style", "dial"))
    ctx.state["style"] = STYLES[(i + 1) % len(STYLES)]


MODULE = {"draw": draw, "on_click": on_click}          # 名字、标题、默认位置都写在 module.json 里
