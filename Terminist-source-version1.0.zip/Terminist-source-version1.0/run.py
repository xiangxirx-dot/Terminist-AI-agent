"""
Terminist 入口
------------------------
  python run.py [要编辑的文件夹]           图形界面
  python run.py --cli [要编辑的文件夹]     命令行

架构:
  surface/  渲染层：界面，把用户指令交给 A库
  lib_a/    执行层：组长拆任务、执行成员并行写、组长查工；要改 Terminist 自己时交给 B库
  lib_b/    改造层：存档 → 制作 → 自检 → A库校对 → 交工（自动重启）/ 回滚重做
  versions/ 每次改造前 A库 和 Surface 的存档

保险：B库改造后自动重启时会带上 --after-upgrade <存档名>。新版本如果在启动后 SAFE_SECONDS 秒内崩溃，
      这里会直接把 A库 和 Surface 恢复成存档（不依赖可能已经坏掉的 lib_a / lib_b），再重新启动。

依赖:  pip install openai pygame-ce playwright faster-whisper yt-dlp "av>=13,<16"
       本地看图：安装 Ollama（winget install Ollama.Ollama）后 ollama pull qwen2.5vl:7b
       上网用系统自带的 Edge；Whisper 模型第一次用时自动下载到 ~/.terminist/models
"""

import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

LAYERS = ("lib_a", "surface")              # 旧格式存档只包含这两层
EXCLUDE_DIRS = {"versions", "memory", ".git", "root", "runtime"}
EXCLUDE_FILES = {"terminist_settings.json",
                 "Terminist.exe", "icon.ico", "build.py", "python_path.txt"}   # 用户设置 + 启动器（build.py 编的，回滚不能删）
SAFE_SECONDS = 60


def _tree(base: Path, only=None) -> dict:
    out = {}
    for f in base.rglob("*"):
        rel = f.relative_to(base).as_posix()
        parts = rel.split("/")
        if (not f.is_file() or parts[0] in EXCLUDE_DIRS or (len(parts) == 1 and parts[0] in EXCLUDE_FILES)
                or rel == "lib_a/config.py"                  # 和 lib_b/versions.py 一样：不存档、不回滚
                or "__pycache__" in parts or (only and parts[0] not in only)):
            continue
        out[rel] = f
    return out


def _restore(snap: str):
    """不依赖 lib_a / lib_b（它们可能已经坏了），直接按存档把文件夹恢复原样。"""
    d = ROOT / "versions" / snap
    src, only = (d / "files", None) if (d / "files").is_dir() else (d, LAYERS)
    saved = _tree(src, only)
    for rel, f in _tree(ROOT, only).items():
        if rel not in saved:
            f.unlink()
    for rel, f in saved.items():
        target = ROOT / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            target.unlink()
        shutil.copy2(f, target)
    for cache in list(ROOT.rglob("__pycache__")):      # 清掉缓存和空目录，回到存档时的样子
        if cache.relative_to(ROOT).parts[0] not in EXCLUDE_DIRS:
            shutil.rmtree(cache, ignore_errors=True)
    for sub in sorted((x for x in ROOT.rglob("*") if x.is_dir()), key=lambda x: len(x.parts), reverse=True):
        rel = sub.relative_to(ROOT).as_posix()
        if rel.split("/")[0] not in EXCLUDE_DIRS and rel != "lib_a/extensions" and not any(sub.iterdir()):
            sub.rmdir()
    meta = d / "meta.json"
    try:
        m = json.loads(meta.read_text(encoding="utf-8"))
        m["status"] = "新版本启动失败，已自动回滚"
        meta.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")
    except (OSError, ValueError):
        pass


LOG_DIR = Path.home() / ".terminist" / "logs"
READY_ENV = "TERMINIST_READY_FILE"       # 新窗口画出第一帧后写这个文件，旧窗口看到了才关
SPLASH_ENV = "TERMINIST_SPLASH_FILE"     # 开机特效的进度文件：界面按启动阶段写「进度|在干什么」
SPLASH_PID_ENV = "TERMINIST_SPLASH_PID"  # 开机特效进程：它还活着，主窗口就先藏着（动画跑完再出来）
SPLASH_DONE_ENV = "TERMINIST_SPLASH_DONE"  # 写 1.0 的时间：特效进程万一卡住，最多再等几秒就出窗口


class Restart:
    """一次界面重启：新进程、它的就绪标记文件、日志文件。"""

    def __init__(self, proc, ready: Path, log: Path):
        self.proc, self.ready, self.log = proc, ready, log
        self.started = time.time()
        self.exited_at = None

    def state(self) -> str:
        """ready：新窗口起来了；failed：新进程退出了还没起来；waiting：还在等。"""
        if self.ready.exists():
            try:
                self.ready.unlink()
            except OSError:
                pass
            return "ready"
        if self.proc.poll() is not None:
            # 新进程启动失败时 main() 会先回滚再起一个，所以退出后再多等一会儿
            self.exited_at = self.exited_at or time.time()
            if time.time() - self.exited_at > 25:
                return "failed"
        return "waiting"

    def log_tail(self, n: int = 1200) -> str:
        try:
            return self.log.read_text(encoding="utf-8", errors="replace")[-n:].strip()
        except OSError:
            return ""


def _python_for_gui() -> str:
    """图形界面用 pythonw.exe（不需要控制台窗口）。"""
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return str(w) if sys.platform == "win32" and exe.name.lower() == "python.exe" and w.is_file() else str(exe)


def launch(args: list[str], notice: str = "", wait: bool = False):
    """用 run.py 重新启动 Terminist。notice 会显示在新窗口里。
    图形界面返回 Restart（调用方等它就绪再退出）；命令行版等新进程结束，返回退出码。"""
    env = dict(os.environ)
    if notice:
        env["TERMINIST_NOTICE"] = notice
    if wait:                     # 命令行版：等新进程结束，避免两个进程抢同一个终端
        return subprocess.call([sys.executable, str(ROOT / "run.py")] + args, cwd=ROOT, env=env)

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    for old in sorted(LOG_DIR.glob("restart_*.log"))[:-10]:          # 只留最近 10 份日志
        try:
            old.unlink()
        except OSError:
            pass
    stamp = time.strftime("%Y%m%d-%H%M%S")
    log = LOG_DIR / f"restart_{stamp}.log"
    # 已经是被重启出来的进程（例如启动失败回滚后再起一次）就沿用同一个就绪标记，最早的旧窗口才等得到
    ready = Path(env.get(READY_ENV) or LOG_DIR / f"ready_{stamp}_{os.getpid()}.flag")
    env[READY_ENV] = str(ready)
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = [_python_for_gui(), str(ROOT / "run.py")] + args
    # 完全脱离当前进程：独立的控制台 / 进程组，并且跳出父进程所在的 Job。
    # 否则从 IDE（VS Code、PyCharm）或某些终端启动时，旧进程一退出，新进程会被一起杀掉。
    detached, group, breakaway = 0x00000008, 0x00000200, 0x01000000
    with open(log, "w", encoding="utf-8") as out:
        kw = dict(cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT, close_fds=True)
        if sys.platform != "win32":
            proc = subprocess.Popen(cmd, start_new_session=True, **kw)
        else:
            try:
                proc = subprocess.Popen(cmd, creationflags=detached | group | breakaway, **kw)
            except OSError:      # 所在的 Job 不允许跳出时退而求其次
                proc = subprocess.Popen(cmd, creationflags=detached | group, **kw)
    return Restart(proc, ready, log)


def signal_ready():
    """新窗口画出第一帧后调用：告诉等着的旧窗口可以关了。"""
    path = os.environ.pop(READY_ENV, "")
    if path:
        try:
            Path(path).write_text(str(os.getpid()), encoding="utf-8")
        except OSError:
            pass


def start_splash():
    """冷启动（不是改造后 / 回滚后的重启）才放开机特效：单独进程画，主程序只往进度文件里写。"""
    if sys.platform != "win32" or os.environ.get(READY_ENV) or os.environ.get("TERMINIST_NO_SPLASH"):
        return
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    for old in LOG_DIR.glob("splash_*.txt"):          # 上次被强杀没删掉的进度文件
        try:
            old.unlink()
        except OSError:
            pass
    path = LOG_DIR / f"splash_{os.getpid()}.txt"
    try:
        path.write_text("0.03|正在启动", encoding="utf-8")
        proc = subprocess.Popen([_python_for_gui(), "-m", "surface.splash", str(path), str(os.getpid())], cwd=ROOT,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=0x08000000)            # CREATE_NO_WINDOW
    except OSError:
        return
    os.environ[SPLASH_ENV] = str(path)
    os.environ[SPLASH_PID_ENV] = str(proc.pid)


def splash_holding() -> bool:
    """开机特效还没放完：主窗口先别露面。"""
    return bool(os.environ.get(SPLASH_PID_ENV))


def splash_finished() -> bool:
    """特效放完了（进程退出了，或者说好之后等了 6 秒还没退）：可以出主窗口了。"""
    pid = os.environ.get(SPLASH_PID_ENV)
    if not pid:
        return True
    from surface.splash import _alive
    done = float(os.environ.get(SPLASH_DONE_ENV) or 0)
    if not _alive(int(pid)) or (done and time.time() - done > 6):
        os.environ.pop(SPLASH_PID_ENV, None)
        return True
    return False


def splash(value: float, label: str = ""):
    """报告启动进度（0~1）。1.0 = 好了，特效炸开淡出。没开特效时什么都不做。"""
    path = os.environ.get(SPLASH_ENV)
    if not path:
        return
    if value >= 1.0:
        os.environ.pop(SPLASH_ENV, None)
        os.environ[SPLASH_DONE_ENV] = str(time.time())
    try:
        Path(path).write_text(f"{value:.3f}|{label}", encoding="utf-8")
    except OSError:
        pass


def _hide_console(args) -> bool:
    """双击 / 快捷方式用 python.exe 打开时会带一个黑色 cmd 窗口：这时换成 pythonw 重新起，自己退出。
    从终端里运行（控制台里还有 cmd / PowerShell 等别的进程）不动它，日志照常打在终端里。返回 True = 已经换走了。"""
    if sys.platform != "win32" or "--cli" in args or Path(sys.executable).name.lower() != "python.exe":
        return False
    import ctypes
    k = ctypes.windll.kernel32
    ids = (ctypes.c_ulong * 16)()
    n = k.GetConsoleProcessList(ids, 16)
    if not 0 < n <= 16:
        return False
    for pid in ids[:n]:                                  # 控制台里只有 py / python 自己 = 这个窗口是专门为我开的
        h = k.OpenProcess(0x1000, False, pid)
        name = ""
        if h:
            buf, size = ctypes.create_unicode_buffer(512), ctypes.c_ulong(512)
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                name = Path(buf.value).name.lower()
            k.CloseHandle(h)
        if name not in ("python.exe", "py.exe", "pythonw.exe"):
            return False
    w = Path(sys.executable).with_name("pythonw.exe")
    if not w.is_file():
        return False
    ctypes.windll.user32.ShowWindow(k.GetConsoleWindow(), 0)       # 先把黑窗口藏起来
    detached, group, breakaway = 0x00000008, 0x00000200, 0x01000000
    kw = dict(cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    try:
        subprocess.Popen([str(w), str(ROOT / "run.py")] + args, creationflags=detached | group | breakaway, **kw)
    except OSError:
        try:
            subprocess.Popen([str(w), str(ROOT / "run.py")] + args, creationflags=detached | group, **kw)
        except OSError:
            ctypes.windll.user32.ShowWindow(k.GetConsoleWindow(), 5)
            return False
    return True


def main():
    args = sys.argv[1:]
    if _hide_console(args):
        return
    snap = None
    if "--after-upgrade" in args:
        i = args.index("--after-upgrade")
        snap = args[i + 1] if i + 1 < len(args) else None
        del args[i:i + 2]
    sys.argv = [sys.argv[0]] + args
    start = time.time()
    try:
        if "--cli" in args:
            from surface.console import main as run
        else:
            start_splash()
            splash(0.08, "正在加载界面模块")
            from surface.gui import main as run
            splash(0.35, "正在建窗口")
        run()
    except Exception:
        splash(1.0, "启动失败")
        if snap and time.time() - start < SAFE_SECONDS and (ROOT / "versions" / snap).is_dir():
            traceback.print_exc()
            print(f"\n新版本启动失败，自动恢复到改造前的版本 {snap} 并重新启动…")
            _restore(snap)
            launch(args, notice=f"新版本启动失败，已自动回滚到改造前的版本 {snap}", wait="--cli" in args)
            return
        raise


if __name__ == "__main__":
    main()
