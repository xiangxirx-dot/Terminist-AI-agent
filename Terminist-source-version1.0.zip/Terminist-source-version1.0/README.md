# Terminist

本地运行的 DeepSeek 智能体，带 pygame 图形界面。

## 从源码运行

```bash
pip install -r requirements.txt
python run.py
```

第一次启动后在顶栏「隐私」里填 DeepSeek API key（用 Windows 账户加密保存在用户目录，不在这个文件夹里）。
要用 root 库的功能，先在终端里运行一次 `python root/seal.py` 封印。

可选：装 [Ollama](https://ollama.com) 并 `ollama pull qwen2.5:3b`（记忆打分）、`ollama pull qwen2.5vl:7b`（看图）。

## 打包

```bash
python build.py
```

选一个文件夹，生成源码版和可执行版（自带 Python，拷到干净的 Windows 双击 `Terminist.exe` 就能用）。

## 模块

`modules/` 里放 `.tmod` 模块包，启动时自动读取。制作教程见 `modules/README.md`。
