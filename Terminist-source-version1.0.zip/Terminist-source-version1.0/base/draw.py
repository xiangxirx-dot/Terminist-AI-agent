"""
画图：Mermaid 源码 → PNG（mermaidx，纯 Python，不需要浏览器 / Node.js）。

mermaidx 自带的字体（DejaVu Sans）没有中文，中文会变成方块。这里把系统的中文字体登记到同样的字体名下，
排版测量和绘制两边都能用上中文。图片存在 ~/.terminist/diagrams（不在 Terminist 文件夹里，不进版本存档）。
"""

import re
import time
from pathlib import Path

from .config import MODELS_DIR

DIAGRAM_DIR = MODELS_DIR.parent / "diagrams"
WIDTH = 1400                     # 渲染宽度（像素），界面里会再按卡片宽度缩小

# 中文字体，按顺序找第一个存在的（常规体, 粗体）
_CJK_FONTS = [(r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc"),
              (r"C:\Windows\Fonts\simhei.ttf", r"C:\Windows\Fonts\simhei.ttf"),
              ("/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/PingFang.ttc"),
              ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc")]
# Mermaid 默认的字体栈 + mermaidx 排版用的字体名，都换成中文字体
_FAMILIES = ("trebuchet ms", "verdana", "arial", "DejaVu Sans")

# 图的类型 → 奖励里算哪一类
FLOW_TYPES = ("flowchart", "graph", "sequenceDiagram", "stateDiagram", "stateDiagram-v2", "journey", "gantt", "timeline")
CONCEPT_TYPES = ("mindmap", "classDiagram", "erDiagram", "block-beta", "quadrantChart", "requirementDiagram", "C4Context")
KIND_LABELS = {"flow": "流程图", "concept": "概念图", "other": "图"}

_ready = False


class DrawError(Exception):
    pass


def _setup():
    global _ready
    if _ready:
        return
    try:
        import mermaidx                      # noqa: F401
        import novasvg.fonts as fonts
        from mermaidx import font_metrics
    except ImportError as e:
        raise DrawError("没有安装 mermaidx：pip install mermaidx") from e
    for regular, bold in _CJK_FONTS:
        if Path(regular).is_file():
            for fam in _FAMILIES:
                fonts.add_font_face_from_file(fam, False, False, regular)
                fonts.add_font_face_from_file(fam, True, False, bold if Path(bold).is_file() else regular)
            font_metrics._REGULAR = font_metrics.Font(bold=False)     # 排版测量用的缓存换成新字体
            font_metrics._BOLD = font_metrics.Font(bold=True)
            break
    _ready = True


def diagram_type(source: str) -> str:
    """Mermaid 源码的第一个关键字，例如 flowchart、mindmap。"""
    for line in source.splitlines():
        line = line.strip()
        if line and not line.startswith("%%") and line != "---":
            return re.split(r"[\s;]", line, 1)[0]
    return ""


def kind_of(source: str) -> str:
    t = diagram_type(source)
    if t in FLOW_TYPES:
        return "flow"
    if t in CONCEPT_TYPES:
        return "concept"
    return "other"


def render(source: str, width: int = WIDTH) -> bytes:
    """Mermaid 源码 → PNG 字节；语法错误时抛 DrawError（带行号，模型可以照着改）。"""
    _setup()
    import mermaidx
    try:
        return mermaidx.render(source).png(width=width, background="#ffffff")
    except RuntimeError as e:
        raise DrawError(str(e).replace("Mermaid rendering failed: ", "Mermaid 语法错误：")[:600]) from e


def save(source: str, title: str = "") -> tuple[Path, str]:
    """渲染并保存，返回 (图片路径, 类型 flow/concept/other)。源码也存一份 .mmd 在旁边。"""
    png = render(source)
    DIAGRAM_DIR.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^\w\u4e00-\u9fff-]+", "_", title or diagram_type(source) or "diagram")[:40].strip("_")
    path = DIAGRAM_DIR / f"{time.strftime('%Y%m%d-%H%M%S')}_{safe or 'diagram'}.png"
    path.write_bytes(png)
    path.with_suffix(".mmd").write_text(source, encoding="utf-8")
    return path, kind_of(source)
