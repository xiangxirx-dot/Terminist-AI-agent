"""
看图：把图片交给本地 Ollama 部署的 Qwen-VL，转成解释性文字（再交给 DeepSeek 思考）。
本地模型没启动时会尝试自己启动 ollama serve。
"""

import base64
import json
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from .config import OLLAMA_URL, VL_MODEL, VL_TIMEOUT

DESCRIBE_PROMPT = """你是 Terminist 的眼睛。把图片里的内容转成准确、有条理的中文文字说明，供另一个不能看图的模型思考。
- 先一句话说这是什么（网页 / 软件界面 / 照片 / 图表 / 文档……）。
- 再按从上到下、从左到右列出要点：标题、正文文字（重要的照原样抄）、按钮、输入框、图表里的数据。
- 只说看到的，不要编造；看不清就说看不清。"""


class VisionError(Exception):
    pass


def _get(path: str, timeout: float = 3):
    with urllib.request.urlopen(OLLAMA_URL + path, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _server_up() -> bool:
    try:
        _get("/api/tags", 2)
        return True
    except (urllib.error.URLError, OSError, ValueError):
        return False


def ensure_server() -> None:
    """Ollama 没在运行就启动它（后台，不弹窗）。"""
    if _server_up():
        return
    exe = shutil.which("ollama")
    default = Path.home() / "AppData" / "Local" / "Programs" / "Ollama" / "ollama.exe"     # 刚装完 PATH 可能还没刷新
    if not exe and default.is_file():
        exe = str(default)
    if not exe:
        raise VisionError("没有找到 Ollama。请先安装：winget install Ollama.Ollama")
    flags = 0x08000000 if sys.platform == "win32" else 0          # CREATE_NO_WINDOW
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
    for _ in range(30):
        time.sleep(0.5)
        if _server_up():
            return
    raise VisionError("Ollama 启动失败")


def available() -> bool:
    """本地看图模型能不能用（服务在、模型已下载）。"""
    try:
        ensure_server()
        names = [m.get("name", "") for m in _get("/api/tags").get("models", [])]
        return any(n == VL_MODEL or n.startswith(VL_MODEL + ":") for n in names)
    except VisionError:
        return False


def describe(image: bytes, question: str = "", system: str = DESCRIBE_PROMPT) -> str:
    """图片（PNG / JPEG 字节）→ 文字说明。"""
    ensure_server()
    body = json.dumps({
        "model": VL_MODEL, "stream": False, "keep_alive": "10m", "options": {"temperature": 0.2},
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": question or "请描述这张图片。",
                      "images": [base64.b64encode(image).decode()]}],
    }).encode("utf-8")
    req = urllib.request.Request(OLLAMA_URL + "/api/chat", data=body, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=VL_TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:200]
        if "not found" in detail:
            raise VisionError(f"本地还没有 {VL_MODEL} 模型，请运行：ollama pull {VL_MODEL}") from e
        raise VisionError(f"Qwen-VL 出错：{detail}") from e
    except (urllib.error.URLError, OSError) as e:
        raise VisionError(f"连不上本地 Qwen-VL：{e}") from e
    return (data.get("message", {}).get("content") or "").strip() or "(没有看清)"
