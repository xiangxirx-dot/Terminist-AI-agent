"""
本地代码语义搜索：把代码按函数 / 类切块，用本地向量模型（bge-m3，和知识库同一个）建索引，
「X 是在哪实现的」一次就返回最相关的几段代码（文件、行号、代码），不用 grep → 读 → 再 grep → 再读一轮轮来回。

- Python 按 ast 切：每个函数、方法、类各一块（类本身只取开头）；别的文本文件按 60 行一窗
- 索引按代码根目录各存一份：~/.terminist/codeindex/<目录指纹>.sqlite；按文件修改时间增量更新（改了的文件才重算）
- 本地跑、不花钱；向量模型不可用时返回错误，让调用方退回 grep
"""

import ast
import hashlib
import os
import re
import sqlite3
import threading
import time
from pathlib import Path

INDEX_DIR = Path.home() / ".terminist" / "codeindex"
SKIP_DIRS = {".git", "__pycache__", "node_modules", "runtime", "versions", "memory", "_unpacked", ".venv", "venv",
             "dist", "build", ".idea", ".vscode", ".logs", ".state", "site-packages"}
EXTS = {".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".md", ".txt", ".ps1", ".bat", ".cs", ".html", ".css", ".toml",
        ".yaml", ".yml", ".ini", ".cfg"}
MAX_FILE_BYTES = 1_500_000
WINDOW = 60                     # 非 Python 文件每块多少行
CHUNK_CHARS = 1800              # 每块拿去算向量的最多多少字（函数太长只算开头）
EMBED_BATCH = 32
SCHEMA = """
CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, mtime REAL NOT NULL, size INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, path TEXT NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL,
  name TEXT NOT NULL, model TEXT NOT NULL, vec BLOB NOT NULL, hash TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS chunks_path ON chunks(path);
"""
_locks: dict[str, threading.Lock] = {}
_cache: dict[str, tuple] = {}   # 根目录 -> (版本, ids, 矩阵, 元信息)


def _db_path(root: Path) -> Path:
    h = hashlib.md5(str(root.resolve()).lower().encode("utf-8")).hexdigest()[:12]
    return INDEX_DIR / f"{root.name or 'root'}-{h}.sqlite"


def _connect(root: Path):
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(_db_path(root)), timeout=15)
    db.executescript(SCHEMA)
    if "hash" not in [r[1] for r in db.execute("PRAGMA table_info(chunks)")]:     # 旧索引补列
        db.execute("ALTER TABLE chunks ADD COLUMN hash TEXT NOT NULL DEFAULT ''")
    return db


def iter_files(root: Path):
    """要索引的文件（相对路径用 / 分隔）。"""
    root = root.resolve()
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix.lower() not in EXTS:
                continue
            try:
                st = p.stat()
            except OSError:
                continue
            if st.st_size > MAX_FILE_BYTES or st.st_size == 0:
                continue
            yield p.relative_to(root).as_posix(), p, st


def _read(p: Path) -> str:
    raw = p.read_bytes()
    for enc in ("utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def chunk_file(rel: str, text: str) -> list[tuple[int, int, str, str]]:
    """一个文件切成 [(起始行, 结束行, 名字, 拿去算向量的文字)]，行号从 1 开始。"""
    lines = text.splitlines()
    out = []
    if rel.endswith(".py"):
        try:
            tree = ast.parse(text)
        except SyntaxError:
            tree = None
        if tree is not None:
            def walk(nodes, prefix=""):
                for n in nodes:
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        name = prefix + n.name
                        start = min([n.lineno] + [d.lineno for d in getattr(n, "decorator_list", [])])
                        end = getattr(n, "end_lineno", n.lineno) or n.lineno
                        if isinstance(n, ast.ClassDef):
                            body_start = n.body[0].lineno if n.body else end
                            head_end = min(end, max(start, body_start + 8))
                            out.append((start, head_end, f"class {name}", "\n".join(lines[start - 1:head_end])))
                            walk(n.body, name + ".")
                        else:
                            out.append((start, end, f"def {name}", "\n".join(lines[start - 1:end])))
            walk(tree.body)
            covered = set()
            for s, e, _n, _t in out:
                covered.update(range(s, e + 1))
            # 模块级的代码（常量、提示词、导入）也要能搜到：没被函数 / 类盖住的连续段，按窗口切
            seg = [i + 1 for i in range(len(lines)) if (i + 1) not in covered]
            out += _windows(rel, lines, seg, "模块级")
            return out
    return _windows(rel, lines, list(range(1, len(lines) + 1)), "")


def _windows(rel, lines, line_nos, tag):
    out = []
    if not line_nos:
        return out
    runs, cur = [], [line_nos[0]]
    for n in line_nos[1:]:
        if n == cur[-1] + 1:
            cur.append(n)
        else:
            runs.append(cur)
            cur = [n]
    runs.append(cur)
    for run in runs:
        for i in range(0, len(run), WINDOW):
            part = run[i:i + WINDOW]
            text = "\n".join(lines[part[0] - 1:part[-1]])
            if text.strip():
                out.append((part[0], part[-1], f"{tag} {part[0]}-{part[-1]}".strip(), text))
    return out


def update(root, embedder=None, progress=None) -> dict:
    """增量更新这个目录的索引：改过的文件重新切块算向量，删掉的文件清掉。返回 {files, changed, chunks}。"""
    import numpy as np
    from . import embed as E
    embedder = embedder or E.embed
    model = E.model()
    root = Path(root).resolve()
    key = str(root).lower()
    lock = _locks.setdefault(key, threading.Lock())
    with lock:
        db = _connect(root)
        try:
            have = {r[0]: (r[1], r[2]) for r in db.execute("SELECT path, mtime, size FROM files")}
            stale_model = db.execute("SELECT 1 FROM chunks WHERE model<>? LIMIT 1", (model,)).fetchone()
            if stale_model:                                    # 换了向量模型：全部重算
                db.execute("DELETE FROM chunks"); db.execute("DELETE FROM files"); have = {}
            seen, changed = set(), []
            for rel, p, st in iter_files(root):
                seen.add(rel)
                if have.get(rel) != (st.st_mtime, st.st_size):
                    changed.append((rel, p, st))
            gone = [r for r in have if r not in seen]
            for rel in gone:
                db.execute("DELETE FROM chunks WHERE path=?", (rel,))
                db.execute("DELETE FROM files WHERE path=?", (rel,))
            todo, reused = [], 0
            for rel, p, st in changed:
                try:
                    pieces = chunk_file(rel, _read(p))
                except OSError:
                    continue
                # 文件改了一处，别的函数没变：按内容指纹把旧向量接着用，只给真改了的那几块重算（gui.py 有上千个函数）
                old = {r[0]: r[1] for r in db.execute("SELECT hash, vec FROM chunks WHERE path=? AND hash<>''", (rel,))}
                db.execute("DELETE FROM chunks WHERE path=?", (rel,))
                db.execute("INSERT OR REPLACE INTO files(path, mtime, size) VALUES(?,?,?)", (rel, st.st_mtime, st.st_size))
                for s, e, n, t in pieces:
                    # 拿去算向量的文字不带行号（「模块级 120-180」的行号一挪，指纹就全变了，旧向量接不上）
                    text = f"{rel} {re.sub(r'[ ]*[0-9]+-[0-9]+$', '', n)}\n{t[:CHUNK_CHARS]}"
                    h = hashlib.md5(text.encode("utf-8")).hexdigest()[:16]
                    if h in old:
                        db.execute("INSERT INTO chunks(path, start, end, name, model, vec, hash) VALUES(?,?,?,?,?,?,?)",
                                   (rel, s, e, n, model, old[h], h))
                        reused += 1
                    else:
                        todo.append((rel, s, e, n, text, h))
            for b in range(0, len(todo), EMBED_BATCH):
                batch = todo[b:b + EMBED_BATCH]
                vecs = embedder([x[4] for x in batch])
                db.executemany("INSERT INTO chunks(path, start, end, name, model, vec, hash) VALUES(?,?,?,?,?,?,?)",
                               [(r, s, e, n, model, np.asarray(v, np.float32).tobytes(), h)
                                for (r, s, e, n, _t, h), v in zip(batch, vecs)])
                if progress:
                    progress(min(len(todo), b + EMBED_BATCH), len(todo))
            db.commit()
            total = db.execute("SELECT count(*) FROM chunks").fetchone()[0]
        finally:
            db.close()
        if changed or gone:
            _cache.pop(key, None)
        return {"files": len(seen), "changed": len(changed) + len(gone), "chunks": total,
                "embedded": len(todo), "reused": reused}


def _matrix(root: Path):
    import numpy as np
    key = str(root).lower()
    db = _connect(root)
    try:
        ver = db.execute("SELECT count(*), coalesce(max(id), 0) FROM chunks").fetchone()
        hit = _cache.get(key)
        if hit and hit[0] == ver:
            return hit[1], hit[2], hit[3]
        rows = db.execute("SELECT id, path, start, end, name, vec FROM chunks").fetchall()
    finally:
        db.close()
    if not rows:
        return [], np.zeros((0, 1), np.float32), []
    mat = np.stack([np.frombuffer(r[5], np.float32) for r in rows])
    mat = mat / np.maximum(np.linalg.norm(mat, axis=1, keepdims=True), 1e-9)
    meta = [(r[1], r[2], r[3], r[4]) for r in rows]
    _cache[key] = (ver, [r[0] for r in rows], mat, meta)
    return [r[0] for r in rows], mat, meta


_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}")


def search(root, query: str, k: int = 6) -> list[dict]:
    """在 root 的代码里找和 query 最相关的 k 段：[{path, start, end, name, score}]（先增量更新索引）。"""
    import numpy as np
    from . import embed as E
    root = Path(root).resolve()
    update(root)
    ids, mat, meta = _matrix(root)
    if not len(ids):
        return []
    qv = np.asarray(E.embed([query], timeout=20)[0], np.float32)
    qv = qv / max(float(np.linalg.norm(qv)), 1e-9)
    sims = mat @ qv
    idents = {w.lower() for w in _IDENT.findall(query)}
    if idents:                                             # 问题里点名了函数 / 变量名：名字对上的加分
        for i, (path, _s, _e, name) in enumerate(meta):
            low = (name + " " + path).lower()
            if any(w in low for w in idents):
                sims[i] += 0.15
    top = np.argsort(-sims)[:k * 3]
    out, seen = [], set()
    for i in top:
        path, s, e, name = meta[i]
        if (path, s) in seen:
            continue
        seen.add((path, s))
        out.append({"path": path, "start": s, "end": e, "name": name, "score": round(float(sims[i]), 3)})
        if len(out) >= k:
            break
    return out


def render(root, hits: list[dict], budget: int = 9000, max_lines: int = 60) -> str:
    """把搜到的代码段拼成给模型看的文字：文件:起-止 名字，下面带行号的代码（太长只给开头）。"""
    root = Path(root)
    parts, used = [], 0
    for h in hits:
        try:
            lines = _read(root / h["path"]).splitlines()
        except OSError:
            continue
        s, e = h["start"], h["end"]
        shown = lines[s - 1:min(e, s - 1 + max_lines)]
        body = "\n".join(f"{s + i:>5}| {ln}" for i, ln in enumerate(shown))
        more = f"\n      …（这段一共 {e - s + 1} 行，后面没显示，要看用 read_lines {h['path']} {s + len(shown)}-{e}）" \
            if e - s + 1 > len(shown) else ""
        block = f"### {h['path']}:{s}-{e}  {h['name']}  （相关度 {h['score']}）\n{body}{more}"
        if used + len(block) > budget and parts:
            parts.append(f"（还有 {len(hits) - len(parts)} 段相关的没放下：{', '.join(x['path'] + ':' + str(x['start']) for x in hits[len(parts):])}）")
            break
        parts.append(block)
        used += len(block)
    return "\n\n".join(parts)


def code_search(roots: dict, query: str, k: int = 5) -> str:
    """工具本体：roots = {名字: 目录}。返回给模型看的文字；向量模型不可用返回错误（让它用 grep_files）。"""
    from . import embed as E
    q = " ".join(str(query or "").split())
    if not q:
        return "错误: query 写要找什么，例如「截图后是怎么画到小屏幕上的」「cost_log 在哪写的」"
    if not E.available():
        return f"错误: 本地代码搜索用不了（{E.why_not()}），先用 grep_files / terminist_search"
    k = max(1, min(10, int(k or 5)))
    out = []
    t = time.time()
    for label, root in roots.items():
        if not root or not Path(root).is_dir():
            continue
        try:
            hits = search(root, q, k=k)
        except Exception as e:
            out.append(f"## {label}（{root}）：搜索出错 {type(e).__name__}: {e}")
            continue
        if hits:
            out.append(f"## {label}（{root}）\n" + render(root, hits, budget=9000 // max(1, len(roots))))
    if not out:
        return "没找到相关代码（换个说法，或者用 grep_files 按名字搜）"
    return "\n\n".join(out) + f"\n\n（本地语义搜索，{time.time() - t:.1f} 秒；要看某段完整的用 read_lines）"
