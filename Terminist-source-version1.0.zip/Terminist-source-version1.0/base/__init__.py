"""
base 中心库：电脑层面的能力和安全规则，集中在这里（受保护，B库 改不了）。

  guard.py   删除确认：任何删除都弹窗，等 3 秒后用户才能确认
  screen.py  屏幕操作：截图 + 坐标网格、鼠标、键盘、窗口（鼠标移到左上角 = 紧急停止）
  web.py     上网：Playwright 驱动 Edge（无窗口、干净环境、不下载文件）
  vision.py  看图：本地 Ollama 部署的 Qwen-VL，把截图 / 图片转成文字
  audio.py   听音视频：本地 faster-whisper 转文字，网页视频用 yt-dlp 只下载音轨
  graphrag.py 知识图谱（GraphRAG）：抽实体 / 关系，防实体漂移、关系冲突、图膨胀（工具在 graph_tools.py）
  draw.py    画图：Mermaid → PNG（mermaidx，补上了中文字体），插进对话给用户看
  config.py  本地模型和浏览器的配置
  tools.py   把这些能力作为工具接到 A库 上：base.attach(agent)
得到的都是文字，交给 DeepSeek 思考。
"""

from . import guard                    # noqa: F401  lib_a 会用到，必须最先能导入


def attach(agent):
    from .tools import attach as _attach
    from . import eye
    eye.attach(agent)                   # 接管模式的眼睛日志（每做一件事带上前 5 秒）
    return _attach(agent)
