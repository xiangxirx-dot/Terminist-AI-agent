"""
前台窗口：现在最上层、拿着键盘焦点的是哪个窗口（标题 + 程序名）。

接管模式用：开始接管时告诉主人和 Agent「现在前台是谁」，接管面板实时显示，眼睛日志里记下前台窗口什么时候换了。
前台如果是 Terminist 自己（主人刚点了接管按钮），再往下找最上层那个不是 Terminist 的窗口——那才是 Agent 要操作的。
只读，不切换、不点任何窗口。只支持 Windows，别的系统返回 None。
"""

import ctypes
import os
import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent

if sys.platform == "win32":
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetTopWindow.restype = wintypes.HWND
    user32.GetTopWindow.argtypes = [wintypes.HWND]
    user32.GetWindow.restype = wintypes.HWND
    user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    _get_long = getattr(user32, "GetWindowLongPtrW", None) or user32.GetWindowLongW
    _get_long.restype = ctypes.c_ssize_t
    _get_long.argtypes = [wintypes.HWND, ctypes.c_int]
else:
    user32 = None

GW_HWNDNEXT = 2
WS_EX_TOOLWINDOW = 0x00000080
_exe_cache: dict[int, str] = {}


def _title(hwnd) -> str:
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _pid(hwnd) -> int:
    pid = wintypes.DWORD(0)
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def _exe_path(pid: int) -> str:
    """进程的程序完整路径（拿不到返回空串）。"""
    if pid in _exe_cache:
        return _exe_cache[pid]
    path = ""
    h = kernel32.OpenProcess(0x1000, False, pid)            # PROCESS_QUERY_LIMITED_INFORMATION
    if h:
        try:
            buf = ctypes.create_unicode_buffer(1024)
            size = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                path = buf.value
        finally:
            kernel32.CloseHandle(h)
    if len(_exe_cache) > 500:
        _exe_cache.clear()
    _exe_cache[pid] = path
    return path


def _cloaked(hwnd) -> bool:
    """被系统藏起来的窗口（其它虚拟桌面上的、后台的 UWP 应用）：看得见属性但人看不见。"""
    try:
        val = ctypes.c_int(0)
        ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(hwnd), 14, ctypes.byref(val), ctypes.sizeof(val))
        return bool(val.value)
    except Exception:
        return False


def info(hwnd) -> dict | None:
    """一个窗口的 {hwnd, title, exe, path, pid, rect, minimized, terminist}。"""
    if user32 is None or not hwnd:
        return None
    pid = _pid(hwnd)
    path = _exe_path(pid)
    r = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    return {"hwnd": int(hwnd), "title": _title(hwnd), "pid": pid, "path": path,
            "exe": os.path.basename(path) if path else "", "rect": (r.left, r.top, r.right - r.left, r.bottom - r.top),
            "minimized": bool(user32.IsIconic(hwnd)), "terminist": is_terminist(pid, path)}


def _parents() -> dict[int, int]:
    """所有进程的 {pid: 父 pid}（一次进程快照）。"""
    out = {}
    if user32 is None:
        return out

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wintypes.DWORD),
                    ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                    ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    snap = kernel32.CreateToolhelp32Snapshot(0x2, 0)                 # TH32CS_SNAPPROCESS
    if not snap or snap == wintypes.HANDLE(-1).value:
        return out
    try:
        pe = PE()
        pe.dwSize = ctypes.sizeof(PE)
        ok = kernel32.Process32FirstW(wintypes.HANDLE(snap), ctypes.byref(pe))
        while ok:
            out[int(pe.th32ProcessID)] = int(pe.th32ParentProcessID)
            ok = kernel32.Process32NextW(wintypes.HANDLE(snap), ctypes.byref(pe))
    finally:
        kernel32.CloseHandle(wintypes.HANDLE(snap))
    return out


_family = {"at": 0.0, "pids": set()}


def _terminist_pids() -> set[int]:
    """Terminist 的进程：自己、父进程（Agent 进程的父进程是界面），以及它们的子进程（Agent 进程、投影壳、开机特效）。
    两秒算一次（拍进程快照要几毫秒）。"""
    import time
    now = time.monotonic()
    if now - _family["at"] < 2 and _family["pids"]:
        return _family["pids"]
    me, parent = os.getpid(), os.getppid()
    roots = {me, parent}
    par = _parents()
    pids = set(roots) | {p for p, pp in par.items() if pp in roots}
    _family.update(at=now, pids=pids)
    return pids


def is_terminist(pid: int, path: str = "") -> bool:
    """是不是 Terminist 自己的窗口：Terminist 的进程（不管用的是自带的 Python 还是系统装的），或者用 Terminist 文件夹里的程序跑的。"""
    if pid in _terminist_pids():
        return True
    try:
        return bool(path) and Path(path).resolve().is_relative_to(APP_ROOT)
    except (OSError, ValueError):
        return False


def foreground() -> dict | None:
    """现在拿着键盘焦点的最上层窗口。"""
    if user32 is None:
        return None
    return info(user32.GetForegroundWindow())


def top_window(skip_terminist: bool = True) -> dict | None:
    """按叠放顺序从上往下，第一个人看得见的普通窗口（跳过隐藏 / 最小化 / 工具小窗 / 没标题的，默认也跳过 Terminist）。"""
    if user32 is None:
        return None
    hwnd = user32.GetTopWindow(None)
    for _ in range(2000):
        if not hwnd:
            return None
        if (user32.IsWindowVisible(hwnd) and not user32.IsIconic(hwnd) and _title(hwnd)
                and not (_get_long(hwnd, -20) & WS_EX_TOOLWINDOW) and not _cloaked(hwnd)):
            it = info(hwnd)
            if it and not (skip_terminist and it["terminist"]):
                return it
        hwnd = user32.GetWindow(hwnd, GW_HWNDNEXT)
    return None


def label(it: dict | None) -> str:
    if not it:
        return "（没有）"
    title = it["title"] or "（没有标题）"
    return f"{title}（{it['exe']}）" if it["exe"] else title


def describe() -> str:
    """一句话：现在前台是谁。前台是 Terminist 自己时，再说它下面最上层的那个窗口。"""
    try:
        fg = foreground()
        if fg is None:
            return "（拿不到前台窗口：只支持 Windows）"
        if fg["terminist"]:
            under = top_window()
            return f"Terminist 自己（它下面最上层的窗口：{label(under)}）"
        return label(fg)
    except Exception as e:
        return f"（拿不到前台窗口：{type(e).__name__}）"


def key() -> tuple | None:
    """比较「前台窗口换没换」用：(hwnd, 标题)。"""
    try:
        fg = foreground()
        return (fg["hwnd"], fg["title"]) if fg else None
    except Exception:
        return None
