"""base 中心库的配置：本地模型、浏览器。"""

from pathlib import Path

# 模型放在 Terminist 文件夹外面，避免版本存档和 B库 的临时副本每次都复制几个 GB；
# 不放 AppData：某些打包环境会把 AppData 重定向到别处，换个程序启动就找不到了
MODELS_DIR = Path.home() / ".terminist" / "models"

# 看图：本地 Ollama 部署的 Qwen-VL
OLLAMA_URL = "http://127.0.0.1:11434"
VL_MODEL = "qwen2.5vl:7b"
VL_TIMEOUT = 300                 # 秒；第一次要把模型载入显存，会慢一些

# 知识库的语义检索：本地 Ollama 的向量模型（没装就自动退回纯字面匹配）。bge-m3 中英都好，约 1.2GB
EMBED_MODEL = "bge-m3"
EMBED_TIMEOUT = 30               # 秒；第一次要把模型载入显存

# 听音频 / 视频：本地 faster-whisper
WHISPER_MODEL = "large-v3-turbo"
WHISPER_DIR = MODELS_DIR / "whisper"
MAX_MEDIA_MB = 500               # 下载音频的大小上限

# 上网：Playwright 驱动系统自带的 Edge
WEB_CHANNEL = "msedge"
WEB_HEADLESS = True              # 不弹出浏览器窗口（不和屏幕操作抢鼠标键盘）
WEB_VIEWPORT = (1280, 900)
WEB_TEXT_LIMIT = 8000            # 返回给模型的网页正文最多多少字
