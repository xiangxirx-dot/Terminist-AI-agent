"""
屏幕操作：截图（带坐标网格，交给能看图的模型读）、鼠标、键盘、窗口。只用 Windows 自带接口 + Pillow。

坐标约定：工具里用的都是**截图坐标**（截图缩到最宽 SHOT_WIDTH 像素，网格每 GRID 像素一条线），
这里负责换算成真实的屏幕坐标。

紧急停止：把鼠标移到屏幕左上角，之后的每个屏幕操作都会拒绝执行（直到鼠标移开）。
"""

import base64
import ctypes
import io
import sys
import time
from ctypes import wintypes
from pathlib import Path

from . import guard

SHOT_WIDTH = 1280           # 截图最宽多少像素（太大模型看不清、也费 token）
GRID = 100                  # 网格间距（截图像素）

if sys.platform == "win32":
    try:                    # 和界面一样按物理像素算坐标（界面已经设置过的话这里会失败，没关系）
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
    user32 = ctypes.windll.user32
else:
    user32 = None

_state = {"k": 1.0, "size": (0, 0)}       # k：截图坐标 × k = 屏幕坐标


class Abort(Exception):
    pass


# ---------------- 基础 ----------------
def _need_windows():
    if user32 is None:
        raise Abort("屏幕操作目前只支持 Windows")


ROOT_LOCK = Path.home() / ".terminist" / "root_dialog.lock"


def _check():
    """紧急停止：鼠标在左上角就拒绝执行。root 权限的确认弹窗开着时也拒绝（AI 不能自己去点确认）。"""
    _need_windows()
    try:
        if ROOT_LOCK.exists() and time.time() - ROOT_LOCK.stat().st_mtime < 1200:
            raise Abort("root 权限的确认弹窗开着：这时不能操作屏幕，等用户自己确认或取消")
    except OSError:
        pass
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    if pt.x <= 2 and pt.y <= 2:
        raise Abort("用户把鼠标移到了屏幕左上角（紧急停止），不要再操作屏幕，停下来问用户")


def screen_size() -> tuple[int, int]:
    _need_windows()
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)


def _to_screen(x, y) -> tuple[int, int]:
    k = _state["k"]
    return round(float(x) * k), round(float(y) * k)


# ---------------- 截图 ----------------
def capture():
    """截全屏，缩小并画上坐标网格，返回 PIL 图片。"""
    from PIL import ImageDraw, ImageFont, ImageGrab
    _need_windows()
    img = ImageGrab.grab()
    w0, h0 = img.size
    scale = max(1.0, w0 / SHOT_WIDTH)
    if scale > 1:
        img = img.resize((round(w0 / scale), round(h0 / scale)))
    sw, _ = screen_size()
    _state["k"] = scale * sw / w0
    _state["size"] = img.size
    w, h = img.size
    d = ImageDraw.Draw(img, "RGBA")
    try:
        font = ImageFont.truetype("arial.ttf", 13)
    except OSError:
        font = ImageFont.load_default()
    for x in range(0, w, GRID):
        d.line([(x, 0), (x, h)], fill=(255, 0, 0, 60), width=1)
        d.text((x + 2, 1), str(x), fill=(220, 0, 0, 255), font=font, stroke_width=2, stroke_fill=(255, 255, 255, 255))
    for y in range(0, h, GRID):
        d.line([(0, y), (w, y)], fill=(255, 0, 0, 60), width=1)
        d.text((2, y + 1), str(y), fill=(220, 0, 0, 255), font=font, stroke_width=2, stroke_fill=(255, 255, 255, 255))
    return img


LOOK_PROMPT = """你是 Terminist 的眼睛：看用户电脑屏幕的截图，回答问题。
截图上画了红色坐标网格，每 {grid} 像素一条线，上边和左边标了数值；截图大小 {w}×{h}。
提到界面元素（按钮、输入框、图标、菜单、文字）时，给出它**中心点**的坐标 (x, y)，用截图上的网格读数，尽量准。
只描述看到的东西，不要编造；看不清就直说。简洁回答。"""


def look(question: str, client, model: str) -> str:
    """截图转成文字（含截图坐标）。优先用本地 Qwen-VL（屏幕不出本机）；本地模型用不了才交给 model（云端）。"""
    from . import vision
    img = capture()
    w, h = img.size
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=80)
    system = LOOK_PROMPT.format(grid=GRID, w=w, h=h)
    question = question or "屏幕上现在有什么？"
    try:
        text, who = vision.describe(buf.getvalue(), question, system=system), f"本地 {vision.VL_MODEL}"
    except vision.VisionError as e:
        url = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
        resp = client.chat.completions.create(model=model, max_tokens=2000, messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": [{"type": "text", "text": question},
                                         {"type": "image_url", "image_url": {"url": url}}]}])
        text = (resp.choices[0].message.content or "").strip() or "(没有看清)"
        who = f"{model}（本地看图不可用：{e}）"
    return (f"[屏幕截图 {w}×{h}，网格每 {GRID} 像素，由 {who} 看图]\n{text}\n"
            f"（坐标是截图坐标，直接传给 screen_click 等工具）")


FIND_WIDTH = 1232            # Qwen-VL 按 28 像素一格处理图片；宽高取 28 的倍数，坐标不会因为缩放走样


def find(target: str) -> str:
    """用 Qwen-VL 原生的定位能力（输出 bbox）找屏幕上的元素，返回中心点的截图坐标。比 screen_look 准。"""
    hits, ans = locate(target)
    if not hits:
        return f"没有在屏幕上找到「{target}」（模型回答：{ans[:200]}）。可以先 screen_look 看看屏幕上有什么。"
    return f"找到「{target}」（截图坐标，直接传给 screen_click）：\n" + "\n".join(
        f"- 中心点 ({h['x']}, {h['y']})，范围 ({h['box'][0]}, {h['box'][1]})~({h['box'][2]}, {h['box'][3]})"
        + (f"  {h['label']}" if h["label"] else "") for h in hits)


def click_on(target: str, button: str = "left", double: bool = False, type_text: str = "", enter: bool = False) -> str:
    """找到屏幕上的东西直接点（本地看图定位 + 点击，一次做完）；可以顺手输入文字、按回车。没找到不乱点。"""
    _check()
    hits, ans = locate(target)
    if not hits:
        return f"错误: 没有在屏幕上找到「{target}」，没有点（模型回答：{ans[:160]}）。换个说法，或者先 screen_look 看看。"
    h = hits[0]
    done = [click(h["x"], h["y"], button, double)]
    if type_text:                                   # 参数名和下面的 type_text() 函数重名：按模块里的函数取
        time.sleep(0.25)
        done.append(_TYPE(type_text))
    if enter:
        done.append(key("enter"))
    more = f"（还找到 {len(hits) - 1} 个相似的，点的是第一个）" if len(hits) > 1 else ""
    return f"已点「{target}」：截图坐标 ({h['x']}, {h['y']}){more}\n" + "\n".join(done)


WAIT_PROMPT = ("看这张电脑屏幕截图，判断这件事现在是否成立：{cond}\n"
               "第一行只回答「是」或「否」；第二行用一句话说你看到了什么（不超过 40 字）。")


def wait_until(condition: str, timeout: float = 60, interval: float = 2.0, should_stop=None) -> str:
    """在本地盯着屏幕（每 interval 秒截一张给本地看图模型判断），直到 condition 成立或超时。等的时候不调用云端模型。"""
    from . import vision
    _need_windows()
    cond = " ".join(str(condition or "").split())
    if not cond:
        return "错误: condition 写要等的情况，例如「视频开始播放」"
    timeout = max(2.0, min(600.0, float(timeout or 60)))
    t0 = time.time()
    seen, n = "", 0
    while True:
        _check()
        if should_stop and should_stop():
            return f"被停止了（等了 {time.time() - t0:.0f} 秒，最后看到：{seen or '还没看清'}）"
        from PIL import ImageGrab
        img = ImageGrab.grab()
        w0, h0 = img.size
        img = img.resize((896, max(1, round(h0 * 896 / w0))))
        buf = io.BytesIO()
        img.convert("RGB").save(buf, "JPEG", quality=70)
        try:
            ans = vision.describe(buf.getvalue(), WAIT_PROMPT.format(cond=cond),
                                  system="你是屏幕观察员：只按截图判断，简短。")
        except vision.VisionError as e:
            return f"错误: 本地看图模型用不了，没法等（{e}）"
        n += 1
        first, _, rest = ans.strip().partition("\n")
        seen = " ".join((rest or first).split())[:80]
        if first.strip().startswith("是") or first.strip().lower().startswith("yes"):
            return f"等到了：「{cond}」（等了 {time.time() - t0:.0f} 秒，看了 {n} 次）。现在屏幕上：{seen}"
        if time.time() - t0 >= timeout:
            return f"错误: 等了 {timeout:.0f} 秒还没等到「{cond}」（看了 {n} 次），最后看到：{seen}"
        left = timeout - (time.time() - t0)
        end = time.time() + min(interval, left)
        while time.time() < end:                          # 小步睡，停止按钮能及时生效
            if should_stop and should_stop():
                break
            time.sleep(0.2)


def locate(target: str):
    """Qwen-VL 定位：返回 ([{x, y, box, label}]（截图坐标，最多 5 个）, 模型原话)。"""
    import re
    from PIL import ImageGrab
    from . import vision
    _need_windows()
    raw = ImageGrab.grab()
    w0, h0 = raw.size
    fw, fh = FIND_WIDTH, max(28, round(FIND_WIDTH * h0 / w0 / 28) * 28)
    buf = io.BytesIO()
    raw.resize((fw, fh)).convert("RGB").save(buf, "PNG")
    ans = vision.describe(buf.getvalue(), f"Locate {target} in the image, output its bbox coordinates using JSON format.",
                          system="You are a helpful assistant.")
    # 和 capture() 用同一套截图坐标，screen_click 可以直接用
    scale = max(1.0, w0 / SHOT_WIDTH)
    sw, _ = screen_size()
    _state["k"] = scale * sw / w0
    to_shot_x, to_shot_y = w0 / fw / scale, h0 / fh / scale
    hits = []
    for m in re.finditer(r"\[\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*\]", ans):
        x1, y1, x2, y2 = (float(v) for v in m.groups())
        cx, cy = round((x1 + x2) / 2 * to_shot_x), round((y1 + y2) / 2 * to_shot_y)
        label = re.search(r'"label"\s*:\s*"([^"]*)"', ans[m.end():m.end() + 120])
        hits.append({"x": cx, "y": cy, "label": label.group(1) if label else "",
                     "box": (round(x1 * to_shot_x), round(y1 * to_shot_y), round(x2 * to_shot_x), round(y2 * to_shot_y))})
        if len(hits) >= 5:
            break
    return hits, ans


# ---------------- 鼠标 ----------------
_MOUSE = {"left": (0x0002, 0x0004), "right": (0x0008, 0x0010), "middle": (0x0020, 0x0040)}


def click(x, y, button: str = "left", double: bool = False) -> str:
    _check()
    sx, sy = _to_screen(x, y)
    user32.SetCursorPos(sx, sy)
    time.sleep(0.05)
    down, up = _MOUSE.get(button, _MOUSE["left"])
    for _ in range(2 if double else 1):
        user32.mouse_event(down, 0, 0, 0, 0)
        user32.mouse_event(up, 0, 0, 0, 0)
        time.sleep(0.08)
    time.sleep(0.3)
    return f"已{'双击' if double else '点击'}（{button}）截图坐标 ({x}, {y})"


def drag(x1, y1, x2, y2) -> str:
    _check()
    a, b = _to_screen(x1, y1), _to_screen(x2, y2)
    user32.SetCursorPos(*a)
    time.sleep(0.05)
    user32.mouse_event(0x0002, 0, 0, 0, 0)
    for i in range(1, 11):                          # 分几步移过去，有些程序需要看到中间的移动
        user32.SetCursorPos(a[0] + (b[0] - a[0]) * i // 10, a[1] + (b[1] - a[1]) * i // 10)
        time.sleep(0.02)
    user32.mouse_event(0x0004, 0, 0, 0, 0)
    time.sleep(0.3)
    return f"已从 ({x1}, {y1}) 拖到 ({x2}, {y2})"


def scroll(x, y, amount: int) -> str:
    _check()
    user32.SetCursorPos(*_to_screen(x, y))
    user32.mouse_event(0x0800, 0, 0, (int(amount) * 120) & 0xFFFFFFFF, 0)
    time.sleep(0.3)
    return f"已在 ({x}, {y}) 滚动 {amount}（正数向上，负数向下）"


# ---------------- 键盘 ----------------
class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("ki", _KEYBDINPUT), ("mi", _MOUSEINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


def _unicode_key(unit: int):
    arr = (_INPUT * 2)()
    for i, flags in enumerate((0x0004, 0x0004 | 0x0002)):          # KEYEVENTF_UNICODE (+ KEYUP)
        arr[i].type = 1
        arr[i].u.ki = _KEYBDINPUT(0, unit, flags, 0, None)
    user32.SendInput(2, arr, ctypes.sizeof(_INPUT))


VK = {"ctrl": 0x11, "control": 0x11, "shift": 0x10, "alt": 0x12, "win": 0x5B, "enter": 0x0D, "return": 0x0D,
      "tab": 0x09, "esc": 0x1B, "escape": 0x1B, "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "space": 0x20,
      "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27, "home": 0x24, "end": 0x23, "pageup": 0x21,
      "pagedown": 0x22, "insert": 0x2D, **{f"f{i}": 0x6F + i for i in range(1, 13)}}


def type_text(text: str) -> str:
    """输入任意文字（包括中文），换行按回车。"""
    _check()
    for ch in text:
        if ch == "\n":
            user32.keybd_event(0x0D, 0, 0, 0)
            user32.keybd_event(0x0D, 0, 2, 0)
            continue
        data = ch.encode("utf-16-le")
        for i in range(0, len(data), 2):                             # 超出 BMP 的字符是两个 UTF-16 单元
            _unicode_key(int.from_bytes(data[i:i + 2], "little"))
        time.sleep(0.005)
    time.sleep(0.2)
    return f"已输入 {len(text)} 个字符"


def key(combo: str) -> str:
    """按键或组合键，例如 enter、ctrl+s、alt+tab、ctrl+shift+esc。"""
    _check()
    parts = [p for p in combo.lower().replace(" ", "").split("+") if p]
    if not parts:
        return "错误: 没有给按键"
    if any(p in ("delete", "del") for p in parts) and not guard.confirm_delete(
            [f"按下 {combo}（如果选中的是文件，会把它删除）"], "屏幕操作：按 Delete 键"):
        return "用户没有确认，已取消这次按键"
    codes = []
    for p in parts:
        if p in VK:
            codes.append(VK[p])
        elif len(p) == 1:
            codes.append(user32.VkKeyScanW(ord(p)) & 0xFF)
        else:
            return f"错误: 不认识的按键 {p}"
    for c in codes:
        user32.keybd_event(c, 0, 0, 0)
    for c in reversed(codes):
        user32.keybd_event(c, 0, 2, 0)
    time.sleep(0.3)
    return f"已按下 {combo}"


# ---------------- 窗口 ----------------
def _windows() -> list[tuple[int, str]]:
    out = []
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                out.append((hwnd, buf.value))
        return True
    user32.EnumWindows(proc(cb), 0)
    return out


def list_windows() -> str:
    _need_windows()
    wins = _windows()
    return "\n".join(f"- {title}" for _, title in wins[:60]) or "(没有可见窗口)"


def focus(title: str) -> str:
    """把标题里含有 title 的窗口切到最前面。"""
    _check()
    for hwnd, t in _windows():
        if title.lower() in t.lower():
            if user32.IsIconic(hwnd):
                user32.ShowWindow(hwnd, 9)                           # SW_RESTORE
            user32.keybd_event(0x12, 0, 0, 0)                        # 按一下 Alt，绕过前台锁
            user32.keybd_event(0x12, 0, 2, 0)
            user32.SetForegroundWindow(hwnd)
            time.sleep(0.4)
            return f"已切换到窗口：{t}"
    return f"错误: 没有找到标题包含「{title}」的窗口，用 screen_windows 看看有哪些"


_TYPE = type_text                # click_on 的参数也叫 type_text，用这个名字调函数
