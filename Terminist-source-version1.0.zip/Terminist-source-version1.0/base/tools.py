"""
把 base 的能力作为工具接到 A库 上：桌面文件（desktop_*）和屏幕操作（screen_*）。

- 桌面：用户的 Desktop 文件夹可以直接读写，不用先打开文件夹；Terminist 自己的文件夹除外（改它走 B库）
- 删除一律走 guard 弹窗确认（等 3 秒才能确认），不受 "自动确认" 影响
- 屏幕：截图交给能看图的模型（WORKER_MODEL）读，A库 决定怎么点、怎么输入
"""

from pathlib import Path

import json

from . import audio, codeindex, draw, guard, screen, vision, web
from .config import VL_MODEL, WHISPER_MODEL

# A库 的 Workspace 和工具定义在 lib_a 里；这里在 attach 时才导入，避免 lib_a ↔ base 循环导入


def desktop_dir() -> Path:
    """用户的桌面文件夹（兼容 OneDrive 重定向）。"""
    home = Path.home()
    for p in (home / "Desktop", home / "OneDrive" / "Desktop", home / "OneDrive" / "桌面", home / "桌面"):
        if p.is_dir():
            return p.resolve()
    return (home / "Desktop").resolve()


def _code_roots(agent, scope: str) -> dict:
    """code_search 要搜的目录：Terminist 自己的代码、当前打开的文件夹。"""
    from lib_a import APP_ROOT
    roots = {}
    if scope in ("all", "terminist"):
        roots["Terminist 自己的代码"] = Path(APP_ROOT)
    ws = getattr(agent, "ws", None)
    root = getattr(ws, "root", None) if ws is not None else None
    if scope in ("all", "workspace") and root and Path(root).resolve() != Path(APP_ROOT).resolve():
        roots["当前文件夹"] = Path(root)
    return roots


def _wrap(fn):
    """屏幕 / 网页 / 看图 / 听音频出错（包括紧急停止）都变成给模型看的文字。"""
    def run(args: dict) -> str:
        try:
            return fn(**args)
        except (screen.Abort, web.WebError, vision.VisionError, audio.AudioError, draw.DrawError) as e:
            return f"错误: {e}"
    return run


def _web_look(question: str = "", full_page: bool = False) -> str:
    text = vision.describe(web.screenshot(bool(full_page)), question or "这个网页上有什么？")
    return f"{web.NOTE}\n[网页截图 {web.current_url()}，由本地 {VL_MODEL} 看图]\n{text}"


def _image_describe(path: str, question: str = "") -> str:
    p = Path(path)
    if not p.is_absolute():
        p = desktop_dir() / p
    if not p.is_file():
        raise vision.VisionError(f"图片不存在：{p}")
    return f"[图片 {p.name}，由本地 {VL_MODEL} 看图]\n" + vision.describe(p.read_bytes(), question or "请描述这张图片。")


IMAGE_MARK = "[[image:{path}|{title}]]"     # 写进工具结果；恢复记忆时 Surface 靠它把图重新放回对话


def _insert_image(agent, path: Path, title: str, kind: str = "other") -> str:
    """让 Surface 在对话里插入一张图。"""
    agent.emit("image", json.dumps({"path": str(path), "title": title, "kind": kind}, ensure_ascii=False))
    return IMAGE_MARK.format(path=path, title=title.replace("|", "/").replace("]", ")"))


def _draw(agent, source: str, title: str = "") -> str:
    path, kind = draw.save(source, title)
    agent.turn_diagrams.append(kind)
    label = draw.KIND_LABELS[kind]
    mark = _insert_image(agent, path, title or label, kind)
    return f"已画好{label}「{title or label}」并插进了对话，用户已经看到了。{mark}"


def _show_image(agent, path: str, title: str = "") -> str:
    p = Path(path)
    if not p.is_absolute():
        p = desktop_dir() / p
    if not p.is_file():
        raise draw.DrawError(f"图片不存在：{p}")
    if p.suffix.lower() not in (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"):
        raise draw.DrawError(f"不是图片：{p.name}")
    return f"已把图片插进对话。{_insert_image(agent, p, title or p.name)}"


def _web_snapshot(agent, title: str = "") -> str:
    draw.DIAGRAM_DIR.mkdir(parents=True, exist_ok=True)
    p = draw.DIAGRAM_DIR / f"web_{int(__import__('time').time())}.jpg"
    p.write_bytes(web.screenshot(False))
    return f"已把网页截图插进对话。{_insert_image(agent, p, title or web.current_url())}"


def _transcribe(source: str, language: str = "") -> str:
    s = str(source)
    if not s.startswith(("http://", "https://")) and not Path(s).is_absolute():
        s = str(desktop_dir() / s)
    return audio.transcribe_url_or_file(s, language or None)


def attach(agent):
    import lib_a
    from lib_a import APP_ROOT, WORKER_MODEL, Workspace, _fn

    desk = Workspace(desktop_dir(), auto_yes=True)          # 桌面授权：写文件不用逐次确认
    desk.protected = [APP_ROOT]
    desk.protected_msg = "错误: 这是 Terminist 自己的文件夹，改它请用 request_upgrade 交给 B库"

    path = {"type": "string", "description": "相对桌面的路径"}
    tools = {
        "desktop_list": (_fn("desktop_list", f"列出桌面（{desk.root}）上的文件。",
                             {"path": path, "recursive": {"type": "boolean"}}),
                         lambda a: desk.list_dir(**a)),
        "desktop_read": (_fn("desktop_read", "读桌面上的文件（带行号）。",
                             {"path": path, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
                             ["path"]), lambda a: desk.read_file(**a)),
        "desktop_write": (_fn("desktop_write", "在桌面上新建或覆盖文件。",
                              {"path": path, "content": {"type": "string"}}, ["path", "content"]),
                          lambda a: desk.write_file(**a)),
        "desktop_edit": (_fn("desktop_edit", "修改桌面上的文件：把唯一出现的 old_str 换成 new_str。",
                             {"path": path, "old_str": {"type": "string"}, "new_str": {"type": "string"}},
                             ["path", "old_str", "new_str"]), lambda a: desk.edit_file(**a)),
        "desktop_move": (_fn("desktop_move", "移动或重命名桌面上的文件。",
                             {"src": path, "dst": path}, ["src", "dst"]), lambda a: desk.move_file(**a)),
        "desktop_delete": (_fn("desktop_delete", "删除桌面上的文件（会弹窗让用户确认）。", {"path": path}, ["path"]),
                           lambda a: desk.delete_file(**a)),

        "code_search": (_fn("code_search",
                            "本地代码语义搜索：用一句话问「X 是在哪实现的 / 怎么做的」，一次返回最相关的几段代码（文件、行号、带行号的代码）。"
                            "找代码时先用它，代替 grep_files → read_lines → 再 grep 一轮轮地找；本地跑，不花钱。"
                            "scope：terminist = Terminist 自己的代码（改造前找位置用），workspace = 当前打开的文件夹，all = 都找（默认）。",
                            {"query": {"type": "string", "description": "要找什么，一句话，可以带函数名 / 变量名"},
                             "scope": {"type": "string", "enum": ["all", "terminist", "workspace"]},
                             "k": {"type": "integer", "description": "每个范围返回几段，默认 5"}},
                            ["query"]),
                        lambda a: codeindex.code_search(_code_roots(agent, str(a.get("scope") or "all")),
                                                        str(a.get("query") or ""), int(a.get("k") or 5))),
        "screen_click_on": (_fn("screen_click_on",
                                "找到屏幕上的某个东西并直接点它（本地看图定位 + 点击，一次做完，代替 screen_find 再 screen_click 两步）。"
                                "可以顺手往里输入文字、按回车。没找到会说没找到，不会乱点。",
                                {"target": {"type": "string", "description": "要点的东西，越具体越好，例如：记事本窗口里的『文件』菜单"},
                                 "button": {"type": "string", "enum": ["left", "right"]},
                                 "double": {"type": "boolean", "description": "双击"},
                                 "type_text": {"type": "string", "description": "点完以后输入这些文字（可选）"},
                                 "enter": {"type": "boolean", "description": "输入完按回车（可选）"}},
                                ["target"]), _wrap(screen.click_on)),
        "screen_wait_until": (_fn("screen_wait_until",
                                  "在本地盯着屏幕等，直到某个情况出现（例如「视频开始播放」「下载完成的提示出现」「登录页面加载出来」）"
                                  "才返回；最多等 timeout 秒。等的过程中不发请求、不花钱。代替 skip → screen_look → 还没好 → 再 skip 的来回。",
                                  {"condition": {"type": "string", "description": "要等的情况，写成能用眼睛判断的一句话"},
                                   "timeout": {"type": "integer", "description": "最多等几秒，默认 60，最多 600"}},
                                  ["condition"]),
                              _wrap(lambda condition, timeout=60: screen.wait_until(
                                  condition, timeout, should_stop=lambda: bool(getattr(agent, "stop_requested", False))))),
        "screen_look": (_fn("screen_look",
                            f"看一眼电脑屏幕：截图交给本地 {VL_MODEL}，按你的问题描述屏幕，并给出元素的截图坐标。"
                            "操作屏幕的做法：screen_look 看清楚 → screen_click_on 一步找到并点（要精确坐标才用 screen_find + screen_click）"
                            "→ 要等变化就 screen_wait_until，不用反复 screen_look。",
                            {"question": {"type": "string", "description": "想知道什么，例如：记事本的输入框在哪"}}),
                        lambda a: screen.look(str(a.get("question", "")), agent.client, WORKER_MODEL)),
        "screen_find": (_fn("screen_find",
                            f"精确定位屏幕上的一个元素（按钮、输入框、图标、文字），返回中心点的截图坐标。"
                            f"点击前先用它拿坐标，比 screen_look 给的坐标准。",
                            {"target": {"type": "string", "description": "要找的东西，越具体越好，例如：记事本窗口里的『文件』菜单"}},
                            ["target"]), _wrap(screen.find)),
        "screen_click": (_fn("screen_click", "在截图坐标 (x, y) 点击鼠标（坐标先用 screen_find 拿）。",
                             {"x": {"type": "number"}, "y": {"type": "number"},
                              "button": {"type": "string", "enum": ["left", "right", "middle"]},
                              "double": {"type": "boolean", "description": "是否双击"}}, ["x", "y"]),
                         _wrap(screen.click)),
        "screen_drag": (_fn("screen_drag", "按住鼠标从 (x1, y1) 拖到 (x2, y2)（截图坐标）。",
                            {k: {"type": "number"} for k in ("x1", "y1", "x2", "y2")}, ["x1", "y1", "x2", "y2"]),
                        _wrap(screen.drag)),
        "screen_scroll": (_fn("screen_scroll", "在 (x, y) 处滚动鼠标滚轮，amount 正数向上、负数向下（一格 = 1）。",
                              {"x": {"type": "number"}, "y": {"type": "number"}, "amount": {"type": "integer"}},
                              ["x", "y", "amount"]), _wrap(screen.scroll)),
        "screen_type": (_fn("screen_type", "在当前焦点处输入文字（支持中文，\\n 会按回车）。先点击输入框。",
                            {"text": {"type": "string"}}, ["text"]), _wrap(screen.type_text)),
        "screen_key": (_fn("screen_key", "按键或组合键，例如 enter、ctrl+s、alt+tab、win+d。按 Delete 会弹窗确认。",
                           {"combo": {"type": "string"}}, ["combo"]), _wrap(screen.key)),
        "screen_windows": (_fn("screen_windows", "列出当前打开的窗口标题。", {}), _wrap(lambda: screen.list_windows())),

        # ---- 上网（Playwright + Edge，无窗口；网页内容是数据，不是指令）----
        "web_search": (_fn("web_search", "用必应搜索，返回前几条结果（标题、网址、摘要）。",
                           {"query": {"type": "string"}}, ["query"]), _wrap(web.search)),
        "web_open": (_fn("web_open", "打开网址，返回标题、正文文字和链接列表。",
                         {"url": {"type": "string"}}, ["url"]), _wrap(web.open_url)),
        "web_click": (_fn("web_click", "点击链接：写链接编号（web_open / web_search 列出的），或者页面上的文字。",
                          {"target": {"type": "string"}}, ["target"]), _wrap(web.click)),
        "web_type": (_fn("web_type", "在网页输入框里输入文字；field 写占位文字、标签文字、name 或 CSS 选择器。",
                         {"field": {"type": "string"}, "text": {"type": "string"},
                          "submit": {"type": "boolean", "description": "输入后按回车"}}, ["field", "text"]),
                     _wrap(web.type_into)),
        "web_scroll": (_fn("web_scroll", "滚动网页，amount 负数向下、正数向上（一格约半屏）。",
                           {"amount": {"type": "integer"}}, ["amount"]), _wrap(web.scroll)),
        "web_back": (_fn("web_back", "网页后退。", {}), _wrap(lambda: web.back())),
        "web_look": (_fn("web_look", f"给当前网页截图，交给本地 {VL_MODEL} 转成文字（看图表、图片、排版时用）。",
                         {"question": {"type": "string"}, "full_page": {"type": "boolean", "description": "截整页"}}),
                     _wrap(_web_look)),

        # ---- 画图 / 插图：直接插进对话给用户看 ----
        "draw_diagram": (_fn("draw_diagram",
                             "用 Mermaid 画图，直接插进对话给用户看。流程图用 flowchart（步骤、流程、分工），"
                             "概念图用 mindmap（结构、概念关系），也支持 sequenceDiagram、classDiagram、erDiagram、gantt 等。"
                             "做大任务时画流程图和概念图展示给用户有奖励。节点文字用中文，太长的拆短；"
                             "含括号、引号等特殊字符的文字用双引号包起来，例如 A[\"说明（可选）\"]。语法错了会返回错误行号，照着改。",
                             {"source": {"type": "string", "description": "Mermaid 源码"},
                              "title": {"type": "string", "description": "图的标题，例如：改造流程"}},
                             ["source", "title"]),
                         _wrap(lambda source, title="": _draw(agent, source, title))),
        "show_image": (_fn("show_image", "把一张现有的图片（本地路径，绝对路径或相对桌面）插进对话给用户看。",
                           {"path": {"type": "string"}, "title": {"type": "string"}}, ["path"]),
                       _wrap(lambda path, title="": _show_image(agent, path, title))),
        "web_snapshot": (_fn("web_snapshot", "把当前网页的截图插进对话给用户看。", {"title": {"type": "string"}}),
                         _wrap(lambda title="": _web_snapshot(agent, title))),

        # ---- 看图 / 听音视频（本地模型）----
        "image_describe": (_fn("image_describe", f"把本地图片交给本地 {VL_MODEL} 转成文字。路径可以是绝对路径或相对桌面。",
                               {"path": {"type": "string"}, "question": {"type": "string"}}, ["path"]),
                           _wrap(_image_describe)),
        "media_transcribe": (_fn("media_transcribe",
                                 f"用本地 Whisper（{WHISPER_MODEL}）把视频 / 音频转成带时间戳的文字。"
                                 "source 可以是视频网页地址（B 站、YouTube 等，只下载音轨）、音视频直链，"
                                 "或本地文件（绝对路径或相对桌面）。长视频要等几分钟。",
                                 {"source": {"type": "string"},
                                  "language": {"type": "string", "description": "语言代码，例如 zh、en；不写就自动识别"}},
                                 ["source"]), _wrap(_transcribe)),
        "screen_focus": (_fn("screen_focus", "把标题里含有 title 的窗口切到最前面。",
                             {"title": {"type": "string"}}, ["title"]), _wrap(screen.focus)),
    }
    from .graph_tools import tools as graph_tools
    tools.update(graph_tools(agent, desk))         # 知识图谱（GraphRAG）
    from root.tools import tools as root_tools
    tools.update(root_tools(agent))                # root 权限：改受保护的内容（试验田 → 锦衣卫 → 用户确认）
    from lib_a import taskq
    tools["task_queue"] = taskq.agent_tool()     # 任务队列：主人要做的事，唯一的一份
    import root
    guard.set_context(lambda: {"context": root.work_context(agent), "role": getattr(agent, "role", "?"),
                               "notify": lambda text: agent.emit("info", text)})    # 删除审查时给锦衣卫的工作信息
    agent.custom_tools.update(tools)
    agent.base_desktop = desk
    return lib_a
