"""
知识图谱（base/graphrag.py）接到 A库 上的四个工具：graph_ingest / graph_query / graph_inspect / graph_fix。
"""

from .graphrag import MAX_ENTITIES, MAX_RELATIONS, TRUST, graph_for

TEXT_SUFFIXES = {".md", ".txt", ".py", ".json", ".csv", ".html", ".htm", ".js", ".ts", ".yaml", ".yml", ".toml",
                 ".ini", ".cfg", ".log", ".rst", ".tex", ".xml", ".css", ".java", ".c", ".cpp", ".h", ".go", ".rs"}


def _read_source(agent, desk, path: str) -> tuple[str, str]:
    """读要喂进图的文件：先按当前工作区，再按桌面；只读文本文件，最多 2MB。"""
    p = None
    for ws in ([agent.ws] if agent.ws is not None else []) + [desk]:
        try:
            p = ws.resolve(path)
        except ValueError:
            p = None
            continue
        if p.is_file():
            break
    if p is None or not p.is_file():
        raise ValueError(f"找不到文件：{path}（只能读当前工作区或桌面里的文件）")
    if p.suffix.lower() not in TEXT_SUFFIXES:
        raise ValueError(f"只能喂文本文件：{p.name}")
    if p.stat().st_size > 2 * 1024 * 1024:
        raise ValueError(f"文件太大（超过 2MB）：{p.name}，请分段读出来再用 text 喂")
    return p.read_text(encoding="utf-8", errors="replace"), str(p)


def _vec_line(gr) -> str:
    """统计里加一行：语义检索（向量）开了没有、补了多少。"""
    try:
        v = gr.vector_status()
    except Exception:
        return ""
    if not v["available"]:
        return f"\n语义检索（向量）：没开——{v['why_not'] or '本地向量模型不可用'}；现在只按字面 + 扩展词找"
    return f"\n语义检索（向量，{v['model']}）：已开，段落 {v['passages']}、实体 {v['entities']} 有向量"


def tools(agent, desk) -> dict:
    from lib_a import _fn

    def g():
        return graph_for(agent)

    def ingest(a):
        text, path = str(a.get("text") or ""), str(a.get("path") or "")
        source, trust = str(a.get("source") or ""), str(a.get("trust") or "")
        if path:
            try:
                text, full = _read_source(agent, desk, path)
            except ValueError as e:
                return f"错误: {e}"
            source, trust = source or full, trust or "file"
        if not text.strip():
            return "错误: text 和 path 至少给一个"
        trust = trust or ("web" if source.startswith(("http://", "https://")) else "guess")
        if trust not in TRUST:
            return f"错误: trust 只能是 {'/'.join(TRUST)}"
        try:
            s = g().ingest(text, source or "对话", TRUST[trust])
        except RuntimeError as e:
            return f"错误: {e}"
        st = g().stats()
        return (f"已写进知识图谱（来源 {source or '对话'}，可信度 {trust}）：抽了 {s['chunks']} 段"
                + (f"，{s['skipped']} 段以前抽过跳过了" if s["skipped"] else "")
                + f"；实体 新 {s['entities_new']} / 对上已有 {s['entities_matched']}；"
                f"关系 新 {s['relations_new']} / 重复加权 {s['reinforced']} / 取代旧说法 {s['superseded_old']} / "
                f"有争议 {s['disputed']} / 驳回 {s['rejected']}；丢掉泛泛的 {s['dropped']} 个"
                + ("；文件太长，只抽了前面一部分，后面的请分段再喂" if s["truncated"] else "")
                + (f"；清理了 {s['pruned']}" if any(s["pruned"].values()) else "")
                + f"\n图里现在：实体 {st['entities']}、有效关系 {st['relations']}、未裁决冲突 {st['open_conflicts']}"
                + ("（用 graph_inspect view=conflicts 看）" if st["open_conflicts"] else ""))

    def query(a):
        q = str(a.get("question") or "").strip()
        if not q:
            return "错误: question 不能为空"
        gr = g()
        # 主动查：先让快模型把问题扩成近义词 / 相关名字（方案 A），实体种子和原文都用上；
        # 原文同时走字面 + 向量语义（方案 B，本地向量模型装了才有）
        terms = gr.expand(q)
        facts = gr.query(q, str(a.get("mode") or "local"), bool(a.get("history")), terms=terms)
        hits = gr.recall_expanded(q, k=4, min_cover=0.2, terms=terms)
        if hits:
            facts += "\n\n## 相关原文（以前的对话 / 资料，按相关度排；【】里是怎么找到的）\n" + "\n".join(
                f"- [{h['score']}【{h.get('how', '字面')}】] {h['source'] or '未注明来源'}：{h['text']}" for h in hits)
        if terms:
            facts += "\n\n（检索时还用了这些扩展词：" + "、".join(terms) + "）"
        return facts

    def inspect(a):
        view = str(a.get("view") or ("entity" if a.get("entity") else "stats"))
        gr = g()
        if view == "entity":
            return gr.inspect(str(a.get("entity") or ""))
        if view == "conflicts":
            return gr.conflicts("open")
        with gr.lock:
            st = gr.stats()
            top = gr.q("SELECT name, type, mentions FROM entities ORDER BY mentions DESC LIMIT 15")
        return (f"知识图谱（{gr.path.name}）：实体 {st['entities']}（别名 {st['aliases']}）、有效关系 {st['relations']}、"
                f"有争议 {st['disputed']}、历史 {st['history']}、未裁决冲突 {st['open_conflicts']}、关系名 {st['predicates']}、"
                f"抽过的段落 {st['chunks']}；上限：实体 {MAX_ENTITIES}、关系 {MAX_RELATIONS}\n提及最多："
                + ("、".join(f"{r['name']}({r['type']},{r['mentions']})" for r in top) or "（空）")
                + _vec_line(gr))

    def fix(a):
        act = str(a.get("action") or "")
        gr = g()
        with gr.lock:
            def ent(key):
                e = gr.find(str(a.get(key) or ""))
                if e is None:
                    raise ValueError(f"图里没有「{a.get(key)}」")
                return e["id"]
            try:
                if act == "merge":
                    out = gr.merge(ent("into"), ent("entity"))
                elif act == "split":
                    out = gr.split(ent("entity"))
                elif act == "resolve":
                    out = gr.resolve_conflict(int(a.get("conflict") or 0), str(a.get("keep") or ""))
                elif act == "forget":
                    out = gr.forget(ent("entity"))
                elif act in ("pin", "unpin"):
                    out = gr.pin(ent("entity"), act == "pin")
                elif act == "delrel":
                    out = gr.drop_relation(int(a.get("relation") or 0))
                elif act == "reanchor":
                    out = gr.set_anchor(ent("entity"), str(a.get("anchor") or ""))
                else:
                    return "错误: action 只能是 merge / split / resolve / forget / pin / unpin / delrel / reanchor"
            except ValueError as e:
                return f"错误: {e}"
            gr.db.commit()
        return out

    return {
        "graph_ingest": (_fn(
            "graph_ingest",
            "把资料写进知识图谱（GraphRAG）：自动抽实体和关系，同一个东西的不同写法会归到一起，互相矛盾的说法会标出来。"
            "用在值得长期记住、以后要查的结构化知识上：项目 / 代码的结构和约定、文档、网页资料、用户明确说的事实和偏好。"
            "闲聊、一次性的东西不要喂。",
            {"text": {"type": "string", "description": "要写进去的文字（和 path 二选一）"},
             "path": {"type": "string", "description": "或者给一个文本文件：相对当前工作区的路径，没打开文件夹时相对桌面"},
             "source": {"type": "string", "description": "出处，例如文件名、网址、「用户说的」"},
             "trust": {"type": "string", "enum": list(TRUST),
                       "description": "可信度：user=用户亲口说的，file=文件/代码，web=网页，guess=你推测的。冲突时可信度高的说了算"}}),
            ingest),
        "graph_query": (_fn(
            "graph_query",
            "查知识图谱 + 以前的对话原文：找到问题里提到的实体，沿关系扩展两跳，返回有出处的事实（有争议的会标出来），"
            "再附上最相关的几段原文（只带最近 8~14 轮对话，更早聊过的都在这里）。主人提到「之前说过 / 上次那个」而你上下文里没有时先查它。"
            "检索不只看字面：会先把问题扩成近义词 / 相关名字，原文还按意思相近（向量）找，问法和原话对不上也能找到。"
            "问「X 和 Y 什么关系」「X 用了什么」之类具体问题用 local；问「整体讲了什么」「有哪些主题」用 global（带社区摘要）。",
            {"question": {"type": "string"},
             "mode": {"type": "string", "enum": ["local", "global"]},
             "history": {"type": "boolean", "description": "是否带上已被取代 / 驳回的旧说法（查某件事怎么变过来的时候用）"}},
            ["question"]), query),
        "graph_inspect": (_fn(
            "graph_inspect",
            "看知识图谱：view=entity 看一个实体的别名、描述、合并记录和全部关系；view=conflicts 看未裁决的冲突；view=stats 看规模。",
            {"view": {"type": "string", "enum": ["entity", "conflicts", "stats"]},
             "entity": {"type": "string", "description": "view=entity 时的实体名"}}), inspect),
        "graph_fix": (_fn(
            "graph_fix",
            "修知识图谱：merge 把 entity 并进 into（同一个东西被记成了两个）；split 撤销最近一次并进 entity 的合并（并错了）；"
            "resolve 裁决冲突（keep=a 旧的对 / b 新的对 / both 都对）；forget 删掉一个实体；pin / unpin 钉住（不会被清理）；"
            "delrel 按 relation 编号删一条关系；reanchor 重写 entity 的锚点描述为 anchor。"
            "拿不准的冲突先问用户再裁决。",
            {"action": {"type": "string", "enum": ["merge", "split", "resolve", "forget", "pin", "unpin", "delrel", "reanchor"]},
             "entity": {"type": "string"}, "into": {"type": "string"},
             "conflict": {"type": "integer"}, "keep": {"type": "string", "enum": ["a", "b", "both"]},
             "relation": {"type": "integer", "description": "delrel 时要删的关系编号，见 inspect 里关系前的 [#id]"},
             "anchor": {"type": "string", "description": "reanchor 时要写的新锚点描述"}},
            ["action"]), fix),
    }
