"""
GraphRAG 知识图谱：把文字（对话、文件、网页）抽成 实体—关系 图，检索时按图扩展，给 A库 带出有出处的事实。

存储：memory/graph/shared.sqlite，所有角色、所有工作区共用一份（角色的对话记忆各管各的，知识大家共享），SQLite，标准库实现。
原文：写进来的文字原样留在 passages 表里（歌词、台词、原话这类要逐字接得上的东西，图里只有实体关系是不够的），
recall() 按字的二元组做模糊匹配（写法差一个字、只说半句也能对上），返回命中位置前后的原文。
抽取：flash（不思考、JSON 输出）。检索：不调模型（全局模式的社区摘要第一次用时才让 flash 写一次，之后缓存）。

三个老问题和这里的做法：
1) 实体漂移（同一个东西被记成好几个实体 / 一个实体慢慢变成别的东西）
   - 别名表：所有写法（大小写、全半角、空格标点不同）都指向一个规范实体
   - 抽取前先把文本里已经出现的已知实体告诉模型：同一个东西就用已有的名字，从源头少产生新写法
   - 模糊合并有护栏：数字 / 版本号不同的绝不合并（v3 ≠ v4，gui.py ≠ gui2.py）；英文词不同的不自动合并；
     相似但不确定的交给 flash 判断（带两边的描述）；还要和规范名本身够像，防止 A→B→C 的别名链越漂越远
   - 每个实体保留第一次的"锚点描述"，后来的描述只留最近几条，不会被一步步改写成别的意思
   - 合并都有记录，可以撤销（graph_fix split）
2) 关系冲突
   - 关系名归一（已有关系名优先复用，相近的映射过去）
   - 每条关系都是带出处的断言：来源、原文、可信度（用户亲口说 > 文件/代码 > 网页 > 推测）、时间
   - 单值关系（版本、默认值、位于、负责人…）出现不同的值、或者同一句话一个肯定一个否定，就是冲突：
     · 新的可信度更高 / 原文明确说"改成了" / 用户本人说的 → 新的生效，旧的标为已被取代（保留历史，可查）
     · 新的可信度更低 → 新的记为驳回（留档）
     · 一样可信又没说改了 → 两条都标"有争议"，检索时一起带出并标明，等 A库 或用户裁决（graph_fix resolve）
3) 图膨胀
   - 抽取有上限（每段最多 12 个实体、15 条关系），只要具体的专名，泛泛的词（用户、文件、代码…）直接丢
   - 同一段文字不重复抽；同一条关系再出现只加权重，不新增；每条关系最多留 5 条出处
   - 有上限（实体 4000、关系 15000），快到时按 "提及次数 + 连接数 + 时间衰减" 清掉最弱的叶子实体，
     过期的已取代 / 驳回关系也清掉；钉住（pin）的不清
   - 检索时每个实体最多展开最强的几条边，超级节点不会把上下文撑爆；社区摘要只在需要时生成并缓存
"""

import hashlib
import json
import math
import re
import sqlite3
import threading
import time
import unicodedata

from lib_a.config import thinking_off          # 关思考的参数只有 DeepSeek 认，别的接口不带
from pathlib import Path

MAX_ENTITIES = 4000
MAX_RELATIONS = 15000
EVIDENCE_CAP = 5
DESC_KEEP = 3                    # 锚点描述之外，最多留最近几条描述
CHUNK_CHARS = 1500
MAX_CHUNKS = 24                  # 一次最多抽多少段（大文件只抽前面这些，提示 A库 分段再喂）
AUTO_MERGE = 0.9                 # 名字相似度 ≥ 这个且没有数字 / 英文词差异：直接当同一个
ASK_MERGE = 0.55                 # 介于两者之间：问 flash
STALE_DAYS = 30                  # 已取代 / 驳回的关系超过这么多天就清掉
HALF_LIFE_DAYS = 60              # 实体重要性的时间衰减

TRUST = {"user": 3, "file": 2, "web": 1, "guess": 0}
TRUST_NAME = {v: k for k, v in TRUST.items()}
TYPES = ("人", "组织", "项目", "模块", "文件", "工具", "模型", "概念", "地点", "事件", "其他")
_COMPAT = [{"模块", "文件"}, {"工具", "项目"}, {"项目", "模块"}]
GENERIC = {"用户", "主人", "我", "你", "他", "她", "它", "我们", "你们", "他们", "文件", "代码", "问题", "东西", "系统",
           "功能", "程序", "软件", "电脑", "内容", "数据", "信息", "这个", "那个", "时候", "方法", "部分", "结果",
           "user", "file", "code", "it", "this", "that", "system", "thing", "data", "function", "program"}

_PUNCT = re.compile(r"[\s\-_·•.,，。:：;；!！?？'\"“”‘’`()（）\[\]【】{}<>《》/\\|]+")


# ============================================================
# 文本工具
# ============================================================
def norm(s: str) -> str:
    """名字归一：全半角统一、小写、去空格和标点。别名表按这个查。"""
    return _PUNCT.sub("", unicodedata.normalize("NFKC", str(s or "")).casefold())


def _grams(s: str) -> set[str]:
    s = norm(s)
    if len(s) <= 2:
        return {s} if s else set()
    return {s[i:i + 2] for i in range(len(s) - 1)}


def similarity(a: str, b: str) -> float:
    """名字相似度（字符二元组 Jaccard，中英文都适用）。"""
    ga, gb = _grams(a), _grams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def _digits(s: str) -> list[str]:
    return re.findall(r"\d+", unicodedata.normalize("NFKC", str(s)))


def _words(s: str) -> set[str]:
    return set(re.findall(r"[a-z]+", unicodedata.normalize("NFKC", str(s)).casefold()))


def merge_blocked(a: str, b: str) -> bool:
    """数字（版本号、序号）不同的名字绝不合并：v3 和 v4、gui.py 和 gui2.py 是两个东西。"""
    return _digits(a) != _digits(b)


def _types_ok(a: str, b: str) -> bool:
    return a == b or "其他" in (a, b) or any({a, b} <= g for g in _COMPAT)


# 问句里的虚词 / 疑问词：拿问题去找实体时不算词（不然「叫什么」会对上所有标题里带「什么」的东西）
QUERY_STOP = {"什么", "怎么", "为什", "为何", "哪个", "哪里", "哪儿", "那个", "这个", "那只", "这只", "一只", "来着", "一下",
              "是不", "不是", "有没", "没有", "可以", "能不", "知道", "记得", "我家", "我们", "你们", "他们", "是什", "么样",
              "的", "了", "吗", "呢", "么", "什", "怎", "哪", "那", "这", "是", "我", "你", "他", "她", "它", "来", "着",
              "叫", "个", "只", "吧", "啊", "呀", "在", "有", "和", "与", "就", "都", "也", "还", "要", "会", "能", "去",
              "说", "把", "被", "给", "让", "对", "一", "下", "家", "们", "how", "what", "the", "is", "a", "of", "to"}


def _tokens(text: str) -> list[str]:
    t = unicodedata.normalize("NFKC", str(text)).casefold()
    cjk = re.findall(r"[一-鿿]", t)
    return re.findall(r"[a-z0-9_]+", t) + ["".join(cjk[i:i + 2]) for i in range(len(cjk) - 1)] + cjk


def chunks(text: str, size: int = CHUNK_CHARS) -> list[str]:
    """按段落切成大约 size 字的块，段落太长再硬切（带 150 字重叠）。"""
    out, cur = [], ""
    for para in re.split(r"\n\s*\n", str(text)):
        para = para.strip()
        if not para:
            continue
        while len(para) > size:
            if cur:
                out.append(cur)
                cur = ""
            out.append(para[:size])
            para = para[size - 150:]
        if len(cur) + len(para) + 2 > size and cur:
            out.append(cur)
            cur = ""
        cur = (cur + "\n\n" + para).strip()
    if cur:
        out.append(cur)
    return out


def _clip(s, n: int) -> str:
    s = " ".join(str(s or "").split())
    return s if len(s) <= n else s[:n - 1] + "…"


# ============================================================
# 调模型（flash，不思考，JSON）
# ============================================================
EXTRACT_PROMPT = """你从一段文字里抽取知识图谱，只输出 JSON：
{"entities": [{"name": "规范名", "type": "类型", "description": "一句话说明它是什么", "aliases": ["文中别的写法"]}],
 "relations": [{"src": "实体名", "pred": "关系", "dst": "实体名（宾语是实体时）", "value": "宾语是数值/文字时填这里，dst 留空",
                "negated": false, "functional": false, "changed": false, "confidence": 0.8, "quote": "原文依据（30字内）"}]}
规则：
- 只要具体、有名字的东西（人、项目、模块、文件、工具、模型、组织、地点、事件、专有概念）；
  不要泛泛的词（用户、文件、代码、问题、功能、系统、这个…），不要把整句话当实体。最多 12 个实体、15 条关系。
- 类型只能是：人、组织、项目、模块、文件、工具、模型、概念、地点、事件、其他。
- 【已知实体】里有的，同一个东西必须用那里的名字（可以把文中写法放进 aliases）；不确定是不是同一个就另起名字，不要硬套。
- 关系名用简短的中文动词短语；【已有关系名】里意思相同的必须复用原名。
- negated：原文是否定（"不用""没有""不是"）时为 true。
- functional：这个关系对同一个主语只能有一个值（版本是、默认模型是、位于、负责人是、属于…）时为 true；"使用""包含""依赖"之类可以多个的为 false。
- changed：原文明确说变了（改成、换成、升级到、现在是、不再…）时为 true。
- confidence：原文直接说的 0.9，推断出来的 0.5 以下。
- 原文没有的不要编。"""

SAME_PROMPT = """判断每一对是不是同一个东西（同一个人 / 项目 / 文件 / 概念），只输出 JSON：{"same": [true, false, ...]}，顺序和输入一致。
名字像但指不同东西（不同版本、不同文件、同名不同人）要判 false；不确定就判 false。"""

COMMUNITY_PROMPT = """下面是知识图谱里联系紧密的一组实体和它们之间的关系。用 2~4 句中文概括这一组讲的是什么、核心是谁、关键事实是什么。
只根据给的内容，不要编；标了「有争议」的要说明有争议。直接输出概括，不要标题。"""


def _llm_json(client, model: str, system: str, user: str) -> dict:
    last = None
    for _ in range(2):
        try:
            msg = client.chat.completions.create(
                model=model, temperature=0, response_format={"type": "json_object"},
                **thinking_off(),
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            ).choices[0].message
            data = json.loads(msg.content or "{}", strict=False)
            if isinstance(data, dict):
                return data
        except Exception as e:                # 网络 / JSON 坏了：再试一次
            last = e
    raise RuntimeError(f"抽取模型调用失败：{type(last).__name__}: {last}" if last else "抽取模型没返回 JSON")


# ============================================================
# 图
# ============================================================
SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS entities(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT '其他',
  anchor TEXT NOT NULL DEFAULT '', descs TEXT NOT NULL DEFAULT '[]',
  mentions INTEGER NOT NULL DEFAULT 1, pinned INTEGER NOT NULL DEFAULT 0, desc_trust INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS aliases(
  norm TEXT NOT NULL, entity INTEGER NOT NULL, alias TEXT NOT NULL, PRIMARY KEY(norm, entity));
CREATE INDEX IF NOT EXISTS aliases_entity ON aliases(entity);
CREATE TABLE IF NOT EXISTS predicates(
  norm TEXT PRIMARY KEY, name TEXT NOT NULL, uses INTEGER NOT NULL DEFAULT 0, functional INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS relations(
  id INTEGER PRIMARY KEY, src INTEGER NOT NULL, pred TEXT NOT NULL, dst INTEGER, value TEXT,
  objkey TEXT NOT NULL, polarity INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'active', trust INTEGER NOT NULL DEFAULT 1, confidence REAL NOT NULL DEFAULT 0.8,
  weight REAL NOT NULL DEFAULT 1, created REAL NOT NULL, updated REAL NOT NULL, ended REAL, by INTEGER);
CREATE INDEX IF NOT EXISTS rel_src ON relations(src, pred);
CREATE INDEX IF NOT EXISTS rel_dst ON relations(dst);
CREATE TABLE IF NOT EXISTS evidence(rel INTEGER NOT NULL, source TEXT, quote TEXT, ts REAL NOT NULL);
CREATE INDEX IF NOT EXISTS ev_rel ON evidence(rel);
CREATE TABLE IF NOT EXISTS conflicts(
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL, a INTEGER NOT NULL, b INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', note TEXT NOT NULL DEFAULT '', created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS merges(
  id INTEGER PRIMARY KEY, kept INTEGER NOT NULL, gone TEXT NOT NULL, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS chunks(hash TEXT PRIMARY KEY, source TEXT, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS passages(id INTEGER PRIMARY KEY, hash TEXT UNIQUE NOT NULL, text TEXT NOT NULL,
  source TEXT, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS inbox(id INTEGER PRIMARY KEY, hash TEXT UNIQUE NOT NULL, text TEXT NOT NULL,
  source TEXT, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS communities(sig TEXT PRIMARY KEY, members TEXT NOT NULL, summary TEXT NOT NULL, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS vectors(kind TEXT NOT NULL, ref INTEGER NOT NULL, model TEXT NOT NULL, hash TEXT NOT NULL,
  vec BLOB NOT NULL, PRIMARY KEY(kind, ref));
"""

# 语义检索（向量余弦）的门槛，用 bge-m3 在这份知识库上量过（2026-11-03）：
#   段落：换了说法的相关问题 0.571~0.711（中位 0.60），无关问题最高 0.490
#   实体：相关问题 0.561~0.743（中位 0.60），无关问题最高 0.540
SIM_PASSAGE = 0.55               # 原文段落：余弦 ≥ 这个才算语义相关（夹在 0.49 和 0.57 中间）
SIM_ENTITY = 0.56                # 实体：≥ 这个当种子（比名字直接出现弱，只在主动查时扩展用）
SIM_ENTITY_STRONG = 0.60         # 实体：≥ 这个当强种子（和名字直接出现一样，自动检索时会带出相关事实）
EMBED_BATCH = 32
EXPAND_PROMPT = """把用户这句话扩展成一组用来检索知识库的词，只输出 JSON：{"terms": ["词1", "词2", ...]}
- 4~10 个，每个 2~12 个字：同义词、近义说法、相关的具体名字（人名、项目名、文件名、软件名）、上位 / 下位概念
- 用户说的是指代（「那个」「上次那个」「我家猫」）就猜它可能指的具体东西
- 只要名词性的短词，不要整句，不要解释"""


class Graph:
    """一个范围的知识图谱。线程安全（A库 和执行成员可能同时用）。"""

    def __init__(self, path: Path, client=None, model: str = ""):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.path), check_same_thread=False, timeout=15)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        if "desc_trust" not in [r[1] for r in self.db.execute("PRAGMA table_info(entities)")]:   # 旧库补列
            self.db.execute("ALTER TABLE entities ADD COLUMN desc_trust INTEGER NOT NULL DEFAULT 0")
        have = [r[1] for r in self.db.execute("PRAGMA table_info(passages)")]
        for col, ddl in (("importance", "REAL"), ("hits", "INTEGER NOT NULL DEFAULT 0"),
                         ("last_access", "REAL"), ("pinned", "INTEGER NOT NULL DEFAULT 0")):
            if col not in have:                # 记忆的重要性和遗忘曲线（lib_a/memory_keeper.py 用本地小模型打分、整理）
                self.db.execute(f"ALTER TABLE passages ADD COLUMN {col} {ddl}")
        self.trust = TRUST["file"]             # 正在写入的这批资料的可信度（描述只收不比已有来源差的）
        self.lock = threading.RLock()
        self.client, self.model = client, model
        self._index = None                    # 别名二元组倒排索引（写入后作废）
        self._pindex = None                   # 原文二元组倒排索引（写入后作废）
        self._vmats: dict = {}                # 语义检索：{kind: (data_version, model, ids, 归一化矩阵)}
        self._vec_busy = False                # 后台补向量的线程在跑
        self._expanded: dict = {}             # 问题扩展词的缓存（同一句话不重复问模型）

    # ---------------- 基础 ----------------
    def q(self, sql, args=()):
        return self.db.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.db.execute(sql, args).fetchone()

    def entity(self, eid: int):
        return self.one("SELECT * FROM entities WHERE id=?", (eid,))

    def _meta(self, key, default=""):
        r = self.one("SELECT value FROM meta WHERE key=?", (key,))
        return r["value"] if r else default

    def _set_meta(self, key, value):
        self.db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (key, str(value)))

    def _bump(self):
        self._set_meta("version", int(self._meta("version", "0")) + 1)
        self._index = None

    def stats(self) -> dict:
        c = lambda sql: self.one(sql)[0]
        return {"entities": c("SELECT COUNT(*) FROM entities"), "aliases": c("SELECT COUNT(*) FROM aliases"),
                "relations": c("SELECT COUNT(*) FROM relations WHERE status='active'"),
                "disputed": c("SELECT COUNT(*) FROM relations WHERE status='disputed'"),
                "history": c("SELECT COUNT(*) FROM relations WHERE status IN ('superseded','rejected')"),
                "open_conflicts": c("SELECT COUNT(*) FROM conflicts WHERE status='open'"),
                "predicates": c("SELECT COUNT(*) FROM predicates"), "chunks": c("SELECT COUNT(*) FROM chunks")}

    # ---------------- 实体：消歧 / 防漂移 ----------------
    def _alias_index(self):
        if self._index is None:
            idx, names = {}, {}
            for r in self.q("SELECT a.norm, a.entity, a.alias FROM aliases a"):
                names.setdefault(r["entity"], []).append(r["alias"])
                for g in _grams(r["norm"]):
                    idx.setdefault(g, set()).add(r["entity"])
            self._index = (idx, names)
        return self._index

    def _add_alias(self, eid: int, alias: str):
        n = norm(alias)
        if n and len(alias) <= 80:
            self.db.execute("INSERT OR IGNORE INTO aliases VALUES(?,?,?)", (n, eid, alias.strip()))

    def _add_desc(self, eid: int, desc: str):
        desc = _clip(desc, 200)
        if not desc:
            return
        e = self.entity(eid)
        if not e["anchor"]:                   # 第一次的描述是锚点，后来的不覆盖它
            self.db.execute("UPDATE entities SET anchor=?, desc_trust=? WHERE id=?", (desc, self.trust, eid))
            return
        if self.trust < e["desc_trust"]:      # 不如已有来源可信（比如网页 vs 文件）：不让它改写描述，防止被带偏
            return
        self.db.execute("UPDATE entities SET desc_trust=? WHERE id=?", (self.trust, eid))
        descs = json.loads(e["descs"])
        if desc != e["anchor"] and desc not in descs:
            descs = (descs + [desc])[-DESC_KEEP:]
            self.db.execute("UPDATE entities SET descs=? WHERE id=?", (json.dumps(descs, ensure_ascii=False), eid))

    def describe(self, e) -> str:
        descs = json.loads(e["descs"])
        return e["anchor"] + (f"（后来：{descs[-1]}）" if descs and descs[-1] != e["anchor"] else "")

    def candidates(self, name: str, etype: str = "其他", k: int = 5) -> list[tuple[float, int]]:
        """和 name 像的已有实体 [(相似度, id)]。先查别名，再按二元组倒排找。"""
        n = norm(name)
        exact = [r["entity"] for r in self.q("SELECT entity FROM aliases WHERE norm=?", (n,))]
        if exact:
            return [(1.0, e) for e in exact]
        if len(n) <= 2:                       # 太短的名字只认精确匹配（"A库"和"B库"只差一个字）
            return []
        idx, names = self._alias_index()
        pool = set()
        for g in _grams(n):
            pool |= idx.get(g, set())
        out = []
        for eid in pool:
            e = self.entity(eid)
            if e is None or not _types_ok(etype, e["type"]):
                continue
            best = max(similarity(name, a) for a in names.get(eid, [e["name"]]))
            if similarity(name, e["name"]) < 0.4 and best < AUTO_MERGE:   # 只像某个别名、不像规范名：防别名链漂移
                continue
            out.append((best, eid))
        return sorted(out, reverse=True)[:k]

    def resolve(self, items: list[dict], context: set[int]) -> dict[str, int]:
        """把一批抽出来的实体对到图上：{抽取名: 实体 id}。新建 / 归并 / 问 flash 都在这里。"""
        out, ask = {}, []
        now = time.time()
        for it in items:
            name, etype = it["name"], it["type"]
            names = [name] + [a for a in it.get("aliases", []) if a]
            hit = None
            for nm in names:                  # 任何一个写法精确命中别名
                exact = self.candidates(nm, etype, k=10)
                exact = [e for s, e in exact if s >= 1.0]
                if exact:
                    typed = [e for e in exact if _types_ok(etype, self.entity(e)["type"])]
                    pool = typed or exact
                    if not typed and etype != "其他":
                        continue              # 同名但类型对不上（文件 "Terminist" 和项目 "Terminist"）：不算同一个
                    # 同名多个：优先这段话里已经出现过的、提及多的
                    hit = max(pool, key=lambda e: (e in context, self.entity(e)["mentions"]))
                    break
            if hit is None:
                cands = [(s, e) for s, e in self.candidates(name, etype)
                         if not merge_blocked(name, self.entity(e)["name"]) and _types_ok(etype, self.entity(e)["type"])]
                if cands and cands[0][0] >= AUTO_MERGE and _words(name) == _words(self.entity(cands[0][1])["name"]):
                    hit = cands[0][1]
                elif cands and cands[0][0] >= ASK_MERGE:
                    ask.append((it, cands[0][1]))
                    continue
            if hit is None:
                hit = self._new_entity(it, now)
            else:
                self._touch(hit, it, now)
            out[name] = hit
            context.add(hit)
        if ask:                               # 拿不准的一次问完
            same = self._ask_same(ask)
            for (it, eid), yes in zip(ask, same):
                if yes:
                    self._touch(eid, it, now)
                    out[it["name"]] = eid
                else:
                    out[it["name"]] = self._new_entity(it, now)
                context.add(out[it["name"]])
        return out

    def _ask_same(self, pairs) -> list[bool]:
        if self.client is None:
            return [False] * len(pairs)
        lines = []
        for i, (it, eid) in enumerate(pairs, 1):
            e = self.entity(eid)
            lines.append(f"{i}. A「{it['name']}」（{it['type']}）：{_clip(it.get('description'), 100)}\n"
                         f"   B「{e['name']}」（{e['type']}）：{_clip(self.describe(e), 120)}")
        try:
            data = _llm_json(self.client, self.model, SAME_PROMPT, "\n".join(lines))
            same = [bool(x) for x in data.get("same", [])]
        except RuntimeError:
            same = []
        return (same + [False] * len(pairs))[:len(pairs)]

    def _new_entity(self, it: dict, now: float) -> int:
        cur = self.db.execute("INSERT INTO entities(name,type,created,updated) VALUES(?,?,?,?)",
                              (it["name"], it["type"], now, now))
        eid = cur.lastrowid
        for a in [it["name"]] + list(it.get("aliases", [])):
            self._add_alias(eid, a)
        self._add_desc(eid, it.get("description", ""))
        self._index = None
        return eid

    def _touch(self, eid: int, it: dict, now: float):
        self.db.execute("UPDATE entities SET mentions=mentions+1, updated=? WHERE id=?", (now, eid))
        e = self.entity(eid)
        for a in [it["name"]] + list(it.get("aliases", [])):
            if a and not merge_blocked(a, e["name"]):     # 带不同数字的写法不收进别名
                self._add_alias(eid, a)
        if e["type"] == "其他" and it["type"] != "其他":
            self.db.execute("UPDATE entities SET type=? WHERE id=?", (it["type"], eid))
        self._add_desc(eid, it.get("description", ""))
        self._index = None

    def find(self, name: str):
        """按名字找实体（精确别名优先，其次最像的）。"""
        c = self.candidates(name, "其他", k=1)
        return self.entity(c[0][1]) if c and c[0][0] >= ASK_MERGE else None

    def merge(self, keep: int, gone: int) -> str:
        """手动合并：gone 的别名、关系都并到 keep。记录下来可以撤销。"""
        if keep == gone:
            return "是同一个实体"
        a, b = self.entity(keep), self.entity(gone)
        if a is None or b is None:
            return "实体不存在"
        snap = {"entity": dict(b), "aliases": [dict(r) for r in self.q("SELECT * FROM aliases WHERE entity=?", (gone,))],
                "src": [r["id"] for r in self.q("SELECT id FROM relations WHERE src=?", (gone,))],
                "dst": [r["id"] for r in self.q("SELECT id FROM relations WHERE dst=?", (gone,))]}
        for r in snap["aliases"]:
            self._add_alias(keep, r["alias"])
        self.db.execute("DELETE FROM aliases WHERE entity=?", (gone,))
        self.db.execute("UPDATE relations SET src=? WHERE src=?", (keep, gone))
        self.db.execute("UPDATE relations SET dst=?, objkey=? WHERE dst=?", (keep, f"e{keep}", gone))
        self.db.execute("UPDATE entities SET mentions=mentions+?, pinned=MAX(pinned,?) WHERE id=?",
                        (b["mentions"], b["pinned"], keep))
        self._add_desc(keep, b["anchor"])
        self.db.execute("DELETE FROM entities WHERE id=?", (gone,))
        self.db.execute("DELETE FROM relations WHERE src=dst AND src=?", (keep,))   # 合并后自己指向自己的关系没意义
        self._dedupe_relations(keep)
        self.db.execute("INSERT INTO merges(kept,gone,ts) VALUES(?,?,?)",
                        (keep, json.dumps(snap, ensure_ascii=False), time.time()))
        self._bump()
        return f"已把「{b['name']}」并进「{a['name']}」（可以用 split 撤销）"

    def split(self, eid: int) -> str:
        """撤销最近一次并进 eid 的合并。"""
        m = self.one("SELECT * FROM merges WHERE kept=? ORDER BY id DESC LIMIT 1", (eid,))
        if m is None:
            return "这个实体没有合并记录，没法拆"
        snap = json.loads(m["gone"])
        e = snap["entity"]
        self.db.execute("INSERT INTO entities(id,name,type,anchor,descs,mentions,pinned,created,updated) "
                        "VALUES(?,?,?,?,?,?,?,?,?)", (e["id"], e["name"], e["type"], e["anchor"], e["descs"],
                                                      e["mentions"], e["pinned"], e["created"], e["updated"]))
        for r in snap["aliases"]:
            self.db.execute("DELETE FROM aliases WHERE entity=? AND norm=?", (eid, r["norm"]))
            self.db.execute("INSERT OR IGNORE INTO aliases VALUES(?,?,?)", (r["norm"], e["id"], r["alias"]))
        self._add_alias(eid, self.entity(eid)["name"])
        for rid in snap["src"]:
            self.db.execute("UPDATE relations SET src=? WHERE id=? AND src=?", (e["id"], rid, eid))
        for rid in snap["dst"]:
            self.db.execute("UPDATE relations SET dst=?, objkey=? WHERE id=? AND dst=?", (e["id"], f"e{e['id']}", rid, eid))
        self.db.execute("UPDATE entities SET mentions=MAX(1, mentions-?) WHERE id=?", (e["mentions"], eid))
        self.db.execute("DELETE FROM merges WHERE id=?", (m["id"],))
        self._bump()
        return f"已把「{e['name']}」从「{self.entity(eid)['name']}」里拆出来"

    def _dedupe_relations(self, eid: int):
        """合并后可能出现完全一样的关系：留一条，权重加起来。"""
        rows = self.q("SELECT * FROM relations WHERE (src=? OR dst=?) AND status='active' ORDER BY id", (eid, eid))
        seen = {}
        for r in rows:
            key = (r["src"], r["pred"], r["objkey"], r["polarity"])
            if key in seen:
                self.db.execute("UPDATE relations SET weight=weight+? WHERE id=?", (r["weight"], seen[key]))
                self.db.execute("UPDATE evidence SET rel=? WHERE rel=?", (seen[key], r["id"]))
                self.db.execute("DELETE FROM relations WHERE id=?", (r["id"],))
            else:
                seen[key] = r["id"]

    # ---------------- 关系：归一 / 冲突 ----------------
    def predicate(self, name: str, functional: bool) -> tuple[str, bool]:
        """关系名归一：已有的直接用，很像的映射过去（数字不同不映射）。返回 (规范名, 是否单值)。"""
        name = _clip(name, 30)
        n = norm(name)
        r = self.one("SELECT * FROM predicates WHERE norm=?", (n,))
        if r is None:
            best = None
            for p in self.q("SELECT * FROM predicates ORDER BY uses DESC LIMIT 300"):
                s = similarity(name, p["name"])
                if s >= 0.75 and not merge_blocked(name, p["name"]) and (best is None or s > best[0]):
                    best = (s, p)
            if best:
                r = best[1]
                self.db.execute("INSERT OR IGNORE INTO predicates VALUES(?,?,0,0)", (n, r["name"]))    # 只记映射，票数记在原名上
        if r is None:
            self.db.execute("INSERT INTO predicates VALUES(?,?,1,?)", (n, name, 1 if functional else -1))
            return name, functional
        # 单值与否按多数票：functional 列存 "单值票数 - 多值票数"
        vote = 1 if functional else -1
        self.db.execute("UPDATE predicates SET uses=uses+1, functional=functional+? WHERE name=?", (vote, r["name"]))
        f = self.one("SELECT SUM(functional) AS v FROM predicates WHERE name=?", (r["name"],))["v"] or 0
        return r["name"], f > 0

    def assert_relation(self, src: int, pred: str, dst: int | None, value: str, *, negated=False, functional=False,
                        changed=False, confidence=0.8, trust=1, source="", quote="") -> tuple[str, int]:
        """写一条关系断言，返回 (结果, 关系 id)。结果：new / reinforced / superseded_old / rejected / disputed。"""
        now = time.time()
        pred, functional = self.predicate(pred, functional)
        value = _clip(value, 120) if dst is None else None
        objkey = f"e{dst}" if dst is not None else "v:" + norm(value)
        pol = -1 if negated else 1
        same = self.one("SELECT * FROM relations WHERE src=? AND pred=? AND objkey=? AND polarity=? "
                        "AND status IN ('active','disputed')", (src, pred, objkey, pol))
        if same:                              # 同一条事实又出现：只加权重和出处
            self.db.execute("UPDATE relations SET weight=weight+1, updated=?, confidence=MAX(confidence,?), "
                            "trust=MAX(trust,?) WHERE id=?", (now, confidence, trust, same["id"]))
            self._evidence(same["id"], source, quote, now)
            if same["status"] == "disputed":      # 有争议的一方被更可信的来源（或用户本人）再说一次：争议就此解决
                settled = False
                for c in self.q("SELECT * FROM conflicts WHERE status='open' AND (a=? OR b=?)", (same["id"], same["id"])):
                    other = self.one("SELECT * FROM relations WHERE id=?", (c["b"] if c["a"] == same["id"] else c["a"],))
                    if other and (changed or trust > other["trust"] or trust == TRUST["user"]):
                        self.db.execute("UPDATE relations SET status='superseded', ended=?, by=? WHERE id=?",
                                        (now, same["id"], other["id"]))
                        self.db.execute("UPDATE conflicts SET status='resolved', note=note||? WHERE id=?",
                                        ("；更可信的来源又确认了一方，自动裁决", c["id"]))
                        settled = True
                if settled and not self.one("SELECT 1 FROM conflicts WHERE status='open' AND (a=? OR b=?)",
                                            (same["id"], same["id"])):
                    self.db.execute("UPDATE relations SET status='active' WHERE id=?", (same["id"],))
                if settled:
                    self._bump()
                    return "superseded_old", same["id"]
            return "reinforced", same["id"]

        # 和它冲突的：同一主语同一关系、宾语一样但肯定/否定相反；或者单值关系但宾语不同
        rivals = self.q("SELECT * FROM relations WHERE src=? AND pred=? AND status IN ('active','disputed') "
                        "AND ((objkey=? AND polarity<>?) OR (?=1 AND objkey<>? AND polarity=1 AND ?=1))",
                        (src, pred, objkey, pol, int(functional), objkey, pol))
        cur = self.db.execute(
            "INSERT INTO relations(src,pred,dst,value,objkey,polarity,status,trust,confidence,weight,created,updated) "
            "VALUES(?,?,?,?,?,?,'active',?,?,1,?,?)", (src, pred, dst, value, objkey, pol, trust, confidence, now, now))
        rid = cur.lastrowid
        self._evidence(rid, source, quote, now)
        outcome = "new"
        for old in rivals:
            kind = "否定" if old["objkey"] == objkey else "单值"
            if changed or trust > old["trust"] or trust == TRUST["user"]:
                self.db.execute("UPDATE relations SET status='superseded', ended=?, by=? WHERE id=?", (now, rid, old["id"]))
                note = "原文说改了" if changed else "新的更可信" if trust > old["trust"] else "用户本人说的"
                self._conflict(kind, old["id"], rid, "resolved", f"新的生效（{note}），旧的留作历史")
                outcome = "superseded_old"
            elif trust < old["trust"]:
                self.db.execute("UPDATE relations SET status='rejected', ended=?, by=? WHERE id=?", (now, old["id"], rid))
                self._conflict(kind, old["id"], rid, "resolved", "新的可信度更低，驳回")
                return "rejected", rid
            else:
                self.db.execute("UPDATE relations SET status='disputed' WHERE id IN (?,?)", (old["id"], rid))
                self._conflict(kind, old["id"], rid, "open", "一样可信、原文也没说改了，等裁决")
                outcome = "disputed"
        self._bump()
        return outcome, rid

    def _evidence(self, rid: int, source: str, quote: str, now: float):
        self.db.execute("INSERT INTO evidence VALUES(?,?,?,?)", (rid, _clip(source, 200), _clip(quote, 120), now))
        self.db.execute("DELETE FROM evidence WHERE rel=? AND rowid NOT IN "
                        "(SELECT rowid FROM evidence WHERE rel=? ORDER BY ts DESC LIMIT ?)", (rid, rid, EVIDENCE_CAP))

    def _conflict(self, kind, a, b, status, note):
        self.db.execute("INSERT INTO conflicts(kind,a,b,status,note,created) VALUES(?,?,?,?,?,?)",
                        (kind, a, b, status, note, time.time()))

    def resolve_conflict(self, cid: int, keep: str) -> str:
        """裁决一个有争议的冲突：keep = a（旧的）/ b（新的）/ both（都对，比如不是单值关系）。"""
        c = self.one("SELECT * FROM conflicts WHERE id=?", (cid,))
        if c is None:
            return "没有这个冲突"
        now = time.time()
        if keep == "both":
            self.db.execute("UPDATE relations SET status='active' WHERE id IN (?,?)", (c["a"], c["b"]))
            r = self.one("SELECT pred FROM relations WHERE id=?", (c["a"],))
            if r and c["kind"] == "单值":     # 都对说明这个关系其实可以有多个值：以后别再当冲突
                self.db.execute("UPDATE predicates SET functional=-1000 WHERE name=?", (r["pred"],))
        elif keep in ("a", "b"):
            win, lose = (c["a"], c["b"]) if keep == "a" else (c["b"], c["a"])
            self.db.execute("UPDATE relations SET status='active' WHERE id=?", (win,))
            self.db.execute("UPDATE relations SET status='superseded', ended=?, by=? WHERE id=?", (now, win, lose))
        else:
            return "keep 只能是 a / b / both"
        self.db.execute("UPDATE conflicts SET status='resolved', note=note||? WHERE id=?", (f"；裁决：{keep}", cid))
        self._bump()
        return f"冲突 #{cid} 已裁决（{keep}）"

    # ---------------- 写入 ----------------
    def ingest(self, text: str, source: str = "", trust: int = 1) -> dict:
        """抽取一段文字写进图里，返回统计。"""
        stats = {"chunks": 0, "skipped": 0, "entities_new": 0, "entities_matched": 0, "relations_new": 0,
                 "reinforced": 0, "superseded_old": 0, "disputed": 0, "rejected": 0, "dropped": 0, "truncated": False}
        parts = chunks(text)
        if len(parts) > MAX_CHUNKS:
            parts, stats["truncated"] = parts[:MAX_CHUNKS], True
        for part in parts:
            h = hashlib.sha1(norm(part).encode("utf-8")).hexdigest()
            self.keep_text(part, source, h)
            with self.lock:
                if self.one("SELECT 1 FROM chunks WHERE hash=?", (h,)):
                    stats["skipped"] += 1          # 一模一样的内容抽过了
                    continue
                known = self._known_in(part)
                preds = [r["name"] for r in self.q("SELECT name, SUM(uses) u FROM predicates GROUP BY name "
                                                    "ORDER BY u DESC LIMIT 40")]
            user = (f"【已知实体】{'；'.join(known) or '无'}\n【已有关系名】{'、'.join(preds) or '无'}\n"
                    f"【来源】{source or '未注明'}\n【文字】\n{part}")
            data = _llm_json(self.client, self.model, EXTRACT_PROMPT, user)     # 调模型时不占锁
            with self.lock:
                self._apply(data, source, trust, stats)
                self.db.execute("INSERT OR IGNORE INTO chunks VALUES(?,?,?)", (h, _clip(source, 200), time.time()))
                self.db.commit()
            stats["chunks"] += 1
        with self.lock:
            stats["pruned"] = self.prune()
            self.db.commit()
        return stats

    # ---------------- 原文（逐字检索）----------------
    def keep_text(self, text: str, source: str = "", h: str = ""):
        """新记忆先写进缓存带（inbox），记忆库进程（lib_a/memory_keeper.py）慢慢消化：打分后再正式收进记忆库。
        还在缓存带里的照样检索得到。同样的内容只存一次。"""
        text = str(text or "").strip()
        if not text:
            return
        h = h or hashlib.sha1(norm(text).encode("utf-8")).hexdigest()
        with self.lock:
            if self.one("SELECT 1 FROM passages WHERE hash=?", (h,)):
                return
            cur = self.db.execute("INSERT OR IGNORE INTO inbox(hash, text, source, ts) VALUES(?,?,?,?)",
                                  (h, text, _clip(source, 200), time.time()))
            if cur.rowcount:
                self.db.commit()
                self._pindex = None

    def pin_text(self, text: str, source: str = "") -> bool:
        """直接收进记忆库并钉住（10 分、永不遗忘、不参与合并）：人设训练这类主人亲手定的东西，不走缓存带打分。
        已经有同样的一条就只把它钉住。返回 True = 新写进去的。"""
        text = str(text or "").strip()
        if not text:
            return False
        h = hashlib.sha1(norm(text).encode("utf-8")).hexdigest()
        with self.lock:
            self.db.execute("DELETE FROM inbox WHERE hash=?", (h,))
            cur = self.db.execute("INSERT OR IGNORE INTO passages(hash, text, source, ts, importance, pinned) "
                                  "VALUES(?,?,?,?,10,1)", (h, text, _clip(source, 200), time.time()))
            new = bool(cur.rowcount)
            if not new:
                self.db.execute("UPDATE passages SET importance=10, pinned=1 WHERE hash=?", (h,))
            self.db.commit()
            self._pindex = None
        return new

    def inbox_batch(self, n: int = 10) -> list:
        return self.q("SELECT id, hash, text, source, ts FROM inbox ORDER BY id LIMIT ?", (n,))

    def inbox_count(self) -> int:
        return self.one("SELECT COUNT(*) c FROM inbox")["c"]

    def digest(self, row, importance: float, pinned: bool = False):
        """缓存带里的一条消化完：带着重要性正式收进记忆库，从缓存带删掉。"""
        with self.lock:
            self.db.execute("INSERT OR IGNORE INTO passages(hash, text, source, ts, importance, pinned) VALUES(?,?,?,?,?,?)",
                            (row["hash"], row["text"], row["source"], row["ts"],
                             max(0.0, min(10.0, float(importance))), 1 if pinned else 0))
            self.db.execute("DELETE FROM inbox WHERE id=?", (row["id"],))
            self.db.commit()
            self._pindex = None

    @staticmethod
    def _flat(text: str) -> str:
        return _PUNCT.sub("", unicodedata.normalize("NFKC", str(text)).casefold())

    @classmethod
    def _grams2(cls, text: str) -> list[str]:
        t = cls._flat(text)
        return [t[i:i + 2] for i in range(len(t) - 1)] if len(t) > 1 else ([t] if t else [])

    def _passage_index(self):
        with self.lock:
            ver = self.one("PRAGMA data_version")[0]   # 别的进程提交过就会变
            if self._pindex is None or getattr(self, "_pver", None) != ver:
                self._pver = ver
                inv: dict[str, set[int]] = {}
                rows = {r["id"]: (r["text"], r["source"]) for r in self.q("SELECT id, text, source FROM passages")}
                rows.update({-r["id"]: (r["text"], r["source"])          # 缓存带里的用负数编号，消化前也查得到
                             for r in self.q("SELECT id, text, source FROM inbox")})
                for pid, (text, _) in rows.items():
                    for g in set(self._grams2(text)):
                        inv.setdefault(g, set()).add(pid)
                self._pindex = (inv, rows)
            return self._pindex

    def recall(self, query: str, k: int = 2, window: int = 120, min_cover: float = 0.5,
               semantic: bool = True, rehearse: bool = True) -> list[dict]:
        """在原文里找和 query 最像的地方：返回 [{text, source, score, how}]，text 是命中处前后的原文。
        两路一起找：
        - 字面：字二元组按稀有度加权，覆盖率 = 命中的权重 / query 全部权重，不到 min_cover 不算（写法差一个字也能对上）
        - 语义：向量余弦 ≥ SIM_PASSAGE 就算（字面一个都对不上、意思相近也能找到；本地向量模型没装就只走字面）
        how 是「字面」或「语义」；score 取两路里高的那个。"""
        qg = list(dict.fromkeys(self._grams2(query)))
        if not qg:
            return []
        inv, rows = self._passage_index()
        n = max(1, len(rows))
        # 原文里从没出现过的二元组（多半是写法不同的那个字）按「只出现过一次」算权重，不让它比真正罕见的词还重
        idf = {g: math.log(1 + n / (1 + max(1, len(inv.get(g, ()))))) for g in qg}
        total = sum(idf.values()) or 1
        score: dict[int, float] = {}
        for g in qg:
            for pid in inv.get(g, ()):
                score[pid] = score.get(pid, 0) + idf[g]
        cand = {pid: sc / total for pid, sc in score.items()}
        how: dict[int, str] = {}
        if semantic:                              # 语义那一路：意思相近但字对不上的也拿进来
            for pid, sim in self.vector_search("passage", query, k=max(k * 3, 6)):
                if sim >= SIM_PASSAGE and pid in rows and sim > cand.get(pid, 0):
                    cand[pid] = sim
                    how[pid] = "语义"
        out = []
        for pid, cover in sorted(cand.items(), key=lambda x: -x[1])[:k]:
            if cover < min_cover and how.get(pid) != "语义":
                continue
            if pid > 0 and rehearse:              # 缓存带里的还没进记忆库，不算复习
                self._rehearse(pid)
            text, source = rows[pid]
            flat = self._flat(text)
            # 命中的位置取中位数（去掉标点后的位置），按比例映射回原文，前面留一点、后面多留（要接下一句）
            pos = sorted(p for g in qg for p in [flat.find(g)] if p >= 0)
            at = int((pos[len(pos) // 2] if pos else 0) / max(1, len(flat)) * len(text))
            lo, hi = max(0, at - window // 3), min(len(text), at + window)
            out.append({"text": ("…" if lo else "") + text[lo:hi].strip() + ("…" if hi < len(text) else ""),
                        "source": source or "", "score": round(cover, 2), "how": how.get(pid, "字面"), "pid": pid})
        return out

    # ---------------- 语义检索（向量余弦，方案 B）----------------
    @staticmethod
    def _vhash(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()[:16]

    def _vec_items(self, kind: str) -> list[tuple[int, str]]:
        """要算向量的东西：原文段落；实体用「名字（类型）：锚点描述 + 别名」。"""
        if kind == "passage":
            return [(r["id"], r["text"]) for r in self.q("SELECT id, text FROM passages")]
        al: dict[int, list[str]] = {}
        for r in self.q("SELECT entity, alias FROM aliases"):
            al.setdefault(r["entity"], []).append(r["alias"])
        out = []
        for r in self.q("SELECT id, name, type, anchor FROM entities"):
            other = [a for a in al.get(r["id"], []) if a != r["name"]][:4]
            out.append((r["id"], f"{r['name']}（{r['type']}）" + (f"，又叫 {'、'.join(other)}" if other else "")
                        + (f"：{r['anchor']}" if r["anchor"] else "")))
        return out

    def index_vectors(self, limit: int = 512, embedder=None) -> int:
        """给还没有向量（或文字改过 / 换了向量模型）的段落和实体补上向量，删掉已经不存在的。返回这次补了几条。"""
        import numpy as np
        from . import embed as E
        embedder = embedder or E.embed
        model = E.model()
        done = 0
        for kind in ("passage", "entity"):
            with self.lock:
                have = {r["ref"]: (r["hash"], r["model"])
                        for r in self.q("SELECT ref, hash, model FROM vectors WHERE kind=?", (kind,))}
                items = self._vec_items(kind)
                live = {i for i, _ in items}
                gone = [r for r in have if r not in live]
                if gone:
                    self.db.executemany("DELETE FROM vectors WHERE kind=? AND ref=?", [(kind, r) for r in gone])
                    self.db.commit()
                    self._vec_gen = getattr(self, "_vec_gen", 0) + 1
                todo = [(i, t) for i, t in items if have.get(i) != (self._vhash(t), model)][:max(0, limit - done)]
            for b in range(0, len(todo), EMBED_BATCH):        # 算向量不拿锁：慢，别挡住别的检索
                batch = todo[b:b + EMBED_BATCH]
                vecs = embedder([t for _, t in batch])
                with self.lock:
                    self.db.executemany("INSERT OR REPLACE INTO vectors(kind, ref, model, hash, vec) VALUES(?,?,?,?,?)",
                                        [(kind, i, model, self._vhash(t), np.asarray(v, np.float32).tobytes())
                                         for (i, t), v in zip(batch, vecs)])
                    self.db.commit()
                    self._vec_gen = getattr(self, "_vec_gen", 0) + 1
                done += len(batch)
        return done

    def refresh_vectors(self) -> bool:
        """后台补向量（不卡调用方）：向量模型可用、没在补才起线程。返回有没有起线程。"""
        from . import embed as E
        if self._vec_busy or not E.available():
            return False
        self._vec_busy = True

        def run():
            try:
                while self.index_vectors(limit=256):
                    pass
            except Exception:
                pass                                         # 模型被关了之类：下次检索时再试
            finally:
                self._vec_busy = False
        threading.Thread(target=run, daemon=True, name="graph-vectors").start()
        return True

    def _vec_matrix(self, kind: str):
        """(ids, 归一化后的向量矩阵)；库变了才重新读。"""
        import numpy as np
        from . import embed as E
        model = E.model()
        with self.lock:
            key = (self.one("PRAGMA data_version")[0], getattr(self, "_vec_gen", 0), model)
            cached = self._vmats.get(kind)
            if cached and cached[0] == key:
                return cached[1], cached[2]
            rows = self.q("SELECT ref, vec FROM vectors WHERE kind=? AND model=?", (kind, model))
        if not rows:
            ids, mat = np.zeros(0, np.int64), np.zeros((0, 1), np.float32)
        else:
            ids = np.array([r["ref"] for r in rows], np.int64)
            mat = np.stack([np.frombuffer(r["vec"], np.float32) for r in rows])
            mat = mat / np.maximum(np.linalg.norm(mat, axis=1, keepdims=True), 1e-9)
        self._vmats[kind] = (key, ids, mat)
        return ids, mat

    def _query_vec(self, text: str):
        """问题的向量（同一句话只算一次：recall 和 seeds 会连着查）。"""
        import numpy as np
        from . import embed as E
        last = getattr(self, "_qvec", None)
        if last and last[0] == text:
            return last[1]
        v = np.asarray(E.embed([text], timeout=8)[0], np.float32)
        v = v / max(float(np.linalg.norm(v)), 1e-9)
        self._qvec = (text, v)
        return v

    def vector_search(self, kind: str, query: str, k: int = 8) -> list[tuple[int, float]]:
        """按向量余弦找最像的 k 个（kind = passage / entity）：[(id, 相似度)]。向量模型不可用返回空。"""
        from . import embed as E
        if not str(query).strip() or not E.available():
            return []
        self.refresh_vectors()                               # 新写进来的还没向量：后台补，这次先用已有的
        try:
            ids, mat = self._vec_matrix(kind)
            if not len(ids):
                return []
            sims = mat @ self._query_vec(str(query)[:1000])
        except Exception:
            return []
        top = sims.argsort()[::-1][:k]
        return [(int(ids[i]), float(sims[i])) for i in top]

    def vector_status(self) -> dict:
        from . import embed as E
        with self.lock:
            n = {r["kind"]: r["c"] for r in self.q("SELECT kind, count(*) AS c FROM vectors WHERE model=? GROUP BY kind",
                                                  (E.model(),))}
            total = {"passage": self.one("SELECT count(*) FROM passages")[0],
                     "entity": self.one("SELECT count(*) FROM entities")[0]}
        return {"model": E.model(), "available": E.available(), "why_not": E.why_not(),
                "passages": f"{n.get('passage', 0)}/{total['passage']}", "entities": f"{n.get('entity', 0)}/{total['entity']}"}

    # ---------------- 经验（动手前先查：以前怎么做成的、踩过什么坑）----------------
    EXP_SOURCE = re.compile(r"经验|教训|踩坑|流程|规矩|反思|复盘|操练总结|批评")
    EXP_TEXT = re.compile(r"经验|教训|踩坑|坑：|正确流程|规矩|反思|复盘|下次|别再|不要再|必须先")

    def is_experience(self, text: str, source: str = "") -> bool:
        """这段原文是不是「经验」：来源写明是经验 / 教训 / 流程 / 复盘，或者开头就在讲这些。"""
        return bool(self.EXP_SOURCE.search(source or "") or self.EXP_TEXT.search(str(text)[:80]))

    def experience_search(self, query: str, k: int = 3, min_sim: float = 0.45) -> list[dict]:
        """只在「经验」里找和 query 相关的：[{text, source, score, how}]。语义（向量）为主，字面兜底。
        门槛比一般检索低一点：只在经验里挑，任务描述和经验的说法常常差得远。"""
        q = " ".join(str(query).split())[:500]
        if not q:
            return []
        _inv, rows = self._passage_index()
        cand: dict[int, tuple[float, str]] = {}
        for pid, sim in self.vector_search("passage", q, k=60):
            if pid in rows and sim >= min_sim and self.is_experience(*rows[pid]):
                cand[pid] = (sim, "语义")
        # 字面兜底：没装向量模型时只有这一路；刚记下、还在缓存带里（没有向量）的经验也靠它找到
        for h in self.recall(q, k=12, min_cover=0.3, semantic=False, rehearse=False):
            pid = h.get("pid")
            if pid in rows and self.is_experience(*rows[pid]) and h["score"] > cand.get(pid, (0, ""))[0]:
                cand[pid] = (h["score"], "字面")
        out = []
        for pid, (sc, how) in sorted(cand.items(), key=lambda x: -x[1][0])[:k]:
            text, source = rows[pid]
            if pid > 0:
                self._rehearse(pid)
            out.append({"text": _clip(" ".join(text.split()), 400), "source": source or "", "score": round(sc, 2),
                        "how": how})
        return out

    def add_experience(self, text: str, kind: str = "复盘") -> bool:
        """记一条经验（原样存进原文库，来源标成「经验·kind」，以后 experience_search 找得到）。"""
        text = str(text).strip()
        if not text:
            return False
        self.keep_text(text, source=f"经验·{kind}")
        return True

    # ---------------- 问题扩展（方案 A）----------------
    def expand(self, question: str) -> list[str]:
        """让快模型把问题扩成一组近义词 / 相关名字（再拿去做字面匹配）。同一句话缓存；失败返回空。"""
        q = " ".join(str(question).split())[:300]
        if not q or self.client is None:
            return []
        if q in self._expanded:
            return self._expanded[q]
        try:
            data = _llm_json(self.client, self.model, EXPAND_PROMPT, q)
            terms = [" ".join(str(t).split()) for t in (data.get("terms") or []) if isinstance(t, (str, int))]
            terms = [t for t in dict.fromkeys(terms) if 1 < len(t) <= 20 and t not in q][:10]
        except Exception:
            return []
        if len(self._expanded) > 200:
            self._expanded.clear()
        self._expanded[q] = terms
        return terms

    def recall_expanded(self, question: str, k: int = 4, min_cover: float = 0.2, terms=None) -> list[dict]:
        """原文检索 + 扩展词：问题本身照常查（字面 + 语义），再拿每个扩展词做字面匹配，合在一起按分数取前 k。"""
        hits = self.recall(question, k=k, min_cover=min_cover)
        seen = {h["text"] for h in hits}
        terms = self.expand(question) if terms is None else terms
        for t in terms:
            for h in self.recall(t, k=1, min_cover=0.75, semantic=False):   # 扩展词短：要对得很准才算
                if h["text"] not in seen:
                    seen.add(h["text"])
                    hits.append({**h, "how": f"扩展词「{t}」", "score": round(h["score"] * 0.8, 2)})
        hits.sort(key=lambda h: -h["score"])
        return hits[:k]

    # ---------------- 记忆的重要性和遗忘 ----------------
    def _rehearse(self, pid: int):
        """被检索出来用了一次：像复习一遍，强度回满，被想起次数 +1（半衰期跟着变长）。"""
        with self.lock:
            self.db.execute("UPDATE passages SET hits=hits+1, last_access=? WHERE id=?", (time.time(), pid))
            self.db.commit()

    @staticmethod
    def half_life_days(importance: float, hits: int = 0) -> float:
        """半衰期（天）：0 分 3 天，5 分约一个月，9 分约 7 个月；每被想起一次再翻一倍多。10 分永不遗忘。"""
        if importance >= 10:
            return float("inf")
        return 3 * (1.6 ** max(0.0, importance)) * (1 + max(0, hits))

    def retention(self, row, now: float | None = None) -> float:
        """记忆强度 0~1：按遗忘曲线算，从上次被想起（没被想起过就从写入时）开始掉。"""
        if row["pinned"] or row["importance"] is None:
            return 1.0
        h = self.half_life_days(row["importance"], row["hits"])
        if h == float("inf"):
            return 1.0
        days = ((now or time.time()) - (row["last_access"] or row["ts"])) / 86400
        return 0.5 ** (max(0.0, days) / h)

    def unscored(self, limit: int = 20) -> list:
        return self.q("SELECT id, text, source FROM passages WHERE importance IS NULL ORDER BY id LIMIT ?", (limit,))

    def set_importance(self, pid: int, score: float, pinned: bool = False):
        with self.lock:
            self.db.execute("UPDATE passages SET importance=?, pinned=? WHERE id=?",
                            (max(0.0, min(10.0, float(score))), 1 if pinned else 0, pid))
            self.db.commit()

    def memory_rows(self) -> list:
        return self.q("SELECT id, text, source, ts, importance, hits, last_access, pinned FROM passages "
                      "WHERE importance IS NOT NULL")

    def forget_passages(self, ids: list[int]):
        """遗忘：删掉这几条记忆。"""
        if not ids:
            return
        with self.lock:
            self.db.executemany("DELETE FROM passages WHERE id=?", [(i,) for i in ids])
            self.db.commit()
            self._pindex = None

    def merge_memories(self, rows: list, text: str):
        """几条快淡掉的相近记忆合成一条更模糊的：重要性取最高，被想起次数加起来，时间取最近的。"""
        text = str(text or "").strip()
        if not text or len(rows) < 2:
            return
        h = hashlib.sha1(norm(text).encode("utf-8")).hexdigest()
        with self.lock:
            self.db.execute("INSERT OR IGNORE INTO passages(hash, text, source, ts, importance, hits, last_access) "
                            "VALUES(?,?,?,?,?,?,?)",
                            (h, text, rows[0]["source"], max(r["ts"] for r in rows),
                             max(r["importance"] for r in rows), sum(r["hits"] for r in rows),
                             max((r["last_access"] or r["ts"]) for r in rows)))
            self.db.executemany("DELETE FROM passages WHERE id=?", [(r["id"],) for r in rows])
            self.db.commit()
            self._pindex = None

    def _known_in(self, text: str, k: int = 30) -> list[str]:
        """文本里出现了哪些已知实体（按别名子串找），给抽取模型对齐名字用。"""
        t = norm(text)
        idx, names = self._alias_index()
        hits = {}
        for r in self.q("SELECT a.norm, e.id, e.name, e.type, e.mentions FROM aliases a JOIN entities e ON e.id=a.entity"):
            if len(r["norm"]) >= 2 and r["norm"] in t:
                hits[r["id"]] = r
        top = sorted(hits.values(), key=lambda r: -r["mentions"])[:k]
        return [f"{r['name']}（{r['type']}）" for r in top]

    def _apply(self, data: dict, source: str, trust: int, stats: dict):
        self.trust = trust
        ents = []
        for e in (data.get("entities") or [])[:12]:
            if not isinstance(e, dict):
                continue
            name = _clip(e.get("name"), 60)
            n = norm(name)
            if len(n) < 2 and not re.search(r"[一-鿿]", n) or name in GENERIC or n in GENERIC or len(n) > 50:
                stats["dropped"] += 1             # 泛泛的词、单个字母、整句话：不进图
                continue
            etype = e.get("type") if e.get("type") in TYPES else "其他"
            aliases = [_clip(a, 60) for a in (e.get("aliases") or []) if isinstance(a, str) and norm(a) not in GENERIC][:5]
            ents.append({"name": name, "type": etype, "description": e.get("description", ""), "aliases": aliases})
        before = self.one("SELECT COUNT(*) FROM entities")[0]
        ids = self.resolve(ents, set())
        made = self.one("SELECT COUNT(*) FROM entities")[0] - before
        stats["entities_new"] += made
        stats["entities_matched"] += len(ids) - made

        def lookup(name):
            if not name:
                return None
            if name in ids:
                return ids[name]
            e = self.find(name)                   # 关系里提到了实体表里没列的已知实体
            return e["id"] if e else None

        for r in (data.get("relations") or [])[:15]:
            if not isinstance(r, dict) or not r.get("pred"):
                continue
            src = lookup(r.get("src"))
            dst = lookup(r.get("dst")) if r.get("dst") else None
            value = str(r.get("value") or "").strip()
            if src is None or (dst is None and not value) or dst == src:
                stats["dropped"] += 1
                continue
            try:
                conf = max(0.0, min(1.0, float(r.get("confidence", 0.8))))
            except (TypeError, ValueError):
                conf = 0.8
            outcome, _ = self.assert_relation(
                src, str(r["pred"]), dst, value, negated=bool(r.get("negated")), functional=bool(r.get("functional")),
                changed=bool(r.get("changed")), confidence=conf, trust=trust, source=source, quote=r.get("quote", ""))
            stats["relations_new" if outcome == "new" else outcome] += 1
        self._bump()

    # ---------------- 防膨胀 ----------------
    def prune(self) -> dict:
        """清过期历史；超出上限时按重要性清最弱的叶子实体。钉住的不清。"""
        now = time.time()
        cut = now - STALE_DAYS * 86400
        gone = {"history": 0, "entities": 0, "relations": 0}
        old = [r["id"] for r in self.q("SELECT id FROM relations WHERE status IN ('superseded','rejected') AND ended<?", (cut,))]
        for rid in old:
            self._drop_relation(rid)
        gone["history"] = len(old)
        self.db.execute("DELETE FROM conflicts WHERE status='resolved' AND created<?", (cut,))
        self.db.execute("DELETE FROM merges WHERE ts<?", (now - 90 * 86400,))

        n_ent = self.one("SELECT COUNT(*) FROM entities")[0]
        if n_ent > MAX_ENTITIES * 0.95:
            target = n_ent - int(MAX_ENTITIES * 0.8)
            for e in self._weakest(target):
                for r in self.q("SELECT id FROM relations WHERE src=? OR dst=?", (e, e)):
                    self._drop_relation(r["id"])
                self.db.execute("DELETE FROM aliases WHERE entity=?", (e,))
                self.db.execute("DELETE FROM entities WHERE id=?", (e,))
                gone["entities"] += 1
        n_rel = self.one("SELECT COUNT(*) FROM relations")[0]
        if n_rel > MAX_RELATIONS * 0.95:
            # 先清旧的历史，再清权重最低、最久没更新的普通关系
            extra = n_rel - int(MAX_RELATIONS * 0.8)
            rows = self.q("SELECT id FROM relations ORDER BY (status='active') ASC, weight * confidence ASC, updated ASC "
                          "LIMIT ?", (extra,))
            for r in rows:
                self._drop_relation(r["id"])
            gone["relations"] = len(rows)
        if any(gone.values()):
            self._bump()
        return gone

    def _weakest(self, n: int) -> list[int]:
        now = time.time()
        deg = {r["e"]: r["d"] for r in self.q(
            "SELECT e, COUNT(*) d FROM (SELECT src e FROM relations WHERE status='active' "
            "UNION ALL SELECT dst e FROM relations WHERE status='active' AND dst IS NOT NULL) GROUP BY e")}
        scored = []
        for e in self.q("SELECT id, mentions, updated FROM entities WHERE pinned=0"):
            d = deg.get(e["id"], 0)
            if d > 1:                              # 只清叶子（连 0~1 条边的），不把图拆散
                continue
            decay = 0.5 ** ((now - e["updated"]) / 86400 / HALF_LIFE_DAYS)
            scored.append((math.log1p(e["mentions"]) * decay + d * 0.5, e["id"]))
        return [e for _, e in sorted(scored)[:n]]

    def _drop_relation(self, rid: int):
        self.db.execute("DELETE FROM evidence WHERE rel=?", (rid,))
        self.db.execute("DELETE FROM relations WHERE id=?", (rid,))

    def drop_relation(self, rid: int) -> str:
        r = self.one("SELECT * FROM relations WHERE id=?", (rid,))
        if r is None:
            return "关系不存在"
        self._drop_relation(rid)
        self._bump()
        return f"已删掉关系 #{rid}"

    def set_anchor(self, eid: int, text: str) -> str:
        e = self.entity(eid)
        if e is None:
            return "实体不存在"
        text = _clip(text, 200)
        if not text:
            return "锚点描述不能为空"
        self.db.execute("UPDATE entities SET anchor=? WHERE id=?", (text, eid))
        self._bump()
        return f"已把「{e['name']}」的锚点描述改成：{text}"

    def forget(self, eid: int) -> str:
        e = self.entity(eid)
        if e is None:
            return "实体不存在"
        for r in self.q("SELECT id FROM relations WHERE src=? OR dst=?", (eid, eid)):
            self._drop_relation(r["id"])
        self.db.execute("DELETE FROM aliases WHERE entity=?", (eid,))
        self.db.execute("DELETE FROM entities WHERE id=?", (eid,))
        self._bump()
        return f"已从图里删掉「{e['name']}」和它的关系"

    def pin(self, eid: int, on: bool = True) -> str:
        self.db.execute("UPDATE entities SET pinned=? WHERE id=?", (int(on), eid))
        e = self.entity(eid)
        return f"已{'钉住' if on else '取消钉住'}「{e['name']}」（钉住的不会被清理）" if e else "实体不存在"

    # ---------------- 检索 ----------------
    def seeds(self, question: str, k: int = 8, semantic: bool = True) -> dict[int, float]:
        """问题里提到的实体：别名出现在问题里的最优先，其次按名字 / 描述的词命中，再加上语义相近的实体（向量余弦）。
        语义很近（≥ SIM_ENTITY_STRONG）的和名字直接出现一样当强种子（分数 ≥ 2），会带出相关事实。"""
        scores = self._lexical_seeds(question, k)
        if semantic:
            for eid, sim in self.vector_search("entity", question, k=k):
                if sim >= SIM_ENTITY_STRONG:
                    s = 2.0 + (sim - SIM_ENTITY_STRONG)
                elif sim >= SIM_ENTITY:
                    s = 0.5 + sim
                else:
                    continue
                scores[eid] = max(scores.get(eid, 0), s)
        return dict(sorted(scores.items(), key=lambda x: -x[1])[:k])

    def term_seeds(self, terms) -> dict[int, float]:
        """扩展词对上的实体：只认「实体的名字 / 别名就在扩展词里」这种确定的（零碎的字词重合不算，会带出一堆无关的）。
        每个扩展词单独比（拼在一起会凑出假的命中）；分数打八折，排在问题里直接提到的后面。"""
        out: dict[int, float] = {}
        for t in terms or []:
            for eid, s in self._lexical_seeds(t, 3).items():
                if s >= 2.0:
                    out[eid] = max(out.get(eid, 0), s * 0.8)
        return out

    def _lexical_seeds(self, question: str, k: int = 8) -> dict[int, float]:
        """字面：别名出现在问题里的最优先，其次按名字 / 描述的词命中。"""
        qn = norm(question)
        scores: dict[int, float] = {}
        for r in self.q("SELECT a.norm, a.entity FROM aliases a"):
            if len(r["norm"]) >= 2 and r["norm"] in qn:
                scores[r["entity"]] = max(scores.get(r["entity"], 0), 2.0 + len(r["norm"]) / 10)
        qt = set(_tokens(question)) - QUERY_STOP              # 「什么」「那个」这类问句里的虚词不算
        if qt and len(scores) < k:
            rows = self.q("SELECT id, name, anchor, mentions FROM entities")
            df: dict[str, int] = {}
            toks = {}
            for e in rows:
                ts = set(_tokens(e["name"] + " " + e["anchor"]))
                toks[e["id"]] = ts
                for t in ts & qt:
                    df[t] = df.get(t, 0) + 1
            n = max(1, len(rows))
            for e in rows:
                s = sum(math.log(1 + n / df[t]) for t in toks[e["id"]] & qt)
                if s > 0:
                    scores[e["id"]] = max(scores.get(e["id"], 0), s / 10 + math.log1p(e["mentions"]) / 20)
        return dict(sorted(scores.items(), key=lambda x: -x[1])[:k])

    def neighborhood(self, seeds: dict[int, float], hops: int = 2, max_nodes: int = 25, per_node: int = 8,
                     history: bool = False) -> tuple[dict[int, float], list]:
        """从种子实体按边权扩展 hops 跳。每个实体最多走最强的 per_node 条边（超级节点不会把结果撑爆）。"""
        status = "('active','disputed','superseded','rejected')" if history else "('active','disputed')"
        score = dict(seeds)
        frontier = dict(seeds)
        rels = {}
        now = time.time()
        for _ in range(hops):
            nxt = {}
            for e, s in frontier.items():
                rows = self.q(f"SELECT * FROM relations WHERE (src=? OR dst=?) AND status IN {status} "
                              f"ORDER BY (status='active') DESC, weight*confidence DESC, updated DESC LIMIT ?",
                              (e, e, per_node))
                for r in rows:
                    rels[r["id"]] = r
                    other = r["dst"] if r["src"] == e else r["src"]
                    if other is None:
                        continue
                    fresh = 0.5 ** ((now - r["updated"]) / 86400 / HALF_LIFE_DAYS)
                    gain = s * 0.5 * min(1.0, 0.4 + 0.2 * r["weight"]) * r["confidence"] * (0.5 + 0.5 * fresh)
                    if gain > score.get(other, 0):
                        score[other] = gain
                        nxt[other] = gain
            frontier = dict(sorted(nxt.items(), key=lambda x: -x[1])[:max_nodes])
            if not frontier:
                break
        keep = dict(sorted(score.items(), key=lambda x: -x[1])[:max_nodes])
        out = [r for r in rels.values() if r["src"] in keep and (r["dst"] is None or r["dst"] in keep)]
        out.sort(key=lambda r: -(keep.get(r["src"], 0) + keep.get(r["dst"], 0) if r["dst"] else keep.get(r["src"], 0)))
        return keep, out

    def fact_line(self, r, names: dict[int, str]) -> str:
        obj = names.get(r["dst"]) or (self.entity(r["dst"])["name"] if r["dst"] else r["value"])
        neg = "不" if r["polarity"] < 0 else ""
        tag = {"disputed": " ⚠有争议", "superseded": " [已被取代]", "rejected": " [被驳回]"}.get(r["status"], "")
        ev = self.one("SELECT source, quote FROM evidence WHERE rel=? ORDER BY ts DESC LIMIT 1", (r["id"],))
        src = f"｜出处：{_clip(ev['source'], 50)}" + (f"「{_clip(ev['quote'], 40)}」" if ev["quote"] else "") if ev else ""
        return (f"- [#{r['id']}] {names.get(r['src']) or self.entity(r['src'])['name']} {neg}{r['pred']} {obj}{tag}"
                f"（可信度 {TRUST_NAME.get(r['trust'], r['trust'])}，出现 {int(r['weight'])} 次{src}）")

    def query(self, question: str, mode: str = "local", history: bool = False, budget: int = 6000,
              expand: bool = False, terms=None) -> str:
        """expand=True：先让快模型把问题扩成近义词 / 相关名字，扩展词命中的实体也当种子（分数打八折）。"""
        if expand and terms is None:
            terms = self.expand(question)                  # 调模型不拿锁
        seeds = self.seeds(question)                       # 可能要算问题的向量：也不拿锁
        if terms:
            for eid, s in self.term_seeds(terms).items():
                seeds[eid] = max(seeds.get(eid, 0), s)
            seeds = dict(sorted(seeds.items(), key=lambda x: -x[1])[:10])
        with self.lock:
            parts = []
            if seeds:
                nodes, rels = self.neighborhood(seeds, history=history)
                names = {}
                ent_lines = []
                for eid in nodes:
                    e = self.entity(eid)
                    if e is None:
                        continue
                    names[eid] = e["name"]
                    al = [r["alias"] for r in self.q("SELECT alias FROM aliases WHERE entity=? LIMIT 4", (eid,))
                          if r["alias"] != e["name"]]
                    ent_lines.append(f"- {e['name']}（{e['type']}{'，又叫 ' + '、'.join(al[:3]) if al else ''}）："
                                     f"{_clip(self.describe(e), 120)}")
                parts.append("## 相关实体\n" + "\n".join(ent_lines))
                if rels:
                    parts.append("## 相关事实\n" + "\n".join(self.fact_line(r, names) for r in rels[:60]))
                disputed = [r for r in rels if r["status"] == "disputed"]
                if disputed:
                    ids = [r["id"] for r in disputed]
                    cs = self.q(f"SELECT id FROM conflicts WHERE status='open' AND (a IN ({','.join('?' * len(ids))}) "
                                f"OR b IN ({','.join('?' * len(ids))}))", ids + ids)
                    parts.append("注意：标了 ⚠有争议 的是互相矛盾、还没裁决的说法（冲突 "
                                 + "、".join(f"#{c['id']}" for c in cs) + "），回答时要说明有争议。")
        if mode == "global" or not seeds:
            comm = self.community_summaries(question)
            if comm:
                parts.append("## 主题概括（社区摘要）\n" + "\n".join(comm))
        text = "\n\n".join(parts)
        if not text:
            return "知识图谱里没有相关内容（可以先用 graph_ingest 把资料喂进来）"
        return text if len(text) <= budget else text[:budget] + "\n…（后面省略，问得更具体一点）"

    # ---------------- 社区（全局检索用）----------------
    def communities(self) -> list[list[int]]:
        """标签传播分社区（只看有效关系）。"""
        adj: dict[int, dict[int, float]] = {}
        for r in self.q("SELECT src, dst, weight FROM relations WHERE status='active' AND dst IS NOT NULL"):
            for a, b in ((r["src"], r["dst"]), (r["dst"], r["src"])):
                adj.setdefault(a, {})[b] = adj.get(a, {}).get(b, 0) + r["weight"]
        label = {n: n for n in adj}
        for _ in range(10):
            moved = 0
            for n in sorted(adj, key=lambda x: (hash((x, _)) & 0xffff)):
                votes: dict[int, float] = {}
                for m, w in adj[n].items():
                    votes[label[m]] = votes.get(label[m], 0) + w
                best = max(votes, key=lambda l: (votes[l], -l))
                if best != label[n]:
                    label[n], moved = best, moved + 1
            if not moved:
                break
        groups: dict[int, list[int]] = {}
        for n, l in label.items():
            groups.setdefault(l, []).append(n)
        return sorted((sorted(g) for g in groups.values() if len(g) >= 3), key=len, reverse=True)

    def community_summaries(self, question: str, k: int = 4) -> list[str]:
        with self.lock:
            groups = self.communities()[:40]
            if not groups:
                return []
            qt = set(_tokens(question))
            ranked = []
            for g in groups:
                names = [self.entity(e)["name"] for e in g if self.entity(e)]
                hit = len(qt & set(_tokens(" ".join(names))))
                ranked.append((hit, len(g), g, names))
            ranked.sort(key=lambda x: (-x[0], -x[1]))
            cached = {r["sig"]: r for r in self.q("SELECT * FROM communities")}
        out = []
        for hit, size, g, names in ranked[:k]:
            sig = hashlib.sha1(",".join(map(str, g)).encode()).hexdigest()[:16]
            row = cached.get(sig)
            if row is None:                       # 成员和以前某个社区差不多（Jaccard ≥ 0.7）就沿用它的摘要，不重新生成
                gs = set(g)
                for r in cached.values():
                    ms = set(json.loads(r["members"]))
                    if len(gs & ms) / max(1, len(gs | ms)) >= 0.7:
                        row = r
                        break
            if row is None and self.client is not None:
                with self.lock:
                    nodes = {e: 1.0 for e in g}
                    rels = self.q(f"SELECT * FROM relations WHERE status IN ('active','disputed') AND src IN "
                                  f"({','.join('?' * len(g))}) LIMIT 40", g)
                    ids = {e: self.entity(e)["name"] for e in nodes if self.entity(e)}
                    body = "\n".join(self.fact_line(r, ids) for r in rels)
                try:
                    msg = self.client.chat.completions.create(
                        model=self.model, temperature=0, **thinking_off(),
                        messages=[{"role": "system", "content": COMMUNITY_PROMPT},
                                  {"role": "user", "content": f"实体：{'、'.join(names[:30])}\n关系：\n{body}"}]
                    ).choices[0].message
                    summary = (msg.content or "").strip()
                except Exception:
                    summary = ""
                if summary:
                    with self.lock:
                        self.db.execute("INSERT OR REPLACE INTO communities VALUES(?,?,?,?)",
                                        (sig, json.dumps(g), summary, time.time()))
                        n = self.one("SELECT COUNT(*) FROM communities")[0]
                        if n > 60:                # 摘要缓存也有上限
                            self.db.execute("DELETE FROM communities WHERE sig IN (SELECT sig FROM communities "
                                            "ORDER BY ts LIMIT ?)", (n - 60,))
                        self.db.commit()
                    row = {"summary": summary}
            if row is not None:
                out.append(f"- （{size} 个实体：{'、'.join(names[:6])}{'…' if len(names) > 6 else ''}）{row['summary']}")
        return out

    # ---------------- 查看 ----------------
    def inspect(self, name: str, history: bool = True) -> str:
        with self.lock:
            e = self.find(name)
            if e is None:
                return f"图里没有「{name}」"
            al = [r["alias"] for r in self.q("SELECT alias FROM aliases WHERE entity=?", (e["id"],))]
            descs = json.loads(e["descs"])
            lines = [f"# {e['name']}（{e['type']}，id {e['id']}，提及 {e['mentions']} 次{'，已钉住' if e['pinned'] else ''}）",
                     f"别名：{'、'.join(al)}", f"锚点描述：{e['anchor'] or '无'}"]
            if descs:
                lines.append("后来的描述：" + "；".join(descs))
            m = self.q("SELECT gone, ts FROM merges WHERE kept=? ORDER BY id DESC LIMIT 5", (e["id"],))
            if m:
                lines.append("合并进来的：" + "、".join(json.loads(x["gone"])["entity"]["name"] for x in m)
                             + "（split 可以撤销最近一次）")
            st = "('active','disputed','superseded','rejected')" if history else "('active','disputed')"
            rels = self.q(f"SELECT * FROM relations WHERE (src=? OR dst=?) AND status IN {st} "
                          f"ORDER BY status, weight DESC LIMIT 60", (e["id"], e["id"]))
            lines.append(f"关系（{len(rels)} 条）：")
            lines += [self.fact_line(r, {e["id"]: e["name"]}) for r in rels]
            return "\n".join(lines)

    def conflicts(self, status: str = "open", limit: int = 20) -> str:
        with self.lock:
            rows = self.q("SELECT * FROM conflicts WHERE status=? ORDER BY id DESC LIMIT ?", (status, limit))
            if not rows:
                return "没有未裁决的冲突" if status == "open" else "没有冲突记录"
            out = []
            for c in rows:
                a = self.one("SELECT * FROM relations WHERE id=?", (c["a"],))
                b = self.one("SELECT * FROM relations WHERE id=?", (c["b"],))
                if not a or not b:
                    continue
                out.append(f"冲突 #{c['id']}（{c['kind']}，{c['note']}）\n  a(旧) {self.fact_line(a, {})[2:]}\n"
                           f"  b(新) {self.fact_line(b, {})[2:]}")
            return "\n".join(out) + "\n用 graph_fix action=resolve conflict=编号 keep=a/b/both 裁决"


# ============================================================
# 每个范围一份，缓存起来
# ============================================================
_graphs: dict[str, Graph] = {}
_glock = threading.Lock()


def graph_dir() -> Path:
    import lib_a
    return Path(lib_a.MEMORY_DIR) / "graph"


def shared_path() -> Path:
    """知识库全局共用一份。以前按工作区分库：第一次用时把旧库里最大的那份改名接过来（其余留着不动）。"""
    d = graph_dir()
    p = d / "shared.sqlite"
    if not p.exists() and d.is_dir():
        old = sorted(d.glob("*.sqlite"), key=lambda f: f.stat().st_size, reverse=True)
        if old:
            try:
                old[0].rename(p)
            except OSError:
                return old[0]                   # 旧进程还开着它（重启时新窗口先起来）：先接着用旧文件，下次再改名
    return p


def graph_for(agent) -> Graph:
    """所有角色、所有工作区共用一个知识库（角色的对话记忆是各自的，见 lib_a/core.py 的 _switch_role_memory）。"""
    path = shared_path()
    with _glock:
        g = _graphs.get(str(path))
        if g is None:
            from lib_a import WORKER_MODEL
            g = _graphs[str(path)] = Graph(path, agent.client, WORKER_MODEL)
        g.client = agent.client                 # 换过 API key 也跟着换
        return g
