"""
删除确认：任何会删除文件的操作都要经过这里。

先交给锦衣卫（root 库附属的独立 AI，把企图往坏里想）做风险审查：
- 风险「低」且没碰到硬底线：直接放行（文件进回收站，删错了能找回来）
- 其他情况（中 / 高 / 极高、碰到硬底线、锦衣卫出错 / 超时 / 来源不对）：弹窗让用户确认，并附上锦衣卫的原因；
  弹窗等 WAIT_SECONDS 秒后用户才能点确认，用户取消、关窗或者 Agent 被停止都算不同意。
这一步不受 "自动确认" 开关影响。base/ 受保护，B库 改不了。

Surface 用 set_handler 换成自己的弹窗；没有界面时（命令行）在终端里倒计时再问。
工作信息（这一轮的任务、最近的动作、写过的文件）由 base.attach 用 set_context 接上，交给锦衣卫参考。
"""

import ctypes
import re
import sys
import threading
import time
from pathlib import Path

WAIT_SECONDS = 3

_handler = None
_context = None
_lock = threading.Lock()

# 看起来会删除文件的命令（run_command 用）；宁可多问，不能漏
DELETE_COMMAND = re.compile(
    r"(?i)(\brm\b|\brmdir\b|\brd\b|\bdel\b|\berase\b|remove-item|\bunlink\b|os\.remove|os\.unlink|"
    r"shutil\.rmtree|\brmtree\b|\.unlink\(|send2trash|clear-content)")


def set_handler(fn):
    """fn(items: list[str], reason: str, wait: float) -> bool，阻塞到用户做出选择。"""
    global _handler
    _handler = fn


def set_context(fn):
    """fn() -> {"context": dict, "role": str, "notify": callable(text) | None}：给锦衣卫的工作信息。"""
    global _context
    _context = fn


def _review(items: list[str], reason: str) -> dict:
    """问锦衣卫。任何问题都返回「要问用户」。"""
    info = {}
    try:
        info = _context() if _context else {}
    except Exception:
        info = {}
    notify = info.get("notify") or (lambda text: None)
    try:
        notify("[锦衣卫] 正在审查这次删除…")
        import root
        v = root.review_delete(items, reason, info.get("context") or {}, str(info.get("role") or "?"))
    except Exception as e:
        v = {"auto": False, "risk": "未知", "why": f"锦衣卫没能审查（{type(e).__name__}: {e}），交给你决定"}
    notify(f"[锦衣卫] 风险「{v['risk']}」：" + ("直接删（进回收站）" if v["auto"] else "要你确认"))
    return v


def confirm_delete(items: list[str], reason: str = "删除文件") -> bool:
    """先让锦衣卫审，低风险直接放行；否则弹窗确认（附上锦衣卫的原因）。返回 True 才允许删。"""
    items = [str(i) for i in items if str(i)]
    if not items:
        return True
    v = _review(items, reason)
    if v["auto"]:
        return True
    reason = f"{reason}\n锦衣卫风险评级「{v['risk']}」，需要你确认：\n{v['why']}"
    try:
        return bool((_handler or _console)(items, reason, WAIT_SECONDS))
    except Exception:
        return False


def remove(path) -> str:
    """删一个文件：Windows 上送进回收站（删错了能从回收站找回），其他系统直接删。返回说明文字。"""
    p = Path(path)
    if sys.platform == "win32":
        class _Op(ctypes.Structure):
            _fields_ = [("hwnd", ctypes.c_void_p), ("wFunc", ctypes.c_uint), ("pFrom", ctypes.c_wchar_p),
                        ("pTo", ctypes.c_wchar_p), ("fFlags", ctypes.c_ushort), ("fAborted", ctypes.c_int),
                        ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", ctypes.c_wchar_p)]
        # FO_DELETE=3；FOF_ALLOWUNDO(0x40)=进回收站，FOF_NOCONFIRMATION(0x10) | FOF_SILENT(0x4) | FOF_NOERRORUI(0x400)
        op = _Op(None, 3, str(p.resolve()) + "\0", None, 0x40 | 0x10 | 0x4 | 0x400, 0, None, None)
        if ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0 and not op.fAborted and not p.exists():
            return "（已放进回收站）"
    p.unlink()
    return ""


def looks_like_delete(command: str) -> bool:
    return bool(DELETE_COMMAND.search(command or ""))


def _console(items: list[str], reason: str, wait: float) -> bool:
    with _lock:
        print(f"\n\033[31m[确认删除] {reason}：\033[0m")
        for i in items[:30]:
            print(f"\033[31m  - {i}\033[0m")
        if len(items) > 30:
            print(f"\033[31m  ...共 {len(items)} 项\033[0m")
        for s in range(int(wait), 0, -1):
            print(f"\033[33m  {s} 秒后可以确认…\033[0m", end="\r", flush=True)
            time.sleep(1)
        try:
            return input("\n确认删除？(y/N) ").strip().lower() == "y"
        except EOFError:
            return False
