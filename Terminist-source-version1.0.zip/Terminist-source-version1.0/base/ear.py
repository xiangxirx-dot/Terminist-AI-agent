"""
耳朵（管子进程的这一头）：接管模式开了就起 base/ear_worker.py 子进程（录电脑声音 + 每 10 秒转一次文字，写耳朵日志），
暂停 / 继续 / 退出接管时发命令给它；Agent 每做一件事时从日志里取最近的几段。

录音和转写全在子进程里，不占 Agent 进程。日志：~/.terminist/ear/ear-YYYYMMDD.log，
一行一段：「日期 开始~结束 | 听到的话」，没声音是「-」。
"""

import os
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = Path.home() / ".terminist" / "ear"
_state = {"proc": None, "on": False, "paused": False}
_lock = threading.Lock()


def log_path(t: float | None = None) -> Path:
    return LOG_DIR / f"ear-{time.strftime('%Y%m%d', time.localtime(t or time.time()))}.log"


def _send(cmd: str) -> bool:
    p = _state["proc"]
    if p is None or p.poll() is not None:
        return False
    try:
        p.stdin.write((cmd + "\n").encode())
        p.stdin.flush()
        return True
    except OSError:
        return False


def _python() -> str:
    """跑子进程用的 Python：和现在这个一样，但用不弹黑窗口的 pythonw（没有就用原来的，靠 CREATE_NO_WINDOW 不弹窗）。"""
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return str(w if sys.platform == "win32" and w.is_file() else exe)


def _start():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    err = open(LOG_DIR / "ear_worker.err.log", "ab")          # 子进程自己崩了的原因
    flags = 0
    if sys.platform == "win32":
        flags = 0x08000000 | 0x00004000                     # CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    _state["proc"] = subprocess.Popen([_python(), "-m", "base.ear_worker", str(LOG_DIR)], cwd=str(APP_ROOT),
                                      stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=err,
                                      creationflags=flags, env=env)
    err.close()


def set_takeover(on: bool, paused: bool = False) -> None:
    """接管开 / 关 / 暂停：开就起耳朵子进程，暂停 / 继续发命令，关就让它退出（3 秒不退就杀掉）。"""
    with _lock:
        running = _state["proc"] is not None and _state["proc"].poll() is None
        if on:
            if not running:
                try:
                    _start()
                except Exception as e:
                    _state["error"] = f"{type(e).__name__}: {e}"
                    return
                _state["paused"] = False
            if paused != _state["paused"]:
                _send("pause" if paused else "resume")
                _state["paused"] = paused
            _state["on"] = True
            return
        _state["on"] = False
        p = _state["proc"]
        if p is None:
            return
        _send("quit")
        try:
            p.stdin.close()
        except OSError:
            pass

        def reap(proc=p):
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
        threading.Thread(target=reap, daemon=True).start()
        _state["proc"] = None


def _parse(line: str):
    """「2026-11-03 16:00:00.000~16:00:10.000 | 文字」→ (开始, 结束, 文字)。"""
    head, sep, text = line.partition(" | ")
    if not sep:
        return None
    try:
        day, span = head.split(" ", 1)
        a, _, b = span.partition("~")

        def ts(s):
            hms, _, ms = s.partition(".")
            return time.mktime(time.strptime(f"{day} {hms}", "%Y-%m-%d %H:%M:%S")) + int(ms or 0) / 1000
        return ts(a), ts(b or a), text.strip()
    except ValueError:
        return None


def recent(seconds: float = 10.0, now: float | None = None) -> list[tuple[float, float, str]]:
    """和最近 seconds 秒有重叠的那几段（从今天的日志末尾读）。"""
    now = time.time() if now is None else now
    try:
        with open(log_path(now), "rb") as f:
            f.seek(0, 2)
            start = max(0, f.tell() - 16384)
            f.seek(start)
            lines = f.read().decode("utf-8", "replace").splitlines()[1 if start else 0:]   # 从中间读才丢第一行（可能是半行）
    except OSError:
        return []
    out = []
    for ln in lines:
        it = _parse(ln)
        if it and it[1] >= now - seconds and it[0] <= now:
            out.append(it)
    return out


def _hm(t: float) -> str:
    return time.strftime("%H:%M:%S", time.localtime(t))


def recent_text(seconds: float = 10.0, now: float | None = None) -> str:
    """给 Agent 看的耳朵日志：最近 seconds 秒（耳朵 10 秒一段，所以至少带上最新的一段）。"""
    now = time.time() if now is None else now
    rows = recent(seconds, now)
    if not rows:
        rows = recent(25, now)[-1:]                          # 这 10 秒还没切完：带上最近一段
    if not rows:
        if not _state["on"]:
            return "（耳朵没开）"
        return "（耳朵刚开，第一段 10 秒还没听完）"
    return "（10 秒一段，「-」= 这段没声音）\n" + "\n".join(
        f"{_hm(a)}~{_hm(b)} {text}" if b - a > 1 else f"{_hm(a)} {text}" for a, b, text in rows)


def status() -> dict:
    p = _state["proc"]
    return {"on": _state["on"], "paused": _state["paused"], "running": p is not None and p.poll() is None,
            "pid": p.pid if p is not None else None, "log": str(log_path()), "error": _state.get("error", "")}
