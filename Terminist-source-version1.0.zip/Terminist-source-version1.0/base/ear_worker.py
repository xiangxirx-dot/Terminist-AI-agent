"""
耳朵（子进程本体）：一直录电脑正在放的声音（WASAPI 回环，不是麦克风），每 10 秒切一段，
没声音记「-」，有声音交给本地 faster-whisper 转文字，写进耳朵日志（带这段的起止时间）。

单独跑在一个子进程里：录音、转写都在这边，不占 Agent 进程的时间、内存和 GIL。
用法（base/ear.py 起它）：python -m base.ear_worker <日志目录>
标准输入收命令：pause / resume / quit；标准输入断了（父进程没了）就自己退出。
只用 Windows 自带的 WASAPI（ctypes 调），不需要额外装录音库。
"""

import ctypes
import queue
import sys
import threading
import time
import traceback
import uuid
from ctypes import wintypes
from pathlib import Path

CHUNK_SECONDS = 10.0
SILENCE_RMS = 0.004            # 这段的音量（均方根，满幅 = 1）低于它算没声音
TARGET_RATE = 16000            # Whisper 要的采样率
MAX_BACKLOG = 6                # 转写跟不上时最多排几段（1 分钟），再多就跳过最老的
LANG = None                    # None = 自动识别语言

_paused = threading.Event()
_quit = threading.Event()
_chunks: "queue.Queue" = queue.Queue()
_log_dir = Path.home() / ".terminist" / "ear"


# ---------------- 日志 ----------------
def _stamp(t: float) -> str:
    return time.strftime("%H:%M:%S", time.localtime(t)) + f".{int(t * 1000) % 1000:03d}"


def write(t0: float, t1: float, text: str):
    """一行：日期 起~止 | 内容。"""
    try:
        _log_dir.mkdir(parents=True, exist_ok=True)
        day = time.strftime("%Y%m%d", time.localtime(t0))
        line = f"{time.strftime('%Y-%m-%d', time.localtime(t0))} {_stamp(t0)}~{_stamp(t1)} | {' '.join(str(text).split())}\n"
        with open(_log_dir / f"ear-{day}.log", "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


# ---------------- WASAPI 回环录音（ctypes 调 COM）----------------
class _GUID(ctypes.Structure):
    _fields_ = [("d1", ctypes.c_uint32), ("d2", ctypes.c_uint16), ("d3", ctypes.c_uint16), ("d4", ctypes.c_ubyte * 8)]


def _guid(s):
    u = uuid.UUID(s)
    return _GUID(u.fields[0], u.fields[1], u.fields[2], (ctypes.c_ubyte * 8)(*u.bytes[8:]))


CLSID_MMDeviceEnumerator = _guid("BCDE0395-E52F-467C-8E3D-C4579291692E")
IID_IMMDeviceEnumerator = _guid("A95664D2-9614-4F35-A746-DE8DB63617E6")
IID_IAudioClient = _guid("1CB9AD4C-DBFA-4C32-B178-C2F568A703B2")
IID_IAudioCaptureClient = _guid("C8ADBD64-E71E-48A0-A4DE-185C395CD317")
FLOAT_SUBTYPE = uuid.UUID("00000003-0000-0010-8000-00aa00389b71")


def _com(obj, index, argtypes, *args):
    """调 COM 接口第 index 个方法（0~2 是 IUnknown）。失败抛 OSError。"""
    vtbl = ctypes.cast(ctypes.cast(obj, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
    fn = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *argtypes)(vtbl[index])
    hr = fn(obj, *args)
    if hr < 0:
        raise OSError(f"WASAPI 调用失败（方法 {index}，HRESULT 0x{hr & 0xFFFFFFFF:08X}）")
    return hr


def _release(obj):
    if obj:
        try:
            vtbl = ctypes.cast(ctypes.cast(obj, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
            ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])(obj)
        except Exception:
            pass


class Loopback:
    """默认播放设备的回环录音：read() 返回这段时间新录到的单声道 float32 采样（numpy），没放声音时返回空。"""

    def __init__(self):
        import numpy as np
        self.np = np
        ole32 = ctypes.windll.ole32
        ole32.CoInitializeEx(None, 0)                       # COINIT_MULTITHREADED
        self.enum = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(ctypes.byref(CLSID_MMDeviceEnumerator), None, 0x17,
                                    ctypes.byref(IID_IMMDeviceEnumerator), ctypes.byref(self.enum))
        if hr < 0:
            raise OSError(f"创建音频设备枚举器失败 0x{hr & 0xFFFFFFFF:08X}")
        self.device = ctypes.c_void_p()
        _com(self.enum, 4, [ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)],
             0, 0, ctypes.byref(self.device))               # GetDefaultAudioEndpoint(eRender, eConsole)
        self.client = ctypes.c_void_p()
        _com(self.device, 3, [ctypes.POINTER(_GUID), wintypes.DWORD, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)],
             ctypes.byref(IID_IAudioClient), 0x17, None, ctypes.byref(self.client))   # Activate
        pfmt = ctypes.c_void_p()
        _com(self.client, 8, [ctypes.POINTER(ctypes.c_void_p)], ctypes.byref(pfmt))   # GetMixFormat
        raw = ctypes.string_at(pfmt, 40)
        tag = int.from_bytes(raw[0:2], "little")
        self.channels = int.from_bytes(raw[2:4], "little")
        self.rate = int.from_bytes(raw[4:8], "little")
        self.block = int.from_bytes(raw[12:14], "little")
        self.bits = int.from_bytes(raw[14:16], "little")
        self.is_float = tag == 3 or (tag == 0xFFFE and uuid.UUID(bytes_le=raw[24:40]) == FLOAT_SUBTYPE)
        _com(self.client, 3, [ctypes.c_int, wintypes.DWORD, ctypes.c_longlong, ctypes.c_longlong, ctypes.c_void_p,
                              ctypes.c_void_p],
             0, 0x00020000, 10_000_000, 0, pfmt, None)      # Initialize(共享, 回环, 1 秒缓冲)
        ctypes.windll.ole32.CoTaskMemFree(pfmt)
        self.capture = ctypes.c_void_p()
        _com(self.client, 14, [ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)],
             ctypes.byref(IID_IAudioCaptureClient), ctypes.byref(self.capture))        # GetService
        _com(self.client, 10, [])                           # Start

    def read(self):
        np = self.np
        parts = []
        n = ctypes.c_uint32(0)
        _com(self.capture, 5, [ctypes.POINTER(ctypes.c_uint32)], ctypes.byref(n))     # GetNextPacketSize
        while n.value:
            data, frames, flags = ctypes.c_void_p(), ctypes.c_uint32(0), wintypes.DWORD(0)
            _com(self.capture, 3, [ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint32),
                                   ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p, ctypes.c_void_p],
                 ctypes.byref(data), ctypes.byref(frames), ctypes.byref(flags), None, None)   # GetBuffer
            count = frames.value
            if count:
                if flags.value & 0x2 or not data:            # AUDCLNT_BUFFERFLAGS_SILENT
                    parts.append(np.zeros(count, np.float32))
                else:
                    buf = ctypes.string_at(data, count * self.block)
                    if self.is_float and self.bits == 32:
                        a = np.frombuffer(buf, np.float32)
                    elif self.bits == 16:
                        a = np.frombuffer(buf, np.int16).astype(np.float32) / 32768.0
                    elif self.bits == 32:
                        a = np.frombuffer(buf, np.int32).astype(np.float32) / 2147483648.0
                    else:
                        a = np.zeros(count * self.channels, np.float32)
                    parts.append(a.reshape(-1, self.channels).mean(axis=1))
            _com(self.capture, 4, [ctypes.c_uint32], count)  # ReleaseBuffer
            _com(self.capture, 5, [ctypes.POINTER(ctypes.c_uint32)], ctypes.byref(n))
        return np.concatenate(parts) if parts else np.zeros(0, np.float32)

    def close(self):
        try:
            _com(self.client, 11, [])                       # Stop
        except Exception:
            pass
        for obj in (self.capture, self.client, self.device, self.enum):
            _release(obj)


# ---------------- 录音线程：每 10 秒切一段 ----------------
def record(make_source=Loopback):
    """一直录；每 CHUNK_SECONDS 秒（按墙上时间切）把这段放进队列。没放声音的那几秒按静音补齐。"""
    import numpy as np
    src = None
    while not _quit.is_set():
        if src is None:
            try:
                src = make_source()
            except Exception as e:
                now = time.time()
                write(now, now, f"（耳朵打不开录音：{type(e).__name__}: {e}，5 秒后再试）")
                _quit.wait(5)
                continue
        t0 = time.time()
        got = []
        broken = False
        while not _quit.is_set() and time.time() - t0 < CHUNK_SECONDS:
            if _paused.is_set():
                break
            try:
                got.append(src.read())
            except Exception:                               # 换了播放设备（插耳机）之类：重开
                broken = True
                break
            _quit.wait(0.02)
        t1 = time.time()
        if broken:
            try:
                src.close()
            except Exception:
                pass
            src = None
        if _paused.is_set():
            while _paused.is_set() and not _quit.is_set():
                _quit.wait(0.2)
            if src is not None:
                try:
                    src.read()                              # 丢掉暂停期间攒下的
                except Exception:
                    pass
            continue
        audio = np.concatenate(got) if got else np.zeros(0, np.float32)
        rate = getattr(src, "rate", 48000) if src is not None else 48000
        want = int((t1 - t0) * rate)
        if len(audio) < want:                               # 没放声音时 WASAPI 不给数据：补成静音
            audio = np.concatenate([audio, np.zeros(want - len(audio), np.float32)])
        while _chunks.qsize() >= MAX_BACKLOG:               # 转写跟不上：跳过最老的
            try:
                a0, a1, _a, _r = _chunks.get_nowait()
                write(a0, a1, "（来不及转写，跳过这段）")
            except queue.Empty:
                break
        _chunks.put((t0, t1, audio, rate))
    if src is not None:
        src.close()


# ---------------- 转写线程 ----------------
def resample(audio, rate):
    import numpy as np
    if rate == TARGET_RATE or not len(audio):
        return audio.astype(np.float32)
    n = int(len(audio) * TARGET_RATE / rate)
    x = np.linspace(0, len(audio) - 1, n)
    return np.interp(x, np.arange(len(audio)), audio).astype(np.float32)


def load_model():
    """本地 faster-whisper（和语音输入用的同一个模型，不重新下载）：先试显卡，不行用 CPU。"""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from base.config import WHISPER_DIR, WHISPER_MODEL
    from faster_whisper import WhisperModel
    last = None
    for device, compute in (("cuda", "float16"), ("cuda", "int8_float16"), ("cpu", "int8")):
        try:
            return WhisperModel(WHISPER_MODEL, device=device, compute_type=compute, download_root=str(WHISPER_DIR)), device
        except Exception as e:
            last = e
    raise RuntimeError(f"Whisper 加载失败：{last}")


HALLUCINATIONS = ("请不吝点赞", "订阅 转发", "打赏支持明镜", "字幕由", "谢谢观看", "Thank you for watching",
                  "字幕志愿者", "中文字幕")


def hear(model, audio16) -> str:
    """一段 16kHz 音频 → 文字；有声音但没人说话（音乐 / 噪音）返回空串。"""
    segs, _info = model.transcribe(audio16, language=LANG, vad_filter=True, beam_size=3,
                                   condition_on_previous_text=False)
    text = " ".join(s.text.strip() for s in segs if s.no_speech_prob < 0.7).strip()
    if text and any(h in text for h in HALLUCINATIONS) and len(text) < 40:
        return ""                                           # Whisper 在没人说话时常编的几句
    return text


def transcribe_loop(model_loader=load_model, hear_fn=hear):
    import numpy as np
    model, device = None, ""
    while not _quit.is_set():
        try:
            t0, t1, audio, rate = _chunks.get(timeout=0.3)
        except queue.Empty:
            continue
        rms = float(np.sqrt(np.mean(np.square(audio)))) if len(audio) else 0.0
        if rms < SILENCE_RMS:
            write(t0, t1, "-")
            continue
        try:
            if model is None:
                model, device = model_loader()
            text = hear_fn(model, resample(audio, rate))
            write(t0, t1, text if text else "（有声音，但没听出人说话：可能是音乐 / 音效）")
        except Exception as e:
            write(t0, t1, f"（有声音，但转写出错：{type(e).__name__}: {str(e)[:120]}）")


# ---------------- 命令 ----------------
def commands(stream=None):
    stream = stream or sys.stdin
    for line in stream:
        cmd = line.strip().lower()
        if cmd == "pause":
            _paused.set()
            write(time.time(), time.time(), "（耳朵暂停）")
        elif cmd == "resume":
            _paused.clear()
            write(time.time(), time.time(), "（耳朵继续）")
        elif cmd == "quit":
            break
    _quit.set()                                             # 收到 quit，或者父进程没了（标准输入断了）


def main(argv):
    global _log_dir
    if len(argv) > 1:
        _log_dir = Path(argv[1])
    if sys.platform != "win32":
        write(time.time(), time.time(), "（耳朵只支持 Windows）")
        return 1
    import numpy  # noqa: F401  先在主线程里导入：录音、转写两个线程同时第一次导入 numpy 会互相卡死（导入锁死锁）
    now = time.time()
    write(now, now, "（耳朵开了：开始听电脑声音，每 10 秒一段）")
    threading.Thread(target=commands, daemon=True).start()
    tr = threading.Thread(target=transcribe_loop, daemon=True)
    tr.start()
    try:
        record()
    except Exception:
        write(time.time(), time.time(), "（耳朵出错退出：" + traceback.format_exc().strip().splitlines()[-1] + "）")
    _quit.set()
    tr.join(timeout=30)
    now = time.time()
    write(now, now, "（耳朵关了）")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
