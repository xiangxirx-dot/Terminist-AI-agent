"""
眼睛：接管模式下在本地不停截屏 + 本地看图模型（Ollama 的 Qwen-VL）识别，写成「眼睛日志」。

- 每张截图先和「上一张识别过的图」比：缩成 64x36 灰度图算平均差异，差异过小就记一个「-」（省略），
  差异够大才交给本地模型看，记下「看到了什么」。时间点是截图那一刻。
- 截图和识别都在本机：图片不出这台电脑，也不落盘（只有文字日志落盘）。
- 日志：~/.terminist/eye/eye-YYYYMMDD.log（一行一条：时间 | 内容），内存里另留最近 10 分钟给 Agent 取。
- Agent 接管模式下每做一件事（每个工具结果、每轮开头）带上前 5 秒的眼睛日志；skip(毫秒) 期间不发请求，眼睛照常看。

对外：set_takeover(on, paused) 开关；recent_text(seconds) 取最近几秒的日志文字；attach(agent) 接到 Agent 上。
"""

import io
import threading
import time
from collections import deque
from pathlib import Path

LOG_DIR = Path.home() / ".terminist" / "eye"
INTERVAL = 0.7                 # 两次截图至少隔多少秒（识别慢的时候自然更久）
DIFF_THRESHOLD = 0.012         # 平均像素差异（0~1）低于它算「差异过小」，记「-」
THUMB = (64, 36)               # 比差异用的缩略图
SHOT_WIDTH = 896               # 交给看图模型的图宽（小一点识别快）
KEEP_SECONDS = 600             # 内存里留多久
DESCRIBE_PROMPT = ("用一两句中文简要说屏幕上现在是什么：前台是哪个软件 / 窗口、主要内容、"
                   "有没有弹窗 / 报错 / 加载中 / 进度。只说看到的，不超过 80 字。")
DESCRIBE_SYSTEM = "你是屏幕观察员：看电脑屏幕截图，只说看到的，简短准确。"

_lock = threading.Lock()
_entries: deque = deque()      # (时间戳, 文字)；文字为 "-" 表示和上一张差不多
_state = {"on": False, "paused": False, "thread": None, "stop": None, "error": "", "shots": 0, "seen": 0}


# ---------------- 截图 / 比较 / 识别（可以替换，测试时换成假的）----------------
def grab():
    """截全屏，返回 PIL 图片。"""
    from PIL import ImageGrab
    return ImageGrab.grab(all_screens=False)


def thumb(img):
    """缩成灰度小图，用来比差异。"""
    return img.convert("L").resize(THUMB)


def difference(a, b) -> float:
    """两张缩略图的平均像素差异（0 = 一样，1 = 全反）。"""
    if a is None or b is None:
        return 1.0
    pa, pb = a.tobytes(), b.tobytes()
    if len(pa) != len(pb) or not pa:
        return 1.0
    return sum(abs(x - y) for x, y in zip(pa, pb)) / (255.0 * len(pa))


def describe(img) -> str:
    """交给本地看图模型说一句看到了什么。"""
    from . import vision
    w, h = img.size
    if w > SHOT_WIDTH:
        img = img.resize((SHOT_WIDTH, max(1, round(h * SHOT_WIDTH / w))))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=70)
    return " ".join(vision.describe(buf.getvalue(), DESCRIBE_PROMPT, system=DESCRIBE_SYSTEM).split())


# ---------------- 日志 ----------------
def _stamp(t: float) -> str:
    return time.strftime("%H:%M:%S", time.localtime(t)) + f".{int(t * 1000) % 1000:03d}"


def _write(t: float, text: str):
    with _lock:
        _entries.append((t, text))
        while _entries and _entries[0][0] < t - KEEP_SECONDS:
            _entries.popleft()
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        day = time.strftime("%Y%m%d", time.localtime(t))
        with open(LOG_DIR / f"eye-{day}.log", "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d', time.localtime(t))} {_stamp(t)} | {text}\n")
    except OSError:
        pass


def log_path(t: float | None = None) -> Path:
    """今天（或 t 那天）的眼睛日志文件。"""
    return LOG_DIR / f"eye-{time.strftime('%Y%m%d', time.localtime(t or time.time()))}.log"


def recent(seconds: float = 5.0, now: float | None = None) -> list[tuple[float, str]]:
    """最近 seconds 秒的日志 [(时间, 文字)]。"""
    now = time.time() if now is None else now
    with _lock:
        return [(t, s) for t, s in _entries if now - seconds <= t <= now]


def _is_seen(s: str) -> bool:
    """这条是不是真正「看到了什么」（不是「-」，也不是「【前台窗口】」「（眼睛开了）」这种附注）。"""
    return s != "-" and not s.startswith(("【", "（"))


def foreground_now() -> str:
    """现在前台（最上层、拿着键盘）的窗口，一句话。"""
    from . import winfo
    return winfo.describe()


def last_seen(before: float) -> tuple[float, str] | None:
    """before 之前最后一条真正「看到了什么」的记录（不是「-」）。"""
    with _lock:
        for t, s in reversed(_entries):
            if t < before and _is_seen(s):
                return t, s
    return None


def recent_text(seconds: float = 5.0, now: float | None = None) -> str:
    """给 Agent 看的：最近 seconds 秒的眼睛日志。这段时间里全是「-」的话，补上之前最后看到的那条，免得它两眼一抹黑。"""
    now = time.time() if now is None else now
    rows = recent(seconds, now)
    lines = [f"{_stamp(t)} {s}" for t, s in rows]
    if not any(_is_seen(s) for _, s in rows):
        prev = last_seen(now - seconds)
        if prev:
            lines.insert(0, f"（{seconds:g} 秒前最后看到）{_stamp(prev[0])} {prev[1]}")
    if not lines:
        if not _state["on"]:
            return "（眼睛没开：不在接管模式）"
        if _state["paused"]:
            return "（接管已暂停，眼睛暂停中）"
        return "（眼睛刚开，还没看到东西）" + (f"；眼睛出错：{_state['error']}" if _state["error"] else "")
    head = f"（「-」= 和前一张差不多，省略；时间是截图那一刻）"
    if _state["error"]:
        head += f"（眼睛最近出错：{_state['error']}）"
    try:
        head = f"当前前台窗口：{foreground_now()}\n" + head
    except Exception:
        pass
    return head + "\n" + "\n".join(lines)


def changes_between(t0: float, t1: float) -> int:
    """t0~t1 之间画面变了几次（「看到了什么」的条数）。"""
    with _lock:
        return sum(1 for t, s in _entries if t0 <= t <= t1 and _is_seen(s))


# ---------------- 循环 ----------------
def _loop(stop: threading.Event):
    base = None                                     # 上一张识别过的图的缩略图
    last_fg = None                                  # 上一次的前台窗口：换了就记一条【前台窗口】
    while not stop.is_set():
        if _state["paused"]:
            stop.wait(0.3)
            continue
        t0 = time.time()
        try:
            from . import winfo
            fg = winfo.key()
            if fg != last_fg:
                last_fg = fg
                _write(time.time(), "【前台窗口】" + foreground_now())
        except Exception:
            pass
        try:
            img = grab()
            t = time.time()
            th = thumb(img)
            _state["shots"] += 1
            if base is not None and difference(base, th) < DIFF_THRESHOLD:
                _write(t, "-")
            else:
                try:
                    text = describe(img) or "(没看清)"
                    _state["error"] = ""
                except Exception as e:              # 看图模型出问题：记下画面变了，原因留给 Agent
                    text = "（画面变了，但本地看图模型没识别出来）"
                    _state["error"] = f"{type(e).__name__}: {e}"[:160]
                base = th
                _state["seen"] += 1
                _write(t, text)
        except Exception as e:                      # 截不了图（锁屏、远程桌面断开……）：歇一下再试
            _state["error"] = f"截图失败：{type(e).__name__}: {e}"[:160]
            stop.wait(2.0)
            continue
        stop.wait(max(0.0, INTERVAL - (time.time() - t0)))


def set_takeover(on: bool, paused: bool = False) -> None:
    """接管开 / 关 / 暂停：开了就起截图识别线程，关了就停。耳朵（录电脑声音转文字的子进程）跟着一起开关。"""
    try:
        from . import ear
        ear.set_takeover(bool(on), bool(paused))
    except Exception:
        pass
    _state["paused"] = bool(paused)
    if on and not _state["on"]:
        _state.update(on=True, error="")
        stop = threading.Event()
        th = threading.Thread(target=_loop, args=(stop,), daemon=True, name="terminist-eye")
        _state.update(stop=stop, thread=th)
        _write(time.time(), "（眼睛开了：进入接管模式）")
        th.start()
    elif not on and _state["on"]:
        _state["on"] = False
        if _state["stop"] is not None:
            _state["stop"].set()
        _write(time.time(), "（眼睛关了：退出接管模式）")


def status() -> dict:
    return {"on": _state["on"], "paused": _state["paused"], "shots": _state["shots"], "seen": _state["seen"],
            "error": _state["error"], "log": str(log_path())}


def senses_text(seconds: float = 5.0) -> str:
    """眼睛（前 seconds 秒）+ 耳朵（最近 10 秒：耳朵 10 秒一段）。"""
    text = recent_text(seconds)
    try:
        from . import ear
        text += "\n\n[耳朵日志：最近 10 秒（电脑放出来的声音转的文字）]\n" + ear.recent_text(10)
    except Exception as e:
        text += f"\n\n[耳朵日志取不到：{type(e).__name__}]"
    return text


def attach(agent) -> None:
    """接到 Agent 上：接管模式下每个工具结果 / 每轮开头带上前 5 秒的眼睛日志和最近的耳朵日志。"""
    agent.eye_source = senses_text
    agent.eye_changes = changes_between
