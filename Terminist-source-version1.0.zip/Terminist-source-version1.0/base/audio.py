"""
听音频 / 视频：本地 faster-whisper 转文字（再交给 DeepSeek 思考）。
网页上的视频（B 站、YouTube 等）用 yt-dlp 只下载音轨；本地的音频 / 视频文件直接转。
有能用的 NVIDIA 显卡就用 GPU，否则用 CPU。
"""

import tempfile
import threading
from pathlib import Path

from .config import MAX_MEDIA_MB, WHISPER_DIR, WHISPER_MODEL

_model = None
_device = ""
_lock = threading.Lock()


class AudioError(Exception):
    pass


def _load():
    global _model, _device
    if _model is not None:
        return _model
    try:
        from faster_whisper import WhisperModel
    except ImportError as e:
        raise AudioError("没有安装 faster-whisper：pip install faster-whisper") from e
    WHISPER_DIR.mkdir(parents=True, exist_ok=True)
    last = None
    for device, compute in (("cuda", "float16"), ("cpu", "int8")):
        try:
            _model = WhisperModel(WHISPER_MODEL, device=device, compute_type=compute, download_root=str(WHISPER_DIR))
            _device = device
            return _model
        except Exception as e:          # 没有 CUDA / cuDNN 时退回 CPU
            last = e
    raise AudioError(f"Whisper 加载失败：{last}")


def device() -> str:
    return _device or "未加载"


def _fmt(t: float) -> str:
    m, s = divmod(int(t), 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def transcribe(path: str, language: str | None = None, limit: int = 20000) -> str:
    """音频 / 视频文件 → 带时间戳的文字。"""
    p = Path(path)
    if not p.is_file():
        raise AudioError(f"文件不存在：{path}")
    with _lock:                          # 同一时间只转一个，避免显存 / 内存爆掉
        model = _load()
        segments, info = model.transcribe(str(p), language=language, vad_filter=True, beam_size=5)
        lines, size = [], 0
        for seg in segments:
            line = f"[{_fmt(seg.start)}] {seg.text.strip()}"
            lines.append(line)
            size += len(line)
            if size > limit:
                lines.append("...(太长，后面截断了)")
                break
    head = f"[语音转文字：{p.name}，时长 {_fmt(info.duration)}，语言 {info.language}，设备 {_device}]"
    return head + "\n" + ("\n".join(lines) or "(没有识别到语音)")


def fetch_audio(url: str, folder: Path) -> Path:
    """用 yt-dlp 下载网页视频的音轨（不需要 ffmpeg）。"""
    try:
        import yt_dlp
    except ImportError as e:
        raise AudioError("没有安装 yt-dlp：pip install yt-dlp") from e
    opts = {"format": "bestaudio/best", "outtmpl": str(folder / "%(id)s.%(ext)s"), "quiet": True,
            "no_warnings": True, "noprogress": True, "noplaylist": True,
            "max_filesize": MAX_MEDIA_MB * 1024 * 1024}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = Path(ydl.prepare_filename(info))
    if not path.is_file():
        found = list(folder.glob("*"))
        if not found:
            raise AudioError("没有下载到音频（可能超过大小上限，或者需要登录）")
        path = found[0]
    return path


def transcribe_url_or_file(source: str, language: str | None = None) -> str:
    """网址就先下载音轨，本地路径就直接转。"""
    if source.startswith(("http://", "https://")):
        with tempfile.TemporaryDirectory(prefix="terminist_audio_") as d:       # 临时音频，用完自动清理
            return transcribe(str(fetch_audio(source, Path(d))), language)
    return transcribe(source, language)
