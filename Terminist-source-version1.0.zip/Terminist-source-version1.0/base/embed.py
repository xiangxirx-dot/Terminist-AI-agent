"""
向量：把文字变成语义向量（本地 Ollama 的向量模型，默认 bge-m3），知识库按余弦相似度找「意思相近」的内容。

本地跑、不花钱；模型没装 / Ollama 没开时 available() 是 False，知识库自动退回纯字面匹配，不报错。
"""

import json
import time
import urllib.error
import urllib.request

from .config import EMBED_MODEL, EMBED_TIMEOUT, OLLAMA_URL

_state = {"checked": 0.0, "ok": False, "why": "", "dim": 0}
CHECK_EVERY = 60                 # 不可用时隔多久再试（装好模型以后不用重启）


class EmbedError(Exception):
    pass


def model() -> str:
    return EMBED_MODEL


def _post(path: str, body: dict, timeout: float):
    req = urllib.request.Request(OLLAMA_URL + path, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def available(force: bool = False) -> bool:
    """向量模型能不能用（Ollama 开着、模型下载好了）。结果缓存：可用就一直用；不可用每分钟重试一次。"""
    now = time.monotonic()
    if not force and (_state["ok"] or now - _state["checked"] < CHECK_EVERY) and _state["checked"]:
        return _state["ok"]
    _state["checked"] = now
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=2) as r:
            names = [m.get("name", "") for m in json.loads(r.read().decode("utf-8")).get("models", [])]
        ok = any(n == EMBED_MODEL or n.startswith(EMBED_MODEL + ":") for n in names)
        _state.update(ok=ok, why="" if ok else f"本地还没有向量模型 {EMBED_MODEL}（ollama pull {EMBED_MODEL}）")
    except (urllib.error.URLError, OSError, ValueError) as e:
        _state.update(ok=False, why=f"连不上本地 Ollama：{e}")
    return _state["ok"]


def why_not() -> str:
    return _state["why"]


def embed(texts: list[str], timeout: float = EMBED_TIMEOUT) -> list[list[float]]:
    """一批文字 → 一批向量（顺序一致）。失败抛 EmbedError。"""
    texts = [str(t)[:4000] or " " for t in texts]
    if not texts:
        return []
    try:
        data = _post("/api/embed", {"model": EMBED_MODEL, "input": texts, "keep_alive": "30m"}, timeout)
    except urllib.error.HTTPError as e:
        raise EmbedError(f"向量模型出错：{e.read().decode('utf-8', 'replace')[:200]}") from e
    except (urllib.error.URLError, OSError) as e:
        raise EmbedError(f"连不上本地 Ollama：{e}") from e
    vecs = data.get("embeddings") or []
    if len(vecs) != len(texts):
        raise EmbedError("向量模型返回的条数不对")
    _state["dim"] = len(vecs[0]) if vecs else _state["dim"]
    return vecs
