# Terminist 更新日志

> 记录每个版本「为什么改、改了什么、怎么验的」。
> 新版本由 `tools/changelog.py` 自动追加骨架，人工补全「改了什么」。
> 详细实现见 `STRUCTURE.md`；版本存档见 `versions/<版本号>/`。

---

## 员工栏拖出成独立窗口（投影技术）

**为什么**：目标队列里「所有区块都能被拖拽出来变成独立窗口」那条，先做员工栏单块跑通。

**改了什么**
- `surface/gui.py` 新增 `PanelWindow`（包 `pygame.Window`）：区块投影窗口只做渲染，
  `blit()` 后必须 `flip()`——`Window.get_surface()` 是 SDL 窗口表面，主循环的 `pygame.display.flip()`
  刷不到它，不调 `flip()` 窗口里就是一片空白。
- `open_staff_window()` / `close_staff_window()` / `draw_staff_window()`：把员工栏投影到第二个无边框窗口，
  自绘标题条（标题 + 收起按钮，标题条能拖着走），内容每帧画完 `pw.blit()` → `pw.flip()`。
- 投影那次 `draw_staff()` 画到临时表面时先存旧的 `staff_rects` / `staff_menu_rects` / `staff_last_rect` /
  `staff_head_rect` / `staff_panel_rect` / `staff_content_h`，画完还原：主窗口占位区不会再被写回可点矩形，
  在虚影上点不会误触发员工行操作。窗口内的命中矩形单独存 `staff_win_rects`（窗口内坐标）。
- 拖出：按住员工栏标题条拖动出虚影（`draw_staff_ghost` / `_dash_rect`），松手在别处就 `open_staff_window()`；
  左栏原位改画占位虚影 `draw_staff_placeholder()`（不接点击，点它就归位）。
- 归位：`_staff_check_dock()` 用 win32 `GetWindowRect` 比主窗口矩形——中心点落在主窗口里或重叠过半就自动收起，
  窗口里按 Esc / 点 ✕ / 点左栏虚影也都归位；`handle_staff_window()` 里按窗口对象或窗口 id 认事件，
  事件不带 `window` 字段时退回前台窗口兜底。滚动、点员工行仍走主窗口那一套状态（`_staff_win_wheel` / `_staff_win_row_click`）。
- 主循环在 `draw()` 之后画独立员工栏那一帧，并每 200ms 兜底查一次是否该归位。

**验**：`python -m py_compile surface/gui.py` 通过；A库 校对。

---


## 小屏幕对齐修复：独立窗口已经开着时每次上网也对齐一次

**改了什么**
- `surface/gui.py` 的 `_screen_auto()`：原来只有窗口没开时才会走 `open_screen_window()`（它内部才对齐），已经开着就直接返回，等于每次上网的自动对齐没生效。现在拆成两支：`screen_win_open` 为真时直接调 `_screen_fit()` 再 return（偏差 ≤2% 不动，用户拖过的尺寸不会被弹回），没开时保持原逻辑（模式 `on` 才自动开）。

**验**：`python -m py_compile surface/gui.py` 通过；A库 校对。

---

## 密钥注册：网页要账号密码时弹窗向主人要

**改了什么**
- 新增 `lib_a/extensions/credentials_store.py`：本地密钥库（`桌面\散兵-密钥\credentials.json`），保存/读取/打码显示，同 site 覆盖，全部容错不抛异常。密码不明文存储：分片盐 -> pbkdf2 派生每站点密钥 -> 流加密 + 乱序，文件里只有 v1: 开头的密文，文件里不出现明文。
- 新增 `lib_a/extensions/web_credentials.py`：A库 工具 `web_need_credentials(site, note)`，只在网页确实要求注册/登录时调用，向主人要账号密码；拒绝就请主人自己登录，明文密码不进对话。
- `base` 层不在 B库 可改范围内，所以密钥存储放在 `lib_a/extensions/`，与扩展工具同目录。
- `lib_a/core.py` 的 `Workspace.ask_credentials(site, note)`：命令行下用 `input()` 问账号密码，直接回车或 `n` = 拒绝。
- `surface/gui.py` 的 `GuiWorkspace.ask_credentials` 重写：把请求塞进 `events` 队列（`credentials`），阻塞等弹窗，超时 0.1 秒轮询，工作流被停掉按拒绝处理。
- `surface/gui.py` 新增 `CredentialsRequest` 与居中弹窗：显示网站名和说明，账号 / 密码两行（密码用 ● 显示），「记住密码」勾选框，底部「提供」「拒绝」；点行切换焦点，Tab 切换，Enter = 提供，Esc = 拒绝；多个请求同时来会排队。名词走 `lang()`（`cred_title` / `cred_user` / `cred_pass` / `cred_remember` / `cred_give` / `cred_deny`），中英各一份。
- 用户拒绝时 Agent 拿到 `{"ok": False}`，不会去猜或编账号密码。

**验**（A库 校对后实测，`桌面\散兵-工具自测\check_credentials.py`，57/57 全过）：
- 加密层：密文 `v1:` 前缀、文件里搜不到明文、解回来一致、同密码不同站点密文不同、乱序可逆、坏密文返回空不抛异常。
- 盐分片：4 片分别在 `桌面\散兵-密钥\.keep.dat`、`%APPDATA%\Terminist\.cache.state`、`%LOCALAPPDATA%\Temp\.tstate`、密钥同目录 `.b`；缺失自动生成、第二次取盐不变、盐不写进密钥文件、函数名里不含 key/password/encrypt/secret。
- 端到端：弹窗「提供」→ 存密文 → 工具返回只带账号、不带明文密码；「拒绝」→ 返回不许猜/不许自己注册；不记住密码时只存账号；工作流被停掉时按拒绝处理。

---

## v049 · 2026-10-30 13:38 — 界面整体切换中英文

**为什么**：界面全是写死的中文，没法给英文用户用。

**改了什么**（`surface/gui.py`）
- `UI_SETTINGS` 注册 `language`（值 `zh`/`en`，默认 `zh`，存 `settings["language"]`，带 aliases）。
- 顶部加词表 `LANG_ZH` / `LANG_EN`，以及模块级 `lang(key, default=None)` 取词函数。
- 界面所有写死的中文改为走 `lang()`：顶栏、设置弹窗（API key 的更换/恢复内置、完成按钮）、确认弹窗、左右栏（含「暂无员工」）、右栏提示（等待模型响应 / 还没有日志 / 收起 / 点击看原图 / 等待网页）、输入框 placeholder、`/set` 命令返回文字、STYLE 各卡片标签。
- 模块加载时 `_LANG = _read_language()`，按存档决定初始语言。

**验**：`set_ui(language="en")` 立即生效，不用重启。

---

## v048 · 2026-10-30 11:30 — 绘制性能：文字缓存 + 阴影缓存

**为什么**：拖窗口、滚动、生成文字时明显卡顿，每帧都在 `font.render`。

**改了什么**（`surface/gui.py`）
- 新增 `utext(font, text, color)`：同字号同文字同颜色的渲染结果存进模块级 `_TEXT_CACHE`，命中直接 blit；全部 `self.font.render / small.render / code.render` 改成 `utext`。
- `soft_shadow` 结果按尺寸缓存，不再每帧重画渐层。

**验**：长历史滚动、拖窗口不掉帧。

---

## v047 · 2026-10-30 11:23 — 卡片高度缓存，长历史不再卡

**为什么**：`draw_cards()` 绘制做了视口裁剪，但布局阶段仍对每条消息调 `message_body()` 完整折行，历史越长每帧开销越大。

**改了什么**（`surface/gui.py`）
- `draw_cards()` 改两阶段：
  - 阶段一顺序累加每条消息高度进 `self._card_h_cache`（key = 消息 id + 种类 + 折行宽度 + 文字长度 + 折叠状态 + 字体 id），缓存缺失才真折行；同时存消息引用防 id 复用。
  - 阶段二只对可见区上下各一屏内的卡片真折行并绘制，窗口外跳过。
- `clear_card_h_cache()` 在换工作区 / 清空对话 / 改缩放时清空。
- `total` / `max_scroll` / `stick` / 滚动条 / `msg_rects` / 图片卡片高度 / 右栏 `draw_flow` 行为不变；缓存与实画不一致时以实画为准并回写。

**验**：消息数很多时打字、滚动流畅。

---

## v046 · 2026-10-30 11:14 — 修 bg_kill 接不到任务表 + grep_files 路径

**为什么**：v045 实测翻车。起 `run_bg` 后再 `bg_kill` 返回「没有这个任务」。

**根因**：`core.load_extensions()` 用 `spec_from_file_location` 加载扩展但**没注册进 `sys.modules`**，fallback 重新 exec 拿到的是另一份空的 `_PROCS`。

**改了什么**
- `lib_a/extensions/bg_kill.py`：`_load_procs()` 改三级取真模块 —— `importlib.import_module("lib_a.extensions.run_bg")` → `sys.modules` 里找带 `_PROCS` 的 → `gc.get_objects()` 兜底；删掉 `spec_from_file_location` 写法。
- `lib_a/extensions/grep_files.py`：`ws` 不为 None 时 base 用 `Path(ws.root)/path`（修「lib_a 不是目录」）。

**验**：`python -m http.server 8899` → 起 job1 → `bg_kill` 回「已停止 job1」→ 再 kill 回「job1 早就结束了（退出码 1）」。grep 能定位 `core.py:351: def load_extensions`，`limit` 截断提示正常。

---

## v045 · 2026-10-30 11:04 — 新增 bg_kill / grep_files 两个工具

**为什么**：任务能起后台任务却没法停；找代码只能瞎猜位置。

**改了什么**
- `lib_a/extensions/bg_kill.py`：`bg_kill(ws, job)` 停掉 `run_bg` 起的后台任务，返回中文结果。
- `lib_a/extensions/grep_files.py`：正则搜文件内容，返回 `文件:行号: 内容`，支持 `file_glob` / `path` / `limit`。
- `STRUCTURE.md` 登记。

**已知问题**：这版有 bug，v046 返工修好。

---

## v044 · 2026-10-30 10:59 — 图片拖拽 + 栏宽拖拽

**为什么**：界面太死，图要靠工具插、栏宽写死。

**改了什么**（`surface/gui.py`）
- `DROPFILE` → `on_drop_file(path)`：支持 png/jpg/jpeg/bmp/gif/webp，符合就 `add_image({path,title})`；非图片或文件不存在只提示 error，不崩。
- 三条可拖分隔条（左栏右边界、右栏左边界、输入框上边缘）：6px 热区、`SIZEWE`/`SIZENS` 光标，范围左 160~500、右 160~700、输入框 70~窗口高 60%。
- `self.sizes = {left, right, input_h}`，`layout()` 全改读它，存 `settings["sizes"]`；登记 `panel_left_w` / `panel_right_w` / `input_height` 三个界面设置。

**验**：拖图入窗插入；拖分隔条实时改宽，重启后保持。

---

## v043 · 2026-10-30 10:51 — 界面美化（纯视觉）

**为什么**：「UI 太简陋」。

**改了什么**（`surface/gui.py`，不动交互逻辑）
- 新增绘制助手：`lerp(a,b,t)` / `mix(c1,c2,t)` 颜色插值、`rounded(surf,rect,color,radius,border)` 圆角矩形 + 描边、`soft_shadow(...)` 多层渐层柔和阴影。
- 顶栏加 1px 分隔线；侧栏标题去灰条改竖条 + 细线。
- 统一圆角：卡片 S(12)、弹窗 S(16)、下拉框 S(10)、按钮 S(8)，卡片/弹窗/下拉框带淡阴影。
- 按钮悬停 `mix(base, C["hdr"], 0.15)`；输入框聚焦加 alpha 60 外发光。
- 全部取色走主题 `C`、尺寸走 `S()`，四套主题自动适配。

**验**：四套主题下视觉一致。

---

## v042 · 2026-10-30 10:46 — more_context：主动申请更早的上下文

**为什么**：界面能看到很久历史，但模型只拿最近 `FRONT_CONTEXT=8000` token，再往前的直接丢弃（不是摘要），导致「刚才说的」找不到。

**改了什么**（`lib_a/core.py`）
- `Agent.extra_context_turns = 0`；新用户输入时复位。
- `request_more_context()`；`_request_messages()` 窗口从 8000 扩到 `*4` 硬上限，按额外 N 轮带入更早历史。
- 注册 `more_context(turns / chars)` 工具 + 工具循环分支。
- 系统提示词加「指代找不到就调 more_context」。

**验**：7 条 → 调 `more_context(turns=5)` → 27 条 → 新输入复位 7 条。

---

## v041 · 2026-10-30 10:24 — 对话与工作流彻底独立

**为什么**：干活时主人发的每条消息都被塞进 `Agent.inbox`，下一步拼进工作流上下文，对话会干扰正在跑的活。

**改了什么**
- 干活（`busy`）时输入框和发送键不锁。
- 普通消息（非 `#` 前缀）交独立闲聊 Agent（`chat_agent`，`memory_key="chat"`，事件带 `chat_` 前缀），输出单独成 `chat` 气泡。
- 不调 `push_user_message`，`busy` / `turn_flow` / 进度条完全不受影响。
- 斜杠命令忙时只提示等这一轮结束。

**验**：干活中聊天，工作流照跑不打断。

---

## v040 · 2026-10-30 10:17 — 双进程：干活时另开一条对话

**为什么**：A库 干活时没法同时聊天。

**改了什么**
- busy 时 `#` 开头的输入走独立第二个 Agent，不打断干活那一轮、不发插话、不进 inbox。
- 非 `#` 输入仍是原来的插话行为，完全不变。

**备注**：被 v041 升级取代（v041 去掉了 `#` 前缀限制，所有普通消息都走独立对话）。

---

## v039 · 2026-10-30 10:13 — 工作流进度条

**为什么**：干活时看不出这一轮跑到哪了。

**改了什么**
- A库 新增 `worker_progress` 工具：`plan(steps,label)` / `done(label)` / `clear`，emit `progress` 事件（payload JSON `{total,done,label}`）。
- Surface `drain_events` 更新 `self.progress`，`draw_progress()` 在输入框正上方画进度条：已完成格填满打勾、当前格 `input_focus` 高亮、右侧「第 k/total · label」。
- `progress_h()` 返回占用高度，`total=0` 返回 0，聊天区布局不变。

**验**：跑一轮 5 步任务，进度条逐格推进，收尾消失。

---

## 待办 / 已知遗留

- [ ] **版本存档自动裁剪**：要求「A库 校验通过后删最老一个 version，保持总数不变」。需改 `lib_b/versions.py`（KEEP）和 `lib_b/builder.py` 的 `_deliver()`，但 `lib_b/` 整个在 `PROTECTED` 名单里，B库 写入被拒，**尚未做成**。
- [ ] `versions/` 现有 13 个存档（v039~v049 等），超过 KEEP 上限时手动清理。
